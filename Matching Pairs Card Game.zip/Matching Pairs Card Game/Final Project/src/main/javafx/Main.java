package main.javafx;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.KeyCombination;

import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Objects;
import java.util.Properties;

public class Main extends Application {

    private double xOffset = 0;
    private double yOffset = 0;
    private Properties properties = new Properties();
    public static MediaPlayer mediaPlayer;

    @Override
    public void start(Stage stage) throws Exception{

        String musicFile = "src/main/resources/Sounds/bohemian-rhapsody.mp3";

        Media sound = new Media(new File(musicFile).toURI().toString());
        mediaPlayer = new MediaPlayer(sound);
        mediaPlayer.setVolume(0.1f);
        //if you want bg mediaPlayer.play();

        double width = 1920,height =1080;
        boolean fullScreen;

        File f = new File("config.properties");
        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            width = Double.parseDouble(properties.getProperty("width"));
            height = Double.parseDouble(properties.getProperty("height"));
            fullScreen = Boolean.parseBoolean(properties.getProperty("fullScreen"));
            stage.setFullScreen(fullScreen);
            stage.setFullScreenExitHint("");
            stage.setFullScreenExitKeyCombination(KeyCombination.NO_MATCH);
        }

        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("../resources/view/MainMenu.fxml")));
        Scene scene = new Scene(root,width,height);
        stage.initStyle(StageStyle.TRANSPARENT);
        stage.setTitle("Memory Game");
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
        scene.setFill(Color.TRANSPARENT);

        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int width1 = Integer.parseInt(properties.getProperty("width"));
            if(width1 == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }

    }

    public static void main(String[] args) {
        launch(args);
    }
}
