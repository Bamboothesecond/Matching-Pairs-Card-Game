package main.javafx.controllers.highscore;

import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.effect.BlurType;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.effect.InnerShadow;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;
import main.javafx.util.SvgLoader;

import java.io.*;
import java.util.Locale;
import java.util.Properties;
import java.util.ResourceBundle;

public class HighScore {

    @FXML
    private Button backButton;
    @FXML
    private Label sm1,sm2,sm3,sm4,m1,m2,m3,m4,l1,l2,l3;
    @FXML
    private BorderPane Panel1,Panel2,gg1;
    @FXML
    private Pane Panelex,Panelex3;
    @FXML
    private GridPane Panelg1,Panelex2,Panelex4;

    private String s1,s2,s3,s4,mu1,mu2,mu3,mu4,bat;

    private Properties properties = new Properties();
    private Properties properties2 = new Properties();
    private MediaPlayer mediaPlayer;
    private double xOffset = 0;
    private double yOffset = 0;

    private InputStream input = null;
    private InputStream input2 = null;
    private OutputStream output = null;
    private OutputStream output2 = null;

    final SvgLoader loader = new SvgLoader();

    DropShadow effectBG_DropShadow,effectC_DropShadowADD,effectC_DropShadow,effectBG_DropShadowADD;

    InnerShadow effectBG_InnerShadowADD,effectBG_InnerShadow,effectC_InnerShadowADD,effectC_InnerShadow;
    InputStream svgFileBackButton,svgFileBackButton_Hover, svgFileOption,svgFileOption_Hover;
    String color,color2;

    public HighScore(){
        Media buttonSound = new Media(new File("src/main/resources/Sounds/buttonSound.wav").toURI().toString());
        mediaPlayer = new MediaPlayer(buttonSound);
    }

    @FXML
    private void initialize() throws IOException{

        File f2 =new File("score.properties");
        File f = new File("config.properties");

        if(f.exists()) {
            input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            int theme = Integer.parseInt(properties.getProperty("TMode"));
            int tColor = Integer.parseInt(properties.getProperty("TColor"));

            if(width == 999 ){

                backButton.setPrefSize(64,64);

                if (theme==1){

                    color = "#f3f5f7";
                    if (tColor==1){

                        gg1.setStyle("-fx-background-color: #007aff;");
                        Panelex2.setStyle("-fx-background-color: #007aff; -fx-background-radius: 36 0 0 0;");
                        Panelex3.setStyle("-fx-background-color: #007aff; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==2){

                        gg1.setStyle("-fx-background-color: #fff44f;");
                        Panelex2.setStyle("-fx-background-color: #fff44f; -fx-background-radius: 36 0 0 0;");
                        Panelex3.setStyle("-fx-background-color: #fff44f; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==3){

                        gg1.setStyle("-fx-background-color: #00c853;");
                        Panelex2.setStyle("-fx-background-color: #00c853; -fx-background-radius: 36 0 0 0;");
                        Panelex3.setStyle("-fx-background-color: #00c853; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==4){

                        gg1.setStyle("-fx-background-color: #d50000;");
                        Panelex2.setStyle("-fx-background-color: #d50000; -fx-background-radius: 36 0 0 0;");
                        Panelex3.setStyle("-fx-background-color: #d50000; -fx-background-radius: 0 0 36 0;");

                    }

                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));
                    Panelex.setStyle("-fx-background-color: #f3f5f7; -fx-background-radius: 36 0 0 0;");
                    Panelg1.setStyle("-fx-background-color: #f3f5f7; -fx-background-radius: 36 0 0 0;");
                    Panelex4.setStyle("-fx-background-color: #f3f5f7; -fx-background-radius: 36 36 0 36;");

                    //BUTTON
                    backButton.setStyle("-fx-background-color: #f3f5f7; -fx-background-radius: 50%;");
                }
                else if (theme==2){

                    color = "#181818";
                    if (tColor==1){

                        gg1.setStyle("-fx-background-color: #004fcb;");
                        Panelex2.setStyle("-fx-background-color: #004fcb; -fx-background-radius: 36 0 0 0;");
                        Panelex3.setStyle("-fx-background-color: #004fcb; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==2){

                        gg1.setStyle("-fx-background-color: #c7cc00;");
                        Panelex2.setStyle("-fx-background-color: #c7cc00; -fx-background-radius: 36 0 0 0;");
                        Panelex3.setStyle("-fx-background-color: #c7cc00; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==3){

                        gg1.setStyle("-fx-background-color: #006500;");
                        Panelex2.setStyle("-fx-background-color: #006500; -fx-background-radius: 36 0 0 0;");
                        Panelex3.setStyle("-fx-background-color: #006500; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==4){

                        gg1.setStyle("-fx-background-color: #9b0000;");
                        Panelex2.setStyle("-fx-background-color: #9b0000; -fx-background-radius: 36 0 0 0;");
                        Panelex3.setStyle("-fx-background-color: #9b0000; -fx-background-radius: 0 0 36 0;");

                    }
                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));
                    Panel1.setStyle("-fx-background-color: #181818; -fx-background-radius: 36 36 36 36;");
                    Panel2.setStyle("-fx-background-color: #181818; -fx-background-radius: 36 36 36 36;");

                    Panelex.setStyle("-fx-background-color: #181818; -fx-background-radius: 36 0 0 0;");
                    Panelg1.setStyle("-fx-background-color: #181818; -fx-background-radius: 36 0 0 0;");
                    Panelex4.setStyle("-fx-background-color: #181818; -fx-background-radius: 36 36 0 36;");

                    //BUTTON
                    backButton.setStyle("-fx-background-color: #121212; -fx-background-radius: 50%;");


                }

            }
            else if(width == 1600 ){

                backButton.setPrefSize(64,64);

                if (theme==1){

                    color = "#f3f5f7";
                    if (tColor==1){

                        gg1.setStyle("-fx-background-color: #007aff; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: #007aff; -fx-background-radius: 36 36 0 0;");
                        Panelex3.setStyle("-fx-background-color: #007aff; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==2){

                        gg1.setStyle("-fx-background-color: #fff44f; -fx-background-radius: 36 36 36 36");
                        Panelex2.setStyle("-fx-background-color: #fff44f; -fx-background-radius: 36 36 0 0;");
                        Panelex3.setStyle("-fx-background-color: #fff44f; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==3){

                        gg1.setStyle("-fx-background-color: #00c853; -fx-background-radius: 36 36 36 36 ");
                        Panelex2.setStyle("-fx-background-color: #00c853; -fx-background-radius: 36 36 0 0;");
                        Panelex3.setStyle("-fx-background-color: #00c853; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==4){

                        gg1.setStyle("-fx-background-color: #d50000; -fx-background-radius: 36 36 36 36");
                        Panelex2.setStyle("-fx-background-color: #d50000; -fx-background-radius: 36 36 0 0;");
                        Panelex3.setStyle("-fx-background-color: #d50000; -fx-background-radius: 0 0 36 0;");

                    }

                    Panelex.setStyle("-fx-background-color: #f3f5f7; -fx-background-radius: 36 34 0 0;");
                    Panelg1.setStyle("-fx-background-color: #f3f5f7; -fx-background-radius: 36 0 34 34");
                    Panelex4.setStyle("-fx-background-color: #f3f5f7; -fx-background-radius: 36 36 0 36;");
                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));
                    //BUTTON
                    backButton.setStyle("-fx-background-color: #f3f5f7; -fx-background-radius: 50%;");

                }
                else if (theme==2){

                    color = "#181818";
                    if (tColor==1){

                        gg1.setStyle("-fx-background-color: #004fcb; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: #004fcb; -fx-background-radius: 36 36 0 0;");
                        Panelex3.setStyle("-fx-background-color: #004fcb; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==2){

                        gg1.setStyle("-fx-background-color: #c7cc00; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: #c7cc00; -fx-background-radius: 36 36 0 0;");
                        Panelex3.setStyle("-fx-background-color: #c7cc00; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==3){

                        gg1.setStyle("-fx-background-color: #006500; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: #006500; -fx-background-radius: 36 36 0 0;");
                        Panelex3.setStyle("-fx-background-color: #006500; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==4){

                        gg1.setStyle("-fx-background-color: #9b0000; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: #9b0000; -fx-background-radius: 36 36 0 0;");
                        Panelex3.setStyle("-fx-background-color: #9b0000; -fx-background-radius: 0 0 36 0;");

                    }
                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));
                    Panelex.setStyle("-fx-background-color: #181818; -fx-background-radius: 34 34 0 0;");
                    Panelg1.setStyle("-fx-background-color: #181818; -fx-background-radius: 36 0 34 34;");
                    Panelex4.setStyle("-fx-background-color: #181818; -fx-background-radius: 36 36 0 36;");

                    Panel1.setStyle("-fx-background-color: #181818; -fx-background-radius: 36 36 36 36;");
                    Panel2.setStyle("-fx-background-color: #181818; -fx-background-radius: 36 36 36 36;");

                    //BUTTON
                    backButton.setStyle("-fx-background-color: #121212; -fx-background-radius: 50%;");

                }

            }
            else if(width == 1280){

                if (theme==1){

                    color = "#f3f5f7";
                    if (tColor==1){

                        gg1.setStyle("-fx-background-color: #007aff; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: #007aff; -fx-background-radius: 36 36 0 0;");
                        Panelex3.setStyle("-fx-background-color: #007aff; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==2){

                        gg1.setStyle("-fx-background-color: #fff44f; -fx-background-radius: 36 36 36 36");
                        Panelex2.setStyle("-fx-background-color: #fff44f; -fx-background-radius: 36 36 0 0;");
                        Panelex3.setStyle("-fx-background-color: #fff44f; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==3){

                        gg1.setStyle("-fx-background-color: #00c853; -fx-background-radius: 36 36 36 36 ");
                        Panelex2.setStyle("-fx-background-color: #00c853; -fx-background-radius: 36 36 0 0;");
                        Panelex3.setStyle("-fx-background-color: #00c853; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==4){

                        gg1.setStyle("-fx-background-color: #d50000; -fx-background-radius: 36 36 36 36");
                        Panelex2.setStyle("-fx-background-color: #d50000; -fx-background-radius: 36 36 0 0;");
                        Panelex3.setStyle("-fx-background-color: #d50000; -fx-background-radius: 0 0 36 0;");

                    }

                    Panelex.setStyle("-fx-background-color: #f3f5f7; -fx-background-radius: 36 34 0 0;");
                    Panelg1.setStyle("-fx-background-color: #f3f5f7; -fx-background-radius: 36 0 34 34");
                    Panelex4.setStyle("-fx-background-color: #f3f5f7; -fx-background-radius: 36 36 0 36;");
                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));
                    //BUTTON
                    backButton.setStyle("-fx-background-color: #f3f5f7; -fx-background-radius: 50%;");

                }
                else if (theme==2){

                    color = "#181818";
                    if (tColor==1){

                        gg1.setStyle("-fx-background-color: #004fcb; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: #004fcb; -fx-background-radius: 36 36 0 0;");
                        Panelex3.setStyle("-fx-background-color: #004fcb; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==2){

                        gg1.setStyle("-fx-background-color: #c7cc00; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: #c7cc00; -fx-background-radius: 36 36 0 0;");
                        Panelex3.setStyle("-fx-background-color: #c7cc00; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==3){

                        gg1.setStyle("-fx-background-color: #006500; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: #006500; -fx-background-radius: 36 36 0 0;");
                        Panelex3.setStyle("-fx-background-color: #006500; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==4){

                        gg1.setStyle("-fx-background-color: #9b0000; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: #9b0000; -fx-background-radius: 36 36 0 0;");
                        Panelex3.setStyle("-fx-background-color: #9b0000; -fx-background-radius: 0 0 36 0;");

                    }
                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));
                    Panelex.setStyle("-fx-background-color: #181818; -fx-background-radius: 34 34 0 0;");
                    Panelg1.setStyle("-fx-background-color: #181818; -fx-background-radius: 36 0 34 34;");
                    Panelex4.setStyle("-fx-background-color: #181818; -fx-background-radius: 36 36 0 36;");

                    Panel1.setStyle("-fx-background-color: #181818; -fx-background-radius: 36 36 36 36;");
                    Panel2.setStyle("-fx-background-color: #181818; -fx-background-radius: 36 36 36 36;");

                    //BUTTON
                    backButton.setStyle("-fx-background-color: #121212; -fx-background-radius: 50%;");

                }

            }
        }
        if(f2.exists()){
            input2 = new FileInputStream("score.properties");
            properties2.load(input2);
            sm1.setText("" + " - " + properties2.getProperty("SingleModeHighScore1"));
            sm2.setText(""  + " - " + properties2.getProperty("SingleModeHighScore2"));
            sm3.setText(""  + " - " + properties2.getProperty("SingleModeHighScore3"));
            sm4.setText(""  + " - " + properties2.getProperty("SingleModeHighScore4"));

            m1.setText("" +" - " +properties2.getProperty("MultiplayerWins1"));
            m2.setText("" +" - " +properties2.getProperty("MultiplayerWins2"));
            m3.setText("" +" - " +properties2.getProperty("MultiplayerWins3"));
            m4.setText("" +" - " +properties2.getProperty("MultiplayerWins4"));

        }
        themeHandler();
    }
    private void themeHandler() throws IOException {

        FadeTransition fadeIn = new FadeTransition();//exit_btn
        FadeTransition fadeIn2 = new FadeTransition();//l1
        FadeTransition fadeIn3 = new FadeTransition();//l2
        FadeTransition fadeIn4 = new FadeTransition();//l3
        FadeTransition fadeIn5 = new FadeTransition();//body
        FadeTransition fadeIn5_1 = new FadeTransition();//body
        FadeTransition fadeIn5_2 = new FadeTransition();//body
        FadeTransition fadeIn6 = new FadeTransition();//p1
        FadeTransition fadeIn7 = new FadeTransition();//p2
        FadeTransition fadeIn8 = new FadeTransition();//button
        FadeTransition fadeIn8_1 = new FadeTransition();//button
        FadeTransition fadeIn8_2 = new FadeTransition();//button
        FadeTransition fadeIn8_3 = new FadeTransition();//button
        FadeTransition fadeIn8_4 = new FadeTransition();//button
        FadeTransition fadeIn8_5 = new FadeTransition();//button
        FadeTransition fadeIn8_6 = new FadeTransition();//button
        FadeTransition fadeIn8_7 = new FadeTransition();//button
        FadeTransition fadeIn8_8 = new FadeTransition();//button
        FadeTransition fadeIn8_9 = new FadeTransition();//button
        FadeTransition fadeIn8_10 = new FadeTransition();//button

        FadeTransition fadeOut = new FadeTransition();//exit_btn
        FadeTransition fadeOut2 = new FadeTransition();//l1
        FadeTransition fadeOut3 = new FadeTransition();//l2
        FadeTransition fadeOut4 = new FadeTransition();//l3
        FadeTransition fadeOut5 = new FadeTransition();//body
        FadeTransition fadeOut5_1 = new FadeTransition();//body
        FadeTransition fadeOut5_2 = new FadeTransition();//body
        FadeTransition fadeOut6 = new FadeTransition();//p1
        FadeTransition fadeOut7 = new FadeTransition();//p2
        FadeTransition fadeOut8 = new FadeTransition();//button
        FadeTransition fadeOut8_1 = new FadeTransition();//button
        FadeTransition fadeOut8_2 = new FadeTransition();//button
        FadeTransition fadeOut8_3 = new FadeTransition();//button
        FadeTransition fadeOut8_4 = new FadeTransition();//button
        FadeTransition fadeOut8_5 = new FadeTransition();//button
        FadeTransition fadeOut8_6 = new FadeTransition();//button
        FadeTransition fadeOut8_7 = new FadeTransition();//button
        FadeTransition fadeOut8_8 = new FadeTransition();//button
        FadeTransition fadeOut8_9 = new FadeTransition();//button
        FadeTransition fadeOut8_10 = new FadeTransition();//button
        FadeTransition fadeOut8_11 = new FadeTransition();//button
        FadeTransition fadeOut8_12 = new FadeTransition();//button
        FadeTransition fadeOut8_13 = new FadeTransition();//button

        GaussianBlur blur = new GaussianBlur(5);

        fadeIn.setDuration(Duration.millis(100));
        fadeIn2.setDuration(Duration.millis(450));
        fadeIn3.setDuration(Duration.millis(450));
        fadeIn4.setDuration(Duration.millis(450));

        fadeIn5.setDuration(Duration.millis(600));
        fadeIn5_1.setDuration(Duration.millis(600));
        fadeIn5_2.setDuration(Duration.millis(600));

        fadeIn6.setDuration(Duration.millis(650));
        fadeIn7.setDuration(Duration.millis(650));

        fadeIn8.setDuration(Duration.millis(700));
        fadeIn8_1.setDuration(Duration.millis(800));
        fadeIn8_2.setDuration(Duration.millis(800));
        fadeIn8_3.setDuration(Duration.millis(1000));

        fadeIn8_4.setDuration(Duration.millis(650));
        fadeIn8_5.setDuration(Duration.millis(750));
        fadeIn8_6.setDuration(Duration.millis(1000));

        fadeIn8_7.setDuration(Duration.millis(650));
        fadeIn8_8.setDuration(Duration.millis(750));
        fadeIn8_9.setDuration(Duration.millis(1000));

        fadeIn8_10.setDuration(Duration.millis(1000));

        fadeOut.setDuration(Duration.millis(100));
        fadeOut2.setDuration(Duration.millis(100));
        fadeOut3.setDuration(Duration.millis(100));
        fadeOut4.setDuration(Duration.millis(100));

        fadeOut5.setDuration(Duration.millis(100));
        fadeOut5_1.setDuration(Duration.millis(100));
        fadeOut5_2.setDuration(Duration.millis(100));

        fadeOut6.setDuration(Duration.millis(100));
        fadeOut7.setDuration(Duration.millis(100));

        fadeOut8.setDuration(Duration.millis(100));
        fadeOut8_1.setDuration(Duration.millis(100));
        fadeOut8_2.setDuration(Duration.millis(100));
        fadeOut8_3.setDuration(Duration.millis(100));

        fadeOut8_4.setDuration(Duration.millis(100));
        fadeOut8_5.setDuration(Duration.millis(100));
        fadeOut8_6.setDuration(Duration.millis(100));

        fadeOut8_7.setDuration(Duration.millis(100));
        fadeOut8_8.setDuration(Duration.millis(100));
        fadeOut8_9.setDuration(Duration.millis(100));

        fadeOut8_10.setDuration(Duration.millis(100));

        fadeIn.setFromValue(0);
        fadeIn.setToValue(10);
        fadeIn2.setFromValue(0);
        fadeIn2.setToValue(10);
        fadeIn3.setFromValue(0);
        fadeIn3.setToValue(10);
        fadeIn4.setFromValue(0);
        fadeIn4.setToValue(10);
        fadeIn5.setFromValue(0);
        fadeIn5.setToValue(10);
        fadeIn5_1.setFromValue(0);
        fadeIn5_1.setToValue(10);
        fadeIn5_2.setFromValue(0);
        fadeIn5_2.setToValue(10);

        fadeIn6.setFromValue(0);
        fadeIn6.setToValue(10);
        fadeIn7.setFromValue(0);
        fadeIn7.setToValue(10);

        fadeIn8.setFromValue(0);
        fadeIn8.setToValue(10);
        fadeIn8_1.setFromValue(0);
        fadeIn8_1.setToValue(10);
        fadeIn8_2.setFromValue(0);
        fadeIn8_2.setToValue(10);
        fadeIn8_3.setFromValue(0);
        fadeIn8_3.setToValue(10);
        fadeIn8_4.setFromValue(0);
        fadeIn8_4.setToValue(10);
        fadeIn8_5.setFromValue(0);
        fadeIn8_5.setToValue(10);
        fadeIn8_6.setFromValue(0);
        fadeIn8_6.setToValue(10);
        fadeIn8_7.setFromValue(0);
        fadeIn8_7.setToValue(10);
        fadeIn8_8.setFromValue(0);
        fadeIn8_8.setToValue(10);
        fadeIn8_9.setFromValue(0);
        fadeIn8_9.setToValue(10);
        fadeIn8_10.setFromValue(0);
        fadeIn8_10.setToValue(10);

        fadeOut.setFromValue(10);
        fadeOut.setToValue(0);
        fadeOut2.setFromValue(10);
        fadeOut2.setToValue(0);
        fadeOut3.setFromValue(10);
        fadeOut3.setToValue(0);
        fadeOut4.setFromValue(10);
        fadeOut4.setToValue(0);
        fadeOut5.setFromValue(10);
        fadeOut5.setToValue(0);
        fadeOut5_1.setFromValue(10);
        fadeOut5_1.setToValue(0);
        fadeOut5_2.setFromValue(10);
        fadeOut5_2.setToValue(0);

        fadeOut6.setFromValue(10);
        fadeOut6.setToValue(0);
        fadeOut7.setFromValue(10);
        fadeOut7.setToValue(0);

        fadeOut8.setFromValue(10);
        fadeOut8.setToValue(0);
        fadeOut8_1.setFromValue(10);
        fadeOut8_1.setToValue(0);
        fadeOut8_2.setFromValue(10);
        fadeOut8_2.setToValue(0);
        fadeOut8_3.setFromValue(10);
        fadeOut8_3.setToValue(0);
        fadeOut8_4.setFromValue(10);
        fadeOut8_4.setToValue(0);
        fadeOut8_5.setFromValue(10);
        fadeOut8_5.setToValue(0);
        fadeOut8_6.setFromValue(10);
        fadeOut8_6.setToValue(0);
        fadeOut8_7.setFromValue(10);
        fadeOut8_7.setToValue(0);
        fadeOut8_8.setFromValue(10);
        fadeOut8_8.setToValue(0);
        fadeOut8_9.setFromValue(10);
        fadeOut8_9.setToValue(0);
        fadeOut8_10.setFromValue(10);
        fadeOut8_10.setToValue(0);

        fadeIn.setCycleCount(1);
        fadeIn2.setCycleCount(1);
        fadeIn3.setCycleCount(1);
        fadeIn4.setCycleCount(1);
        fadeIn5.setCycleCount(1);
        fadeIn5_1.setCycleCount(1);
        fadeIn5_2.setCycleCount(1);
        fadeIn6.setCycleCount(1);
        fadeIn7.setCycleCount(1);
        fadeIn8.setCycleCount(1);
        fadeIn8_1.setCycleCount(1);
        fadeIn8_2.setCycleCount(1);
        fadeIn8_3.setCycleCount(1);
        fadeIn8_4.setCycleCount(1);
        fadeIn8_5.setCycleCount(1);
        fadeIn8_6.setCycleCount(1);
        fadeIn8_7.setCycleCount(1);
        fadeIn8_8.setCycleCount(1);
        fadeIn8_9.setCycleCount(1);
        fadeIn8_10.setCycleCount(1);

        fadeOut.setCycleCount(1);
        fadeOut2.setCycleCount(1);
        fadeOut3.setCycleCount(1);
        fadeOut4.setCycleCount(1);
        fadeOut5.setCycleCount(1);
        fadeOut5_1.setCycleCount(1);
        fadeOut5_2.setCycleCount(1);
        fadeOut6.setCycleCount(1);
        fadeOut7.setCycleCount(1);
        fadeOut8.setCycleCount(1);
        fadeOut8_1.setCycleCount(1);
        fadeOut8_2.setCycleCount(1);
        fadeOut8_3.setCycleCount(1);
        fadeOut8_4.setCycleCount(1);
        fadeOut8_5.setCycleCount(1);
        fadeOut8_6.setCycleCount(1);
        fadeOut8_7.setCycleCount(1);
        fadeOut8_8.setCycleCount(1);
        fadeOut8_9.setCycleCount(1);
        fadeOut8_10.setCycleCount(1);

        fadeIn.setNode(backButton);
        fadeIn2.setNode(l1);
        fadeIn3.setNode(l2);
        fadeIn4.setNode(l3);
        fadeIn5.setNode(Panelg1);
        fadeIn5_1.setNode(Panelex);
        fadeIn5_2.setNode(Panelex4);
        fadeIn6.setNode(Panel1);
        fadeIn7.setNode(Panel2);

        fadeOut5.setNode(Panelg1);
        fadeOut5_1.setNode(Panelex);
        fadeOut5_2.setNode(Panelex4);
        fadeOut.setNode(backButton);
        fadeOut2.setNode(l1);
        fadeOut3.setNode(l2);
        fadeOut4.setNode(l3);
        fadeOut6.setNode(Panel1);
        fadeOut7.setNode(Panel2);

        File f = new File("config.properties");
        if(f.exists()) {

            input = new FileInputStream("config.properties");
            properties.load(input);

            int theme = Integer.parseInt(properties.getProperty("TMode"));
            int tColor = Integer.parseInt(properties.getProperty("TColor"));
            int menuSelected = Integer.parseInt(properties.getProperty("MenuSelected"));

            if (menuSelected==1){

                fadeIn5.play();
                fadeIn5_1.play();
                fadeIn5_2.play();
                fadeIn.play();
                fadeIn2.play();
                fadeIn3.play();
                fadeIn4.play();
                fadeIn6.play();
                fadeIn7.play();
                fadeIn8.play();
                fadeIn8.play();
                fadeIn8_1.play();
                fadeIn8_2.play();
                fadeIn8_3.play();
                fadeIn8_4.play();
                fadeIn8_5.play();
                fadeIn8_6.play();
                fadeIn8_7.play();
                fadeIn8_8.play();
                fadeIn8_9.play();
                fadeIn8_10.play();

                output = new FileOutputStream("config.properties");
                properties.setProperty("MenuSelected", "2");
                properties.store(output, null);

            }
            else {

            }

            if (theme == 1) {

                color = "#f3f5f7";

                effectBG_DropShadowADD = new DropShadow(BlurType.GAUSSIAN, Color.rgb(206,207,210), 36, 0, 9, 9);
                effectBG_DropShadow = new DropShadow(BlurType.GAUSSIAN, Color.rgb(255,255,255), 18, 0, -9, -9);
                effectBG_DropShadow.setInput(effectBG_DropShadowADD);

                effectBG_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(206,207,210), 18, 0, 9, 9);
                effectBG_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(255,255,255), 18, 0, -9, -9);
                effectBG_InnerShadow.setInput(effectBG_InnerShadowADD);

                Panel1.setEffect(effectBG_DropShadow);
                Panel2.setEffect(effectBG_DropShadow);

                if (tColor == 1) {

                    color2 = "#007aff";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,104,217), 18, 0, 9, 9);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,140,255), 18, 0, -9, -9);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,104,217), 18, 0, 9, 9);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,140,255), 18, 0, -9, -9);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBackButton = getClass().getResourceAsStream("../../../resources/svg/left-arrow.svg");
                    svgFileBackButton_Hover = getClass().getResourceAsStream("../../../resources/svg/left-arrow_blue.svg");

                    svgFileOption = getClass().getResourceAsStream("../../../resources/svg/menu/menu.svg");
                    svgFileOption_Hover = getClass().getResourceAsStream("../../../resources/svg/menu/menu_blue.svg");

                    Group svgImageBackButton = loader.loadSvg(svgFileBackButton);
                    Group svgImageBackButton_Hover = loader.loadSvg(svgFileBackButton_Hover);

                    Group svgImageOption = loader.loadSvg(svgFileOption);
                    Group svgImageOption_Hover = loader.loadSvg(svgFileOption_Hover);

                    svgImageBackButton.setScaleX(.04);
                    svgImageBackButton.setScaleY(.04);
                    svgImageBackButton_Hover.setScaleX(.04);
                    svgImageBackButton_Hover.setScaleY(.04);

                    svgImageOption.setScaleX(.04);
                    svgImageOption.setScaleY(.04);
                    svgImageOption_Hover.setScaleX(.04);
                    svgImageOption_Hover.setScaleY(.04);

                    Group svgIconBackButton = new Group(svgImageBackButton);
                    Group svgIconBackButton_Hover = new Group(svgImageBackButton_Hover);

                    Group svgIconOption = new Group(svgImageOption);
                    Group svgIconOption_Hover = new Group(svgImageOption_Hover);

                    backButton.setGraphic(svgIconOption);

                    fadeIn.setDuration(Duration.millis(500));
                    fadeOut.setDuration(Duration.millis(200));

                    fadeIn.setFromValue(0);
                    fadeIn.setToValue(10);

                    fadeOut.setFromValue(10);
                    fadeOut.setToValue(0);

                    fadeIn.setCycleCount(1);
                    fadeOut.setCycleCount(1);

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        backButton.setEffect(effectC_DropShadow);
                        backButton.setGraphic(svgIconBackButton);

                        l1.setText("");
                        l2.setText("Back to Home");
                        l3.setText("");

                        Panel1.setEffect(blur);
                        Panel2.setEffect(blur);
                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        backButton.setEffect(effectC_DropShadow);
                        backButton.setGraphic(svgIconOption);

                        l1.setText("MEMORY");
                        l2.setText("GAME");
                        l3.setText("Mᴜʟᴛɪ Pʟᴀʏᴇʀ");

                        Panel1.setEffect(effectBG_DropShadow);
                        Panel2.setEffect(effectBG_DropShadow);

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e ->{

                        backButton.setGraphic(svgIconBackButton_Hover);

                        Panel1.setEffect(null);
                        Panel2.setEffect(null);

                        fadeOut5.play();
                        fadeOut5_1.play();
                        fadeOut5_2.play();
                        fadeOut.play();
                        fadeOut2.play();
                        fadeOut3.play();
                        fadeOut4.play();
                        fadeOut6.play();
                        fadeOut7.play();
                        fadeOut8.play();
                        fadeOut8_1.play();
                        fadeOut8_2.play();
                        fadeOut8_3.play();
                        fadeOut8_4.play();
                        fadeOut8_5.play();
                        fadeOut8_6.play();
                        fadeOut8_7.play();
                        fadeOut8_8.play();
                        fadeOut8_9.play();
                        fadeOut8_10.play();
                        fadeOut8_11.play();
                        fadeOut8_12.play();
                        fadeOut8_13.play();

                    });

                    Panelex3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        backButton.setGraphic(svgIconOption_Hover);

                    });
                    Panelex3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        backButton.setGraphic(svgIconOption);

                    });

                }
                else if (tColor == 2) {

                    color2 = "#fff44f";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.web("#d9cf43"), 18, 0, 9, 9);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.web("#ffff5b"), 18, 0, -9, -9);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.web("#d9cf43"), 18, 0, 9, 9);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.web("#ffff5b"), 18, 0, -9, -9);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBackButton = getClass().getResourceAsStream("../../../resources/svg/left-arrow.svg");
                    svgFileBackButton_Hover = getClass().getResourceAsStream("../../../resources/svg/left-arrow_yellow.svg");

                    svgFileOption = getClass().getResourceAsStream("../../../resources/svg/menu/menu.svg");
                    svgFileOption_Hover = getClass().getResourceAsStream("../../../resources/svg/menu/menu_yellow.svg");

                    Group svgImageBackButton = loader.loadSvg(svgFileBackButton);
                    Group svgImageBackButton_Hover = loader.loadSvg(svgFileBackButton_Hover);

                    Group svgImageOption = loader.loadSvg(svgFileOption);
                    Group svgImageOption_Hover = loader.loadSvg(svgFileOption_Hover);

                    svgImageBackButton.setScaleX(.04);
                    svgImageBackButton.setScaleY(.04);
                    svgImageBackButton_Hover.setScaleX(.04);
                    svgImageBackButton_Hover.setScaleY(.04);

                    svgImageOption.setScaleX(.04);
                    svgImageOption.setScaleY(.04);
                    svgImageOption_Hover.setScaleX(.04);
                    svgImageOption_Hover.setScaleY(.04);

                    Group svgIconBackButton = new Group(svgImageBackButton);
                    Group svgIconBackButton_Hover = new Group(svgImageBackButton_Hover);

                    Group svgIconOption = new Group(svgImageOption);
                    Group svgIconOption_Hover = new Group(svgImageOption_Hover);

                    backButton.setGraphic(svgIconOption);

                    fadeIn.setDuration(Duration.millis(500));
                    fadeOut.setDuration(Duration.millis(200));

                    fadeIn.setFromValue(0);
                    fadeIn.setToValue(10);

                    fadeOut.setFromValue(10);
                    fadeOut.setToValue(0);

                    fadeIn.setCycleCount(1);
                    fadeOut.setCycleCount(1);

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        backButton.setEffect(effectC_DropShadow);
                        backButton.setGraphic(svgIconBackButton);

                        l1.setText("");
                        l2.setText("Back to Home");
                        l3.setText("");

                        Panel1.setEffect(blur);
                        Panel2.setEffect(blur);
                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        backButton.setEffect(effectC_DropShadow);
                        backButton.setGraphic(svgIconOption);

                        l1.setText("MEMORY");
                        l2.setText("GAME");
                        l3.setText("Mᴜʟᴛɪ Pʟᴀʏᴇʀ");

                        Panel1.setEffect(effectBG_DropShadow);
                        Panel2.setEffect(effectBG_DropShadow);

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e ->{

                        backButton.setGraphic(svgIconBackButton_Hover);

                        Panel1.setEffect(null);
                        Panel2.setEffect(null);

                        fadeOut5.play();
                        fadeOut5_1.play();
                        fadeOut5_2.play();
                        fadeOut.play();
                        fadeOut2.play();
                        fadeOut3.play();
                        fadeOut4.play();
                        fadeOut6.play();
                        fadeOut7.play();
                        fadeOut8.play();
                        fadeOut8_1.play();
                        fadeOut8_2.play();
                        fadeOut8_3.play();
                        fadeOut8_4.play();
                        fadeOut8_5.play();
                        fadeOut8_6.play();
                        fadeOut8_7.play();
                        fadeOut8_8.play();
                        fadeOut8_9.play();
                        fadeOut8_10.play();
                        fadeOut8_11.play();
                        fadeOut8_12.play();
                        fadeOut8_13.play();

                    });

                    Panelex3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        backButton.setGraphic(svgIconOption_Hover);

                    });
                    Panelex3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        backButton.setGraphic(svgIconOption);

                    });

                }
                else if (tColor == 3) {

                    color2 = "#00c853";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,200,83), 18, 0, 9, 9);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,230,95), 18, 0, -9, -9);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,200,83), 18, 0, 9, 9);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,230,95), 18, 0, -9, -9);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBackButton = getClass().getResourceAsStream("../../../resources/svg/left-arrow.svg");
                    svgFileBackButton_Hover = getClass().getResourceAsStream("../../../resources/svg/left-arrow_green.svg");

                    svgFileOption = getClass().getResourceAsStream("../../../resources/svg/menu/menu.svg");
                    svgFileOption_Hover = getClass().getResourceAsStream("../../../resources/svg/menu/menu_green.svg");

                    Group svgImageBackButton = loader.loadSvg(svgFileBackButton);
                    Group svgImageBackButton_Hover = loader.loadSvg(svgFileBackButton_Hover);

                    Group svgImageOption = loader.loadSvg(svgFileOption);
                    Group svgImageOption_Hover = loader.loadSvg(svgFileOption_Hover);

                    svgImageBackButton.setScaleX(.04);
                    svgImageBackButton.setScaleY(.04);
                    svgImageBackButton_Hover.setScaleX(.04);
                    svgImageBackButton_Hover.setScaleY(.04);

                    svgImageOption.setScaleX(.04);
                    svgImageOption.setScaleY(.04);
                    svgImageOption_Hover.setScaleX(.04);
                    svgImageOption_Hover.setScaleY(.04);

                    Group svgIconBackButton = new Group(svgImageBackButton);
                    Group svgIconBackButton_Hover = new Group(svgImageBackButton_Hover);

                    Group svgIconOption = new Group(svgImageOption);
                    Group svgIconOption_Hover = new Group(svgImageOption_Hover);

                    backButton.setGraphic(svgIconOption);

                    fadeIn.setDuration(Duration.millis(500));
                    fadeOut.setDuration(Duration.millis(200));

                    fadeIn.setFromValue(0);
                    fadeIn.setToValue(10);

                    fadeOut.setFromValue(10);
                    fadeOut.setToValue(0);

                    fadeIn.setCycleCount(1);
                    fadeOut.setCycleCount(1);

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        backButton.setEffect(effectC_DropShadow);
                        backButton.setGraphic(svgIconBackButton);

                        l1.setText("");
                        l2.setText("Back to Home");
                        l3.setText("");

                        Panel1.setEffect(blur);
                        Panel2.setEffect(blur);
                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        backButton.setEffect(effectC_DropShadow);
                        backButton.setGraphic(svgIconOption);

                        l1.setText("MEMORY");
                        l2.setText("GAME");
                        l3.setText("Mᴜʟᴛɪ Pʟᴀʏᴇʀ");

                        Panel1.setEffect(effectBG_DropShadow);
                        Panel2.setEffect(effectBG_DropShadow);

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e ->{

                        backButton.setGraphic(svgIconBackButton_Hover);

                        Panel1.setEffect(null);
                        Panel2.setEffect(null);

                        fadeOut5.play();
                        fadeOut5_1.play();
                        fadeOut5_2.play();
                        fadeOut.play();
                        fadeOut2.play();
                        fadeOut3.play();
                        fadeOut4.play();
                        fadeOut6.play();
                        fadeOut7.play();
                        fadeOut8.play();
                        fadeOut8_1.play();
                        fadeOut8_2.play();
                        fadeOut8_3.play();
                        fadeOut8_4.play();
                        fadeOut8_5.play();
                        fadeOut8_6.play();
                        fadeOut8_7.play();
                        fadeOut8_8.play();
                        fadeOut8_9.play();
                        fadeOut8_10.play();
                        fadeOut8_11.play();
                        fadeOut8_12.play();
                        fadeOut8_13.play();

                    });

                    Panelex3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        backButton.setGraphic(svgIconOption_Hover);

                    });
                    Panelex3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        backButton.setGraphic(svgIconOption);

                    });

                }
                else if (tColor == 4) {

                    color2 = "#d50000";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(181,0,0), 18, 0, 9, 9);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(245,0,0), 18, 0, -9, -9);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(181,0,0), 18, 0, 9, 9);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(245,0,0), 18, 0, -9, -9);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBackButton = getClass().getResourceAsStream("../../../resources/svg/left-arrow.svg");
                    svgFileBackButton_Hover = getClass().getResourceAsStream("../../../resources/svg/left-arrow_red.svg");

                    svgFileOption = getClass().getResourceAsStream("../../../resources/svg/menu/menu.svg");
                    svgFileOption_Hover = getClass().getResourceAsStream("../../../resources/svg/menu/menu_red.svg");

                    Group svgImageBackButton = loader.loadSvg(svgFileBackButton);
                    Group svgImageBackButton_Hover = loader.loadSvg(svgFileBackButton_Hover);

                    Group svgImageOption = loader.loadSvg(svgFileOption);
                    Group svgImageOption_Hover = loader.loadSvg(svgFileOption_Hover);

                    svgImageBackButton.setScaleX(.04);
                    svgImageBackButton.setScaleY(.04);
                    svgImageBackButton_Hover.setScaleX(.04);
                    svgImageBackButton_Hover.setScaleY(.04);

                    svgImageOption.setScaleX(.04);
                    svgImageOption.setScaleY(.04);
                    svgImageOption_Hover.setScaleX(.04);
                    svgImageOption_Hover.setScaleY(.04);

                    Group svgIconBackButton = new Group(svgImageBackButton);
                    Group svgIconBackButton_Hover = new Group(svgImageBackButton_Hover);

                    Group svgIconOption = new Group(svgImageOption);
                    Group svgIconOption_Hover = new Group(svgImageOption_Hover);

                    backButton.setGraphic(svgIconOption);

                    fadeIn.setDuration(Duration.millis(500));
                    fadeOut.setDuration(Duration.millis(200));

                    fadeIn.setFromValue(0);
                    fadeIn.setToValue(10);

                    fadeOut.setFromValue(10);
                    fadeOut.setToValue(0);

                    fadeIn.setCycleCount(1);
                    fadeOut.setCycleCount(1);

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        backButton.setEffect(effectC_DropShadow);
                        backButton.setGraphic(svgIconBackButton);

                        l1.setText("");
                        l2.setText("Back to Home");
                        l3.setText("");

                        Panel1.setEffect(blur);
                        Panel2.setEffect(blur);
                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        backButton.setEffect(effectC_DropShadow);
                        backButton.setGraphic(svgIconOption);

                        l1.setText("MEMORY");
                        l2.setText("GAME");
                        l3.setText("Mᴜʟᴛɪ Pʟᴀʏᴇʀ");

                        Panel1.setEffect(effectBG_DropShadow);
                        Panel2.setEffect(effectBG_DropShadow);

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e ->{

                        backButton.setGraphic(svgIconBackButton_Hover);

                        Panel1.setEffect(null);
                        Panel2.setEffect(null);

                        fadeOut5.play();
                        fadeOut5_1.play();
                        fadeOut5_2.play();
                        fadeOut.play();
                        fadeOut2.play();
                        fadeOut3.play();
                        fadeOut4.play();
                        fadeOut6.play();
                        fadeOut7.play();
                        fadeOut8.play();
                        fadeOut8_1.play();
                        fadeOut8_2.play();
                        fadeOut8_3.play();
                        fadeOut8_4.play();
                        fadeOut8_5.play();
                        fadeOut8_6.play();
                        fadeOut8_7.play();
                        fadeOut8_8.play();
                        fadeOut8_9.play();
                        fadeOut8_10.play();
                        fadeOut8_11.play();
                        fadeOut8_12.play();
                        fadeOut8_13.play();

                    });

                    Panelex3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        backButton.setGraphic(svgIconOption_Hover);

                    });
                    Panelex3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        backButton.setGraphic(svgIconOption);

                    });

                }

            }
            else if (theme == 2) {

                color = "#121212";

                effectBG_DropShadowADD = new DropShadow(BlurType.GAUSSIAN, Color.rgb(20,20,20), 18, 0, 9, 9);
                effectBG_DropShadow = new DropShadow(BlurType.GAUSSIAN, Color.rgb(28,28,28), 18, 0, -9, -9);
                effectBG_DropShadow.setInput(effectBG_DropShadowADD);

                effectBG_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(20,20,20), 18, 0, 9, 9);
                effectBG_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(20,20,20), 18, 0, -9, -9);
                effectBG_InnerShadow.setInput(effectBG_InnerShadowADD);

                Panel1.setEffect(effectBG_DropShadow);
                Panel2.setEffect(effectBG_DropShadow);

                if (tColor == 1) {

                    color2 = "#004fcb";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,67,173), 24, 0, 9, 9);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,91,233), 24, 0, -9, -9);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,67,173), 18, 0, 9, 9);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,91,233), 18, 0, -9, -9);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBackButton = getClass().getResourceAsStream("../../../resources/svg/left-arrow_d.svg");
                    svgFileBackButton_Hover = getClass().getResourceAsStream("../../../resources/svg/left-arrow_dblue.svg");

                    svgFileOption = getClass().getResourceAsStream("../../../resources/svg/menu/menu_d.svg");
                    svgFileOption_Hover = getClass().getResourceAsStream("../../../resources/svg/menu/menu_dblue.svg");

                    Group svgImageBackButton = loader.loadSvg(svgFileBackButton);
                    Group svgImageBackButton_Hover = loader.loadSvg(svgFileBackButton_Hover);

                    Group svgImageOption = loader.loadSvg(svgFileOption);
                    Group svgImageOption_Hover = loader.loadSvg(svgFileOption_Hover);

                    svgImageBackButton.setScaleX(.04);
                    svgImageBackButton.setScaleY(.04);
                    svgImageBackButton_Hover.setScaleX(.04);
                    svgImageBackButton_Hover.setScaleY(.04);

                    svgImageOption.setScaleX(.04);
                    svgImageOption.setScaleY(.04);
                    svgImageOption_Hover.setScaleX(.04);
                    svgImageOption_Hover.setScaleY(.04);

                    Group svgIconBackButton = new Group(svgImageBackButton);
                    Group svgIconBackButton_Hover = new Group(svgImageBackButton_Hover);

                    Group svgIconOption = new Group(svgImageOption);
                    Group svgIconOption_Hover = new Group(svgImageOption_Hover);

                    backButton.setGraphic(svgIconOption);

                    fadeIn.setDuration(Duration.millis(500));
                    fadeOut.setDuration(Duration.millis(200));

                    fadeIn.setFromValue(0);
                    fadeIn.setToValue(10);

                    fadeOut.setFromValue(10);
                    fadeOut.setToValue(0);

                    fadeIn.setCycleCount(1);
                    fadeOut.setCycleCount(1);

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        backButton.setEffect(effectC_DropShadow);
                        backButton.setGraphic(svgIconBackButton);

                        l1.setText("");
                        l2.setText("Back to Home");
                        l3.setText("");

                        Panel1.setEffect(blur);
                        Panel2.setEffect(blur);
                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        backButton.setEffect(effectC_DropShadow);
                        backButton.setGraphic(svgIconOption);

                        l1.setText("MEMORY");
                        l2.setText("GAME");
                        l3.setText("Mᴜʟᴛɪ Pʟᴀʏᴇʀ");

                        Panel1.setEffect(effectBG_DropShadow);
                        Panel2.setEffect(effectBG_DropShadow);

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e ->{

                        backButton.setGraphic(svgIconBackButton_Hover);

                        Panel1.setEffect(null);
                        Panel2.setEffect(null);

                        fadeOut5.play();
                        fadeOut5_1.play();
                        fadeOut5_2.play();
                        fadeOut.play();
                        fadeOut2.play();
                        fadeOut3.play();
                        fadeOut4.play();
                        fadeOut6.play();
                        fadeOut7.play();
                        fadeOut8.play();
                        fadeOut8_1.play();
                        fadeOut8_2.play();
                        fadeOut8_3.play();
                        fadeOut8_4.play();
                        fadeOut8_5.play();
                        fadeOut8_6.play();
                        fadeOut8_7.play();
                        fadeOut8_8.play();
                        fadeOut8_9.play();
                        fadeOut8_10.play();
                        fadeOut8_11.play();
                        fadeOut8_12.play();
                        fadeOut8_13.play();

                    });

                    Panelex3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        backButton.setGraphic(svgIconOption_Hover);

                    });
                    Panelex3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        backButton.setGraphic(svgIconOption);

                    });

                }
                else if (tColor == 2) {

                    color2 = "#c9c208";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.web("#aba507"), 18, 0, 9, 9);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.web("#e7df09"), 18, 0, -9, -9);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.web("#aba507"), 18, 0, 9, 9);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.web("#e7df09"), 18, 0, -9, -9);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBackButton = getClass().getResourceAsStream("../../../resources/svg/left-arrow_d.svg");
                    svgFileBackButton_Hover = getClass().getResourceAsStream("../../../resources/svg/left-arrow_dyellow.svg");

                    svgFileOption = getClass().getResourceAsStream("../../../resources/svg/menu/menu_d.svg");
                    svgFileOption_Hover = getClass().getResourceAsStream("../../../resources/svg/menu/menu_dyellow.svg");

                    Group svgImageBackButton = loader.loadSvg(svgFileBackButton);
                    Group svgImageBackButton_Hover = loader.loadSvg(svgFileBackButton_Hover);

                    Group svgImageOption = loader.loadSvg(svgFileOption);
                    Group svgImageOption_Hover = loader.loadSvg(svgFileOption_Hover);

                    svgImageBackButton.setScaleX(.04);
                    svgImageBackButton.setScaleY(.04);
                    svgImageBackButton_Hover.setScaleX(.04);
                    svgImageBackButton_Hover.setScaleY(.04);

                    svgImageOption.setScaleX(.04);
                    svgImageOption.setScaleY(.04);
                    svgImageOption_Hover.setScaleX(.04);
                    svgImageOption_Hover.setScaleY(.04);

                    Group svgIconBackButton = new Group(svgImageBackButton);
                    Group svgIconBackButton_Hover = new Group(svgImageBackButton_Hover);

                    Group svgIconOption = new Group(svgImageOption);
                    Group svgIconOption_Hover = new Group(svgImageOption_Hover);

                    backButton.setGraphic(svgIconOption);

                    fadeIn.setDuration(Duration.millis(500));
                    fadeOut.setDuration(Duration.millis(200));

                    fadeIn.setFromValue(0);
                    fadeIn.setToValue(10);

                    fadeOut.setFromValue(10);
                    fadeOut.setToValue(0);

                    fadeIn.setCycleCount(1);
                    fadeOut.setCycleCount(1);

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        backButton.setEffect(effectC_DropShadow);
                        backButton.setGraphic(svgIconBackButton);

                        l1.setText("");
                        l2.setText("Back to Home");
                        l3.setText("");

                        Panel1.setEffect(blur);
                        Panel2.setEffect(blur);
                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        backButton.setEffect(effectC_DropShadow);
                        backButton.setGraphic(svgIconOption);

                        l1.setText("MEMORY");
                        l2.setText("GAME");
                        l3.setText("Mᴜʟᴛɪ Pʟᴀʏᴇʀ");

                        Panel1.setEffect(effectBG_DropShadow);
                        Panel2.setEffect(effectBG_DropShadow);

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e ->{

                        backButton.setGraphic(svgIconBackButton_Hover);

                        Panel1.setEffect(null);
                        Panel2.setEffect(null);

                        fadeOut5.play();
                        fadeOut5_1.play();
                        fadeOut5_2.play();
                        fadeOut.play();
                        fadeOut2.play();
                        fadeOut3.play();
                        fadeOut4.play();
                        fadeOut6.play();
                        fadeOut7.play();
                        fadeOut8.play();
                        fadeOut8_1.play();
                        fadeOut8_2.play();
                        fadeOut8_3.play();
                        fadeOut8_4.play();
                        fadeOut8_5.play();
                        fadeOut8_6.play();
                        fadeOut8_7.play();
                        fadeOut8_8.play();
                        fadeOut8_9.play();
                        fadeOut8_10.play();
                        fadeOut8_11.play();
                        fadeOut8_12.play();
                        fadeOut8_13.play();

                    });

                    Panelex3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        backButton.setGraphic(svgIconOption_Hover);

                    });
                    Panelex3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        backButton.setGraphic(svgIconOption);

                    });


                }
                else if (tColor == 3) {

                    color2 = "#c006500";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,86,0), 18, 0, 9, 9);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,116,0), 18, 0, -9, -9);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,86,0), 18, 0, 9, 9);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,116,0), 18, 0, -9, -9);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBackButton = getClass().getResourceAsStream("../../../resources/svg/left-arrow_d.svg");
                    svgFileBackButton_Hover = getClass().getResourceAsStream("../../../resources/svg/left-arrow_dgreen.svg");

                    svgFileOption = getClass().getResourceAsStream("../../../resources/svg/menu/menu_d.svg");
                    svgFileOption_Hover = getClass().getResourceAsStream("../../../resources/svg/menu/menu_dgreen.svg");

                    Group svgImageBackButton = loader.loadSvg(svgFileBackButton);
                    Group svgImageBackButton_Hover = loader.loadSvg(svgFileBackButton_Hover);

                    Group svgImageOption = loader.loadSvg(svgFileOption);
                    Group svgImageOption_Hover = loader.loadSvg(svgFileOption_Hover);

                    svgImageBackButton.setScaleX(.04);
                    svgImageBackButton.setScaleY(.04);
                    svgImageBackButton_Hover.setScaleX(.04);
                    svgImageBackButton_Hover.setScaleY(.04);

                    svgImageOption.setScaleX(.04);
                    svgImageOption.setScaleY(.04);
                    svgImageOption_Hover.setScaleX(.04);
                    svgImageOption_Hover.setScaleY(.04);

                    Group svgIconBackButton = new Group(svgImageBackButton);
                    Group svgIconBackButton_Hover = new Group(svgImageBackButton_Hover);

                    Group svgIconOption = new Group(svgImageOption);
                    Group svgIconOption_Hover = new Group(svgImageOption_Hover);

                    backButton.setGraphic(svgIconOption);

                    fadeIn.setDuration(Duration.millis(500));
                    fadeOut.setDuration(Duration.millis(200));

                    fadeIn.setFromValue(0);
                    fadeIn.setToValue(10);

                    fadeOut.setFromValue(10);
                    fadeOut.setToValue(0);

                    fadeIn.setCycleCount(1);
                    fadeOut.setCycleCount(1);

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        backButton.setEffect(effectC_DropShadow);
                        backButton.setGraphic(svgIconBackButton);

                        l1.setText("");
                        l2.setText("Back to Home");
                        l3.setText("");

                        Panel1.setEffect(blur);
                        Panel2.setEffect(blur);
                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        backButton.setEffect(effectC_DropShadow);
                        backButton.setGraphic(svgIconOption);

                        l1.setText("MEMORY");
                        l2.setText("GAME");
                        l3.setText("Mᴜʟᴛɪ Pʟᴀʏᴇʀ");

                        Panel1.setEffect(effectBG_DropShadow);
                        Panel2.setEffect(effectBG_DropShadow);

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e ->{

                        backButton.setGraphic(svgIconBackButton_Hover);

                        Panel1.setEffect(null);
                        Panel2.setEffect(null);

                        fadeOut5.play();
                        fadeOut5_1.play();
                        fadeOut5_2.play();
                        fadeOut.play();
                        fadeOut2.play();
                        fadeOut3.play();
                        fadeOut4.play();
                        fadeOut6.play();
                        fadeOut7.play();
                        fadeOut8.play();
                        fadeOut8_1.play();
                        fadeOut8_2.play();
                        fadeOut8_3.play();
                        fadeOut8_4.play();
                        fadeOut8_5.play();
                        fadeOut8_6.play();
                        fadeOut8_7.play();
                        fadeOut8_8.play();
                        fadeOut8_9.play();
                        fadeOut8_10.play();
                        fadeOut8_11.play();
                        fadeOut8_12.play();
                        fadeOut8_13.play();

                    });

                    Panelex3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        backButton.setGraphic(svgIconOption_Hover);

                    });
                    Panelex3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        backButton.setGraphic(svgIconOption);

                    });

                }
                else if (tColor == 4) {

                    color2 = "#9b0000";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(155,0,0), 18, 0, 9, 9);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(178,0,0), 18, 0, -9, -9);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(155,0,0), 18, 0, 9, 9);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(178,0,0), 18, 0, -9, -9);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBackButton = getClass().getResourceAsStream("../../../resources/svg/left-arrow_d.svg");
                    svgFileBackButton_Hover = getClass().getResourceAsStream("../../../resources/svg/left-arrow_dred.svg");

                    svgFileOption = getClass().getResourceAsStream("../../../resources/svg/menu/menu_d.svg");
                    svgFileOption_Hover = getClass().getResourceAsStream("../../../resources/svg/menu/menu_dred.svg");

                    Group svgImageBackButton = loader.loadSvg(svgFileBackButton);
                    Group svgImageBackButton_Hover = loader.loadSvg(svgFileBackButton_Hover);

                    Group svgImageOption = loader.loadSvg(svgFileOption);
                    Group svgImageOption_Hover = loader.loadSvg(svgFileOption_Hover);

                    svgImageBackButton.setScaleX(.04);
                    svgImageBackButton.setScaleY(.04);
                    svgImageBackButton_Hover.setScaleX(.04);
                    svgImageBackButton_Hover.setScaleY(.04);

                    svgImageOption.setScaleX(.04);
                    svgImageOption.setScaleY(.04);
                    svgImageOption_Hover.setScaleX(.04);
                    svgImageOption_Hover.setScaleY(.04);

                    Group svgIconBackButton = new Group(svgImageBackButton);
                    Group svgIconBackButton_Hover = new Group(svgImageBackButton_Hover);

                    Group svgIconOption = new Group(svgImageOption);
                    Group svgIconOption_Hover = new Group(svgImageOption_Hover);

                    backButton.setGraphic(svgIconOption);

                    fadeIn.setDuration(Duration.millis(500));
                    fadeOut.setDuration(Duration.millis(200));

                    fadeIn.setFromValue(0);
                    fadeIn.setToValue(10);

                    fadeOut.setFromValue(10);
                    fadeOut.setToValue(0);

                    fadeIn.setCycleCount(1);
                    fadeOut.setCycleCount(1);

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        backButton.setEffect(effectC_DropShadow);
                        backButton.setGraphic(svgIconBackButton);

                        l1.setText("");
                        l2.setText("Back to Home");
                        l3.setText("");

                        Panel1.setEffect(blur);
                        Panel2.setEffect(blur);
                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        backButton.setEffect(effectC_DropShadow);
                        backButton.setGraphic(svgIconOption);

                        l1.setText("MEMORY");
                        l2.setText("GAME");
                        l3.setText("Mᴜʟᴛɪ Pʟᴀʏᴇʀ");

                        Panel1.setEffect(effectBG_DropShadow);
                        Panel2.setEffect(effectBG_DropShadow);

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e ->{

                        backButton.setGraphic(svgIconBackButton_Hover);

                        Panel1.setEffect(null);
                        Panel2.setEffect(null);

                        fadeOut5.play();
                        fadeOut5_1.play();
                        fadeOut5_2.play();
                        fadeOut.play();
                        fadeOut2.play();
                        fadeOut3.play();
                        fadeOut4.play();
                        fadeOut6.play();
                        fadeOut7.play();
                        fadeOut8.play();
                        fadeOut8_1.play();
                        fadeOut8_2.play();
                        fadeOut8_3.play();
                        fadeOut8_4.play();
                        fadeOut8_5.play();
                        fadeOut8_6.play();
                        fadeOut8_7.play();
                        fadeOut8_8.play();
                        fadeOut8_9.play();
                        fadeOut8_10.play();
                        fadeOut8_11.play();
                        fadeOut8_12.play();
                        fadeOut8_13.play();

                    });

                    Panelex3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        backButton.setGraphic(svgIconOption_Hover);

                    });
                    Panelex3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        backButton.setGraphic(svgIconOption);

                    });

                }

            }

        }

    }

    @FXML
    private void backButtonClicked() throws IOException{
        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        output = new FileOutputStream("config.properties");
        properties.setProperty("MenuSelected", "1");
        properties.store(output, null);

        Parent root = FXMLLoader.load(getClass().getResource("../../../resources/view/MainMenu.fxml"));
        Stage stage = (Stage) backButton.getScene().getWindow();
        stage.getScene().setRoot(root);

        File f = new File("config.properties");
        if(f.exists()) {
            input2 = new FileInputStream("config.properties");
            properties2.load(input2);

            int width = Integer.parseInt(properties2.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }

    }


}
