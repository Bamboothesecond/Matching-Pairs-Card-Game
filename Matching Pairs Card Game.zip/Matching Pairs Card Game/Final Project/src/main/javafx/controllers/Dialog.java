package main.javafx.controllers;

import javafx.animation.FadeTransition;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.effect.BlurType;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.InnerShadow;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;
import main.javafx.util.SvgLoader;

import java.io.*;
import java.util.Locale;
import java.util.Properties;
import java.util.ResourceBundle;

public class Dialog  {

    @FXML
    private Button yes,no,B1;

    @FXML
    private AnchorPane Panelex;

    @FXML
    private Label exit;

    private Properties properties = new Properties();

    private MediaPlayer mediaPlayer;
    final SvgLoader loader = new SvgLoader();

    DropShadow effectBG_DropShadowADD,effectBG_DropShadow,effectC_DropShadowADD,effectC_DropShadow;

    String color,color2;
    InnerShadow effectBG_InnerShadowADD,effectBG_InnerShadow,effectC_InnerShadowADD,effectC_InnerShadow;
    InputStream svgFileBG,svgFileYes,svgFileYes_Hover,svgFileNo,svgFileNo_Hover;

    public Dialog(){

        Media buttonSound = new Media(new File("src/main/resources/Sounds/buttonSound.wav").toURI().toString());
        mediaPlayer = new MediaPlayer(buttonSound);
    }
    @FXML
    private void initialize() throws IOException{
        File f = new File("config.properties");

        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            int theme = Integer.parseInt(properties.getProperty("TMode"));
            int tColor = Integer.parseInt(properties.getProperty("TColor"));

            B1.setStyle("-fx-background-color:transparent;");

            if (width==999){

                Panelex.setPrefSize(1920,1080);

                if (theme == 1) {

                    color = "#f3f5f7";

                    if (tColor == 1) {

                        color2 = "#007aff";
                        exit.setTextFill(Color.web("#004fcb"));
                        yes.setTextFill(Color.web("#c0c2c4"));
                        no.setTextFill(Color.web("#c0c2c4"));
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 0;");
                        yes.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        no.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");

                    }
                    else if (tColor == 2) {

                        color2 = "#fff44f";
                        exit.setTextFill(Color.web("#c9c208"));
                        yes.setTextFill(Color.web("#c0c2c4"));
                        no.setTextFill(Color.web("#c0c2c4"));
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 0;");
                        yes.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        no.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");

                    }
                    else if (tColor == 3) {

                        color2 = "#00c853";
                        exit.setTextFill(Color.web("#006500"));
                        yes.setTextFill(Color.web("#c0c2c4"));
                        no.setTextFill(Color.web("#c0c2c4"));
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 0;");
                        yes.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        no.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");

                    }
                    else if (tColor == 4) {

                        color2 = "#d50000";
                        exit.setTextFill(Color.web("#9b0000"));
                        yes.setTextFill(Color.web("#c0c2c4"));
                        no.setTextFill(Color.web("#c0c2c4"));
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 0;");
                        yes.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        no.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");

                    }

                }
                else if (theme == 2) {

                    color = "#181818";

                    if (tColor == 1) {

                        color2 = "#004fcb";
                        exit.setTextFill(Color.web("#007aff"));
                        yes.setTextFill(Color.web("#3E3E3E"));
                        no.setTextFill(Color.web("#3E3E3E"));
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 0;");
                        yes.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        no.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");

                    }
                    else if (tColor == 2) {

                        color2 = "#c9c208";
                        exit.setTextFill(Color.web("#fff44f"));
                        yes.setTextFill(Color.web("#3E3E3E"));
                        no.setTextFill(Color.web("#3E3E3E"));
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 0;");
                        yes.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        no.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");

                    }
                    else if (tColor == 3) {

                        color2 = "#006500";
                        exit.setTextFill(Color.web("#00c853"));
                        yes.setTextFill(Color.web("#3E3E3E"));
                        no.setTextFill(Color.web("#3E3E3E"));
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 0;");
                        yes.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        no.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");

                    }
                    else if (tColor == 4) {

                        color2 = "#9b0000";
                        exit.setTextFill(Color.web("#d50000"));
                        yes.setTextFill(Color.web("#3E3E3E"));
                        no.setTextFill(Color.web("#3E3E3E"));
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 0;");
                        yes.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        no.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");

                    }

                }

            }
            else if (width==1600){

                Panelex.setPrefSize(1600,900);

                if (theme == 1) {

                    color = "#f3f5f7";

                    if (tColor == 1) {

                        color2 = "#007aff";
                        exit.setTextFill(Color.web("#004fcb"));
                        yes.setTextFill(Color.web("#c0c2c4"));
                        no.setTextFill(Color.web("#c0c2c4"));
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        yes.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        no.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");

                    }
                    else if (tColor == 2) {

                        color2 = "#fff44f";
                        exit.setTextFill(Color.web("#c9c208"));
                        yes.setTextFill(Color.web("#c0c2c4"));
                        no.setTextFill(Color.web("#c0c2c4"));
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        yes.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        no.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");

                    }
                    else if (tColor == 3) {

                        color2 = "#00c853";
                        exit.setTextFill(Color.web("#006500"));
                        yes.setTextFill(Color.web("#c0c2c4"));
                        no.setTextFill(Color.web("#c0c2c4"));
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        yes.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        no.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");

                    }
                    else if (tColor == 4) {

                        color2 = "#d50000";
                        exit.setTextFill(Color.web("#9b0000"));
                        yes.setTextFill(Color.web("#c0c2c4"));
                        no.setTextFill(Color.web("#c0c2c4"));
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        yes.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        no.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");

                    }

                }
                else if (theme == 2) {

                    color = "#181818";

                    if (tColor == 1) {

                        color2 = "#004fcb";
                        exit.setTextFill(Color.web("#007aff"));
                        yes.setTextFill(Color.web("#3E3E3E"));
                        no.setTextFill(Color.web("#3E3E3E"));
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        yes.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        no.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");

                    }
                    else if (tColor == 2) {

                        color2 = "#c9c208";
                        exit.setTextFill(Color.web("#fff44f"));
                        yes.setTextFill(Color.web("#3E3E3E"));
                        no.setTextFill(Color.web("#3E3E3E"));
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        yes.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        no.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");

                    }
                    else if (tColor == 3) {

                        color2 = "#006500";
                        exit.setTextFill(Color.web("#00c853"));
                        yes.setTextFill(Color.web("#3E3E3E"));
                        no.setTextFill(Color.web("#3E3E3E"));
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        yes.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        no.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");

                    }
                    else if (tColor == 4) {

                        color2 = "#9b0000";
                        exit.setTextFill(Color.web("#d50000"));
                        yes.setTextFill(Color.web("#3E3E3E"));
                        no.setTextFill(Color.web("#3E3E3E"));
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        yes.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        no.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");

                    }

                }

            }
            else if (width==1280){

                if (theme == 1) {

                    color = "#f3f5f7";

                    if (tColor == 1) {

                        color2 = "#007aff";
                        exit.setTextFill(Color.web("#004fcb"));
                        yes.setTextFill(Color.web("#c0c2c4"));
                        no.setTextFill(Color.web("#c0c2c4"));
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        yes.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        no.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");

                    }
                    else if (tColor == 2) {

                        color2 = "#fff44f";
                        exit.setTextFill(Color.web("#c9c208"));
                        yes.setTextFill(Color.web("#c0c2c4"));
                        no.setTextFill(Color.web("#c0c2c4"));
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        yes.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        no.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");

                    }
                    else if (tColor == 3) {

                        color2 = "#00c853";
                        exit.setTextFill(Color.web("#006500"));
                        yes.setTextFill(Color.web("#c0c2c4"));
                        no.setTextFill(Color.web("#c0c2c4"));
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        yes.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        no.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");

                    }
                    else if (tColor == 4) {

                        color2 = "#d50000";
                        exit.setTextFill(Color.web("#9b0000"));
                        yes.setTextFill(Color.web("#c0c2c4"));
                        no.setTextFill(Color.web("#c0c2c4"));
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        yes.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        no.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");

                    }

                }
                else if (theme == 2) {

                    color = "#181818";

                    if (tColor == 1) {

                        color2 = "#004fcb";
                        exit.setTextFill(Color.web("#007aff"));
                        yes.setTextFill(Color.web("#3E3E3E"));
                        no.setTextFill(Color.web("#3E3E3E"));
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        yes.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        no.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");

                    }
                    else if (tColor == 2) {

                        color2 = "#c9c208";
                        exit.setTextFill(Color.web("#fff44f"));
                        yes.setTextFill(Color.web("#3E3E3E"));
                        no.setTextFill(Color.web("#3E3E3E"));
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        yes.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        no.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");

                    }
                    else if (tColor == 3) {

                        color2 = "#006500";
                        exit.setTextFill(Color.web("#00c853"));
                        yes.setTextFill(Color.web("#3E3E3E"));
                        no.setTextFill(Color.web("#3E3E3E"));
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        yes.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        no.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");

                    }
                    else if (tColor == 4) {

                        color2 = "#9b0000";
                        exit.setTextFill(Color.web("#d50000"));
                        yes.setTextFill(Color.web("#3E3E3E"));
                        no.setTextFill(Color.web("#3E3E3E"));
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        yes.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        no.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");

                    }

                }

            }

        }
        themeHandler();
    }

    private void themeHandler() throws IOException {
        final SvgLoader loader = new SvgLoader();
        File f = new File("config.properties");
        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int theme = Integer.parseInt(properties.getProperty("TMode"));
            int tColor = Integer.parseInt(properties.getProperty("TColor"));

            if (theme == 1) {

                color = "#f3f5f7";

                effectBG_DropShadowADD = new DropShadow(BlurType.GAUSSIAN, Color.rgb(206,207,210), 36, 0, 9, 9);
                effectBG_DropShadow = new DropShadow(BlurType.GAUSSIAN, Color.rgb(255,255,255), 18, 0, -9, -9);
                effectBG_DropShadow.setInput(effectBG_DropShadowADD);

                effectBG_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(206,207,210), 18, 0, 9, 9);
                effectBG_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(255,255,255), 18, 0, -9, -9);
                effectBG_InnerShadow.setInput(effectBG_InnerShadowADD);

                if (tColor == 1) {

                    color2 = "#007aff";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,104,217), 18, 0, 9, 9);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,140,255), 18, 0, -9, -9);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,104,217), 18, 0, 9, 9);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,140,255), 18, 0, -9, -9);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBG = getClass().getResourceAsStream("../../resources/svg/log-out/log-out_dblue.svg");
                    svgFileYes = getClass().getResourceAsStream("../../resources/svg/check/check.svg");
                    svgFileYes_Hover = getClass().getResourceAsStream("../../resources/svg/check/check_dblue.svg");
                    svgFileNo = getClass().getResourceAsStream("../../resources/svg/delete/delete.svg");
                    svgFileNo_Hover = getClass().getResourceAsStream("../../resources/svg/delete/delete_dblue.svg");

                    Group svgImageBG = loader.loadSvg(svgFileBG);
                    Group svgImageYes = loader.loadSvg(svgFileYes);
                    Group svgImageYes_Hover = loader.loadSvg(svgFileYes_Hover);
                    Group svgImageNo = loader.loadSvg(svgFileNo);
                    Group svgImageNo_Hover = loader.loadSvg(svgFileNo_Hover);

                    svgImageBG.setScaleX(.3);
                    svgImageBG.setScaleY(.3);

                    svgImageYes.setScaleX(.1);
                    svgImageYes.setScaleY(.1);

                    svgImageYes_Hover.setScaleX(.1);
                    svgImageYes_Hover.setScaleY(.1);

                    svgImageNo.setScaleX(.09);
                    svgImageNo.setScaleY(.09);

                    svgImageNo_Hover.setScaleX(.09);
                    svgImageNo_Hover.setScaleY(.09);

                    Group svgIconBG = new Group(svgImageBG);
                    Group svgIconYes = new Group(svgImageYes);
                    Group svgIconYes_Hover = new Group(svgImageYes_Hover);
                    Group svgIconNo = new Group(svgImageNo);
                    Group svgIconNo_Hover = new Group(svgImageNo_Hover);

                    B1.setGraphic(svgIconBG);
                    yes.setGraphic(svgIconYes);
                    no.setGraphic(svgIconNo);

                    yes.addEventHandler(MouseEvent.MOUSE_ENTERED,e->{
                        yes.setGraphic(svgIconYes_Hover);
                        yes.setTextFill(Color.web("#004fcb"));
                        yes.setEffect(effectC_DropShadow);
                    });
                    yes.addEventHandler(MouseEvent.MOUSE_EXITED,e->{
                        yes.setGraphic(svgIconYes);
                        yes.setTextFill(Color.web("#c0c2c4"));
                        yes.setEffect(null);
                    });
                    no.addEventHandler(MouseEvent.MOUSE_ENTERED,e->{
                        no.setGraphic(svgIconNo_Hover);
                        no.setTextFill(Color.web("#004fcb"));
                        no.setEffect(effectC_DropShadow);
                    });
                    no.addEventHandler(MouseEvent.MOUSE_EXITED,e->{
                        no.setGraphic(svgIconNo);
                        no.setTextFill(Color.web("#c0c2c4"));
                        no.setEffect(null);
                    });


                }
                else if (tColor == 2) {

                    color2 = "#fff44f";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.web("#d9cf43"), 18, 0, 9, 9);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.web("#ffff5b"), 18, 0, -9, -9);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.web("#d9cf43"), 18, 0, 9, 9);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.web("#ffff5b"), 18, 0, -9, -9);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);


                    svgFileBG = getClass().getResourceAsStream("../../resources/svg/log-out/log-out_dyellow.svg");
                    svgFileYes = getClass().getResourceAsStream("../../resources/svg/check/check.svg");
                    svgFileYes_Hover = getClass().getResourceAsStream("../../resources/svg/check/check_dyellow.svg");
                    svgFileNo = getClass().getResourceAsStream("../../resources/svg/delete/delete.svg");
                    svgFileNo_Hover = getClass().getResourceAsStream("../../resources/svg/delete/delete_dyellow.svg");

                    Group svgImageBG = loader.loadSvg(svgFileBG);
                    Group svgImageYes = loader.loadSvg(svgFileYes);
                    Group svgImageYes_Hover = loader.loadSvg(svgFileYes_Hover);
                    Group svgImageNo = loader.loadSvg(svgFileNo);
                    Group svgImageNo_Hover = loader.loadSvg(svgFileNo_Hover);

                    svgImageBG.setScaleX(.3);
                    svgImageBG.setScaleY(.3);

                    svgImageYes.setScaleX(.1);
                    svgImageYes.setScaleY(.1);

                    svgImageYes_Hover.setScaleX(.1);
                    svgImageYes_Hover.setScaleY(.1);

                    svgImageNo.setScaleX(.09);
                    svgImageNo.setScaleY(.09);

                    svgImageNo_Hover.setScaleX(.09);
                    svgImageNo_Hover.setScaleY(.09);

                    Group svgIconBG = new Group(svgImageBG);
                    Group svgIconYes = new Group(svgImageYes);
                    Group svgIconYes_Hover = new Group(svgImageYes_Hover);
                    Group svgIconNo = new Group(svgImageNo);
                    Group svgIconNo_Hover = new Group(svgImageNo_Hover);

                    B1.setGraphic(svgIconBG);
                    yes.setGraphic(svgIconYes);
                    no.setGraphic(svgIconNo);

                    yes.addEventHandler(MouseEvent.MOUSE_ENTERED,e->{
                        yes.setGraphic(svgIconYes_Hover);
                        yes.setTextFill(Color.web("#c9c208"));
                        yes.setEffect(effectC_DropShadow);
                    });
                    yes.addEventHandler(MouseEvent.MOUSE_EXITED,e->{
                        yes.setGraphic(svgIconYes);
                        yes.setTextFill(Color.web("#c0c2c4"));
                        yes.setEffect(null);
                    });
                    no.addEventHandler(MouseEvent.MOUSE_ENTERED,e->{
                        no.setGraphic(svgIconNo_Hover);
                        no.setTextFill(Color.web("#c9c208"));
                        no.setEffect(effectC_DropShadow);
                    });
                    no.addEventHandler(MouseEvent.MOUSE_EXITED,e->{
                        no.setGraphic(svgIconNo);
                        no.setTextFill(Color.web("#c0c2c4"));
                        no.setEffect(null);
                    });

                }
                else if (tColor == 3) {

                    color2 = "#00c853";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,200,83), 18, 0, 9, 9);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,230,95), 18, 0, -9, -9);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,200,83), 18, 0, 9, 9);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,230,95), 18, 0, -9, -9);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBG = getClass().getResourceAsStream("../../resources/svg/log-out/log-out_dgreen.svg");
                    svgFileYes = getClass().getResourceAsStream("../../resources/svg/check/check.svg");
                    svgFileYes_Hover = getClass().getResourceAsStream("../../resources/svg/check/check_dgreen.svg");
                    svgFileNo = getClass().getResourceAsStream("../../resources/svg/delete/delete.svg");
                    svgFileNo_Hover = getClass().getResourceAsStream("../../resources/svg/delete/delete_dgreen.svg");

                    Group svgImageBG = loader.loadSvg(svgFileBG);
                    Group svgImageYes = loader.loadSvg(svgFileYes);
                    Group svgImageYes_Hover = loader.loadSvg(svgFileYes_Hover);
                    Group svgImageNo = loader.loadSvg(svgFileNo);
                    Group svgImageNo_Hover = loader.loadSvg(svgFileNo_Hover);

                    svgImageBG.setScaleX(.3);
                    svgImageBG.setScaleY(.3);

                    svgImageYes.setScaleX(.1);
                    svgImageYes.setScaleY(.1);

                    svgImageYes_Hover.setScaleX(.1);
                    svgImageYes_Hover.setScaleY(.1);

                    svgImageNo.setScaleX(.09);
                    svgImageNo.setScaleY(.09);

                    svgImageNo_Hover.setScaleX(.09);
                    svgImageNo_Hover.setScaleY(.09);

                    Group svgIconBG = new Group(svgImageBG);
                    Group svgIconYes = new Group(svgImageYes);
                    Group svgIconYes_Hover = new Group(svgImageYes_Hover);
                    Group svgIconNo = new Group(svgImageNo);
                    Group svgIconNo_Hover = new Group(svgImageNo_Hover);

                    B1.setGraphic(svgIconBG);
                    yes.setGraphic(svgIconYes);
                    no.setGraphic(svgIconNo);

                    yes.addEventHandler(MouseEvent.MOUSE_ENTERED,e->{
                        yes.setGraphic(svgIconYes_Hover);
                        yes.setTextFill(Color.web("#006500"));
                        yes.setEffect(effectC_DropShadow);
                    });
                    yes.addEventHandler(MouseEvent.MOUSE_EXITED,e->{
                        yes.setGraphic(svgIconYes);
                        yes.setTextFill(Color.web("#c0c2c4"));
                        yes.setEffect(null);
                    });
                    no.addEventHandler(MouseEvent.MOUSE_ENTERED,e->{
                        no.setGraphic(svgIconNo_Hover);
                        no.setTextFill(Color.web("#006500"));
                        no.setEffect(effectC_DropShadow);
                    });
                    no.addEventHandler(MouseEvent.MOUSE_EXITED,e->{
                        no.setGraphic(svgIconNo);
                        no.setTextFill(Color.web("#c0c2c4"));
                        no.setEffect(null);
                    });

                }
                else if (tColor == 4) {

                    color2 = "#d50000";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(181,0,0), 18, 0, 9, 9);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(245,0,0), 18, 0, -9, -9);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(181,0,0), 18, 0, 9, 9);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(245,0,0), 18, 0, -9, -9);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);


                    svgFileBG = getClass().getResourceAsStream("../../resources/svg/log-out/log-out_dred.svg");
                    svgFileYes = getClass().getResourceAsStream("../../resources/svg/check/check.svg");
                    svgFileYes_Hover = getClass().getResourceAsStream("../../resources/svg/check/check_dred.svg");
                    svgFileNo = getClass().getResourceAsStream("../../resources/svg/delete/delete.svg");
                    svgFileNo_Hover = getClass().getResourceAsStream("../../resources/svg/delete/delete_dred.svg");

                    Group svgImageBG = loader.loadSvg(svgFileBG);
                    Group svgImageYes = loader.loadSvg(svgFileYes);
                    Group svgImageYes_Hover = loader.loadSvg(svgFileYes_Hover);
                    Group svgImageNo = loader.loadSvg(svgFileNo);
                    Group svgImageNo_Hover = loader.loadSvg(svgFileNo_Hover);

                    svgImageBG.setScaleX(.3);
                    svgImageBG.setScaleY(.3);

                    svgImageYes.setScaleX(.1);
                    svgImageYes.setScaleY(.1);

                    svgImageYes_Hover.setScaleX(.1);
                    svgImageYes_Hover.setScaleY(.1);

                    svgImageNo.setScaleX(.09);
                    svgImageNo.setScaleY(.09);

                    svgImageNo_Hover.setScaleX(.09);
                    svgImageNo_Hover.setScaleY(.09);

                    Group svgIconBG = new Group(svgImageBG);
                    Group svgIconYes = new Group(svgImageYes);
                    Group svgIconYes_Hover = new Group(svgImageYes_Hover);
                    Group svgIconNo = new Group(svgImageNo);
                    Group svgIconNo_Hover = new Group(svgImageNo_Hover);

                    B1.setGraphic(svgIconBG);
                    yes.setGraphic(svgIconYes);
                    no.setGraphic(svgIconNo);

                    yes.addEventHandler(MouseEvent.MOUSE_ENTERED,e->{
                        yes.setGraphic(svgIconYes_Hover);
                        yes.setTextFill(Color.web("#9b0000"));
                        yes.setEffect(effectC_DropShadow);
                    });
                    yes.addEventHandler(MouseEvent.MOUSE_EXITED,e->{
                        yes.setGraphic(svgIconYes);
                        yes.setTextFill(Color.web("#c0c2c4"));
                        yes.setEffect(null);
                    });
                    no.addEventHandler(MouseEvent.MOUSE_ENTERED,e->{
                        no.setGraphic(svgIconNo_Hover);
                        no.setTextFill(Color.web("#9b0000"));
                        no.setEffect(effectC_DropShadow);
                    });
                    no.addEventHandler(MouseEvent.MOUSE_EXITED,e->{
                        no.setGraphic(svgIconNo);
                        no.setTextFill(Color.web("#c0c2c4"));
                        no.setEffect(null);
                    });

                }

            }
            else if (theme == 2) {

                color = "#181818";

                effectBG_DropShadowADD = new DropShadow(BlurType.GAUSSIAN, Color.rgb(20,20,20), 18, 0, 9, 9);
                effectBG_DropShadow = new DropShadow(BlurType.GAUSSIAN, Color.rgb(28,28,28), 18, 0, -9, -9);
                effectBG_DropShadow.setInput(effectBG_DropShadowADD);

                effectBG_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(20,20,20), 18, 0, 9, 9);
                effectBG_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(20,20,20), 18, 0, -9, -9);
                effectBG_InnerShadow.setInput(effectBG_InnerShadowADD);

                if (tColor == 1) {

                    color2 = "#004fcb";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,67,173), 24, 0, 9, 9);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,91,233), 24, 0, -9, -9);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,67,173), 18, 0, 9, 9);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,91,233), 18, 0, -9, -9);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBG = getClass().getResourceAsStream("../../resources/svg/log-out/log-out_blue.svg");
                    svgFileYes = getClass().getResourceAsStream("../../resources/svg/check/check_d.svg");
                    svgFileYes_Hover = getClass().getResourceAsStream("../../resources/svg/check/check_blue.svg");
                    svgFileNo = getClass().getResourceAsStream("../../resources/svg/delete/delete_d.svg");
                    svgFileNo_Hover = getClass().getResourceAsStream("../../resources/svg/delete/delete_blue.svg");

                    Group svgImageBG = loader.loadSvg(svgFileBG);
                    Group svgImageYes = loader.loadSvg(svgFileYes);
                    Group svgImageYes_Hover = loader.loadSvg(svgFileYes_Hover);
                    Group svgImageNo = loader.loadSvg(svgFileNo);
                    Group svgImageNo_Hover = loader.loadSvg(svgFileNo_Hover);

                    svgImageBG.setScaleX(.3);
                    svgImageBG.setScaleY(.3);

                    svgImageYes.setScaleX(.1);
                    svgImageYes.setScaleY(.1);

                    svgImageYes_Hover.setScaleX(.1);
                    svgImageYes_Hover.setScaleY(.1);

                    svgImageNo.setScaleX(.09);
                    svgImageNo.setScaleY(.09);

                    svgImageNo_Hover.setScaleX(.09);
                    svgImageNo_Hover.setScaleY(.09);

                    Group svgIconBG = new Group(svgImageBG);
                    Group svgIconYes = new Group(svgImageYes);
                    Group svgIconYes_Hover = new Group(svgImageYes_Hover);
                    Group svgIconNo = new Group(svgImageNo);
                    Group svgIconNo_Hover = new Group(svgImageNo_Hover);

                    B1.setGraphic(svgIconBG);
                    yes.setGraphic(svgIconYes);
                    no.setGraphic(svgIconNo);

                    yes.addEventHandler(MouseEvent.MOUSE_ENTERED,e->{
                        yes.setGraphic(svgIconYes_Hover);
                        yes.setTextFill(Color.web("#007aff"));
                        yes.setEffect(effectC_DropShadow);
                    });
                    yes.addEventHandler(MouseEvent.MOUSE_EXITED,e->{
                        yes.setGraphic(svgIconYes);
                        yes.setTextFill(Color.web("#3E3E3E"));
                        yes.setEffect(null);
                    });
                    no.addEventHandler(MouseEvent.MOUSE_ENTERED,e->{
                        no.setGraphic(svgIconNo_Hover);
                        no.setTextFill(Color.web("#007aff"));
                        no.setEffect(effectC_DropShadow);
                    });
                    no.addEventHandler(MouseEvent.MOUSE_EXITED,e->{
                        no.setGraphic(svgIconNo);
                        no.setTextFill(Color.web("#3E3E3E"));
                        no.setEffect(null);
                    });

                }
                else if (tColor == 2) {

                    color2 = "#c9c208";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.web("#aba507"), 18, 0, 9, 9);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.web("#e7df09"), 18, 0, -9, -9);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.web("#aba507"), 18, 0, 9, 9);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.web("#e7df09"), 18, 0, -9, -9);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);


                    svgFileBG = getClass().getResourceAsStream("../../resources/svg/log-out/log-out_yellow.svg");
                    svgFileYes = getClass().getResourceAsStream("../../resources/svg/check/check_d.svg");
                    svgFileYes_Hover = getClass().getResourceAsStream("../../resources/svg/check/check_yellow.svg");
                    svgFileNo = getClass().getResourceAsStream("../../resources/svg/delete/delete_d.svg");
                    svgFileNo_Hover = getClass().getResourceAsStream("../../resources/svg/delete/delete_yellow.svg");

                    Group svgImageBG = loader.loadSvg(svgFileBG);
                    Group svgImageYes = loader.loadSvg(svgFileYes);
                    Group svgImageYes_Hover = loader.loadSvg(svgFileYes_Hover);
                    Group svgImageNo = loader.loadSvg(svgFileNo);
                    Group svgImageNo_Hover = loader.loadSvg(svgFileNo_Hover);

                    svgImageBG.setScaleX(.3);
                    svgImageBG.setScaleY(.3);

                    svgImageYes.setScaleX(.1);
                    svgImageYes.setScaleY(.1);

                    svgImageYes_Hover.setScaleX(.1);
                    svgImageYes_Hover.setScaleY(.1);

                    svgImageNo.setScaleX(.09);
                    svgImageNo.setScaleY(.09);

                    svgImageNo_Hover.setScaleX(.09);
                    svgImageNo_Hover.setScaleY(.09);

                    Group svgIconBG = new Group(svgImageBG);
                    Group svgIconYes = new Group(svgImageYes);
                    Group svgIconYes_Hover = new Group(svgImageYes_Hover);
                    Group svgIconNo = new Group(svgImageNo);
                    Group svgIconNo_Hover = new Group(svgImageNo_Hover);

                    B1.setGraphic(svgIconBG);
                    yes.setGraphic(svgIconYes);
                    no.setGraphic(svgIconNo);

                    yes.addEventHandler(MouseEvent.MOUSE_ENTERED,e->{
                        yes.setGraphic(svgIconYes_Hover);
                        yes.setTextFill(Color.web("#fff44f"));
                        yes.setEffect(effectC_DropShadow);
                    });
                    yes.addEventHandler(MouseEvent.MOUSE_EXITED,e->{
                        yes.setGraphic(svgIconYes);
                        yes.setTextFill(Color.web("#3E3E3E"));
                        yes.setEffect(null);
                    });
                    no.addEventHandler(MouseEvent.MOUSE_ENTERED,e->{
                        no.setGraphic(svgIconNo_Hover);
                        no.setTextFill(Color.web("#fff44f"));
                        no.setEffect(effectC_DropShadow);
                    });
                    no.addEventHandler(MouseEvent.MOUSE_EXITED,e->{
                        no.setGraphic(svgIconNo);
                        no.setTextFill(Color.web("#3E3E3E"));
                        no.setEffect(null);
                    });

                }
                else if (tColor == 3) {

                    color2 = "#006500";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,86,0), 18, 0, 9, 9);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,116,0), 18, 0, -9, -9);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,86,0), 18, 0, 9, 9);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,116,0), 18, 0, -9, -9);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);


                    svgFileBG = getClass().getResourceAsStream("../../resources/svg/log-out/log-out_green.svg");
                    svgFileYes = getClass().getResourceAsStream("../../resources/svg/check/check_d.svg");
                    svgFileYes_Hover = getClass().getResourceAsStream("../../resources/svg/check/check_green.svg");
                    svgFileNo = getClass().getResourceAsStream("../../resources/svg/delete/delete_d.svg");
                    svgFileNo_Hover = getClass().getResourceAsStream("../../resources/svg/delete/delete_green.svg");

                    Group svgImageBG = loader.loadSvg(svgFileBG);
                    Group svgImageYes = loader.loadSvg(svgFileYes);
                    Group svgImageYes_Hover = loader.loadSvg(svgFileYes_Hover);
                    Group svgImageNo = loader.loadSvg(svgFileNo);
                    Group svgImageNo_Hover = loader.loadSvg(svgFileNo_Hover);

                    svgImageBG.setScaleX(.3);
                    svgImageBG.setScaleY(.3);

                    svgImageYes.setScaleX(.1);
                    svgImageYes.setScaleY(.1);

                    svgImageYes_Hover.setScaleX(.1);
                    svgImageYes_Hover.setScaleY(.1);

                    svgImageNo.setScaleX(.09);
                    svgImageNo.setScaleY(.09);

                    svgImageNo_Hover.setScaleX(.09);
                    svgImageNo_Hover.setScaleY(.09);

                    Group svgIconBG = new Group(svgImageBG);
                    Group svgIconYes = new Group(svgImageYes);
                    Group svgIconYes_Hover = new Group(svgImageYes_Hover);
                    Group svgIconNo = new Group(svgImageNo);
                    Group svgIconNo_Hover = new Group(svgImageNo_Hover);

                    B1.setGraphic(svgIconBG);
                    yes.setGraphic(svgIconYes);
                    no.setGraphic(svgIconNo);

                    yes.addEventHandler(MouseEvent.MOUSE_ENTERED,e->{
                        yes.setGraphic(svgIconYes_Hover);
                        yes.setTextFill(Color.web("#00c853"));
                        yes.setEffect(effectC_DropShadow);
                    });
                    yes.addEventHandler(MouseEvent.MOUSE_EXITED,e->{
                        yes.setGraphic(svgIconYes);
                        yes.setTextFill(Color.web("#3E3E3E"));
                        yes.setEffect(null);
                    });
                    no.addEventHandler(MouseEvent.MOUSE_ENTERED,e->{
                        no.setGraphic(svgIconNo_Hover);
                        no.setTextFill(Color.web("#00c853"));
                        no.setEffect(effectC_DropShadow);
                    });
                    no.addEventHandler(MouseEvent.MOUSE_EXITED,e->{
                        no.setGraphic(svgIconNo);
                        no.setTextFill(Color.web("#3E3E3E"));
                        no.setEffect(null);
                    });

                }
                else if (tColor == 4) {

                    color2 = "#9b0000";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(155,0,0), 18, 0, 9, 9);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(178,0,0), 18, 0, -9, -9);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(155,0,0), 18, 0, 9, 9);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(178,0,0), 18, 0, -9, -9);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);


                    svgFileBG = getClass().getResourceAsStream("../../resources/svg/log-out/log-out_red.svg");
                    svgFileYes = getClass().getResourceAsStream("../../resources/svg/check/check_d.svg");
                    svgFileYes_Hover = getClass().getResourceAsStream("../../resources/svg/check/check_red.svg");
                    svgFileNo = getClass().getResourceAsStream("../../resources/svg/delete/delete_d.svg");
                    svgFileNo_Hover = getClass().getResourceAsStream("../../resources/svg/delete/delete_red.svg");

                    Group svgImageBG = loader.loadSvg(svgFileBG);
                    Group svgImageYes = loader.loadSvg(svgFileYes);
                    Group svgImageYes_Hover = loader.loadSvg(svgFileYes_Hover);
                    Group svgImageNo = loader.loadSvg(svgFileNo);
                    Group svgImageNo_Hover = loader.loadSvg(svgFileNo_Hover);

                    svgImageBG.setScaleX(.3);
                    svgImageBG.setScaleY(.3);

                    svgImageYes.setScaleX(.1);
                    svgImageYes.setScaleY(.1);

                    svgImageYes_Hover.setScaleX(.1);
                    svgImageYes_Hover.setScaleY(.1);

                    svgImageNo.setScaleX(.09);
                    svgImageNo.setScaleY(.09);

                    svgImageNo_Hover.setScaleX(.09);
                    svgImageNo_Hover.setScaleY(.09);

                    Group svgIconBG = new Group(svgImageBG);
                    Group svgIconYes = new Group(svgImageYes);
                    Group svgIconYes_Hover = new Group(svgImageYes_Hover);
                    Group svgIconNo = new Group(svgImageNo);
                    Group svgIconNo_Hover = new Group(svgImageNo_Hover);

                    B1.setGraphic(svgIconBG);
                    yes.setGraphic(svgIconYes);
                    no.setGraphic(svgIconNo);

                    yes.addEventHandler(MouseEvent.MOUSE_ENTERED,e->{
                        yes.setGraphic(svgIconYes_Hover);
                        yes.setTextFill(Color.web("#d50000"));
                        yes.setEffect(effectC_DropShadow);
                    });
                    yes.addEventHandler(MouseEvent.MOUSE_EXITED,e->{
                        yes.setGraphic(svgIconYes);
                        yes.setTextFill(Color.web("#3E3E3E"));
                        yes.setEffect(null);
                    });
                    no.addEventHandler(MouseEvent.MOUSE_ENTERED,e->{
                        no.setGraphic(svgIconNo_Hover);
                        no.setTextFill(Color.web("#d50000"));
                        no.setEffect(effectC_DropShadow);
                    });
                    no.addEventHandler(MouseEvent.MOUSE_EXITED,e->{
                        no.setGraphic(svgIconNo);
                        no.setTextFill(Color.web("#3E3E3E"));
                        no.setEffect(null);
                    });

                }

            }

        }

    }

    @FXML
    private void yesClicked(){

        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        Platform.exit();
    }

    @FXML
    private void noClicked() {

        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        Stage dialog = (Stage) no.getScene().getWindow();

        Parent root = dialog.getOwner().getScene().getRoot();
        root.setEffect(null);

        dialog.close();
    }


}