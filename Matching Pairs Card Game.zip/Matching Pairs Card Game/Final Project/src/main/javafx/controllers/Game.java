package main.javafx.controllers;

import javafx.animation.FadeTransition;
import javafx.animation.KeyFrame;
import javafx.animation.ScaleTransition;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.effect.BlurType;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.effect.InnerShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.media.AudioClip;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;
import main.javafx.model.Card;
import main.javafx.model.GameMode;
import main.javafx.model.Score;
import main.javafx.util.SvgLoader;

import java.io.*;
import java.util.*;

public class  Game {

    @FXML
    private Button backButton,b1,b2,b3,b11,b21;

    @FXML
    private Label l1,l2,l3,l4;

    public GameMode gameMode;
    public ArrayList<ImageView> imageViews,foundCards,seenImageViewsElephant,seenImageViewsKangaroo;
    public ArrayList<Card> cards,seenCardsElephant,seenCardsKangaroo;

    private Image theme;
    private int clicks = 0,clicks1 = 0,moves1,moves2,moves3,moves4;
    public int id1,id2,id3,id4;

    public ImageView imageView1,imageView2;
    public Card card1,card2,card3,card4;

    private Properties properties = new Properties();
    private Properties properties2 = new Properties();
    private Properties properties3 = new Properties();

    private InputStream input = null;
    private InputStream input3 = null;
    private OutputStream output = null;
    private OutputStream output3 = null;
    private String word1,word2;
    private int b111 = 0,p=0;
    final SvgLoader loader = new SvgLoader();

    DropShadow effectBG_DropShadow,effectC_DropShadowADD,effectC_DropShadow,effectBG_DropShadowADD;

    InnerShadow effectBG_InnerShadowADD,effectBG_InnerShadow,effectC_InnerShadowADD,effectC_InnerShadow;
    InputStream svgFileBack,svgFileBack_Hover,svgFileHome,svgFileHome_Hover,svgFileHome1,svgFileHome1_Hover,svgFileRetry,svgFileRetry_Hover,svgFileRetry1,svgFileRetry1_Hover,svgFilePause,svgFilePause_Hover,svgFileMenu,svgFileMenu_Hover;

    String color,color2;

    @FXML
    private GridPane grid,grid2,grid21,Panelex,Panelex2;
    @FXML
    private BorderPane gg11;
    public Score score;
    public Score score2;
    public Score score3;
    public Score score4;
    @FXML
    private Label Moves,foundCardsLabel;

    public Boolean cardsMatch;
    private MediaPlayer mediaPlayer;

    public Game(){
        gameMode = new GameMode();
        imageViews = new ArrayList<>();
        cards = new ArrayList<>();
        foundCards = new ArrayList<>();
        seenImageViewsElephant = new ArrayList<>();
        seenCardsElephant = new ArrayList<>();
        seenImageViewsKangaroo = new ArrayList<>();
        seenCardsKangaroo = new ArrayList<>();
        score= new Score();
        score2= new Score();
        score3= new Score();
        score4= new Score();
        cardsMatch = false;
        Media buttonSound = new Media(new File("src/main/resources/Sounds/buttonSound.wav").toURI().toString());
        mediaPlayer = new MediaPlayer(buttonSound);
    }

    @FXML
    private void initialize() throws IOException{
        File f2 =new File("score.properties");
        File f1 =new File("config.properties");

        if(f1.exists()){
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            int theme = Integer.parseInt(properties.getProperty("TMode"));
            int tColor = Integer.parseInt(properties.getProperty("TColor"));


            if (width==999){

                backButton.setPrefSize(64,64);

                if (theme==1){

                    color = "#f3f5f7";

                    if (tColor==1){

                        color2 = "#007aff";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#c0c2c4"));
                        b11.setTextFill(Color.web("#c0c2c4"));
                        b2.setTextFill(Color.web("#c0c2c4"));
                        b21.setTextFill(Color.web("#c0c2c4"));
                        b3.setTextFill(Color.web("#c0c2c4"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+";");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==2){

                        color2 = "#fff44f";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#c0c2c4"));
                        b11.setTextFill(Color.web("#c0c2c4"));
                        b2.setTextFill(Color.web("#c0c2c4"));
                        b21.setTextFill(Color.web("#c0c2c4"));
                        b3.setTextFill(Color.web("#c0c2c4"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+";");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==3){

                        color2 = "#00c853";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#c0c2c4"));
                        b11.setTextFill(Color.web("#c0c2c4"));
                        b2.setTextFill(Color.web("#c0c2c4"));
                        b21.setTextFill(Color.web("#c0c2c4"));
                        b3.setTextFill(Color.web("#c0c2c4"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+";");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==4){

                        color2 = "#d50000";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#c0c2c4"));
                        b11.setTextFill(Color.web("#c0c2c4"));
                        b2.setTextFill(Color.web("#c0c2c4"));
                        b21.setTextFill(Color.web("#c0c2c4"));
                        b3.setTextFill(Color.web("#c0c2c4"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+";");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }

                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));
                    Panelex.setStyle("-fx-background-color: "+color+"; -fx-background-radius:  0 0 0 34;");
                    Panelex2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 0 0;");

                }
                else if (theme==2){

                    color = "#181818";

                    if (tColor==1){

                        color2 = "#004fcb";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#3E3E3E"));
                        b11.setTextFill(Color.web("#3E3E3E"));
                        b2.setTextFill(Color.web("#3E3E3E"));
                        b21.setTextFill(Color.web("#3E3E3E"));
                        b3.setTextFill(Color.web("#3E3E3E"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }
                    else if (tColor==2){

                        color2 = "#c9c208";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#3E3E3E"));
                        b11.setTextFill(Color.web("#3E3E3E"));
                        b2.setTextFill(Color.web("#3E3E3E"));
                        b21.setTextFill(Color.web("#3E3E3E"));
                        b3.setTextFill(Color.web("#3E3E3E"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+";");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==3){

                        color2 = "#006500";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#3E3E3E"));
                        b11.setTextFill(Color.web("#3E3E3E"));
                        b2.setTextFill(Color.web("#3E3E3E"));
                        b21.setTextFill(Color.web("#3E3E3E"));
                        b3.setTextFill(Color.web("#3E3E3E"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+";");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==4){
                        color2 = "#9b0000";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#3E3E3E"));
                        b11.setTextFill(Color.web("#3E3E3E"));
                        b2.setTextFill(Color.web("#3E3E3E"));
                        b21.setTextFill(Color.web("#3E3E3E"));
                        b3.setTextFill(Color.web("#3E3E3E"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+";");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }

                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));
                    Panelex.setStyle("-fx-background-color: "+color+"; -fx-background-radius:  0 0 0 34;");
                    Panelex2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 0 0;");

                }

            }
            else if (width==1600){

                backButton.setPrefSize(64,64);

                if (theme==1){

                    color = "#f3f5f7";

                    if (tColor==1){

                        color2 = "#007aff";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#c0c2c4"));
                        b11.setTextFill(Color.web("#c0c2c4"));
                        b2.setTextFill(Color.web("#c0c2c4"));
                        b21.setTextFill(Color.web("#c0c2c4"));
                        b3.setTextFill(Color.web("#c0c2c4"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }
                    else if (tColor==2){

                        color2 = "#fff44f";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#c0c2c4"));
                        b11.setTextFill(Color.web("#c0c2c4"));
                        b2.setTextFill(Color.web("#c0c2c4"));
                        b21.setTextFill(Color.web("#c0c2c4"));
                        b3.setTextFill(Color.web("#c0c2c4"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }
                    else if (tColor==3){

                        color2 = "#00c853";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#c0c2c4"));
                        b11.setTextFill(Color.web("#c0c2c4"));
                        b2.setTextFill(Color.web("#c0c2c4"));
                        b21.setTextFill(Color.web("#c0c2c4"));
                        b3.setTextFill(Color.web("#c0c2c4"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }
                    else if (tColor==4){

                        color2 = "#d50000";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#c0c2c4"));
                        b11.setTextFill(Color.web("#c0c2c4"));
                        b2.setTextFill(Color.web("#c0c2c4"));
                        b21.setTextFill(Color.web("#c0c2c4"));
                        b3.setTextFill(Color.web("#c0c2c4"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }

                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));
                    Panelex.setStyle("-fx-background-color: "+color+"; -fx-background-radius:  0 0 0 34;");
                    Panelex2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 34 0;");

                }
                else if (theme==2){

                    color = "#181818";

                    if (tColor==1){

                        color2 = "#004fcb";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#3E3E3E"));
                        b11.setTextFill(Color.web("#3E3E3E"));
                        b2.setTextFill(Color.web("#3E3E3E"));
                        b21.setTextFill(Color.web("#3E3E3E"));
                        b3.setTextFill(Color.web("#3E3E3E"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }
                    else if (tColor==2){

                        color2 = "#c9c208";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#3E3E3E"));
                        b11.setTextFill(Color.web("#3E3E3E"));
                        b2.setTextFill(Color.web("#3E3E3E"));
                        b21.setTextFill(Color.web("#3E3E3E"));
                        b3.setTextFill(Color.web("#3E3E3E"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }
                    else if (tColor==3){

                        color2 = "#006500";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#3E3E3E"));
                        b11.setTextFill(Color.web("#3E3E3E"));
                        b2.setTextFill(Color.web("#3E3E3E"));
                        b21.setTextFill(Color.web("#3E3E3E"));
                        b3.setTextFill(Color.web("#3E3E3E"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }
                    else if (tColor==4){
                        color2 = "#9b0000";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#3E3E3E"));
                        b11.setTextFill(Color.web("#3E3E3E"));
                        b2.setTextFill(Color.web("#3E3E3E"));
                        b21.setTextFill(Color.web("#3E3E3E"));
                        b3.setTextFill(Color.web("#3E3E3E"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }

                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));
                    Panelex.setStyle("-fx-background-color: "+color+"; -fx-background-radius:  0 0 0 34;");
                    Panelex2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 34 0;");

                }

            }
            else if (width==1280){

                if (theme==1){

                    color = "#f3f5f7";

                    if (tColor==1){

                        color2 = "#007aff";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#c0c2c4"));
                        b11.setTextFill(Color.web("#c0c2c4"));
                        b2.setTextFill(Color.web("#c0c2c4"));
                        b21.setTextFill(Color.web("#c0c2c4"));
                        b3.setTextFill(Color.web("#c0c2c4"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }
                    else if (tColor==2){

                        color2 = "#fff44f";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#c0c2c4"));
                        b11.setTextFill(Color.web("#c0c2c4"));
                        b2.setTextFill(Color.web("#c0c2c4"));
                        b21.setTextFill(Color.web("#c0c2c4"));
                        b3.setTextFill(Color.web("#c0c2c4"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }
                    else if (tColor==3){

                        color2 = "#00c853";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#c0c2c4"));
                        b11.setTextFill(Color.web("#c0c2c4"));
                        b2.setTextFill(Color.web("#c0c2c4"));
                        b21.setTextFill(Color.web("#c0c2c4"));
                        b3.setTextFill(Color.web("#c0c2c4"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }
                    else if (tColor==4){

                        color2 = "#d50000";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#c0c2c4"));
                        b11.setTextFill(Color.web("#c0c2c4"));
                        b2.setTextFill(Color.web("#c0c2c4"));
                        b21.setTextFill(Color.web("#c0c2c4"));
                        b3.setTextFill(Color.web("#c0c2c4"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }

                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));
                    Panelex.setStyle("-fx-background-color: "+color+"; -fx-background-radius:  0 0 0 34;");
                    Panelex2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 34 0;");

                }
                else if (theme==2){

                    color = "#181818";

                    if (tColor==1){

                        color2 = "#004fcb";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#3E3E3E"));
                        b11.setTextFill(Color.web("#3E3E3E"));
                        b2.setTextFill(Color.web("#3E3E3E"));
                        b21.setTextFill(Color.web("#3E3E3E"));
                        b3.setTextFill(Color.web("#3E3E3E"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }
                    else if (tColor==2){

                        color2 = "#c9c208";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#3E3E3E"));
                        b11.setTextFill(Color.web("#3E3E3E"));
                        b2.setTextFill(Color.web("#3E3E3E"));
                        b21.setTextFill(Color.web("#3E3E3E"));
                        b3.setTextFill(Color.web("#3E3E3E"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }
                    else if (tColor==3){

                        color2 = "#006500";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#3E3E3E"));
                        b11.setTextFill(Color.web("#3E3E3E"));
                        b2.setTextFill(Color.web("#3E3E3E"));
                        b21.setTextFill(Color.web("#3E3E3E"));
                        b3.setTextFill(Color.web("#3E3E3E"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }
                    else if (tColor==4){
                        color2 = "#9b0000";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#3E3E3E"));
                        b11.setTextFill(Color.web("#3E3E3E"));
                        b2.setTextFill(Color.web("#3E3E3E"));
                        b21.setTextFill(Color.web("#3E3E3E"));
                        b3.setTextFill(Color.web("#3E3E3E"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }

                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));
                    Panelex.setStyle("-fx-background-color: "+color+"; -fx-background-radius:  0 0 0 34;");
                    Panelex2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 34 0;");

                }

            }

        }
        if(f2.exists()){
            InputStream input2 = new FileInputStream("score.properties");
            properties2.load(input2);

            moves1 = Integer.parseInt(properties2.getProperty("SingleModeHighScore1"));
            moves2 = Integer.parseInt(properties2.getProperty("SingleModeHighScore2"));
            moves3 = Integer.parseInt(properties2.getProperty("SingleModeHighScore3"));
            moves4 = Integer.parseInt(properties2.getProperty("SingleModeHighScore3"));
        }

        themeHandler();
    }
    private void themeHandler() throws IOException {

        ///
        FadeTransition fadeIn = new FadeTransition();//Back button
        FadeTransition fadeIn2 = new FadeTransition();//BG-g
        FadeTransition fadeIn3 = new FadeTransition();//BG-g1
        FadeTransition fadeIn4 = new FadeTransition();//PANELex
        FadeTransition fadeIn4_1 = new FadeTransition();//PANELex2
        FadeTransition fadeIn5 = new FadeTransition();//l1
        FadeTransition fadeIn5_1 = new FadeTransition();//l2
        FadeTransition fadeIn5_2 = new FadeTransition();//l3
        FadeTransition fadeIn5_3 = new FadeTransition();//l4
        FadeTransition fadeIn6 = new FadeTransition();//b11
        FadeTransition fadeIn6_1 = new FadeTransition();//b21
        FadeTransition fadeIn7 = new FadeTransition();//b1
        FadeTransition fadeIn7_1 = new FadeTransition();//b2
        FadeTransition fadeIn7_2 = new FadeTransition();//b3
        ////

        FadeTransition fadeIn8 = new FadeTransition();//lt1
        FadeTransition fadeIn8_1 = new FadeTransition();//lt2
        FadeTransition fadeIn9 = new FadeTransition();//r1
        FadeTransition fadeIn9_1 = new FadeTransition();//r2
        FadeTransition fadeIn10 = new FadeTransition();//back
        FadeTransition fadeIn11 = new FadeTransition();//l2

        ///
        FadeTransition fadeOut = new FadeTransition();//BG
        FadeTransition fadeOut2 = new FadeTransition();//BG
        FadeTransition fadeOut3 = new FadeTransition();//BG
        FadeTransition fadeOut4 = new FadeTransition();//PANELex1
        FadeTransition fadeOut4_1 = new FadeTransition();//PANELex2
        FadeTransition fadeOut5 = new FadeTransition();//l1
        FadeTransition fadeOut5_1 = new FadeTransition();//l2
        FadeTransition fadeOut5_2 = new FadeTransition();//l3
        FadeTransition fadeOut5_3 = new FadeTransition();//l4
        FadeTransition fadeOut6 = new FadeTransition();//b11
        FadeTransition fadeOut6_1 = new FadeTransition();//b21
        FadeTransition fadeOut7 = new FadeTransition();//b1
        FadeTransition fadeOut7_1 = new FadeTransition();//b2
        FadeTransition fadeOut7_2 = new FadeTransition();//b3
        ////
        FadeTransition fadeOut8 = new FadeTransition();//lt1
        FadeTransition fadeOut8_1 = new FadeTransition();//lt2
        FadeTransition fadeOut9 = new FadeTransition();//r1
        FadeTransition fadeOut9_1 = new FadeTransition();//r2
        FadeTransition fadeOut10 = new FadeTransition();//back
        FadeTransition fadeOut11 = new FadeTransition();//l2

        fadeIn.setDuration(Duration.millis(500));//BG
        fadeIn2.setDuration(Duration.millis(500));//BG
        fadeIn3.setDuration(Duration.millis(500));//BG
        fadeIn4.setDuration(Duration.millis(100));//PANEL1
        fadeIn4_1.setDuration(Duration.millis(100));//PANEL2
        fadeIn5.setDuration(Duration.millis(250));//l1
        fadeIn5_1.setDuration(Duration.millis(350));//l2
        fadeIn5_2.setDuration(Duration.millis(400));//l3
        fadeIn5_3.setDuration(Duration.millis(400));//l4
        fadeIn6.setDuration(Duration.millis(100));//b11
        fadeIn6_1.setDuration(Duration.millis(200));//b21
        fadeIn7.setDuration(Duration.millis(650));//b1
        fadeIn7_1.setDuration(Duration.millis(750));//b2
        fadeIn7_2.setDuration(Duration.millis(900));//b3

        fadeIn8.setDuration(Duration.millis(100));//lt1
        fadeIn8_1.setDuration(Duration.millis(60));//lt2
        fadeIn9.setDuration(Duration.millis(250));//r1
        fadeIn9_1.setDuration(Duration.millis(750));//r2
        fadeIn10.setDuration(Duration.millis(750));//back
        fadeIn11.setDuration(Duration.millis(750));//l2

        fadeOut.setDuration(Duration.millis(500));//BG
        fadeOut2.setDuration(Duration.millis(500));//BG
        fadeOut3.setDuration(Duration.millis(500));//BG
        fadeOut4.setDuration(Duration.millis(250));//PANEL1
        fadeOut4_1.setDuration(Duration.millis(250));//PANEL2
        fadeOut5.setDuration(Duration.millis(500));//l1
        fadeOut5_1.setDuration(Duration.millis(500));//l2
        fadeOut5_2.setDuration(Duration.millis(500));//l3
        fadeOut5_3.setDuration(Duration.millis(500));//l3
        fadeOut6.setDuration(Duration.millis(250));//b11
        fadeOut6_1.setDuration(Duration.millis(250));//b21
        fadeOut7.setDuration(Duration.millis(500));//b1
        fadeOut7_1.setDuration(Duration.millis(500));//b2
        fadeOut7_2.setDuration(Duration.millis(500));//b3

        fadeOut8.setDuration(Duration.millis(250));//lt1
        fadeOut8_1.setDuration(Duration.millis(500));//lt2
        fadeOut9.setDuration(Duration.millis(500));//r1
        fadeOut9_1.setDuration(Duration.millis(500));//r2
        fadeOut10.setDuration(Duration.millis(300));//back
        fadeOut11.setDuration(Duration.millis(300));//l2

        fadeIn.setFromValue(0);
        fadeIn.setToValue(10);
        fadeIn2.setFromValue(0);
        fadeIn2.setToValue(10);
        fadeIn3.setFromValue(0);
        fadeIn3.setToValue(10);
        fadeIn4.setFromValue(0);
        fadeIn4.setToValue(10);
        fadeIn4_1.setFromValue(0);
        fadeIn4_1.setToValue(10);
        fadeIn5.setFromValue(0);
        fadeIn5.setToValue(10);
        fadeIn5_1.setFromValue(0);
        fadeIn5_1.setToValue(10);
        fadeIn5_2.setFromValue(0);
        fadeIn5_2.setToValue(10);
        fadeIn5_3.setFromValue(0);
        fadeIn5_3.setToValue(10);
        fadeIn6.setFromValue(0);
        fadeIn6.setToValue(10);
        fadeIn6_1.setFromValue(0);
        fadeIn6_1.setToValue(10);
        fadeIn7.setFromValue(0);
        fadeIn7.setToValue(10);
        fadeIn7_1.setFromValue(0);
        fadeIn7_1.setToValue(10);
        fadeIn7_2.setFromValue(0);
        fadeIn7_2.setToValue(10);

        fadeIn8.setFromValue(0);
        fadeIn8.setToValue(10);
        fadeIn8_1.setFromValue(0);
        fadeIn8_1.setToValue(10);
        fadeIn9.setFromValue(0);
        fadeIn9.setToValue(10);
        fadeIn9_1.setFromValue(0);
        fadeIn9_1.setToValue(10);
        fadeIn10.setFromValue(0);
        fadeIn10.setToValue(10);
        fadeIn11.setFromValue(0);
        fadeIn11.setToValue(10);

        fadeOut.setFromValue(10);
        fadeOut.setToValue(0);
        fadeOut2.setFromValue(10);
        fadeOut2.setToValue(0);
        fadeOut3.setFromValue(10);
        fadeOut3.setToValue(0);
        fadeOut4.setFromValue(10);
        fadeOut4.setToValue(0);
        fadeOut4_1.setFromValue(10);
        fadeOut4_1.setToValue(0);
        fadeOut5.setFromValue(10);
        fadeOut5.setToValue(0);
        fadeOut5_1.setFromValue(10);
        fadeOut5_1.setToValue(0);
        fadeOut5_2.setFromValue(10);
        fadeOut5_2.setToValue(0);
        fadeOut5_3.setFromValue(10);
        fadeOut5_3.setToValue(0);
        fadeOut6.setFromValue(10);
        fadeOut6.setToValue(0);
        fadeOut6_1.setFromValue(10);
        fadeOut6_1.setToValue(0);
        fadeOut7.setFromValue(10);
        fadeOut7.setToValue(0);
        fadeOut7_1.setFromValue(10);
        fadeOut7_1.setToValue(0);
        fadeOut7_2.setFromValue(10);
        fadeOut7_2.setToValue(0);

        fadeOut8.setFromValue(10);
        fadeOut8.setToValue(0);
        fadeOut8_1.setFromValue(10);
        fadeOut8_1.setToValue(0);
        fadeOut9.setFromValue(10);
        fadeOut9.setToValue(0);
        fadeOut9_1.setFromValue(10);
        fadeOut9_1.setToValue(0);
        fadeOut10.setFromValue(10);
        fadeOut10.setToValue(0);
        fadeOut11.setFromValue(10);
        fadeOut11.setToValue(0);

        fadeIn.setCycleCount(1);
        fadeIn2.setCycleCount(1);
        fadeIn3.setCycleCount(1);
        fadeIn4.setCycleCount(1);
        fadeIn4_1.setCycleCount(1);
        fadeIn5.setCycleCount(1);
        fadeIn5_1.setCycleCount(1);
        fadeIn5_2.setCycleCount(1);
        fadeIn5_3.setCycleCount(1);
        fadeIn6.setCycleCount(1);
        fadeIn6_1.setCycleCount(1);
        fadeIn7.setCycleCount(1);
        fadeIn7_1.setCycleCount(1);
        fadeIn7_2.setCycleCount(1);

        fadeIn8.setCycleCount(1);
        fadeIn8_1.setCycleCount(1);
        fadeIn9.setCycleCount(1);
        fadeIn9_1.setCycleCount(1);
        fadeIn10.setCycleCount(1);
        fadeIn11.setCycleCount(1);

        fadeOut.setCycleCount(1);
        fadeOut2.setCycleCount(1);
        fadeOut3.setCycleCount(1);
        fadeOut4.setCycleCount(1);
        fadeOut4_1.setCycleCount(1);
        fadeOut5.setCycleCount(1);
        fadeOut5_1.setCycleCount(1);
        fadeOut5_2.setCycleCount(1);
        fadeOut5_3.setCycleCount(1);
        fadeOut6.setCycleCount(1);
        fadeOut6_1.setCycleCount(1);
        fadeOut7.setCycleCount(1);
        fadeOut7_1.setCycleCount(1);
        fadeOut7_2.setCycleCount(1);

        fadeOut8.setCycleCount(1);
        fadeOut8_1.setCycleCount(1);
        fadeOut9.setCycleCount(1);
        fadeOut9_1.setCycleCount(1);
        fadeOut10.setCycleCount(1);
        fadeOut11.setCycleCount(1);

        fadeIn.setNode(backButton);
        fadeIn2.setNode(grid);
        fadeIn3.setNode(grid2);
        fadeIn4.setNode(Panelex);
        fadeIn4_1.setNode(Panelex2);
        fadeIn5.setNode(l1);
        fadeIn5_1.setNode(l2);
        fadeIn5_2.setNode(l3);
        fadeIn5_3.setNode(l4);
        fadeIn6.setNode(b11);
        fadeIn6_1.setNode(b21);
        fadeIn7.setNode(b1);
        fadeIn7_1.setNode(b2);
        fadeIn7_2.setNode(b3);

        fadeOut.setNode(backButton);
        fadeOut2.setNode(grid);
        fadeOut3.setNode(grid2);
        fadeOut4.setNode(Panelex);
        fadeOut4_1.setNode(Panelex2);
        fadeOut5.setNode(l1);
        fadeOut5_1.setNode(l2);
        fadeOut5_2.setNode(l3);
        fadeOut5_3.setNode(l4);
        fadeOut6.setNode(b11);
        fadeOut6_1.setNode(b21);
        fadeOut7.setNode(b1);
        fadeOut7_1.setNode(b2);
        fadeOut7_2.setNode(b3);

        backButton.setVisible(false);
        grid.setVisible(false);
        Panelex.setVisible(false);
        Panelex2.setVisible(false);
        l1.setVisible(false);
        l2.setVisible(false);

        File f = new File("config.properties");
        if(f.exists()) {
            input = new FileInputStream("config.properties");
            properties.load(input);

            int menuSelected = Integer.parseInt(properties.getProperty("MenuSelected"));
            int theme = Integer.parseInt(properties.getProperty("TMode"));
            int tColor = Integer.parseInt(properties.getProperty("TColor"));

            if (menuSelected == 1){

                backButton.setVisible(true);
                grid.setVisible(true);
                Panelex.setVisible(true);
                Panelex2.setVisible(true);
                l1.setVisible(true);
                l2.setVisible(true);

                fadeIn.play();
                fadeIn2.play();
                fadeIn4.play();
                fadeIn4_1.play();
                fadeIn5.play();
                fadeIn5_1.play();

                output = new FileOutputStream("config.properties");
                properties.setProperty("MenuSelected", "2");
                properties.store(output, null);

            }

            if(theme==1){

                color = "#f3f5f7";

                effectBG_DropShadowADD = new DropShadow(BlurType.GAUSSIAN, Color.rgb(206,207,210), 36, 0, 9, 9);
                effectBG_DropShadow = new DropShadow(BlurType.GAUSSIAN, Color.rgb(255,255,255), 18, 0, -9, -9);
                effectBG_DropShadow.setInput(effectBG_DropShadowADD);

                effectBG_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(206,207,210), 18, 0, 9, 9);
                effectBG_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(255,255,255), 18, 0, -9, -9);
                effectBG_InnerShadow.setInput(effectBG_InnerShadowADD);

                if (tColor==1) {

                    color2 = "#007aff";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,104,217), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,140,255), 10, 0, -5, -5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,104,217), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,140,255), 10, 0, -5, -5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBack = getClass().getResourceAsStream("../../resources/svg/left_arrow_2/left-arrow.svg");//
                    svgFileBack_Hover = getClass().getResourceAsStream("../../resources/svg/left_arrow_2/left-arrow_dblue.svg");//

                    svgFileHome = getClass().getResourceAsStream("../../resources/svg/home/home.svg");//
                    svgFileHome_Hover = getClass().getResourceAsStream("../../resources/svg/home/home_dblue.svg");//

                    svgFileHome1 = getClass().getResourceAsStream("../../resources/svg/home/home.svg");//
                    svgFileHome1_Hover = getClass().getResourceAsStream("../../resources/svg/home/home_dblue.svg");//

                    svgFileRetry = getClass().getResourceAsStream("../../resources/svg/refresh/refresh.svg");//
                    svgFileRetry_Hover = getClass().getResourceAsStream("../../resources/svg/refresh/refresh_dblue.svg");//

                    svgFileRetry1 = getClass().getResourceAsStream("../../resources/svg/refresh/refresh.svg");//
                    svgFileRetry1_Hover = getClass().getResourceAsStream("../../resources/svg/refresh/refresh_dblue.svg");//

                    svgFilePause = getClass().getResourceAsStream("../../resources/svg/pause/pause.svg");//
                    svgFilePause_Hover = getClass().getResourceAsStream("../../resources/svg/pause/pause_dblue.svg");//

                    svgFileMenu = getClass().getResourceAsStream("../../resources/svg/menu/menu.svg");//
                    svgFileMenu_Hover = getClass().getResourceAsStream("../../resources/svg/menu/menu_dblue.svg");//

                    Group svgBack = loader.loadSvg(svgFileBack);
                    Group svgBack_Hover = loader.loadSvg(svgFileBack_Hover);
                    Group svgHome = loader.loadSvg(svgFileHome);
                    Group svgHome_Hover = loader.loadSvg(svgFileHome_Hover);
                    Group svgHome1 = loader.loadSvg(svgFileHome1);
                    Group svgHome1_Hover = loader.loadSvg(svgFileHome1_Hover);
                    Group svgRetry = loader.loadSvg(svgFileRetry);
                    Group svgRetry_Hover = loader.loadSvg(svgFileRetry_Hover);
                    Group svgRetry1 = loader.loadSvg(svgFileRetry1);
                    Group svgRetry1_Hover = loader.loadSvg(svgFileRetry1_Hover);
                    Group svgPause = loader.loadSvg(svgFilePause);
                    Group svgPause_Hover = loader.loadSvg(svgFilePause_Hover);
                    Group svgMenu = loader.loadSvg(svgFileMenu);
                    Group svgMenu_Hover = loader.loadSvg(svgFileMenu_Hover);

                    svgBack.setScaleX(.1);
                    svgBack.setScaleY(.1);
                    svgBack_Hover.setScaleX(.1);
                    svgBack_Hover.setScaleY(.1);
                    svgHome.setScaleX(.1);
                    svgHome.setScaleY(.1);
                    svgHome_Hover.setScaleX(.1);
                    svgHome_Hover.setScaleY(.1);
                    svgHome1.setScaleX(.1);
                    svgHome1.setScaleY(.1);
                    svgHome1_Hover.setScaleX(.1);
                    svgHome1_Hover.setScaleY(.1);
                    svgRetry.setScaleX(.1);
                    svgRetry.setScaleY(.1);
                    svgRetry_Hover.setScaleX(.1);
                    svgRetry_Hover.setScaleY(.1);
                    svgRetry1.setScaleX(.1);
                    svgRetry1.setScaleY(.1);
                    svgRetry1_Hover.setScaleX(.1);
                    svgRetry1_Hover.setScaleY(.1);
                    svgPause.setScaleX(.04);
                    svgPause.setScaleY(.04);
                    svgPause_Hover.setScaleX(.04);
                    svgPause_Hover.setScaleY(.04);
                    svgMenu.setScaleX(.04);
                    svgMenu.setScaleY(.04);
                    svgMenu_Hover.setScaleX(.04);
                    svgMenu_Hover.setScaleY(.04);

                    Group svgIconBack = new Group(svgBack);
                    Group svgIconBack_Hover = new Group(svgBack_Hover);
                    Group svgIconHome = new Group(svgHome);
                    Group svgIconHome_Hover = new Group(svgHome_Hover);
                    Group svgIconHome1 = new Group(svgHome1);
                    Group svgIconHome1_Hover = new Group(svgHome1_Hover);
                    Group svgIconRetry = new Group(svgRetry);
                    Group svgIconRetry_Hover = new Group(svgRetry_Hover);
                    Group svgIconRetry1 = new Group(svgRetry1);
                    Group svgIconRetry1_Hover = new Group(svgRetry1_Hover);
                    Group svgIconPause = new Group(svgPause);
                    Group svgIconPause_Hover = new Group(svgPause_Hover);
                    Group svgIconMenu = new Group(svgMenu);
                    Group svgIconMenu_Hover = new Group(svgMenu_Hover);

                    backButton.setGraphic(svgIconMenu);

                    b1.setGraphic(svgIconBack);
                    b2.setGraphic(svgIconRetry);
                    b3.setGraphic(svgIconHome);
                    b11.setGraphic(svgIconRetry1);
                    b21.setGraphic(svgIconHome1);
                    l4.setEffect(effectC_InnerShadow);
                    l3.setEffect(effectC_InnerShadow);

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        if (b111==0){

                            l1.setText("");
                            l2.setText("Pause");
                            backButton.setEffect(effectC_DropShadow);
                            backButton.setGraphic(svgIconPause_Hover);
                            backButton.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");

                        }else {


                            backButton.setGraphic(svgIconPause);

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        if (b111==0){

                            l1.setText("Memory");
                            l2.setText("Game");
                            backButton.setEffect(null);
                            backButton.setGraphic(svgIconMenu);
                            backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                        }else {

                            backButton.setEffect(null);
                            backButton.setGraphic(svgIconPause);

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        if (b111==0){
                            b111=1;
                            grid2.setVisible(true);
                            grid2.setDisable(false);

                            fadeOut.play();
                            fadeOut5.play();
                            fadeOut5_1.play();

                            fadeIn3.play();
                            fadeIn5_3.play();

                            fadeIn7.play();
                            fadeIn7_1.play();
                            fadeIn7_2.play();

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        fadeIn.play();

                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        backButton.setGraphic(svgIconPause);

                    });

                    b1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b1.setTextFill(Color.web("#004fcb"));
                        b1.setEffect(effectC_DropShadow);
                        b1.setGraphic(svgIconBack_Hover);

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b1.setTextFill(Color.web("#c0c2c4"));
                        b1.setEffect(null);
                        b1.setGraphic(svgIconBack);

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {
                        b111=0;
                        fadeIn.play();
                        fadeIn5.play();
                        fadeIn5_1.play();

                        fadeOut3.play();
                        fadeOut5_3.play();

                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                        grid2.setDisable(true);
                        backButton.setGraphic(svgIconMenu);
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                    });

                    b2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b2.setTextFill(Color.web("#004fcb"));
                        b2.setEffect(effectC_DropShadow);
                        b2.setGraphic(svgIconRetry_Hover);

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b2.setTextFill(Color.web("#c0c2c4"));
                        b2.setEffect(null);
                        b2.setGraphic(svgIconRetry);

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut2.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_3.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            backClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b3.setTextFill(Color.web("#004fcb"));
                        b3.setEffect(effectC_DropShadow);
                        b3.setGraphic(svgIconHome_Hover);

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b3.setTextFill(Color.web("#c0c2c4"));
                        b3.setEffect(null);
                        b3.setGraphic(svgIconHome);

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut2.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_3.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            HomeClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b11.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b11.setTextFill(Color.web("#004fcb"));
                        b11.setEffect(effectC_DropShadow);
                        b11.setGraphic(svgIconRetry1_Hover);

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b11.setTextFill(Color.web("#c0c2c4"));
                        b11.setEffect(null);
                        b11.setGraphic(svgIconRetry1);

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_2.play();
                        fadeOut6.play();
                        fadeOut6_1.play();

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            backClicked2();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b21.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b21.setTextFill(Color.web("#004fcb"));
                        b21.setEffect(effectC_DropShadow);
                        b21.setGraphic(svgIconHome1_Hover);

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b21.setTextFill(Color.web("#c0c2c4"));
                        b21.setEffect(null);
                        b21.setGraphic(svgIconHome1);

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_2.play();
                        fadeOut6.play();
                        fadeOut6_1.play();

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            HomeClicked2();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                }
                else if (tColor==2) {

                    color2 = "#fff44f";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.web("#d9cf43"), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.web("#ffff5b"), 10, 0, -5, -5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.web("#d9cf43"), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.web("#ffff5b"), 10, 0, -5, -5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBack = getClass().getResourceAsStream("../../resources/svg/left_arrow_2/left-arrow.svg");//
                    svgFileBack_Hover = getClass().getResourceAsStream("../../resources/svg/left_arrow_2/left-arrow_dyellow.svg");//

                    svgFileHome = getClass().getResourceAsStream("../../resources/svg/home/home.svg");//
                    svgFileHome_Hover = getClass().getResourceAsStream("../../resources/svg/home/home_dyellow.svg");//

                    svgFileHome1 = getClass().getResourceAsStream("../../resources/svg/home/home.svg");//
                    svgFileHome1_Hover = getClass().getResourceAsStream("../../resources/svg/home/home_dyellow.svg");//

                    svgFileRetry = getClass().getResourceAsStream("../../resources/svg/refresh/refresh.svg");//
                    svgFileRetry_Hover = getClass().getResourceAsStream("../../resources/svg/refresh/refresh_dyellow.svg");//

                    svgFileRetry1 = getClass().getResourceAsStream("../../resources/svg/refresh/refresh.svg");//
                    svgFileRetry1_Hover = getClass().getResourceAsStream("../../resources/svg/refresh/refresh_dyellow.svg");//

                    svgFilePause = getClass().getResourceAsStream("../../resources/svg/pause/pause.svg");//
                    svgFilePause_Hover = getClass().getResourceAsStream("../../resources/svg/pause/pause_dyellow.svg");//

                    svgFileMenu = getClass().getResourceAsStream("../../resources/svg/menu/menu.svg");//
                    svgFileMenu_Hover = getClass().getResourceAsStream("../../resources/svg/menu/menu_dyellow.svg");//

                    Group svgBack = loader.loadSvg(svgFileBack);
                    Group svgBack_Hover = loader.loadSvg(svgFileBack_Hover);
                    Group svgHome = loader.loadSvg(svgFileHome);
                    Group svgHome_Hover = loader.loadSvg(svgFileHome_Hover);
                    Group svgHome1 = loader.loadSvg(svgFileHome1);
                    Group svgHome1_Hover = loader.loadSvg(svgFileHome1_Hover);
                    Group svgRetry = loader.loadSvg(svgFileRetry);
                    Group svgRetry_Hover = loader.loadSvg(svgFileRetry_Hover);
                    Group svgRetry1 = loader.loadSvg(svgFileRetry1);
                    Group svgRetry1_Hover = loader.loadSvg(svgFileRetry1_Hover);
                    Group svgPause = loader.loadSvg(svgFilePause);
                    Group svgPause_Hover = loader.loadSvg(svgFilePause_Hover);
                    Group svgMenu = loader.loadSvg(svgFileMenu);
                    Group svgMenu_Hover = loader.loadSvg(svgFileMenu_Hover);

                    svgBack.setScaleX(.1);
                    svgBack.setScaleY(.1);
                    svgBack_Hover.setScaleX(.1);
                    svgBack_Hover.setScaleY(.1);
                    svgHome.setScaleX(.1);
                    svgHome.setScaleY(.1);
                    svgHome_Hover.setScaleX(.1);
                    svgHome_Hover.setScaleY(.1);
                    svgHome1.setScaleX(.1);
                    svgHome1.setScaleY(.1);
                    svgHome1_Hover.setScaleX(.1);
                    svgHome1_Hover.setScaleY(.1);
                    svgRetry.setScaleX(.1);
                    svgRetry.setScaleY(.1);
                    svgRetry_Hover.setScaleX(.1);
                    svgRetry_Hover.setScaleY(.1);
                    svgRetry1.setScaleX(.1);
                    svgRetry1.setScaleY(.1);
                    svgRetry1_Hover.setScaleX(.1);
                    svgRetry1_Hover.setScaleY(.1);
                    svgPause.setScaleX(.04);
                    svgPause.setScaleY(.04);
                    svgPause_Hover.setScaleX(.04);
                    svgPause_Hover.setScaleY(.04);
                    svgMenu.setScaleX(.04);
                    svgMenu.setScaleY(.04);
                    svgMenu_Hover.setScaleX(.04);
                    svgMenu_Hover.setScaleY(.04);

                    Group svgIconBack = new Group(svgBack);
                    Group svgIconBack_Hover = new Group(svgBack_Hover);
                    Group svgIconHome = new Group(svgHome);
                    Group svgIconHome_Hover = new Group(svgHome_Hover);
                    Group svgIconHome1 = new Group(svgHome1);
                    Group svgIconHome1_Hover = new Group(svgHome1_Hover);
                    Group svgIconRetry = new Group(svgRetry);
                    Group svgIconRetry_Hover = new Group(svgRetry_Hover);
                    Group svgIconRetry1 = new Group(svgRetry1);
                    Group svgIconRetry1_Hover = new Group(svgRetry1_Hover);
                    Group svgIconPause = new Group(svgPause);
                    Group svgIconPause_Hover = new Group(svgPause_Hover);
                    Group svgIconMenu = new Group(svgMenu);
                    Group svgIconMenu_Hover = new Group(svgMenu_Hover);

                    backButton.setGraphic(svgIconMenu);

                    b1.setGraphic(svgIconBack);
                    b2.setGraphic(svgIconRetry);
                    b3.setGraphic(svgIconHome);
                    b11.setGraphic(svgIconRetry1);
                    b21.setGraphic(svgIconHome1);
                    l4.setEffect(effectC_InnerShadow);
                    l3.setEffect(effectC_InnerShadow);

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        if (b111==0){

                            l1.setText("");
                            l2.setText("Pause");
                            backButton.setEffect(effectC_DropShadow);
                            backButton.setGraphic(svgIconPause_Hover);
                            backButton.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");

                        }else {


                            backButton.setGraphic(svgIconPause);

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        if (b111==0){

                            l1.setText("Memory");
                            l2.setText("Game");
                            backButton.setEffect(null);
                            backButton.setGraphic(svgIconMenu);
                            backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                        }else {

                            backButton.setEffect(null);
                            backButton.setGraphic(svgIconPause);

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        if (b111==0){
                            b111=1;
                            grid2.setVisible(true);
                            grid2.setDisable(false);

                            fadeOut.play();
                            fadeOut5.play();
                            fadeOut5_1.play();

                            fadeIn3.play();
                            fadeIn5_3.play();

                            fadeIn7.play();
                            fadeIn7_1.play();
                            fadeIn7_2.play();

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        fadeIn.play();

                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        backButton.setGraphic(svgIconPause);

                    });

                    b1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b1.setTextFill(Color.web("#c9c208"));
                        b1.setEffect(effectC_DropShadow);
                        b1.setGraphic(svgIconBack_Hover);

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b1.setTextFill(Color.web("#c0c2c4"));
                        b1.setEffect(null);
                        b1.setGraphic(svgIconBack);

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {
                        b111=0;
                        fadeIn.play();
                        fadeIn5.play();
                        fadeIn5_1.play();

                        fadeOut3.play();
                        fadeOut5_3.play();

                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                        grid2.setDisable(true);
                        backButton.setGraphic(svgIconMenu);
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                    });

                    b2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b2.setTextFill(Color.web("#c9c208"));
                        b2.setEffect(effectC_DropShadow);
                        b2.setGraphic(svgIconRetry_Hover);

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b2.setTextFill(Color.web("#c0c2c4"));
                        b2.setEffect(null);
                        b2.setGraphic(svgIconRetry);

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut2.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_3.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            backClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b3.setTextFill(Color.web("#c9c208"));
                        b3.setEffect(effectC_DropShadow);
                        b3.setGraphic(svgIconHome_Hover);

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b3.setTextFill(Color.web("#c0c2c4"));
                        b3.setEffect(null);
                        b3.setGraphic(svgIconHome);

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut2.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_3.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            HomeClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b11.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b11.setTextFill(Color.web("#c9c208"));
                        b11.setEffect(effectC_DropShadow);
                        b11.setGraphic(svgIconRetry1_Hover);

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b11.setTextFill(Color.web("#c0c2c4"));
                        b11.setEffect(null);
                        b11.setGraphic(svgIconRetry1);

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_2.play();
                        fadeOut6.play();
                        fadeOut6_1.play();

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            backClicked2();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b21.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b21.setTextFill(Color.web("#c9c208"));
                        b21.setEffect(effectC_DropShadow);
                        b21.setGraphic(svgIconHome1_Hover);

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b21.setTextFill(Color.web("#c0c2c4"));
                        b21.setEffect(null);
                        b21.setGraphic(svgIconHome1);

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_2.play();
                        fadeOut6.play();
                        fadeOut6_1.play();

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            HomeClicked2();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                }
                else if (tColor==3) {

                    color2 = "#00c853";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,200,83), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,230,95), 10, 0, -5, -5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,200,83), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,230,95), 10, 0, -5, -5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBack = getClass().getResourceAsStream("../../resources/svg/left_arrow_2/left-arrow.svg");//
                    svgFileBack_Hover = getClass().getResourceAsStream("../../resources/svg/left_arrow_2/left-arrow_dgreen.svg");//

                    svgFileHome = getClass().getResourceAsStream("../../resources/svg/home/home.svg");//
                    svgFileHome_Hover = getClass().getResourceAsStream("../../resources/svg/home/home_dgreen.svg");//

                    svgFileHome1 = getClass().getResourceAsStream("../../resources/svg/home/home.svg");//
                    svgFileHome1_Hover = getClass().getResourceAsStream("../../resources/svg/home/home_dgreen.svg");//

                    svgFileRetry = getClass().getResourceAsStream("../../resources/svg/refresh/refresh.svg");//
                    svgFileRetry_Hover = getClass().getResourceAsStream("../../resources/svg/refresh/refresh_dgreen.svg");//

                    svgFileRetry1 = getClass().getResourceAsStream("../../resources/svg/refresh/refresh.svg");//
                    svgFileRetry1_Hover = getClass().getResourceAsStream("../../resources/svg/refresh/refresh_dgreen.svg");//

                    svgFilePause = getClass().getResourceAsStream("../../resources/svg/pause/pause.svg");//
                    svgFilePause_Hover = getClass().getResourceAsStream("../../resources/svg/pause/pause_dgreen.svg");//

                    svgFileMenu = getClass().getResourceAsStream("../../resources/svg/menu/menu.svg");//
                    svgFileMenu_Hover = getClass().getResourceAsStream("../../resources/svg/menu/menu_dgreen.svg");//

                    Group svgBack = loader.loadSvg(svgFileBack);
                    Group svgBack_Hover = loader.loadSvg(svgFileBack_Hover);
                    Group svgHome = loader.loadSvg(svgFileHome);
                    Group svgHome_Hover = loader.loadSvg(svgFileHome_Hover);
                    Group svgHome1 = loader.loadSvg(svgFileHome1);
                    Group svgHome1_Hover = loader.loadSvg(svgFileHome1_Hover);
                    Group svgRetry = loader.loadSvg(svgFileRetry);
                    Group svgRetry_Hover = loader.loadSvg(svgFileRetry_Hover);
                    Group svgRetry1 = loader.loadSvg(svgFileRetry1);
                    Group svgRetry1_Hover = loader.loadSvg(svgFileRetry1_Hover);
                    Group svgPause = loader.loadSvg(svgFilePause);
                    Group svgPause_Hover = loader.loadSvg(svgFilePause_Hover);
                    Group svgMenu = loader.loadSvg(svgFileMenu);
                    Group svgMenu_Hover = loader.loadSvg(svgFileMenu_Hover);

                    svgBack.setScaleX(.1);
                    svgBack.setScaleY(.1);
                    svgBack_Hover.setScaleX(.1);
                    svgBack_Hover.setScaleY(.1);
                    svgHome.setScaleX(.1);
                    svgHome.setScaleY(.1);
                    svgHome_Hover.setScaleX(.1);
                    svgHome_Hover.setScaleY(.1);
                    svgHome1.setScaleX(.1);
                    svgHome1.setScaleY(.1);
                    svgHome1_Hover.setScaleX(.1);
                    svgHome1_Hover.setScaleY(.1);
                    svgRetry.setScaleX(.1);
                    svgRetry.setScaleY(.1);
                    svgRetry_Hover.setScaleX(.1);
                    svgRetry_Hover.setScaleY(.1);
                    svgRetry1.setScaleX(.1);
                    svgRetry1.setScaleY(.1);
                    svgRetry1_Hover.setScaleX(.1);
                    svgRetry1_Hover.setScaleY(.1);
                    svgPause.setScaleX(.04);
                    svgPause.setScaleY(.04);
                    svgPause_Hover.setScaleX(.04);
                    svgPause_Hover.setScaleY(.04);
                    svgMenu.setScaleX(.04);
                    svgMenu.setScaleY(.04);
                    svgMenu_Hover.setScaleX(.04);
                    svgMenu_Hover.setScaleY(.04);

                    Group svgIconBack = new Group(svgBack);
                    Group svgIconBack_Hover = new Group(svgBack_Hover);
                    Group svgIconHome = new Group(svgHome);
                    Group svgIconHome_Hover = new Group(svgHome_Hover);
                    Group svgIconHome1 = new Group(svgHome1);
                    Group svgIconHome1_Hover = new Group(svgHome1_Hover);
                    Group svgIconRetry = new Group(svgRetry);
                    Group svgIconRetry_Hover = new Group(svgRetry_Hover);
                    Group svgIconRetry1 = new Group(svgRetry1);
                    Group svgIconRetry1_Hover = new Group(svgRetry1_Hover);
                    Group svgIconPause = new Group(svgPause);
                    Group svgIconPause_Hover = new Group(svgPause_Hover);
                    Group svgIconMenu = new Group(svgMenu);
                    Group svgIconMenu_Hover = new Group(svgMenu_Hover);

                    backButton.setGraphic(svgIconMenu);

                    b1.setGraphic(svgIconBack);
                    b2.setGraphic(svgIconRetry);
                    b3.setGraphic(svgIconHome);
                    b11.setGraphic(svgIconRetry1);
                    b21.setGraphic(svgIconHome1);
                    l4.setEffect(effectC_InnerShadow);
                    l3.setEffect(effectC_InnerShadow);

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        if (b111==0){

                            l1.setText("");
                            l2.setText("Pause");
                            backButton.setEffect(effectC_DropShadow);
                            backButton.setGraphic(svgIconPause_Hover);
                            backButton.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");

                        }else {


                            backButton.setGraphic(svgIconPause);

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        if (b111==0){

                            l1.setText("Memory");
                            l2.setText("Game");
                            backButton.setEffect(null);
                            backButton.setGraphic(svgIconMenu);
                            backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                        }else {

                            backButton.setEffect(null);
                            backButton.setGraphic(svgIconPause);

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        if (b111==0){
                            b111=1;
                            grid2.setVisible(true);
                            grid2.setDisable(false);

                            fadeOut.play();
                            fadeOut5.play();
                            fadeOut5_1.play();

                            fadeIn3.play();
                            fadeIn5_3.play();

                            fadeIn7.play();
                            fadeIn7_1.play();
                            fadeIn7_2.play();

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        fadeIn.play();

                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        backButton.setGraphic(svgIconPause);

                    });

                    b1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b1.setTextFill(Color.web("#006500"));
                        b1.setEffect(effectC_DropShadow);
                        b1.setGraphic(svgIconBack_Hover);

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b1.setTextFill(Color.web("#c0c2c4"));
                        b1.setEffect(null);
                        b1.setGraphic(svgIconBack);

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {
                        b111=0;
                        fadeIn.play();
                        fadeIn5.play();
                        fadeIn5_1.play();

                        fadeOut3.play();
                        fadeOut5_3.play();

                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                        grid2.setDisable(true);
                        backButton.setGraphic(svgIconMenu);
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                    });

                    b2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b2.setTextFill(Color.web("#006500"));
                        b2.setEffect(effectC_DropShadow);
                        b2.setGraphic(svgIconRetry_Hover);

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b2.setTextFill(Color.web("#c0c2c4"));
                        b2.setEffect(null);
                        b2.setGraphic(svgIconRetry);

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut2.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_3.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            backClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b3.setTextFill(Color.web("#006500"));
                        b3.setEffect(effectC_DropShadow);
                        b3.setGraphic(svgIconHome_Hover);

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b3.setTextFill(Color.web("#c0c2c4"));
                        b3.setEffect(null);
                        b3.setGraphic(svgIconHome);

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut2.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_3.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            HomeClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b11.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b11.setTextFill(Color.web("#006500"));
                        b11.setEffect(effectC_DropShadow);
                        b11.setGraphic(svgIconRetry1_Hover);

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b11.setTextFill(Color.web("#c0c2c4"));
                        b11.setEffect(null);
                        b11.setGraphic(svgIconRetry1);

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_2.play();
                        fadeOut6.play();
                        fadeOut6_1.play();

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            backClicked2();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b21.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b21.setTextFill(Color.web("#006500"));
                        b21.setEffect(effectC_DropShadow);
                        b21.setGraphic(svgIconHome1_Hover);

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b21.setTextFill(Color.web("#c0c2c4"));
                        b21.setEffect(null);
                        b21.setGraphic(svgIconHome1);

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_2.play();
                        fadeOut6.play();
                        fadeOut6_1.play();

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            HomeClicked2();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                }
                else if (tColor==4) {

                    color2 = "#d50000";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(181,0,0), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(245,0,0), 10, 0, -5, -5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(181,0,0), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(245,0,0), 10, 0, -5, -5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBack = getClass().getResourceAsStream("../../resources/svg/left_arrow_2/left-arrow.svg");//
                    svgFileBack_Hover = getClass().getResourceAsStream("../../resources/svg/left_arrow_2/left-arrow_dred.svg");//

                    svgFileHome = getClass().getResourceAsStream("../../resources/svg/home/home.svg");//
                    svgFileHome_Hover = getClass().getResourceAsStream("../../resources/svg/home/home_dred.svg");//

                    svgFileHome1 = getClass().getResourceAsStream("../../resources/svg/home/home.svg");//
                    svgFileHome1_Hover = getClass().getResourceAsStream("../../resources/svg/home/home_dred.svg");//

                    svgFileRetry = getClass().getResourceAsStream("../../resources/svg/refresh/refresh.svg");//
                    svgFileRetry_Hover = getClass().getResourceAsStream("../../resources/svg/refresh/refresh_dred.svg");//

                    svgFileRetry1 = getClass().getResourceAsStream("../../resources/svg/refresh/refresh.svg");//
                    svgFileRetry1_Hover = getClass().getResourceAsStream("../../resources/svg/refresh/refresh_dred.svg");//

                    svgFilePause = getClass().getResourceAsStream("../../resources/svg/pause/pause.svg");//
                    svgFilePause_Hover = getClass().getResourceAsStream("../../resources/svg/pause/pause_dred.svg");//

                    svgFileMenu = getClass().getResourceAsStream("../../resources/svg/menu/menu.svg");//
                    svgFileMenu_Hover = getClass().getResourceAsStream("../../resources/svg/menu/menu_dred.svg");//

                    Group svgBack = loader.loadSvg(svgFileBack);
                    Group svgBack_Hover = loader.loadSvg(svgFileBack_Hover);
                    Group svgHome = loader.loadSvg(svgFileHome);
                    Group svgHome_Hover = loader.loadSvg(svgFileHome_Hover);
                    Group svgHome1 = loader.loadSvg(svgFileHome1);
                    Group svgHome1_Hover = loader.loadSvg(svgFileHome1_Hover);
                    Group svgRetry = loader.loadSvg(svgFileRetry);
                    Group svgRetry_Hover = loader.loadSvg(svgFileRetry_Hover);
                    Group svgRetry1 = loader.loadSvg(svgFileRetry1);
                    Group svgRetry1_Hover = loader.loadSvg(svgFileRetry1_Hover);
                    Group svgPause = loader.loadSvg(svgFilePause);
                    Group svgPause_Hover = loader.loadSvg(svgFilePause_Hover);
                    Group svgMenu = loader.loadSvg(svgFileMenu);
                    Group svgMenu_Hover = loader.loadSvg(svgFileMenu_Hover);

                    svgBack.setScaleX(.1);
                    svgBack.setScaleY(.1);
                    svgBack_Hover.setScaleX(.1);
                    svgBack_Hover.setScaleY(.1);
                    svgHome.setScaleX(.1);
                    svgHome.setScaleY(.1);
                    svgHome_Hover.setScaleX(.1);
                    svgHome_Hover.setScaleY(.1);
                    svgHome1.setScaleX(.1);
                    svgHome1.setScaleY(.1);
                    svgHome1_Hover.setScaleX(.1);
                    svgHome1_Hover.setScaleY(.1);
                    svgRetry.setScaleX(.1);
                    svgRetry.setScaleY(.1);
                    svgRetry_Hover.setScaleX(.1);
                    svgRetry_Hover.setScaleY(.1);
                    svgRetry1.setScaleX(.1);
                    svgRetry1.setScaleY(.1);
                    svgRetry1_Hover.setScaleX(.1);
                    svgRetry1_Hover.setScaleY(.1);
                    svgPause.setScaleX(.04);
                    svgPause.setScaleY(.04);
                    svgPause_Hover.setScaleX(.04);
                    svgPause_Hover.setScaleY(.04);
                    svgMenu.setScaleX(.04);
                    svgMenu.setScaleY(.04);
                    svgMenu_Hover.setScaleX(.04);
                    svgMenu_Hover.setScaleY(.04);

                    Group svgIconBack = new Group(svgBack);
                    Group svgIconBack_Hover = new Group(svgBack_Hover);
                    Group svgIconHome = new Group(svgHome);
                    Group svgIconHome_Hover = new Group(svgHome_Hover);
                    Group svgIconHome1 = new Group(svgHome1);
                    Group svgIconHome1_Hover = new Group(svgHome1_Hover);
                    Group svgIconRetry = new Group(svgRetry);
                    Group svgIconRetry_Hover = new Group(svgRetry_Hover);
                    Group svgIconRetry1 = new Group(svgRetry1);
                    Group svgIconRetry1_Hover = new Group(svgRetry1_Hover);
                    Group svgIconPause = new Group(svgPause);
                    Group svgIconPause_Hover = new Group(svgPause_Hover);
                    Group svgIconMenu = new Group(svgMenu);
                    Group svgIconMenu_Hover = new Group(svgMenu_Hover);

                    backButton.setGraphic(svgIconMenu);

                    b1.setGraphic(svgIconBack);
                    b2.setGraphic(svgIconRetry);
                    b3.setGraphic(svgIconHome);
                    b11.setGraphic(svgIconRetry1);
                    b21.setGraphic(svgIconHome1);
                    l4.setEffect(effectC_InnerShadow);
                    l3.setEffect(effectC_InnerShadow);

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        if (b111==0){

                            l1.setText("");
                            l2.setText("Pause");
                            backButton.setEffect(effectC_DropShadow);
                            backButton.setGraphic(svgIconPause_Hover);
                            backButton.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");

                        }else {


                            backButton.setGraphic(svgIconPause);

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        if (b111==0){

                            l1.setText("Memory");
                            l2.setText("Game");
                            backButton.setEffect(null);
                            backButton.setGraphic(svgIconMenu);
                            backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                        }else {

                            backButton.setEffect(null);
                            backButton.setGraphic(svgIconPause);

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        if (b111==0){
                            b111=1;
                            grid2.setVisible(true);
                            grid2.setDisable(false);

                            fadeOut.play();
                            fadeOut5.play();
                            fadeOut5_1.play();

                            fadeIn3.play();
                            fadeIn5_3.play();

                            fadeIn7.play();
                            fadeIn7_1.play();
                            fadeIn7_2.play();

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        fadeIn.play();

                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        backButton.setGraphic(svgIconPause);

                    });

                    b1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b1.setTextFill(Color.web("#9b0000"));
                        b1.setEffect(effectC_DropShadow);
                        b1.setGraphic(svgIconBack_Hover);

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b1.setTextFill(Color.web("#c0c2c4"));
                        b1.setEffect(null);
                        b1.setGraphic(svgIconBack);

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {
                        b111=0;
                        fadeIn.play();
                        fadeIn5.play();
                        fadeIn5_1.play();

                        fadeOut3.play();
                        fadeOut5_3.play();

                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                        grid2.setDisable(true);
                        backButton.setGraphic(svgIconMenu);
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                    });

                    b2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b2.setTextFill(Color.web("#9b0000"));
                        b2.setEffect(effectC_DropShadow);
                        b2.setGraphic(svgIconRetry_Hover);

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b2.setTextFill(Color.web("#c0c2c4"));
                        b2.setEffect(null);
                        b2.setGraphic(svgIconRetry);

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut2.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_3.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            backClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b3.setTextFill(Color.web("#9b0000"));
                        b3.setEffect(effectC_DropShadow);
                        b3.setGraphic(svgIconHome_Hover);

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b3.setTextFill(Color.web("#c0c2c4"));
                        b3.setEffect(null);
                        b3.setGraphic(svgIconHome);

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut2.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_3.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            HomeClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b11.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b11.setTextFill(Color.web("#9b0000"));
                        b11.setEffect(effectC_DropShadow);
                        b11.setGraphic(svgIconRetry1_Hover);

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b11.setTextFill(Color.web("#c0c2c4"));
                        b11.setEffect(null);
                        b11.setGraphic(svgIconRetry1);

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_2.play();
                        fadeOut6.play();
                        fadeOut6_1.play();

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            backClicked2();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b21.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b21.setTextFill(Color.web("#9b0000"));
                        b21.setEffect(effectC_DropShadow);
                        b21.setGraphic(svgIconHome1_Hover);

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b21.setTextFill(Color.web("#c0c2c4"));
                        b21.setEffect(null);
                        b21.setGraphic(svgIconHome1);

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_2.play();
                        fadeOut6.play();
                        fadeOut6_1.play();

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            HomeClicked2();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                }

            }
            else if(theme==2){

                color = "#181818";

                effectBG_DropShadowADD = new DropShadow(BlurType.GAUSSIAN, Color.rgb(20,20,20), 18, 0, 9, 9);
                effectBG_DropShadow = new DropShadow(BlurType.GAUSSIAN, Color.rgb(28,28,28), 18, 0, -9, -9);
                effectBG_DropShadow.setInput(effectBG_DropShadowADD);

                effectBG_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(20,20,20), 18, 0, 9, 9);
                effectBG_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(20,20,20), 18, 0, -9, -9);
                effectBG_InnerShadow.setInput(effectBG_InnerShadowADD);

                if (tColor==1) {

                    color2 = "#004fcb";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,67,173), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,91,233), 10, 0, -5, -5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,67,173), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,91,233), 10, 0, -5, -5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBack = getClass().getResourceAsStream("../../resources/svg/left_arrow_2/left-arrow_d.svg");//
                    svgFileBack_Hover = getClass().getResourceAsStream("../../resources/svg/left_arrow_2/left-arrow_blue.svg");//

                    svgFileHome = getClass().getResourceAsStream("../../resources/svg/home/home_d.svg");//
                    svgFileHome_Hover = getClass().getResourceAsStream("../../resources/svg/home/home_blue.svg");//

                    svgFileHome1 = getClass().getResourceAsStream("../../resources/svg/home/home_d.svg");//
                    svgFileHome1_Hover = getClass().getResourceAsStream("../../resources/svg/home/home_blue.svg");//

                    svgFileRetry = getClass().getResourceAsStream("../../resources/svg/refresh/refresh_d.svg");//
                    svgFileRetry_Hover = getClass().getResourceAsStream("../../resources/svg/refresh/refresh_blue.svg");//

                    svgFileRetry1 = getClass().getResourceAsStream("../../resources/svg/refresh/refresh_d.svg");//
                    svgFileRetry1_Hover = getClass().getResourceAsStream("../../resources/svg/refresh/refresh_blue.svg");//

                    svgFilePause = getClass().getResourceAsStream("../../resources/svg/pause/pause_d.svg");//
                    svgFilePause_Hover = getClass().getResourceAsStream("../../resources/svg/pause/pause_blue.svg");//

                    svgFileMenu = getClass().getResourceAsStream("../../resources/svg/menu/menu_d.svg");//
                    svgFileMenu_Hover = getClass().getResourceAsStream("../../resources/svg/menu/menu_blue.svg");//

                    Group svgBack = loader.loadSvg(svgFileBack);
                    Group svgBack_Hover = loader.loadSvg(svgFileBack_Hover);
                    Group svgHome = loader.loadSvg(svgFileHome);
                    Group svgHome_Hover = loader.loadSvg(svgFileHome_Hover);
                    Group svgHome1 = loader.loadSvg(svgFileHome1);
                    Group svgHome1_Hover = loader.loadSvg(svgFileHome1_Hover);
                    Group svgRetry = loader.loadSvg(svgFileRetry);
                    Group svgRetry_Hover = loader.loadSvg(svgFileRetry_Hover);
                    Group svgRetry1 = loader.loadSvg(svgFileRetry1);
                    Group svgRetry1_Hover = loader.loadSvg(svgFileRetry1_Hover);
                    Group svgPause = loader.loadSvg(svgFilePause);
                    Group svgPause_Hover = loader.loadSvg(svgFilePause_Hover);
                    Group svgMenu = loader.loadSvg(svgFileMenu);
                    Group svgMenu_Hover = loader.loadSvg(svgFileMenu_Hover);

                    svgBack.setScaleX(.1);
                    svgBack.setScaleY(.1);
                    svgBack_Hover.setScaleX(.1);
                    svgBack_Hover.setScaleY(.1);
                    svgHome.setScaleX(.1);
                    svgHome.setScaleY(.1);
                    svgHome_Hover.setScaleX(.1);
                    svgHome_Hover.setScaleY(.1);
                    svgHome1.setScaleX(.1);
                    svgHome1.setScaleY(.1);
                    svgHome1_Hover.setScaleX(.1);
                    svgHome1_Hover.setScaleY(.1);
                    svgRetry.setScaleX(.1);
                    svgRetry.setScaleY(.1);
                    svgRetry_Hover.setScaleX(.1);
                    svgRetry_Hover.setScaleY(.1);
                    svgRetry1.setScaleX(.1);
                    svgRetry1.setScaleY(.1);
                    svgRetry1_Hover.setScaleX(.1);
                    svgRetry1_Hover.setScaleY(.1);
                    svgPause.setScaleX(.04);
                    svgPause.setScaleY(.04);
                    svgPause_Hover.setScaleX(.04);
                    svgPause_Hover.setScaleY(.04);
                    svgMenu.setScaleX(.04);
                    svgMenu.setScaleY(.04);
                    svgMenu_Hover.setScaleX(.04);
                    svgMenu_Hover.setScaleY(.04);

                    Group svgIconBack = new Group(svgBack);
                    Group svgIconBack_Hover = new Group(svgBack_Hover);
                    Group svgIconHome = new Group(svgHome);
                    Group svgIconHome_Hover = new Group(svgHome_Hover);
                    Group svgIconHome1 = new Group(svgHome1);
                    Group svgIconHome1_Hover = new Group(svgHome1_Hover);
                    Group svgIconRetry = new Group(svgRetry);
                    Group svgIconRetry_Hover = new Group(svgRetry_Hover);
                    Group svgIconRetry1 = new Group(svgRetry1);
                    Group svgIconRetry1_Hover = new Group(svgRetry1_Hover);
                    Group svgIconPause = new Group(svgPause);
                    Group svgIconPause_Hover = new Group(svgPause_Hover);
                    Group svgIconMenu = new Group(svgMenu);
                    Group svgIconMenu_Hover = new Group(svgMenu_Hover);

                    backButton.setGraphic(svgIconMenu);

                    b1.setGraphic(svgIconBack);
                    b2.setGraphic(svgIconRetry);
                    b3.setGraphic(svgIconHome);
                    b11.setGraphic(svgIconRetry1);
                    b21.setGraphic(svgIconHome1);
                    l4.setEffect(effectC_InnerShadow);
                    l3.setEffect(effectC_InnerShadow);

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        if (b111==0){

                            l1.setText("");
                            l2.setText("Pause");
                            backButton.setEffect(effectC_DropShadow);
                            backButton.setGraphic(svgIconPause_Hover);
                            backButton.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");

                        }else {


                            backButton.setGraphic(svgIconPause);

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        if (b111==0){

                            l1.setText("Memory");
                            l2.setText("Game");
                            backButton.setEffect(null);
                            backButton.setGraphic(svgIconMenu);
                            backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                        }else {

                            backButton.setEffect(null);
                            backButton.setGraphic(svgIconPause);

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        if (b111==0){
                            b111=1;
                            grid2.setVisible(true);
                            grid2.setDisable(false);

                            fadeOut.play();
                            fadeOut5.play();
                            fadeOut5_1.play();

                            fadeIn3.play();
                            fadeIn5_3.play();

                            fadeIn7.play();
                            fadeIn7_1.play();
                            fadeIn7_2.play();

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        fadeIn.play();

                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        backButton.setGraphic(svgIconPause);

                    });

                    b1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b1.setTextFill(Color.web("#007aff"));
                        b1.setEffect(effectC_DropShadow);
                        b1.setGraphic(svgIconBack_Hover);

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b1.setTextFill(Color.web("#3E3E3E"));
                        b1.setEffect(null);
                        b1.setGraphic(svgIconBack);

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {
                        b111=0;
                        fadeIn.play();
                        fadeIn5.play();
                        fadeIn5_1.play();

                        fadeOut3.play();
                        fadeOut5_3.play();

                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                        grid2.setDisable(true);
                        backButton.setGraphic(svgIconMenu);
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                    });

                    b2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b2.setTextFill(Color.web("#007aff"));
                        b2.setEffect(effectC_DropShadow);
                        b2.setGraphic(svgIconRetry_Hover);

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b2.setTextFill(Color.web("#3E3E3E"));
                        b2.setEffect(null);
                        b2.setGraphic(svgIconRetry);

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut2.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_3.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            backClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b3.setTextFill(Color.web("#007aff"));
                        b3.setEffect(effectC_DropShadow);
                        b3.setGraphic(svgIconHome_Hover);

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b3.setTextFill(Color.web("#3E3E3E"));
                        b3.setEffect(null);
                        b3.setGraphic(svgIconHome);

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut2.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_3.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            HomeClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b11.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b11.setTextFill(Color.web("#007aff"));
                        b11.setEffect(effectC_DropShadow);
                        b11.setGraphic(svgIconRetry1_Hover);

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b11.setTextFill(Color.web("#3E3E3E"));
                        b11.setEffect(null);
                        b11.setGraphic(svgIconRetry1);

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_2.play();
                        fadeOut6.play();
                        fadeOut6_1.play();

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            backClicked2();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b21.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b21.setTextFill(Color.web("#007aff"));
                        b21.setEffect(effectC_DropShadow);
                        b21.setGraphic(svgIconHome1_Hover);

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b21.setTextFill(Color.web("#3E3E3E"));
                        b21.setEffect(null);
                        b21.setGraphic(svgIconHome1);

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_2.play();
                        fadeOut6.play();
                        fadeOut6_1.play();

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            HomeClicked2();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                }
                else if (tColor==2) {

                    color2 = "#c9c208";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(169,173,0), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(229,235,0), 10, 0, -5, -5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(169,173,0), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(229,235,0), 10, 0, -5, -5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBack = getClass().getResourceAsStream("../../resources/svg/left_arrow_2/left-arrow_d.svg");//
                    svgFileBack_Hover = getClass().getResourceAsStream("../../resources/svg/left_arrow_2/left-arrow_yellow.svg");//

                    svgFileHome = getClass().getResourceAsStream("../../resources/svg/home/home_d.svg");//
                    svgFileHome_Hover = getClass().getResourceAsStream("../../resources/svg/home/home_yellow.svg");//

                    svgFileHome1 = getClass().getResourceAsStream("../../resources/svg/home/home_d.svg");//
                    svgFileHome1_Hover = getClass().getResourceAsStream("../../resources/svg/home/home_yellow.svg");//

                    svgFileRetry = getClass().getResourceAsStream("../../resources/svg/refresh/refresh_d.svg");//
                    svgFileRetry_Hover = getClass().getResourceAsStream("../../resources/svg/refresh/refresh_yellow.svg");//

                    svgFileRetry1 = getClass().getResourceAsStream("../../resources/svg/refresh/refresh_d.svg");//
                    svgFileRetry1_Hover = getClass().getResourceAsStream("../../resources/svg/refresh/refresh_yellow.svg");//

                    svgFilePause = getClass().getResourceAsStream("../../resources/svg/pause/pause_d.svg");//
                    svgFilePause_Hover = getClass().getResourceAsStream("../../resources/svg/pause/pause_yellow.svg");//

                    svgFileMenu = getClass().getResourceAsStream("../../resources/svg/menu/menu_d.svg");//
                    svgFileMenu_Hover = getClass().getResourceAsStream("../../resources/svg/menu/menu_yellow.svg");//

                    Group svgBack = loader.loadSvg(svgFileBack);
                    Group svgBack_Hover = loader.loadSvg(svgFileBack_Hover);
                    Group svgHome = loader.loadSvg(svgFileHome);
                    Group svgHome_Hover = loader.loadSvg(svgFileHome_Hover);
                    Group svgHome1 = loader.loadSvg(svgFileHome1);
                    Group svgHome1_Hover = loader.loadSvg(svgFileHome1_Hover);
                    Group svgRetry = loader.loadSvg(svgFileRetry);
                    Group svgRetry_Hover = loader.loadSvg(svgFileRetry_Hover);
                    Group svgRetry1 = loader.loadSvg(svgFileRetry1);
                    Group svgRetry1_Hover = loader.loadSvg(svgFileRetry1_Hover);
                    Group svgPause = loader.loadSvg(svgFilePause);
                    Group svgPause_Hover = loader.loadSvg(svgFilePause_Hover);
                    Group svgMenu = loader.loadSvg(svgFileMenu);
                    Group svgMenu_Hover = loader.loadSvg(svgFileMenu_Hover);

                    svgBack.setScaleX(.1);
                    svgBack.setScaleY(.1);
                    svgBack_Hover.setScaleX(.1);
                    svgBack_Hover.setScaleY(.1);
                    svgHome.setScaleX(.1);
                    svgHome.setScaleY(.1);
                    svgHome_Hover.setScaleX(.1);
                    svgHome_Hover.setScaleY(.1);
                    svgHome1.setScaleX(.1);
                    svgHome1.setScaleY(.1);
                    svgHome1_Hover.setScaleX(.1);
                    svgHome1_Hover.setScaleY(.1);
                    svgRetry.setScaleX(.1);
                    svgRetry.setScaleY(.1);
                    svgRetry_Hover.setScaleX(.1);
                    svgRetry_Hover.setScaleY(.1);
                    svgRetry1.setScaleX(.1);
                    svgRetry1.setScaleY(.1);
                    svgRetry1_Hover.setScaleX(.1);
                    svgRetry1_Hover.setScaleY(.1);
                    svgPause.setScaleX(.04);
                    svgPause.setScaleY(.04);
                    svgPause_Hover.setScaleX(.04);
                    svgPause_Hover.setScaleY(.04);
                    svgMenu.setScaleX(.04);
                    svgMenu.setScaleY(.04);
                    svgMenu_Hover.setScaleX(.04);
                    svgMenu_Hover.setScaleY(.04);

                    Group svgIconBack = new Group(svgBack);
                    Group svgIconBack_Hover = new Group(svgBack_Hover);
                    Group svgIconHome = new Group(svgHome);
                    Group svgIconHome_Hover = new Group(svgHome_Hover);
                    Group svgIconHome1 = new Group(svgHome1);
                    Group svgIconHome1_Hover = new Group(svgHome1_Hover);
                    Group svgIconRetry = new Group(svgRetry);
                    Group svgIconRetry_Hover = new Group(svgRetry_Hover);
                    Group svgIconRetry1 = new Group(svgRetry1);
                    Group svgIconRetry1_Hover = new Group(svgRetry1_Hover);
                    Group svgIconPause = new Group(svgPause);
                    Group svgIconPause_Hover = new Group(svgPause_Hover);
                    Group svgIconMenu = new Group(svgMenu);
                    Group svgIconMenu_Hover = new Group(svgMenu_Hover);

                    backButton.setGraphic(svgIconMenu);

                    b1.setGraphic(svgIconBack);
                    b2.setGraphic(svgIconRetry);
                    b3.setGraphic(svgIconHome);
                    b11.setGraphic(svgIconRetry1);
                    b21.setGraphic(svgIconHome1);
                    l4.setEffect(effectC_InnerShadow);
                    l3.setEffect(effectC_InnerShadow);

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        if (b111==0){

                            l1.setText("");
                            l2.setText("Pause");
                            backButton.setEffect(effectC_DropShadow);
                            backButton.setGraphic(svgIconPause_Hover);
                            backButton.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");

                        }else {


                            backButton.setGraphic(svgIconPause);

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        if (b111==0){

                            l1.setText("Memory");
                            l2.setText("Game");
                            backButton.setEffect(null);
                            backButton.setGraphic(svgIconMenu);
                            backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                        }else {

                            backButton.setEffect(null);
                            backButton.setGraphic(svgIconPause);

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        if (b111==0){
                            b111=1;
                            grid2.setVisible(true);
                            grid2.setDisable(false);

                            fadeOut.play();
                            fadeOut5.play();
                            fadeOut5_1.play();

                            fadeIn3.play();
                            fadeIn5_3.play();

                            fadeIn7.play();
                            fadeIn7_1.play();
                            fadeIn7_2.play();

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        fadeIn.play();

                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        backButton.setGraphic(svgIconPause);

                    });

                    b1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b1.setTextFill(Color.web("#fff44f"));
                        b1.setEffect(effectC_DropShadow);
                        b1.setGraphic(svgIconBack_Hover);

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b1.setTextFill(Color.web("#3E3E3E"));
                        b1.setEffect(null);
                        b1.setGraphic(svgIconBack);

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {
                        b111=0;
                        fadeIn.play();
                        fadeIn5.play();
                        fadeIn5_1.play();

                        fadeOut3.play();
                        fadeOut5_3.play();

                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                        grid2.setDisable(true);
                        backButton.setGraphic(svgIconMenu);
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                    });

                    b2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b2.setTextFill(Color.web("#fff44f"));
                        b2.setEffect(effectC_DropShadow);
                        b2.setGraphic(svgIconRetry_Hover);

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b2.setTextFill(Color.web("#3E3E3E"));
                        b2.setEffect(null);
                        b2.setGraphic(svgIconRetry);

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut2.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_3.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            backClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b3.setTextFill(Color.web("#fff44f"));
                        b3.setEffect(effectC_DropShadow);
                        b3.setGraphic(svgIconHome_Hover);

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b3.setTextFill(Color.web("#3E3E3E"));
                        b3.setEffect(null);
                        b3.setGraphic(svgIconHome);

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut2.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_3.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            HomeClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b11.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b11.setTextFill(Color.web("#fff44f"));
                        b11.setEffect(effectC_DropShadow);
                        b11.setGraphic(svgIconRetry1_Hover);

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b11.setTextFill(Color.web("#3E3E3E"));
                        b11.setEffect(null);
                        b11.setGraphic(svgIconRetry1);

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_2.play();
                        fadeOut6.play();
                        fadeOut6_1.play();

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            backClicked2();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b21.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b21.setTextFill(Color.web("#fff44f"));
                        b21.setEffect(effectC_DropShadow);
                        b21.setGraphic(svgIconHome1_Hover);

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b21.setTextFill(Color.web("#3E3E3E"));
                        b21.setEffect(null);
                        b21.setGraphic(svgIconHome1);

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_2.play();
                        fadeOut6.play();
                        fadeOut6_1.play();

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            HomeClicked2();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                }
                else if (tColor==3) {

                    color2 = "#006500";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,86,0), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,116,0), 10, 0, -5, -5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,86,0), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,116,0), 10, 0, -5, -5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBack = getClass().getResourceAsStream("../../resources/svg/left_arrow_2/left-arrow_d.svg");//
                    svgFileBack_Hover = getClass().getResourceAsStream("../../resources/svg/left_arrow_2/left-arrow_green.svg");//

                    svgFileHome = getClass().getResourceAsStream("../../resources/svg/home/home_d.svg");//
                    svgFileHome_Hover = getClass().getResourceAsStream("../../resources/svg/home/home_green.svg");//

                    svgFileHome1 = getClass().getResourceAsStream("../../resources/svg/home/home_d.svg");//
                    svgFileHome1_Hover = getClass().getResourceAsStream("../../resources/svg/home/home_green.svg");//

                    svgFileRetry = getClass().getResourceAsStream("../../resources/svg/refresh/refresh_d.svg");//
                    svgFileRetry_Hover = getClass().getResourceAsStream("../../resources/svg/refresh/refresh_green.svg");//

                    svgFileRetry1 = getClass().getResourceAsStream("../../resources/svg/refresh/refresh_d.svg");//
                    svgFileRetry1_Hover = getClass().getResourceAsStream("../../resources/svg/refresh/refresh_green.svg");//

                    svgFilePause = getClass().getResourceAsStream("../../resources/svg/pause/pause_d.svg");//
                    svgFilePause_Hover = getClass().getResourceAsStream("../../resources/svg/pause/pause_green.svg");//

                    svgFileMenu = getClass().getResourceAsStream("../../resources/svg/menu/menu_d.svg");//
                    svgFileMenu_Hover = getClass().getResourceAsStream("../../resources/svg/menu/menu_green.svg");//

                    Group svgBack = loader.loadSvg(svgFileBack);
                    Group svgBack_Hover = loader.loadSvg(svgFileBack_Hover);
                    Group svgHome = loader.loadSvg(svgFileHome);
                    Group svgHome_Hover = loader.loadSvg(svgFileHome_Hover);
                    Group svgHome1 = loader.loadSvg(svgFileHome1);
                    Group svgHome1_Hover = loader.loadSvg(svgFileHome1_Hover);
                    Group svgRetry = loader.loadSvg(svgFileRetry);
                    Group svgRetry_Hover = loader.loadSvg(svgFileRetry_Hover);
                    Group svgRetry1 = loader.loadSvg(svgFileRetry1);
                    Group svgRetry1_Hover = loader.loadSvg(svgFileRetry1_Hover);
                    Group svgPause = loader.loadSvg(svgFilePause);
                    Group svgPause_Hover = loader.loadSvg(svgFilePause_Hover);
                    Group svgMenu = loader.loadSvg(svgFileMenu);
                    Group svgMenu_Hover = loader.loadSvg(svgFileMenu_Hover);

                    svgBack.setScaleX(.1);
                    svgBack.setScaleY(.1);
                    svgBack_Hover.setScaleX(.1);
                    svgBack_Hover.setScaleY(.1);
                    svgHome.setScaleX(.1);
                    svgHome.setScaleY(.1);
                    svgHome_Hover.setScaleX(.1);
                    svgHome_Hover.setScaleY(.1);
                    svgHome1.setScaleX(.1);
                    svgHome1.setScaleY(.1);
                    svgHome1_Hover.setScaleX(.1);
                    svgHome1_Hover.setScaleY(.1);
                    svgRetry.setScaleX(.1);
                    svgRetry.setScaleY(.1);
                    svgRetry_Hover.setScaleX(.1);
                    svgRetry_Hover.setScaleY(.1);
                    svgRetry1.setScaleX(.1);
                    svgRetry1.setScaleY(.1);
                    svgRetry1_Hover.setScaleX(.1);
                    svgRetry1_Hover.setScaleY(.1);
                    svgPause.setScaleX(.04);
                    svgPause.setScaleY(.04);
                    svgPause_Hover.setScaleX(.04);
                    svgPause_Hover.setScaleY(.04);
                    svgMenu.setScaleX(.04);
                    svgMenu.setScaleY(.04);
                    svgMenu_Hover.setScaleX(.04);
                    svgMenu_Hover.setScaleY(.04);

                    Group svgIconBack = new Group(svgBack);
                    Group svgIconBack_Hover = new Group(svgBack_Hover);
                    Group svgIconHome = new Group(svgHome);
                    Group svgIconHome_Hover = new Group(svgHome_Hover);
                    Group svgIconHome1 = new Group(svgHome1);
                    Group svgIconHome1_Hover = new Group(svgHome1_Hover);
                    Group svgIconRetry = new Group(svgRetry);
                    Group svgIconRetry_Hover = new Group(svgRetry_Hover);
                    Group svgIconRetry1 = new Group(svgRetry1);
                    Group svgIconRetry1_Hover = new Group(svgRetry1_Hover);
                    Group svgIconPause = new Group(svgPause);
                    Group svgIconPause_Hover = new Group(svgPause_Hover);
                    Group svgIconMenu = new Group(svgMenu);
                    Group svgIconMenu_Hover = new Group(svgMenu_Hover);

                    backButton.setGraphic(svgIconMenu);

                    b1.setGraphic(svgIconBack);
                    b2.setGraphic(svgIconRetry);
                    b3.setGraphic(svgIconHome);
                    b11.setGraphic(svgIconRetry1);
                    b21.setGraphic(svgIconHome1);
                    l4.setEffect(effectC_InnerShadow);
                    l3.setEffect(effectC_InnerShadow);

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        if (b111==0){

                            l1.setText("");
                            l2.setText("Pause");
                            backButton.setEffect(effectC_DropShadow);
                            backButton.setGraphic(svgIconPause_Hover);
                            backButton.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");

                        }else {


                            backButton.setGraphic(svgIconPause);

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        if (b111==0){

                            l1.setText("Memory");
                            l2.setText("Game");
                            backButton.setEffect(null);
                            backButton.setGraphic(svgIconMenu);
                            backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                        }else {

                            backButton.setEffect(null);
                            backButton.setGraphic(svgIconPause);

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        if (b111==0){
                            b111=1;
                            grid2.setVisible(true);
                            grid2.setDisable(false);

                            fadeOut.play();
                            fadeOut5.play();
                            fadeOut5_1.play();

                            fadeIn3.play();
                            fadeIn5_3.play();

                            fadeIn7.play();
                            fadeIn7_1.play();
                            fadeIn7_2.play();

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        fadeIn.play();

                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        backButton.setGraphic(svgIconPause);

                    });

                    b1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b1.setTextFill(Color.web("#00c853"));
                        b1.setEffect(effectC_DropShadow);
                        b1.setGraphic(svgIconBack_Hover);

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b1.setTextFill(Color.web("#3E3E3E"));
                        b1.setEffect(null);
                        b1.setGraphic(svgIconBack);

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {
                        b111=0;
                        fadeIn.play();
                        fadeIn5.play();
                        fadeIn5_1.play();

                        fadeOut3.play();
                        fadeOut5_3.play();

                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                        grid2.setDisable(true);
                        backButton.setGraphic(svgIconMenu);
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                    });

                    b2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b2.setTextFill(Color.web("#00c853"));
                        b2.setEffect(effectC_DropShadow);
                        b2.setGraphic(svgIconRetry_Hover);

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b2.setTextFill(Color.web("#3E3E3E"));
                        b2.setEffect(null);
                        b2.setGraphic(svgIconRetry);

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut2.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_3.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            backClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b3.setTextFill(Color.web("#00c853"));
                        b3.setEffect(effectC_DropShadow);
                        b3.setGraphic(svgIconHome_Hover);

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b3.setTextFill(Color.web("#3E3E3E"));
                        b3.setEffect(null);
                        b3.setGraphic(svgIconHome);

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut2.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_3.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            HomeClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b11.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b11.setTextFill(Color.web("#00c853"));
                        b11.setEffect(effectC_DropShadow);
                        b11.setGraphic(svgIconRetry1_Hover);

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b11.setTextFill(Color.web("#3E3E3E"));
                        b11.setEffect(null);
                        b11.setGraphic(svgIconRetry1);

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_2.play();
                        fadeOut6.play();
                        fadeOut6_1.play();

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            backClicked2();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b21.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b21.setTextFill(Color.web("#00c853"));
                        b21.setEffect(effectC_DropShadow);
                        b21.setGraphic(svgIconHome1_Hover);

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b21.setTextFill(Color.web("#3E3E3E"));
                        b21.setEffect(null);
                        b21.setGraphic(svgIconHome1);

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_2.play();
                        fadeOut6.play();
                        fadeOut6_1.play();

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            HomeClicked2();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                }
                else if (tColor==4) {

                    color2 = "#9b0000";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(155,0,0), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(178,0,0), 10, 0, -5, -5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(155,0,0), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(178,0,0), 10, 0, -5, -5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBack = getClass().getResourceAsStream("../../resources/svg/left_arrow_2/left-arrow_d.svg");//
                    svgFileBack_Hover = getClass().getResourceAsStream("../../resources/svg/left_arrow_2/left-arrow_red.svg");//

                    svgFileHome = getClass().getResourceAsStream("../../resources/svg/home/home_d.svg");//
                    svgFileHome_Hover = getClass().getResourceAsStream("../../resources/svg/home/home_red.svg");//

                    svgFileHome1 = getClass().getResourceAsStream("../../resources/svg/home/home_d.svg");//
                    svgFileHome1_Hover = getClass().getResourceAsStream("../../resources/svg/home/home_red.svg");//

                    svgFileRetry = getClass().getResourceAsStream("../../resources/svg/refresh/refresh_d.svg");//
                    svgFileRetry_Hover = getClass().getResourceAsStream("../../resources/svg/refresh/refresh_red.svg");//

                    svgFileRetry1 = getClass().getResourceAsStream("../../resources/svg/refresh/refresh_d.svg");//
                    svgFileRetry1_Hover = getClass().getResourceAsStream("../../resources/svg/refresh/refresh_red.svg");//

                    svgFilePause = getClass().getResourceAsStream("../../resources/svg/pause/pause_d.svg");//
                    svgFilePause_Hover = getClass().getResourceAsStream("../../resources/svg/pause/pause_red.svg");//

                    svgFileMenu = getClass().getResourceAsStream("../../resources/svg/menu/menu_d.svg");//
                    svgFileMenu_Hover = getClass().getResourceAsStream("../../resources/svg/menu/menu_red.svg");//

                    Group svgBack = loader.loadSvg(svgFileBack);
                    Group svgBack_Hover = loader.loadSvg(svgFileBack_Hover);
                    Group svgHome = loader.loadSvg(svgFileHome);
                    Group svgHome_Hover = loader.loadSvg(svgFileHome_Hover);
                    Group svgHome1 = loader.loadSvg(svgFileHome1);
                    Group svgHome1_Hover = loader.loadSvg(svgFileHome1_Hover);
                    Group svgRetry = loader.loadSvg(svgFileRetry);
                    Group svgRetry_Hover = loader.loadSvg(svgFileRetry_Hover);
                    Group svgRetry1 = loader.loadSvg(svgFileRetry1);
                    Group svgRetry1_Hover = loader.loadSvg(svgFileRetry1_Hover);
                    Group svgPause = loader.loadSvg(svgFilePause);
                    Group svgPause_Hover = loader.loadSvg(svgFilePause_Hover);
                    Group svgMenu = loader.loadSvg(svgFileMenu);
                    Group svgMenu_Hover = loader.loadSvg(svgFileMenu_Hover);

                    svgBack.setScaleX(.1);
                    svgBack.setScaleY(.1);
                    svgBack_Hover.setScaleX(.1);
                    svgBack_Hover.setScaleY(.1);
                    svgHome.setScaleX(.1);
                    svgHome.setScaleY(.1);
                    svgHome_Hover.setScaleX(.1);
                    svgHome_Hover.setScaleY(.1);
                    svgHome1.setScaleX(.1);
                    svgHome1.setScaleY(.1);
                    svgHome1_Hover.setScaleX(.1);
                    svgHome1_Hover.setScaleY(.1);
                    svgRetry.setScaleX(.1);
                    svgRetry.setScaleY(.1);
                    svgRetry_Hover.setScaleX(.1);
                    svgRetry_Hover.setScaleY(.1);
                    svgRetry1.setScaleX(.1);
                    svgRetry1.setScaleY(.1);
                    svgRetry1_Hover.setScaleX(.1);
                    svgRetry1_Hover.setScaleY(.1);
                    svgPause.setScaleX(.04);
                    svgPause.setScaleY(.04);
                    svgPause_Hover.setScaleX(.04);
                    svgPause_Hover.setScaleY(.04);
                    svgMenu.setScaleX(.04);
                    svgMenu.setScaleY(.04);
                    svgMenu_Hover.setScaleX(.04);
                    svgMenu_Hover.setScaleY(.04);

                    Group svgIconBack = new Group(svgBack);
                    Group svgIconBack_Hover = new Group(svgBack_Hover);
                    Group svgIconHome = new Group(svgHome);
                    Group svgIconHome_Hover = new Group(svgHome_Hover);
                    Group svgIconHome1 = new Group(svgHome1);
                    Group svgIconHome1_Hover = new Group(svgHome1_Hover);
                    Group svgIconRetry = new Group(svgRetry);
                    Group svgIconRetry_Hover = new Group(svgRetry_Hover);
                    Group svgIconRetry1 = new Group(svgRetry1);
                    Group svgIconRetry1_Hover = new Group(svgRetry1_Hover);
                    Group svgIconPause = new Group(svgPause);
                    Group svgIconPause_Hover = new Group(svgPause_Hover);
                    Group svgIconMenu = new Group(svgMenu);
                    Group svgIconMenu_Hover = new Group(svgMenu_Hover);

                    backButton.setGraphic(svgIconMenu);

                    b1.setGraphic(svgIconBack);
                    b2.setGraphic(svgIconRetry);
                    b3.setGraphic(svgIconHome);
                    b11.setGraphic(svgIconRetry1);
                    b21.setGraphic(svgIconHome1);
                    l4.setEffect(effectC_InnerShadow);
                    l3.setEffect(effectC_InnerShadow);

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        if (b111==0){

                            l1.setText("");
                            l2.setText("Pause");
                            backButton.setEffect(effectC_DropShadow);
                            backButton.setGraphic(svgIconPause_Hover);
                            backButton.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");

                        }else {


                            backButton.setGraphic(svgIconPause);

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        if (b111==0){

                            l1.setText("Memory");
                            l2.setText("Game");
                            backButton.setEffect(null);
                            backButton.setGraphic(svgIconMenu);
                            backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                        }else {

                            backButton.setEffect(null);
                            backButton.setGraphic(svgIconPause);

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        if (b111==0){
                            b111=1;
                            grid2.setVisible(true);
                            grid2.setDisable(false);

                            fadeOut.play();
                            fadeOut5.play();
                            fadeOut5_1.play();

                            fadeIn3.play();
                            fadeIn5_3.play();

                            fadeIn7.play();
                            fadeIn7_1.play();
                            fadeIn7_2.play();

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        fadeIn.play();

                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        backButton.setGraphic(svgIconPause);

                    });

                    b1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b1.setTextFill(Color.web("#d50000"));
                        b1.setEffect(effectC_DropShadow);
                        b1.setGraphic(svgIconBack_Hover);

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b1.setTextFill(Color.web("#3E3E3E"));
                        b1.setEffect(null);
                        b1.setGraphic(svgIconBack);

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {
                        b111=0;
                        fadeIn.play();
                        fadeIn5.play();
                        fadeIn5_1.play();

                        fadeOut3.play();
                        fadeOut5_3.play();

                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                        grid2.setDisable(true);
                        backButton.setGraphic(svgIconMenu);
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                    });

                    b2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b2.setTextFill(Color.web("#d50000"));
                        b2.setEffect(effectC_DropShadow);
                        b2.setGraphic(svgIconRetry_Hover);

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b2.setTextFill(Color.web("#3E3E3E"));
                        b2.setEffect(null);
                        b2.setGraphic(svgIconRetry);

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut2.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_3.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            backClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b3.setTextFill(Color.web("#d50000"));
                        b3.setEffect(effectC_DropShadow);
                        b3.setGraphic(svgIconHome_Hover);

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b3.setTextFill(Color.web("#3E3E3E"));
                        b3.setEffect(null);
                        b3.setGraphic(svgIconHome);

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut2.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_3.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            HomeClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b11.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b11.setTextFill(Color.web("#d50000"));
                        b11.setEffect(effectC_DropShadow);
                        b11.setGraphic(svgIconRetry1_Hover);

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b11.setTextFill(Color.web("#3E3E3E"));
                        b11.setEffect(null);
                        b11.setGraphic(svgIconRetry1);

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_2.play();
                        fadeOut6.play();
                        fadeOut6_1.play();

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            backClicked2();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b21.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b21.setTextFill(Color.web("#d50000"));
                        b21.setEffect(effectC_DropShadow);
                        b21.setGraphic(svgIconHome1_Hover);

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b21.setTextFill(Color.web("#3E3E3E"));
                        b21.setEffect(null);
                        b21.setGraphic(svgIconHome1);

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_2.play();
                        fadeOut6.play();
                        fadeOut6_1.play();

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            HomeClicked2();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                }

            }

        }

    }

    public void gameStart(){
        createImageViews(grid,imageViews);
        createImages(cards);
        shuffleCards(imageViews);
        setImages(imageViews,cards);

        player();
        playerg2();
        playerg3();
        playerg4();
    }

    //Game
    public void setMode(GameMode gameMode,Image theme) throws IOException{
        this.gameMode = gameMode;
        this.theme = theme;

        gameMode.CreateMode();
        gameMode.gameResolution();

    }

    //PLAYER
    public void player(){
        for(int i = 0; i<imageViews.size();i++){
            final ImageView imageView = imageViews.get(i);
            final Card card = cards.get(i);
            imageViews.get(i).setOnMouseClicked(event -> clickEvent(imageView,card));
        }
    }
    public void playerg2(){
        for(int i = 0; i<imageViews.size();i++){
            final ImageView imageView = imageViews.get(i);
            final Card card = cards.get(i);
            imageViews.get(i).setOnMouseClicked(event -> clickEvent(imageView,card));
        }
    }
    public void playerg3(){
        for(int i = 0; i<imageViews.size();i++){
            final ImageView imageView = imageViews.get(i);
            final Card card = cards.get(i);
            imageViews.get(i).setOnMouseClicked(event -> clickEvent(imageView,card));
        }
    }
    public void playerg4(){

        for(int i = 0; i<imageViews.size();i++){
            final ImageView imageView = imageViews.get(i);
            final Card card = cards.get(i);
            imageViews.get(i).setOnMouseClicked(event -> clickEvent(imageView,card));
        }
    }

    public void clickEvent(ImageView imageView,Card card){
        cardsMatch = false;
        clicks++;

        imageView.setDisable(true);
        ScaleTransition scaleTransition = new ScaleTransition(Duration.seconds(0.4),imageView);
        scaleTransition.setFromX(1);
        scaleTransition.setToX(-1);
        scaleTransition.play();
        scaleTransition.setOnFinished(event -> {imageView.setScaleX(1);imageView.setImage(card.getValue());});

        if(!gameMode.getGlobalMode().equals("SingleMode")){
            p++;
            if (gameMode.getRivalsNumber()==1){
                if(clicks == 1){
                    id1 = card.getId();
                    imageView1 = imageView;
                    card1 = card;
                }
                if(clicks == 2) {
                    id2 = card.getId();
                    imageView2 = imageView;
                    card2 = card;
                    if (gameMode.getMode() != 3) {
                        score.updateMoves();
                        score2.updateMoves2();
                        if (id1 != id2) {
                            if (p==2){ }
                            else if (p==4){p=0;}
                        }
                        disableAll();
                        if (id1 == id2) {

                            if (p==2){
                                score.updateFoundCards();
                                p=0;}
                            else if (p==4){
                                score2.updateFoundCards2();
                                p=2;
                            }

                            cardsMatch = true;
                            foundCards.add(imageView1);
                            foundCards.add(imageView2);
                            Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(0.6), event -> {
                                imageView1.setDisable(true);
                                imageView2.setDisable(true);
                                imageView1.setOpacity(0.6);
                                imageView2.setOpacity(0.6);
                                if (gameMode.getGlobalMode().equals("SingleMode"))
                                    enableAll();
                            }));
                            timeline.play();
                        } else {
                            Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1.2), event -> {
                                imageView1.setImage(card1.getBackground());
                                imageView2.setImage(card2.getBackground());
                                if (gameMode.getGlobalMode().equals("SingleMode")) {
                                    imageView1.setDisable(false);
                                    imageView2.setDisable(false);
                                    enableAll();
                                }
                            }));
                            timeline.play();
                        }
                        clicks=0;
                    }
                }
            }
            else if (gameMode.getRivalsNumber()==2){
                if(clicks == 1){
                    id1 = card.getId();
                    imageView1 = imageView;
                    card1 = card;
                }
                if(clicks == 2) {
                    id2 = card.getId();
                    imageView2 = imageView;
                    card2 = card;
                    if (gameMode.getMode() != 3) {
                        score.updateMoves();
                        score2.updateMoves2();
                        score3.updateMoves3();
                        if (id1 != id2) {
                            if (p==2){ }
                            else if (p==4){ }
                            else if (p==6){
                                p=0;
                            }
                        }
                        disableAll();
                        if (id1 == id2) {

                            if (p==2){
                                score.updateFoundCards();
                                p=0;}
                            else if (p==4){
                                score2.updateFoundCards2();
                                p=2;
                            }
                            else if (p==6){
                                score3.updateFoundCards3();
                                p=4;
                            }

                            cardsMatch = true;
                            foundCards.add(imageView1);
                            foundCards.add(imageView2);
                            Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(0.6), event -> {
                                imageView1.setDisable(true);
                                imageView2.setDisable(true);
                                imageView1.setOpacity(0.6);
                                imageView2.setOpacity(0.6);
                                if (gameMode.getGlobalMode().equals("SingleMode"))
                                    enableAll();
                            }));
                            timeline.play();
                        } else {
                            Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1.2), event -> {
                                imageView1.setImage(card1.getBackground());
                                imageView2.setImage(card2.getBackground());
                                if (gameMode.getGlobalMode().equals("SingleMode")) {
                                    imageView1.setDisable(false);
                                    imageView2.setDisable(false);
                                    enableAll();
                                }
                            }));
                            timeline.play();
                        }
                        clicks=0;
                    }
                }
            }
            else if (gameMode.getRivalsNumber()==3){
                if(clicks == 1){
                    id1 = card.getId();
                    imageView1 = imageView;
                    card1 = card;
                }
                if(clicks == 2) {
                    id2 = card.getId();
                    imageView2 = imageView;
                    card2 = card;
                    if (gameMode.getMode() != 3) {
                        score.updateMoves();
                        score2.updateMoves2();
                        score3.updateMoves3();
                        score4.updateMoves4();
                        if (id1 != id2) {
                            if (p==2){ }
                            else if (p==4){ }
                            else if (p==6){ }
                            else if (p==8){
                                p=0;
                            }
                        }
                        disableAll();
                        if (id1 == id2) {

                            if (p==2){
                                score.updateFoundCards();
                                p=0;}
                            else if (p==4){
                                score2.updateFoundCards2();
                                p=2;
                            }
                            else if (p==6){
                                score3.updateFoundCards3();
                                p=4;
                            }
                            else if (p==8){
                                score4.updateFoundCards4();
                                p=6;
                            }

                            cardsMatch = true;
                            foundCards.add(imageView1);
                            foundCards.add(imageView2);
                            Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(0.6), event -> {
                                imageView1.setDisable(true);
                                imageView2.setDisable(true);
                                imageView1.setOpacity(0.6);
                                imageView2.setOpacity(0.6);
                                if (gameMode.getGlobalMode().equals("SingleMode"))
                                    enableAll();
                            }));
                            timeline.play();
                        }
                        else {
                            Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1.2), event -> {
                                imageView1.setImage(card1.getBackground());
                                imageView2.setImage(card2.getBackground());
                                imageView1.setDisable(false);
                                imageView2.setDisable(false);
                                enableAll();

                            }));
                            timeline.play();
                        }
                        clicks=0;
                    }
                }
            }


        }
        else {

            if(clicks == 1){
                id1 = card.getId();
                imageView1 = imageView;
                card1 = card;
            }
            if(clicks == 2) {
                id2 = card.getId();
                imageView2 = imageView;
                card2 = card;
                score.updateMoves();
                if(gameMode.getGlobalMode().equals("SingleMode"))
                    Moves.setText(""+score.getMoves());
                disableAll();
                if (id1 == id2) {
                    score.updateFoundCards();
                    if(gameMode.getGlobalMode().equals("SingleMode"))
                        foundCardsLabel.setText(""+score.getFoundCards());
                    cardsMatch = true;
                    foundCards.add(imageView1);
                    foundCards.add(imageView2);
                    seenImageViewsElephant.remove(imageView1);
                    seenImageViewsElephant.remove(imageView2);
                    seenImageViewsKangaroo.remove(imageView1);
                    seenCardsElephant.remove(card1);
                    seenCardsElephant.remove(card2);
                    seenCardsKangaroo.remove(card1);
                    Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(0.6), event -> {
                        imageView1.setDisable(true);
                        imageView2.setDisable(true);
                        imageView1.setOpacity(0.6);
                        imageView2.setOpacity(0.6);
                        if(gameMode.getGlobalMode().equals("SingleMode"))
                            enableAll();
                    }));
                    timeline.play();
                } else {
                    Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1.2),event -> {
                        imageView1.setImage(card1.getBackground());
                        imageView2.setImage(card2.getBackground());
                        if(gameMode.getGlobalMode().equals("SingleMode")) {
                            imageView1.setDisable(false);
                            imageView2.setDisable(false);
                            enableAll();
                        }
                    }));
                    timeline.play();
                }
                if (foundCards.size() == gameMode.getSize() && gameMode.getGlobalMode().equals("SingleMode")) {
                    Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(3),event -> eraseCards(grid)));
                    timeline.play();

                    grid21.setVisible(true);
                    grid21.setDisable(false);

                    ///
                    FadeTransition fadeIn = new FadeTransition();//Back button
                    FadeTransition fadeIn2 = new FadeTransition();//BG-g
                    FadeTransition fadeIn3 = new FadeTransition();//BG-g1
                    FadeTransition fadeIn4 = new FadeTransition();//PANELex
                    FadeTransition fadeIn4_1 = new FadeTransition();//PANELex2
                    FadeTransition fadeIn5_2 = new FadeTransition();//l3
                    FadeTransition fadeIn6 = new FadeTransition();//b11
                    FadeTransition fadeIn6_1 = new FadeTransition();//b21

                    ///
                    FadeTransition fadeOut = new FadeTransition();//Back button
                    FadeTransition fadeOut2 = new FadeTransition();//BG
                    FadeTransition fadeOut3 = new FadeTransition();//BG
                    FadeTransition fadeOut4 = new FadeTransition();//PANELex1
                    FadeTransition fadeOut4_1 = new FadeTransition();//PANELex2
                    FadeTransition fadeOut5 = new FadeTransition();//l1
                    FadeTransition fadeOut5_1 = new FadeTransition();//l2
                    FadeTransition fadeOut5_2 = new FadeTransition();//l3
                    FadeTransition fadeOut6 = new FadeTransition();//b11
                    FadeTransition fadeOut6_1 = new FadeTransition();//b21

                    fadeIn.setDuration(Duration.millis(500));//BG
                    fadeIn2.setDuration(Duration.millis(500));//BG
                    fadeIn3.setDuration(Duration.millis(500));//BG
                    fadeIn4.setDuration(Duration.millis(750));//PANEL1
                    fadeIn4_1.setDuration(Duration.millis(800));//PANEL2
                    fadeIn5_2.setDuration(Duration.millis(400));//l3
                    fadeIn6.setDuration(Duration.millis(100));//b11
                    fadeIn6_1.setDuration(Duration.millis(200));//b21

                    fadeOut.setDuration(Duration.millis(500));//BG
                    fadeOut2.setDuration(Duration.millis(500));//BG
                    fadeOut3.setDuration(Duration.millis(500));//BG
                    fadeOut4.setDuration(Duration.millis(750));//PANEL1
                    fadeOut4_1.setDuration(Duration.millis(800));//
                    fadeOut5.setDuration(Duration.millis(500));//l3
                    fadeOut5_1.setDuration(Duration.millis(500));//l3
                    fadeOut5_2.setDuration(Duration.millis(500));//l3
                    fadeOut6.setDuration(Duration.millis(250));//b11
                    fadeOut6_1.setDuration(Duration.millis(250));//b21

                    fadeIn.setFromValue(0);
                    fadeIn.setToValue(10);
                    fadeIn2.setFromValue(0);
                    fadeIn2.setToValue(10);
                    fadeIn3.setFromValue(0);
                    fadeIn3.setToValue(10);
                    fadeIn4.setFromValue(0);
                    fadeIn4.setToValue(10);
                    fadeIn4_1.setFromValue(0);
                    fadeIn4_1.setToValue(10);
                    fadeIn5_2.setFromValue(0);
                    fadeIn5_2.setToValue(10);
                    fadeIn6.setFromValue(0);
                    fadeIn6.setToValue(10);
                    fadeIn6_1.setFromValue(0);
                    fadeIn6_1.setToValue(10);

                    fadeOut.setFromValue(10);
                    fadeOut.setToValue(0);
                    fadeOut2.setFromValue(10);
                    fadeOut2.setToValue(0);
                    fadeOut3.setFromValue(10);
                    fadeOut3.setToValue(0);
                    fadeOut4.setFromValue(10);
                    fadeOut4.setToValue(0);
                    fadeOut4_1.setFromValue(10);
                    fadeOut4_1.setToValue(0);
                    fadeOut5.setFromValue(10);
                    fadeOut5.setToValue(0);
                    fadeOut5_1.setFromValue(10);
                    fadeOut5_1.setToValue(0);
                    fadeOut5_2.setFromValue(10);
                    fadeOut5_2.setToValue(0);
                    fadeOut6.setFromValue(10);
                    fadeOut6.setToValue(0);
                    fadeOut6_1.setFromValue(10);
                    fadeOut6_1.setToValue(0);

                    fadeIn.setCycleCount(1);
                    fadeIn2.setCycleCount(1);
                    fadeIn3.setCycleCount(1);
                    fadeIn4.setCycleCount(1);
                    fadeIn4_1.setCycleCount(1);
                    fadeIn5_2.setCycleCount(1);
                    fadeIn6.setCycleCount(1);
                    fadeIn6_1.setCycleCount(1);

                    fadeOut.setCycleCount(1);
                    fadeOut2.setCycleCount(1);
                    fadeOut3.setCycleCount(1);
                    fadeOut4.setCycleCount(1);
                    fadeOut4_1.setCycleCount(1);
                    fadeOut5.setCycleCount(1);
                    fadeOut5_1.setCycleCount(1);
                    fadeOut5_2.setCycleCount(1);
                    fadeOut6.setCycleCount(1);
                    fadeOut6_1.setCycleCount(1);

                    fadeIn.setNode(backButton);
                    fadeIn2.setNode(grid);
                    fadeIn3.setNode(grid21);
                    fadeIn5_2.setNode(l3);
                    fadeIn6.setNode(b11);
                    fadeIn6_1.setNode(b21);

                    fadeOut.setNode(backButton);
                    fadeOut2.setNode(grid);
                    fadeOut3.setNode(grid21);
                    fadeOut5.setNode(l1);
                    fadeOut5_1.setNode(l2);
                    fadeOut5_2.setNode(l3);
                    fadeOut6.setNode(b11);
                    fadeOut6_1.setNode(b21);

                    fadeOut.play();
                    fadeOut5.play();
                    fadeOut5_1.play();
                    fadeOut.play();
                    fadeIn3.play();
                    fadeIn5_2.play();
                    fadeIn6.play();
                    fadeIn6_1.play();

                    //here retry
                    if(gameMode.getMode() == 1){
                        int ss = Integer.parseInt(properties2.getProperty("SingleModeHighScore1"));
                        int ss1 = score.getMoves();
                        if (ss==0){
                            ss=9999;
                        }
                        if (ss>ss1) {
                            properties2.setProperty("SingleModeHighScore1", Integer.toString(score.getMoves()));
                        }

                    }
                    else if(gameMode.getMode() == 2){

                        int ss = Integer.parseInt(properties2.getProperty("SingleModeHighScore2"));
                        if (ss==0){
                            ss=9999;
                        }
                        int ss1 = score.getMoves();

                        if (ss>ss1) {
                            l3.setText(Integer.toString(ss1));
                            properties2.setProperty("SingleModeHighScore2", Integer.toString(score.getMoves()));
                        }

                    }
                    else if(gameMode.getMode() == 3){

                        int ss = Integer.parseInt(properties2.getProperty("SingleModeHighScore3"));
                        if (ss==0){
                            ss=9999;
                        }
                        int ss1 = score.getMoves();

                        if (ss>ss1) {
                            properties2.setProperty("SingleModeHighScore3", Integer.toString(score.getMoves()));
                        }

                    }
                    else if(gameMode.getMode() == 4){

                        int ss = Integer.parseInt(properties2.getProperty("SingleModeHighScore4"));
                        if (ss==0){
                            ss=9999;
                        }
                        int ss1 = score.getMoves();

                        if (ss>ss1) {
                            properties2.setProperty("SingleModeHighScore4", Integer.toString(score.getMoves()));
                        }

                    }
                    try {
                        output = new FileOutputStream("score.properties");
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                    try {
                        properties2.store(output,null);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                clicks = 0;
            }

        }

    }

    public void eraseCards(GridPane grid){
        for(int i = 0;i<imageViews.size();i++){
            grid.getChildren().remove(imageViews.get(i));
        }
    }

    public void enableAll(){
        for(int i = 0;i<imageViews.size();i++){
            imageViews.get(i).setDisable(false);
        }

        for(int i = 0;i<foundCards.size();i++){
            foundCards.get(i).setDisable(true);
        }
    }

    public void disableAll(){
        for(int i = 0;i<imageViews.size();i++){
            imageViews.get(i).setDisable(true);
        }
    }

    public void backClicked() throws IOException {
        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        output = new FileOutputStream("config.properties");
        properties.setProperty("MenuSelected", "1");
        properties.store(output, null);

        Parent root = FXMLLoader.load(getClass().getResource("../../resources/view/SingleModeSettings.fxml"));
        Stage stage = (Stage) b2.getScene().getWindow();
        stage.getScene().setRoot(root);

    }

    public void backClicked2() throws IOException {
        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        output = new FileOutputStream("config.properties");
        properties.setProperty("MenuSelected", "1");
        properties.store(output, null);

        Parent root = FXMLLoader.load(getClass().getResource("../../resources/view/SingleModeSettings.fxml"));
        Stage stage = (Stage) b11.getScene().getWindow();
        stage.getScene().setRoot(root);

    }

    public void HomeClicked() throws IOException {
        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        output = new FileOutputStream("config.properties");
        properties.setProperty("MenuSelected", "1");
        properties.store(output, null);

        Parent root = FXMLLoader.load(getClass().getResource("../../resources/view/MainMenu.fxml"));
        Stage stage = (Stage) b3.getScene().getWindow();
        stage.getScene().setRoot(root);

    }

    public void HomeClicked2() throws IOException {
        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        output = new FileOutputStream("config.properties");
        properties.setProperty("MenuSelected", "1");
        properties.store(output, null);

        Parent root = FXMLLoader.load(getClass().getResource("../../resources/view/MainMenu.fxml"));
        Stage stage = (Stage) b21.getScene().getWindow();
        stage.getScene().setRoot(root);

    }

    public void createImageViews(GridPane grid,ArrayList<ImageView> imageViews) {

        File f = new File("config.properties");
        File f3 = new File("gamemode.properties");
        if(f.exists()) {

            try {
                input = new FileInputStream("config.properties");
                properties.load(input);

                int width = Integer.parseInt(properties.getProperty("width"));
                int theme = Integer.parseInt(properties.getProperty("TMode"));
                int tColor = Integer.parseInt(properties.getProperty("TColor"));

                if(theme==1){

                    if (tColor==1) {

                        effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,104,217), 10, 0, 5, 5);
                        effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,140,255), 10, 0, -5, -5);
                        effectC_DropShadow.setInput(effectC_DropShadowADD);

                    }
                    else if (tColor==2) {

                        effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.web("#d9cf43"), 10, 0, 5, 5);
                        effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.web("#ffff5b"), 10, 0, -5, -5);
                        effectC_DropShadow.setInput(effectC_DropShadowADD);

                    }
                    else if (tColor==3) {

                        effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,200,83), 10, 0, 5, 5);
                        effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,230,95), 10, 0, -5, -5);
                        effectC_DropShadow.setInput(effectC_DropShadowADD);

                    }
                    else if (tColor==4) {

                        effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(181,0,0), 10, 0, 5, 5);
                        effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(245,0,0), 10, 0, -5, -5);
                        effectC_DropShadow.setInput(effectC_DropShadowADD);

                    }

                }
                else if(theme==2){

                    if (tColor==1) {

                        effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,67,173), 10, 0, 5, 5);
                        effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,91,233), 10, 0, -5, -5);
                        effectC_DropShadow.setInput(effectC_DropShadowADD);

                    }
                    else if (tColor==2) {

                        effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(169,173,0), 10, 0, 5, 5);
                        effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(229,235,0), 10, 0, -5, -5);
                        effectC_DropShadow.setInput(effectC_DropShadowADD);

                    }
                    else if (tColor==3) {

                        effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,86,0), 10, 0, 5, 5);
                        effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,116,0), 10, 0, -5, -5);
                        effectC_DropShadow.setInput(effectC_DropShadowADD);

                    }
                    else if (tColor==4) {

                        effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(155,0,0), 10, 0, 5, 5);
                        effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(178,0,0), 10, 0, -5, -5);
                        effectC_DropShadow.setInput(effectC_DropShadowADD);

                    }

                }

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            grid.setHgap(10);
            grid.setVgap(10);
            for(int i = 0; i<gameMode.getRows();i++){
                RowConstraints row = new RowConstraints(gameMode.getImHeight());
                row.setMinHeight(Double.MIN_VALUE);
                //  row.setMaxHeight(Double.MAX_VALUE);
                row.setVgrow(Priority.ALWAYS);
                grid.getRowConstraints().add(row);
            }
            for(int i = 0; i<gameMode.getColumns();i++){
                ColumnConstraints column = new ColumnConstraints(gameMode.getImWidth());
                column.setMinWidth(Double.MIN_VALUE);
                //  column.setMaxWidth(Double.MAX_VALUE);
                column.setHgrow(Priority.ALWAYS);
                grid.getColumnConstraints().add(column);
            }
            for(int i = 0; i<gameMode.getRows();i++){
                for(int j = 0; j<gameMode.getColumns();j++) {
                    ImageView imageView = new ImageView();
                    imageView.setPreserveRatio(true);

                    imageView.setFitWidth(gameMode.getImWidth());
                    imageView.setFitHeight(gameMode.getImHeight());

                    imageView.addEventHandler(MouseEvent.MOUSE_ENTERED,e->{

                        imageView.setEffect(effectC_DropShadow);

                    });

                    imageView.addEventHandler(MouseEvent.MOUSE_EXITED,e->{

                        imageView.setEffect(null);

                    });

                    grid.add(imageView,j,i);
                    imageViews.add(imageView);
                }
            }

        }

    }

    public void createImages(ArrayList<Card> cards) {
        Image value;

        int times = 0;
        int j = 0;
        for(int i =1; i<=gameMode.getSize();i++) {
            if(i%gameMode.getSelectCards() == 1){
                times++;
                j++;
            }
            File f3 = new File("gamemode.properties");
            if(f3.exists()) {
                try {
                    input3 = new FileInputStream("gamemode.properties");
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                try {
                    properties3.load(input3);
                } catch (IOException e) {
                    e.printStackTrace();
                }

                int tfSelected = Integer.parseInt(properties3.getProperty("TFSelected"));
                int tSelected = Integer.parseInt(properties3.getProperty("TSelected"));
                int gSelected = Integer.parseInt(properties3.getProperty("GSelected"));

                if (gSelected==1){

                    if (tSelected==1){

                        if (tfSelected==1){
                            value = new Image("main/resources/images/Cards/Light/Easy/" + j + ".png");
                            Card image2 = new Card(value,theme,times);
                            cards.add(image2);
                        }
                        else if (tfSelected==2){
                            value = new Image("main/resources/images/Cards/Dark/Easy/" + j + ".png");
                            Card image2 = new Card(value,theme,times);
                            cards.add(image2);
                        }
                        else if (tfSelected==3){
                            value = new Image("main/resources/images/Cards/Red/Easy/" + j + ".png");
                            Card image2 = new Card(value,theme,times);
                            cards.add(image2);
                        }

                    }
                    else if (tSelected==2){

                        value = new Image("main/resources/images/Cards/UNO/Easy/" + j + ".png");
                        Card image2 = new Card(value,theme,times);
                        cards.add(image2);

                    }

                }else {

                    if (tSelected==1){

                        if (tfSelected==1){
                            value = new Image("main/resources/images/Cards/Light/" + j + ".png");
                            Card image2 = new Card(value,theme,times);
                            cards.add(image2);
                        }
                        else if (tfSelected==2){
                            value = new Image("main/resources/images/Cards/Dark/" + j + ".png");
                            Card image2 = new Card(value,theme,times);
                            cards.add(image2);
                        }
                        else if (tfSelected==3){
                            value = new Image("main/resources/images/Cards/Red/" + j + ".png");
                            Card image2 = new Card(value,theme,times);
                            cards.add(image2);
                        }

                    }
                    else if (tSelected==2){

                        value = new Image("main/resources/images/Cards/UNO/" + j + ".png");
                        Card image2 = new Card(value,theme,times);
                        cards.add(image2);

                    }

                }
            }
        }
    }

    public void setImages(ArrayList<ImageView> imageViews,ArrayList<Card> cards){
        for(int i = 0;i<imageViews.size();i++){
            imageViews.get(i).setImage(cards.get(i).getBackground());
        }
    }

    public void shuffleCards(ArrayList<ImageView> imageViews){
        Collections.shuffle(imageViews);
    }

}