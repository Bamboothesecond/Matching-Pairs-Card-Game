package main.javafx.controllers.settings;

import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.effect.BlurType;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.InnerShadow;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;
import main.javafx.util.SvgLoader;

import java.io.*;
import java.util.Locale;
import java.util.Properties;

public class SettingsDisplayPane {

    public MenuItem x66;
    public MenuItem x86;

    @FXML
    private BorderPane gg1;

    @FXML
    private VBox Panel4;

    @FXML
    private GridPane Panelg1,Panelg2;
    @FXML
    private CheckBox r1litsener,r2litsener,r3litsener;

    @FXML
    private MenuItem fullScreen,x1280;
    @FXML
    private MenuButton resolution;
    @FXML
    private ToggleButton sounds;
    @FXML
    private Button clearProgress,light,dark,backButton,p1,p2,p3,Panel1,Panel2,Panel3,b1,b2,b3;
    @FXML
    private Label l1,l2,settingsLabel,resolutionLabel,soundsLabel,clearProgressLabel;
    @FXML
    private Slider volume;

    private Properties properties = new Properties();
    private Properties properties2 = new Properties();
    private OutputStream output = null;
    private InputStream input = null;

    private double xOffset = 0;
    private double yOffset = 0;

    private String fs,theme,mode;

    public SettingsDisplayPane(){

    }
    @FXML
    private void initialize() throws IOException {
        btnHandler();
        File f = new File("config.properties");

        properties.setProperty("width","800");
        properties.setProperty("height","600");
        properties.setProperty("fullScreen","false");

        if(f.exists()) {
            input = new FileInputStream("config.properties");
            properties.load(input);


        }

    }

    private void btnHandler() throws IOException {

        final SvgLoader loader = new SvgLoader();

        //SVG FILE
        InputStream svgFile = getClass().getResourceAsStream("../../../resources/svg/settings.svg");
        InputStream svgFile2 = getClass().getResourceAsStream("../../../resources/svg/left-arrow.svg");//
        InputStream svgFile3 = getClass().getResourceAsStream("../../../resources/svg/settings.svg");
        InputStream svgFile4 = getClass().getResourceAsStream("../../../resources/svg/delete.svg");
        InputStream svgFileDisplay = getClass().getResourceAsStream("../../../resources/svg/resolution.svg");//
        InputStream svgFileSound = getClass().getResourceAsStream("../../../resources/svg/resolution.svg");//
        InputStream svgFileTheme = getClass().getResourceAsStream("../../../resources/svg/resolution.svg");//

        Group svgImage = loader.loadSvg(svgFile);
        Group svgImage2 = loader.loadSvg(svgFile2);
        Group svgImage3 = loader.loadSvg(svgFile3);
        Group svgImage4 = loader.loadSvg(svgFile4);
        Group svgDisplay = loader.loadSvg(svgFileDisplay);//
        Group svgSound = loader.loadSvg(svgFileSound);//
        Group svgTheme = loader.loadSvg(svgFileTheme);//


        svgImage.setScaleX(.04);
        svgImage.setScaleY(.04);

        svgImage2.setScaleX(.06);
        svgImage2.setScaleY(.06);

        svgImage3.setScaleX(.04);
        svgImage3.setScaleY(.04);

        svgImage4.setScaleX(.06);
        svgImage4.setScaleY(.06);

        svgDisplay.setScaleX(.25);//
        svgDisplay.setScaleY(.25);//

        svgSound.setScaleX(.25);//
        svgSound.setScaleY(.25);//

        svgTheme.setScaleX(.25);//
        svgTheme.setScaleY(.25);//

        Group graphic1 = new Group(svgImage);
        Group graphic2 = new Group(svgImage2);
        Group graphic3 = new Group(svgImage3);
        Group graphic4 = new Group(svgImage4);
        Group svgIconDisplay = new Group(svgDisplay);
        Group svgIconSound = new Group(svgSound);
        Group svgIconTheme = new Group(svgTheme);

        backButton.setGraphic(graphic3);

        //Button light foreground
        DropShadow btn_OutBoxShadowADD = new DropShadow(BlurType.GAUSSIAN, Color.rgb(206,207,210), 36, 0, 9, 9);
        DropShadow btn_OutBoxShadow = new DropShadow(BlurType.GAUSSIAN, Color.rgb(255,255,255), 18, 0, -9, -9);
        btn_OutBoxShadow.setInput(btn_OutBoxShadowADD);

        InnerShadow btn_InBoxShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(206,207,210), 18, 0, 9, 9);
        InnerShadow btn_InBoxShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(255,255,255), 18, 0, -9, -9);
        btn_InBoxShadow.setInput(btn_InBoxShadowADD);

        //Button light Background
        DropShadow dropShadow1 = new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,104,217), 18, 0, 9, 9);
        DropShadow dropShadow2 = new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,140,255), 18, 0, -9, -9);
        dropShadow2.setInput(dropShadow1);

        InnerShadow dropShadow11 = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,104,217), 18, 0, 9, 9);
        InnerShadow dropShadow22 = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,140,255), 18, 0, -9, -9);
        dropShadow22.setInput(dropShadow11);

        FadeTransition fadeIn = new FadeTransition();
        FadeTransition fadeOut = new FadeTransition();

        fadeIn.setDuration(Duration.millis(500));
        fadeOut.setDuration(Duration.millis(200));

        fadeIn.setFromValue(0);
        fadeIn.setToValue(10);

        fadeOut.setFromValue(10);
        fadeOut.setToValue(0);

        fadeIn.setCycleCount(1);
        fadeOut.setCycleCount(1);

        //linear-gradient(145deg, #dadbde, #ffffff);

        backButton.addEventHandler(MouseEvent.MOUSE_ENTERED,
                e -> {
                    backButton.setEffect(dropShadow2);
                    backButton.setGraphic(graphic2);
                    l2.setText("Back to Home");
                    l1.setText("");
                });

        backButton.addEventHandler(MouseEvent.MOUSE_EXITED,
                e -> {
                    backButton.setEffect(dropShadow2);
                    backButton.setGraphic(graphic1);
                    l1.setText("MEMORY");
                    l2.setText("GAME");
                });

        File f = new File("config.properties");
        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){
                r3litsener.setSelected(true);
                b3.setEffect(btn_OutBoxShadow);
            }
            else if(width == 1600 ){
                r2litsener.setSelected(true);
                b2.setEffect(btn_OutBoxShadow);
            }
            else if(width == 1280){
                r1litsener.setSelected(true);
                b1.setEffect(btn_OutBoxShadow);
            }
        }

        b1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> b1.setEffect(btn_OutBoxShadow));
        b1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
            if (r1litsener.isSelected()){
                b1.setEffect(btn_OutBoxShadow);}
            else{b1.setEffect(null);}
        });
        b1.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
            r1litsener.setSelected(true);
            r2litsener.setSelected(false);
            r3litsener.setSelected(false);
            b1.setEffect(btn_OutBoxShadow);
        });

        b2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> b2.setEffect(btn_OutBoxShadow));
        b2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
            if (r2litsener.isSelected()){
                b2.setEffect(btn_OutBoxShadow);}
            else{b2.setEffect(null);}
        });
        b2.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
            b2.setEffect(btn_OutBoxShadow);
            r1litsener.setSelected(false);
            r2litsener.setSelected(true);
            r3litsener.setSelected(false);

        });

        b3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> b3.setEffect(btn_OutBoxShadow));
        b3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
            if (r3litsener.isSelected()){
                b3.setEffect(btn_OutBoxShadow);}
            else{
                b3.setEffect(null);}
        });
        b3.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

            b3.setEffect(btn_OutBoxShadow);
            r1litsener.setSelected(false);
            r2litsener.setSelected(false);
            r3litsener.setSelected(true);
        });


    }

    @FXML
    private void closeSettings() throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("../../../resources/view/SettingsPane.fxml"));
        Stage stage = (Stage) backButton.getScene().getWindow();
        stage.getScene().setRoot(root);

        File f = new File("config.properties");
        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }

    }
    @FXML
    private void x1280Selected() throws IOException {
        output = new FileOutputStream("config.properties");
        properties.setProperty("resolution", "1280x720");
        properties.setProperty("fullScreen", "false");
        properties.setProperty("width", "1280");
        properties.setProperty("height", "720");
        properties.store(output, null);

        Parent root = FXMLLoader.load(getClass().getResource("../../../resources/view/SettingsDisplayPane.fxml"));
        Stage stage = (Stage) b2.getScene().getWindow();

        stage.setWidth(1280);
        stage.setHeight(720);
        stage.getScene().setRoot(root);
        stage.setFullScreen(false);

        File f = new File("config.properties");
        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }

    }
    @FXML
    private void x1600Selected() throws IOException {
        output = new FileOutputStream("config.properties");
        properties.setProperty("resolution", "1600x900");
        properties.setProperty("fullScreen", "false");
        properties.setProperty("width", "1600");
        properties.setProperty("height", "900");
        properties.store(output, null);

        Parent root = FXMLLoader.load(getClass().getResource("../../../resources/view/SettingsDisplayPane.fxml"));
        Stage stage = (Stage) b2.getScene().getWindow();

        stage.setWidth(1600);
        stage.setHeight(900);
        stage.getScene().setRoot(root);
        stage.setFullScreen(false);

        File f = new File("config.properties");
        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }

        }
    @FXML
    private void fullScreenSelected() throws IOException {
        output = new FileOutputStream("config.properties");
        properties.setProperty("fullScreen", "true");
        properties.setProperty("width", "999");
        properties.setProperty("height", "999");
        properties.setProperty("resolution", "FullScreen");
        properties.store(output, null);

        Parent root = FXMLLoader.load(getClass().getResource("../../../resources/view/SettingsDisplayPane.fxml"));
        Stage stage = (Stage) b3.getScene().getWindow();
        stage.setWidth(1920);
        stage.setHeight(1080);
        stage.setFullScreen(true);
        stage.getScene().setRoot(root);
        stage.setFullScreen(true);

        File f = new File("config.properties");
        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }

    }


}