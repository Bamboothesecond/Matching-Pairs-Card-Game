package main.javafx.controllers.settings;

import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.effect.BlurType;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.effect.InnerShadow;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;
import main.javafx.Main;
import main.javafx.util.SvgLoader;

import java.io.*;
import java.util.*;

public class SettingsPane {

    @FXML
    private BorderPane gg1;

    @FXML
    private VBox Panel4;

    @FXML
    private GridPane Panel1, Panel2, Panel3, Panelg1, Panelg2, Panelex, Panelex1, Panelex4;
    @FXML
    private Pane Panelex2, Panelex3;
    @FXML
    private CheckBox r1litsener, r2litsener, r3litsener, t1litsener, t2litsener, c1litsener, c2litsener, c3litsener, c4litsener;

    @FXML
    private Button clearProgress, light, dark, backButton, p1, p2, p3, b1, b2, b3, t1, t2, c1, c2, c3, c4, resetSetting, resetGame;

    @FXML
    private Label l1, l2, l3, lt1, lt2, settingsLabel, resolutionLabel, soundsLabel, clearProgressLabel;
    @FXML
    private Slider volume;

    private Properties properties = new Properties();
    private Properties properties2 = new Properties();
    private OutputStream output = null;
    private OutputStream output2 = null;
    private InputStream input = null;
    private InputStream input2 = null;

    private MediaPlayer mediaPlayer;

    private double xOffset = 0;
    private double yOffset = 0;
    @FXML
    private Button close;

    private String fs, theme, mode;

    final SvgLoader loader = new SvgLoader();

    DropShadow effectBG_DropShadow,effectC_DropShadowADD,effectC_DropShadow,effectBG_DropShadowADD;

    InnerShadow effectBG_InnerShadowADD,effectBG_InnerShadow,effectC_InnerShadowADD,effectC_InnerShadow;
    InputStream svgFileBack,svgFileDisplay,svgFileDisplay_Hover,svgFileTheme,svgFileTheme_Hover,svgFileSetting,svgFileSetting_Hover,svgFileSound,svgFileSound_Hover;

    String color,color2;

    public SettingsPane() {
        Media buttonSound = new Media(new File("src/main/resources/Sounds/buttonSound.wav").toURI().toString());
        mediaPlayer = new MediaPlayer(buttonSound);
    }

    @FXML
    private void initialize() throws IOException {

        File f = new File("config.properties");
        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            int theme = Integer.parseInt(properties.getProperty("TMode"));
            int tColor = Integer.parseInt(properties.getProperty("TColor"));

            if(width == 999 ){

                backButton.setPrefSize(64,64);

                if(theme==1){
                    color = "#f3f5f7";

                    if (tColor==1){
                        color2 = "#007aff";

                        //PANEL
                        gg1.setStyle("-fx-background-color: "+color2+"; ");//body

                        //exitpanel
                        Panelex.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==2){
                        color2 = "#fff44f";

                        //t1.setTextFill(Color.rgb(255,255,0));

                        //PANEL
                        gg1.setStyle("-fx-background-color: "+color2+"; ");//body

                        //exitpanel
                        Panelex.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==3){
                        color2 = "#00c853";

                        //PANEL
                        gg1.setStyle("-fx-background-color: "+color2+";");//body

                        //exitpanel
                        Panelex.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==4){
                        color2 = "#d50000";

                        //PANEL
                        gg1.setStyle("-fx-background-color: "+color2+"; ;");//body

                        //exitpanel
                        Panelex.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }

                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));

                    //BUTTON
                    backButton.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                    Panel1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");
                    Panel2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");
                    Panel3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");

                    p1.setStyle("-fx-background-color: "+color+";");
                    p2.setStyle("-fx-background-color: "+color+";");
                    p3.setStyle("-fx-background-color: "+color+";");

                    Panelex1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 0 36;");
                    Panelex3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 0 0;");
                    Panel4.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");

                    //menu
                    Panelex4.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 0 0;");

                }
                else if(theme==2){
                    color = "#181818";

                    if (tColor==1){
                        color2 = "#004fcb";

                        //PANEL
                        gg1.setStyle("-fx-background-color: "+color2+"; ;");//body

                        //exitpanel
                        Panelex.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==2){
                        color2 = "#c9c208";

                        //PANEL
                        gg1.setStyle("-fx-background-color: "+color2+"; ;");//body

                        //exitpanel
                        Panelex.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==3){
                        color2 = "#006500";

                        //PANEL
                        gg1.setStyle("-fx-background-color: "+color2+"; ;");//body

                        //exitpanel
                        Panelex.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==4){
                        color2 = "#9b0000";

                        //PANEL
                        gg1.setStyle("-fx-background-color: "+color2+";");//body

                        //exitpanel
                        Panelex.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }

                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));

                    //BUTTON
                    backButton.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                    Panel1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");
                    Panel2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");
                    Panel3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");
                    b1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");
                    b2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");
                    b3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");
                    resetSetting.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");
                    resetGame.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");

                    p1.setStyle("-fx-background-color: "+color+";");
                    p2.setStyle("-fx-background-color: "+color+";");
                    p3.setStyle("-fx-background-color: "+color+";");

                    c1.setStyle("-fx-background-color: #004fcb; -fx-background-radius: 50%;");
                    c2.setStyle("-fx-background-color: #c9c208; -fx-background-radius: 50%;");
                    c3.setStyle("-fx-background-color: #006500; -fx-background-radius: 50%;");
                    c4.setStyle("-fx-background-color: #9b0000; -fx-background-radius: 50%;");

                    //exitpanel
                    Panelex1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 0 36;");
                    Panelex3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 0 0;");
                    Panel4.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");

                    //menu
                    Panelex4.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 0 0;");

                }

            }
            else if(width == 1600 ){
                backButton.setPrefSize(64,64);

                if(theme==1){
                    color = "#f3f5f7";

                    if (tColor==1){
                        color2 = "#007aff";

                        //PANEL
                        gg1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");//body

                        //exitpanel
                        Panelex.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 0 36 0;");

                    }
                    else if (tColor==2){
                        color2 = "#fff44f";

                        //PANEL
                        gg1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");//body

                        //exitpanel
                        Panelex.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 0 36 0;");

                    }
                    else if (tColor==3){
                        color2 = "#00c853";

                        //PANEL
                        gg1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");//body

                        //exitpanel
                        Panelex.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 0 36 0;");

                    }
                    else if (tColor==4){
                        color2 = "#d50000";

                        //PANEL
                        gg1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");//body

                        //exitpanel
                        Panelex.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 0 36 0;");

                    }

                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));

                    //BUTTON
                    backButton.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                    Panel1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");
                    Panel2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");
                    Panel3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");

                    p1.setStyle("-fx-background-color: "+color+";");
                    p2.setStyle("-fx-background-color: "+color+";");
                    p3.setStyle("-fx-background-color: "+color+";");

                    //exitpanel
                    Panelex1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 0 36;");
                    Panelex3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 34 0 0;");
                    Panel4.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");

                    //menu
                    Panelex4.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 34 34;");

                    //TEXT

                }
                else if(theme==2){
                    color = "#181818";

                    if (tColor==1){
                        color2 = "#004fcb";

                        //PANEL
                        gg1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");//body

                        //exitpanel
                        Panelex.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 0 36 0;");

                    }
                    else if (tColor==2){
                        color2 = "#c9c208";

                        //PANEL
                        gg1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");//body

                        //exitpanel
                        Panelex.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 0 36 0;");

                    }
                    else if (tColor==3){
                        color2 = "#006500";

                        //PANEL
                        gg1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");//body

                        //exitpanel
                        Panelex.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 0 36 0;");

                    }
                    else if (tColor==4){
                        color2 = "#9b0000";

                        //PANEL
                        gg1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");//body

                        //exitpanel
                        Panelex.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 0 36 0;");

                    }

                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));

                    //BUTTON
                    backButton.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                    Panel1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");
                    Panel2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");
                    Panel3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");
                    b1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");
                    b2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");
                    b3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");
                    resetSetting.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");
                    resetGame.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");

                    c1.setStyle("-fx-background-color: #004fcb; -fx-background-radius: 50%;");
                    c2.setStyle("-fx-background-color: #c9c208; -fx-background-radius: 50%;");
                    c3.setStyle("-fx-background-color: #006500; -fx-background-radius: 50%;");
                    c4.setStyle("-fx-background-color: #9b0000; -fx-background-radius: 50%;");

                    p1.setStyle("-fx-background-color: "+color+";");
                    p2.setStyle("-fx-background-color: "+color+";");
                    p3.setStyle("-fx-background-color: "+color+";");

                    //exitpanel
                    Panelex1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 0 36;");
                    Panelex3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 34 0 0;");
                    Panel4.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");

                    //menu
                    Panelex4.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 34 34;");

                }

            }
            else if(width == 1280){

                if(theme==1){
                    color = "#f3f5f7";

                    if (tColor==1){
                        color2 = "#007aff";

                        //PANEL
                        gg1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");//body

                        //exitpanel
                        Panelex.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 0 36 0;");

                    }
                    else if (tColor==2){
                        color2 = "#fff44f";

                        //PANEL
                        gg1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");//body

                        //exitpanel
                        Panelex.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 0 36 0;");

                    }
                    else if (tColor==3){
                        color2 = "#00c853";

                        //PANEL
                        gg1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");//body

                        //exitpanel
                        Panelex.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 0 36 0;");

                    }
                    else if (tColor==4){
                        color2 = "#d50000";

                        //PANEL
                        gg1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");//body

                        //exitpanel
                        Panelex.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 0 36 0;");

                    }

                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));

                    //BUTTON
                    backButton.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                    Panel1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");
                    Panel2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");
                    Panel3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");

                    p1.setStyle("-fx-background-color: "+color+";");
                    p2.setStyle("-fx-background-color: "+color+";");
                    p3.setStyle("-fx-background-color: "+color+";");

                    //exitpanel
                    Panelex1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 0 36;");
                    Panelex3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 34 0 0;");
                    Panel4.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");

                    //menu
                    Panelex4.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 34 34;");

                    //TEXT

                }
                else if(theme==2){
                    color = "#181818";

                    if (tColor==1){
                        color2 = "#004fcb";

                        //PANEL
                        gg1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");//body

                        //exitpanel
                        Panelex.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 0 36 0;");

                    }
                    else if (tColor==2){
                        color2 = "#c9c208";

                        //PANEL
                        gg1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");//body

                        //exitpanel
                        Panelex.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 0 36 0;");

                    }
                    else if (tColor==3){
                        color2 = "#006500";

                        //PANEL
                        gg1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");//body

                        //exitpanel
                        Panelex.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 0 36 0;");

                    }
                    else if (tColor==4){
                        color2 = "#9b0000";

                        //PANEL
                        gg1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");//body

                        //exitpanel
                        Panelex.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 0 36 0;");

                    }

                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));

                    //BUTTON
                    backButton.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                    Panel1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");
                    Panel2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");
                    Panel3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");
                    b1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");
                    b2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");
                    b3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");
                    resetSetting.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");
                    resetGame.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");

                    c1.setStyle("-fx-background-color: #004fcb; -fx-background-radius: 50%;");
                    c2.setStyle("-fx-background-color: #c9c208; -fx-background-radius: 50%;");
                    c3.setStyle("-fx-background-color: #006500; -fx-background-radius: 50%;");
                    c4.setStyle("-fx-background-color: #9b0000; -fx-background-radius: 50%;");

                    p1.setStyle("-fx-background-color: "+color+";");
                    p2.setStyle("-fx-background-color: "+color+";");
                    p3.setStyle("-fx-background-color: "+color+";");

                    //exitpanel
                    Panelex1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 0 36;");
                    Panelex3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 34 0 0;");
                    Panel4.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");

                    //menu
                    Panelex4.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 34 34;");

                }
            }

        }

        themeHandler();

    }

    private void themeHandler() throws IOException {

        GaussianBlur blur = new GaussianBlur(5);

        FadeTransition fadeIn = new FadeTransition();//BG
        FadeTransition fadeIn2 = new FadeTransition();//BG
        FadeTransition fadeIn3 = new FadeTransition();//BG
        FadeTransition fadeIn4 = new FadeTransition();//PANEL1
        FadeTransition fadeIn4_1 = new FadeTransition();//PANEL2
        FadeTransition fadeIn4_2 = new FadeTransition();//PANEL3
        FadeTransition fadeIn4_3 = new FadeTransition();//PANEL4
        FadeTransition fadeIn5 = new FadeTransition();//B1
        FadeTransition fadeIn5_1 = new FadeTransition();//B2
        FadeTransition fadeIn5_2 = new FadeTransition();//B3
        FadeTransition fadeIn6 = new FadeTransition();//T1
        FadeTransition fadeIn6_1 = new FadeTransition();//T2
        FadeTransition fadeIn7 = new FadeTransition();//C1
        FadeTransition fadeIn7_1 = new FadeTransition();//C2
        FadeTransition fadeIn7_2 = new FadeTransition();//C3
        FadeTransition fadeIn7_3 = new FadeTransition();//C4
        FadeTransition fadeIn8 = new FadeTransition();//lt1
        FadeTransition fadeIn8_1 = new FadeTransition();//lt2
        FadeTransition fadeIn9 = new FadeTransition();//r1
        FadeTransition fadeIn9_1 = new FadeTransition();//r2
        FadeTransition fadeIn10 = new FadeTransition();//back
        FadeTransition fadeIn11 = new FadeTransition();//l2

        FadeTransition fadeOut = new FadeTransition();//BG
        FadeTransition fadeOut2 = new FadeTransition();//BG
        FadeTransition fadeOut3 = new FadeTransition();//BG
        FadeTransition fadeOut4 = new FadeTransition();//PANEL1
        FadeTransition fadeOut4_1 = new FadeTransition();//PANEL2
        FadeTransition fadeOut4_2 = new FadeTransition();//PANEL3
        FadeTransition fadeOut4_3 = new FadeTransition();//PANEL4
        FadeTransition fadeOut5 = new FadeTransition();//B1
        FadeTransition fadeOut5_1 = new FadeTransition();//B2
        FadeTransition fadeOut5_2 = new FadeTransition();//B3
        FadeTransition fadeOut6 = new FadeTransition();//T1
        FadeTransition fadeOut6_1 = new FadeTransition();//T2
        FadeTransition fadeOut7 = new FadeTransition();//C1
        FadeTransition fadeOut7_1 = new FadeTransition();//C2
        FadeTransition fadeOut7_2 = new FadeTransition();//C3
        FadeTransition fadeOut7_3 = new FadeTransition();//C4
        FadeTransition fadeOut8 = new FadeTransition();//lt1
        FadeTransition fadeOut8_1 = new FadeTransition();//lt2
        FadeTransition fadeOut9 = new FadeTransition();//r1
        FadeTransition fadeOut9_1 = new FadeTransition();//r2
        FadeTransition fadeOut10 = new FadeTransition();//back
        FadeTransition fadeOut11 = new FadeTransition();//l2

        fadeIn.setDuration(Duration.millis(500));//BG
        fadeIn2.setDuration(Duration.millis(500));//BG
        fadeIn3.setDuration(Duration.millis(500));//BG
        fadeIn4.setDuration(Duration.millis(750));//PANEL1
        fadeIn4_1.setDuration(Duration.millis(800));//PANEL2
        fadeIn4_2.setDuration(Duration.millis(950));//PANEL3
        fadeIn4_3.setDuration(Duration.millis(1000));//PANEL4
        fadeIn5.setDuration(Duration.millis(250));//B1
        fadeIn5_1.setDuration(Duration.millis(350));//B2
        fadeIn5_2.setDuration(Duration.millis(400));//B3
        fadeIn6.setDuration(Duration.millis(100));//T1
        fadeIn6_1.setDuration(Duration.millis(200));//T2
        fadeIn7.setDuration(Duration.millis(650));//C1
        fadeIn7_1.setDuration(Duration.millis(750));//C2
        fadeIn7_2.setDuration(Duration.millis(900));//C3
        fadeIn7_3.setDuration(Duration.millis(1000));//C4
        fadeIn8.setDuration(Duration.millis(100));//lt1
        fadeIn8_1.setDuration(Duration.millis(60));//lt2
        fadeIn9.setDuration(Duration.millis(250));//r1
        fadeIn9_1.setDuration(Duration.millis(750));//r2
        fadeIn10.setDuration(Duration.millis(750));//back
        fadeIn11.setDuration(Duration.millis(750));//l2

        fadeOut.setDuration(Duration.millis(500));//BG
        fadeOut2.setDuration(Duration.millis(500));//BG
        fadeOut3.setDuration(Duration.millis(500));//BG
        fadeOut4.setDuration(Duration.millis(750));//PANEL1
        fadeOut4_1.setDuration(Duration.millis(800));//PANEL2
        fadeOut4_2.setDuration(Duration.millis(950));//PANEL3
        fadeOut4_3.setDuration(Duration.millis(1000));//PANEL4
        fadeOut5.setDuration(Duration.millis(500));//B1
        fadeOut5_1.setDuration(Duration.millis(500));//B2
        fadeOut5_2.setDuration(Duration.millis(500));//B3
        fadeOut6.setDuration(Duration.millis(250));//T1
        fadeOut6_1.setDuration(Duration.millis(250));//T2
        fadeOut7.setDuration(Duration.millis(500));//C1
        fadeOut7_1.setDuration(Duration.millis(500));//C2
        fadeOut7_2.setDuration(Duration.millis(500));//C3
        fadeOut7_3.setDuration(Duration.millis(500));//C4
        fadeOut8.setDuration(Duration.millis(250));//lt1
        fadeOut8_1.setDuration(Duration.millis(500));//lt2
        fadeOut9.setDuration(Duration.millis(500));//r1
        fadeOut9_1.setDuration(Duration.millis(500));//r2
        fadeOut10.setDuration(Duration.millis(300));//back
        fadeOut11.setDuration(Duration.millis(300));//l2

        fadeIn.setFromValue(0);
        fadeIn.setToValue(10);
        fadeIn2.setFromValue(0);
        fadeIn2.setToValue(10);
        fadeIn3.setFromValue(0);
        fadeIn3.setToValue(10);
        fadeIn4.setFromValue(0);
        fadeIn4.setToValue(10);
        fadeIn4_1.setFromValue(0);
        fadeIn4_1.setToValue(10);
        fadeIn4_2.setFromValue(0);
        fadeIn4_2.setToValue(10);
        fadeIn4_3.setFromValue(0);
        fadeIn4_3.setToValue(10);
        fadeIn5.setFromValue(0);
        fadeIn5.setToValue(10);
        fadeIn5_1.setFromValue(0);
        fadeIn5_1.setToValue(10);
        fadeIn5_2.setFromValue(0);
        fadeIn5_2.setToValue(10);
        fadeIn6.setFromValue(0);
        fadeIn6.setToValue(10);
        fadeIn6_1.setFromValue(0);
        fadeIn6_1.setToValue(10);
        fadeIn7.setFromValue(0);
        fadeIn7.setToValue(10);
        fadeIn7_1.setFromValue(0);
        fadeIn7_1.setToValue(10);
        fadeIn7_2.setFromValue(0);
        fadeIn7_2.setToValue(10);
        fadeIn7_3.setFromValue(0);
        fadeIn7_3.setToValue(10);
        fadeIn8.setFromValue(0);
        fadeIn8.setToValue(10);
        fadeIn8_1.setFromValue(0);
        fadeIn8_1.setToValue(10);
        fadeIn9.setFromValue(0);
        fadeIn9.setToValue(10);
        fadeIn9_1.setFromValue(0);
        fadeIn9_1.setToValue(10);
        fadeIn10.setFromValue(0);
        fadeIn10.setToValue(10);
        fadeIn11.setFromValue(0);
        fadeIn11.setToValue(10);

        fadeOut.setFromValue(10);
        fadeOut.setToValue(0);
        fadeOut2.setFromValue(10);
        fadeOut2.setToValue(0);
        fadeOut3.setFromValue(10);
        fadeOut3.setToValue(0);
        fadeOut4.setFromValue(10);
        fadeOut4.setToValue(0);
        fadeOut4_1.setFromValue(10);
        fadeOut4_1.setToValue(0);
        fadeOut4_2.setFromValue(10);
        fadeOut4_2.setToValue(0);
        fadeOut4_3.setFromValue(10);
        fadeOut4_3.setToValue(0);
        fadeOut5.setFromValue(10);
        fadeOut5.setToValue(0);
        fadeOut5_1.setFromValue(10);
        fadeOut5_1.setToValue(0);
        fadeOut5_2.setFromValue(10);
        fadeOut5_2.setToValue(0);
        fadeOut6.setFromValue(10);
        fadeOut6.setToValue(0);
        fadeOut6_1.setFromValue(10);
        fadeOut6_1.setToValue(0);
        fadeOut7.setFromValue(10);
        fadeOut7.setToValue(0);
        fadeOut7_1.setFromValue(10);
        fadeOut7_1.setToValue(0);
        fadeOut7_2.setFromValue(10);
        fadeOut7_2.setToValue(0);
        fadeOut7_3.setFromValue(10);
        fadeOut7_3.setToValue(0);
        fadeOut8.setFromValue(10);
        fadeOut8.setToValue(0);
        fadeOut8_1.setFromValue(10);
        fadeOut8_1.setToValue(0);
        fadeOut9.setFromValue(10);
        fadeOut9.setToValue(0);
        fadeOut9_1.setFromValue(10);
        fadeOut9_1.setToValue(0);
        fadeOut10.setFromValue(10);
        fadeOut10.setToValue(0);
        fadeOut11.setFromValue(10);
        fadeOut11.setToValue(0);

        fadeIn.setCycleCount(1);
        fadeIn2.setCycleCount(1);
        fadeIn3.setCycleCount(1);
        fadeIn4.setCycleCount(1);
        fadeIn4_1.setCycleCount(1);
        fadeIn4_2.setCycleCount(1);
        fadeIn4_3.setCycleCount(1);
        fadeIn5.setCycleCount(1);
        fadeIn5_1.setCycleCount(1);
        fadeIn5_2.setCycleCount(1);
        fadeIn6.setCycleCount(1);
        fadeIn6_1.setCycleCount(1);
        fadeIn7.setCycleCount(1);
        fadeIn7_1.setCycleCount(1);
        fadeIn7_2.setCycleCount(1);
        fadeIn7_3.setCycleCount(1);
        fadeIn8.setCycleCount(1);
        fadeIn8_1.setCycleCount(1);
        fadeIn9.setCycleCount(1);
        fadeIn9_1.setCycleCount(1);
        fadeIn10.setCycleCount(1);
        fadeIn11.setCycleCount(1);

        fadeOut.setCycleCount(1);
        fadeOut2.setCycleCount(1);
        fadeOut3.setCycleCount(1);
        fadeOut4.setCycleCount(1);
        fadeOut4_1.setCycleCount(1);
        fadeOut4_2.setCycleCount(1);
        fadeOut4_3.setCycleCount(1);
        fadeOut5.setCycleCount(1);
        fadeOut5_1.setCycleCount(1);
        fadeOut5_2.setCycleCount(1);
        fadeOut6.setCycleCount(1);
        fadeOut6_1.setCycleCount(1);
        fadeOut7.setCycleCount(1);
        fadeOut7_1.setCycleCount(1);
        fadeOut7_2.setCycleCount(1);
        fadeOut7_3.setCycleCount(1);
        fadeOut8.setCycleCount(1);
        fadeOut8_1.setCycleCount(1);
        fadeOut9.setCycleCount(1);
        fadeOut9_1.setCycleCount(1);
        fadeOut10.setCycleCount(1);
        fadeOut11.setCycleCount(1);

        fadeIn.setNode(Panelex1);
        fadeIn2.setNode(Panelex4);
        fadeIn3.setNode(Panelex3);
        fadeIn4.setNode(Panel1);
        fadeIn4_1.setNode(Panel2);
        fadeIn4_2.setNode(Panel3);
        fadeIn4_3.setNode(Panel4);
        fadeIn5.setNode(b1);
        fadeIn5_1.setNode(b2);
        fadeIn5_2.setNode(b3);
        fadeIn6.setNode(t1);
        fadeIn6_1.setNode(t2);
        fadeIn7.setNode(c1);
        fadeIn7_1.setNode(c2);
        fadeIn7_2.setNode(c3);
        fadeIn7_3.setNode(c4);
        fadeIn8.setNode(lt1);
        fadeIn8_1.setNode(lt2);
        fadeIn9.setNode(resetSetting);
        fadeIn9_1.setNode(resetGame);
        fadeIn10.setNode(backButton);
        fadeIn11.setNode(l2);

        fadeOut.setNode(Panelex1);
        fadeOut2.setNode(Panelex4);
        fadeOut3.setNode(Panelex3);
        fadeOut4.setNode(Panel1);
        fadeOut4_1.setNode(Panel2);
        fadeOut4_2.setNode(Panel3);
        fadeOut4_3.setNode(Panel4);
        fadeOut5.setNode(b1);
        fadeOut5_1.setNode(b2);
        fadeOut5_2.setNode(b3);
        fadeOut6.setNode(t1);
        fadeOut6_1.setNode(t2);
        fadeOut7.setNode(c1);
        fadeOut7_1.setNode(c2);
        fadeOut7_2.setNode(c3);
        fadeOut7_3.setNode(c4);
        fadeOut8.setNode(lt1);
        fadeOut8_1.setNode(lt2);
        fadeOut9.setNode(resetSetting);
        fadeOut9_1.setNode(resetGame);
        fadeOut10.setNode(backButton);
        fadeOut11.setNode(l2);

        File f = new File("config.properties");
        if(f.exists()) {
            input = new FileInputStream("config.properties");
            properties.load(input);

            int menuSelected = Integer.parseInt(properties.getProperty("MenuSelected"));
            int theme = Integer.parseInt(properties.getProperty("TMode"));
            int tColor = Integer.parseInt(properties.getProperty("TColor"));

            if (menuSelected == 1){
                b1.setVisible(false);
                b2.setVisible(false);
                b3.setVisible(false);

                lt1.setVisible(false);
                lt2.setVisible(false);

                t1.setVisible(false);
                t2.setVisible(false);

                c1.setVisible(false);
                c2.setVisible(false);
                c3.setVisible(false);
                c4.setVisible(false);

                resetSetting.setVisible(false);
                resetGame.setVisible(false);

                fadeIn.play();//BG
                fadeIn2.play();//BG
                fadeIn3.play();//BG
                fadeIn4.play();//PANEL1
                fadeIn4_1.play();//PANEL2
                fadeIn4_2.play();//PANEL3
                fadeIn4_3.play();//PANEL4

                Panel1.setVisible(true);
                Panel2.setVisible(true);
                Panel3.setVisible(true);
                Panel4.setVisible(true);

                Panelex4.setVisible(true);
                Panelex3.setVisible(true);
                Panelex1.setVisible(true);

                output = new FileOutputStream("config.properties");
                properties.setProperty("MenuSelected", "2");
                properties.store(output, null);

            }

            if(theme==1){

                color = "#f3f5f7";

                effectBG_DropShadowADD = new DropShadow(BlurType.GAUSSIAN, Color.rgb(206,207,210), 36, 0, 9, 9);
                effectBG_DropShadow = new DropShadow(BlurType.GAUSSIAN, Color.rgb(255,255,255), 10, 0, -5,-5);
                effectBG_DropShadow.setInput(effectBG_DropShadowADD);

                effectBG_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(206,207,210), 10, 0, 5,5);
                effectBG_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(255,255,255), 10, 0, -5,-5);
                effectBG_InnerShadow.setInput(effectBG_InnerShadowADD);

                if (tColor==1) {

                    color2 = "#007aff";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,104,217), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,140,255), 10, 0, -5, -5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,104,217), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,140,255), 10, 0, -5, -5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBack = getClass().getResourceAsStream("../../../resources/svg/left-arrow_blue.svg");//

                    svgFileDisplay = getClass().getResourceAsStream("../../../resources/svg/resolution.svg");
                    svgFileDisplay_Hover = getClass().getResourceAsStream("../../../resources/svg/resolution_blue.svg");

                    svgFileTheme = getClass().getResourceAsStream("../../../resources/svg/theme.svg");
                    svgFileTheme_Hover = getClass().getResourceAsStream("../../../resources/svg/theme_blue.svg");

                    svgFileSetting = getClass().getResourceAsStream("../../../resources/svg/menu/menu.svg");
                    svgFileSetting_Hover = getClass().getResourceAsStream("../../../resources/svg/menu/menu_blue.svg");

                    svgFileSound = getClass().getResourceAsStream("../../../resources/svg/volume.svg");
                    svgFileSound_Hover = getClass().getResourceAsStream("../../../resources/svg/volume_blue.svg");

                    Group svgBack = loader.loadSvg(svgFileBack);
                    Group svgSetting = loader.loadSvg(svgFileSetting);
                    Group svgSetting_Hover = loader.loadSvg(svgFileSetting_Hover);

                    Group svgDisplay = loader.loadSvg(svgFileDisplay);
                    Group svgDisplay_Hover = loader.loadSvg(svgFileDisplay_Hover);

                    Group svgSound = loader.loadSvg(svgFileSound);
                    Group svgSound_Hover = loader.loadSvg(svgFileSound_Hover);

                    Group svgTheme = loader.loadSvg(svgFileTheme);
                    Group svgTheme_Hover = loader.loadSvg(svgFileTheme_Hover);

                    svgBack.setScaleX(.04);
                    svgBack.setScaleY(.04);

                    svgSetting.setScaleX(.04);
                    svgSetting.setScaleY(.04);

                    svgSetting_Hover.setScaleX(.04);
                    svgSetting_Hover.setScaleY(.04);

                    svgDisplay.setScaleX(.25);
                    svgDisplay.setScaleY(.25);

                    svgDisplay_Hover.setScaleX(.25);
                    svgDisplay_Hover.setScaleY(.25);

                    svgSound.setScaleX(.25);
                    svgSound.setScaleY(.25);

                    svgSound_Hover.setScaleX(.25);
                    svgSound_Hover.setScaleY(.25);

                    svgTheme.setScaleX(.25);
                    svgTheme.setScaleY(.25);

                    svgTheme_Hover.setScaleX(.25);
                    svgTheme_Hover.setScaleY(.25);

                    Group svgIconBack = new Group(svgBack);
                    Group svgIconSetting = new Group(svgSetting);
                    Group svgIconSetting_Hover = new Group(svgSetting_Hover);

                    Group svgIconDisplay = new Group(svgDisplay);
                    Group svgIconDisplay_Hover = new Group(svgDisplay_Hover);

                    Group svgIconSound = new Group(svgSound);
                    Group svgIconSound_Hover = new Group(svgSound_Hover);

                    Group svgIconTheme = new Group(svgTheme);
                    Group svgIconTheme_Hover = new Group(svgTheme_Hover);

                    if (f.exists()) {
                        properties.load(input);

                        int width = Integer.parseInt(properties.getProperty("width"));
                        if (width == 999) {
                            r3litsener.setSelected(true);
                            b3.setEffect(effectBG_DropShadow);
                            b3.setTextFill(Color.web(color2));
                            b3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");

                            t1.setPrefSize(128, 128);
                            t2.setPrefSize(128, 128);

                            c1.setPrefSize(128, 128);
                            c2.setPrefSize(128, 128);
                            c3.setPrefSize(128, 128);
                            c4.setPrefSize(128, 128);
                        }
                        else if (width == 1600) {
                            r2litsener.setSelected(true);
                            b2.setEffect(effectBG_DropShadow);
                            b2.setTextFill(Color.web(color2));
                            b2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");

                            t1.setPrefSize(96, 96);
                            t2.setPrefSize(96, 96);

                            c1.setPrefSize(96, 96);
                            c2.setPrefSize(96, 96);
                            c3.setPrefSize(96, 96);
                            c4.setPrefSize(96, 96);
                        }
                        else if (width == 1280) {
                            r1litsener.setSelected(true);
                            b1.setEffect(effectBG_DropShadow);
                            b1.setTextFill(Color.web(color2));
                            b1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");
                        }

                        int t = Integer.parseInt(properties.getProperty("TMode"));
                        if (t == 1) {

                            t1litsener.setSelected(true);
                            t2litsener.setSelected(false);

                            t1.setEffect(effectBG_DropShadow);
                            t1.setStyle("-fx-background-color: #f3f5f7; -fx-background-radius: 50%; -fx-border-color: "+color2+"; -fx-border-radius: 50%; -fx-border-width: 3  ;");

                            t2.setEffect(null);

                        }
                        else {

                            t1litsener.setSelected(false);
                            t2litsener.setSelected(true);

                            t1.setEffect(null);
                            t2.setEffect(effectBG_DropShadow);
                            t2.setStyle("-fx-background-color: #000; -fx-background-radius: 50%; -fx-border-color: "+color2+"; -fx-border-radius: 50%; -fx-border-width: 3  ;");


                        }

                        int c = Integer.parseInt(properties.getProperty("TColor"));
                        if (c == 1) {

                            c1litsener.setSelected(true);
                            c2litsener.setSelected(false);
                            c3litsener.setSelected(false);
                            c4litsener.setSelected(false);

                            c1.setEffect(effectBG_DropShadow);
                            c1.setStyle("-fx-background-color: #007aff; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                            c2.setEffect(null);
                            c3.setEffect(null);
                            c4.setEffect(null);

                        }
                        else if (c == 2) {

                            c1.setEffect(null);
                            c2.setEffect(effectBG_DropShadow);
                            c2.setStyle("-fx-background-color: #fff44f; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                            c3.setEffect(null);
                            c4.setEffect(null);

                            c1litsener.setSelected(false);
                            c2litsener.setSelected(true);
                            c3litsener.setSelected(false);
                            c4litsener.setSelected(false);

                        }
                        else if (c == 3) {

                            c1litsener.setSelected(false);
                            c2litsener.setSelected(false);
                            c3litsener.setSelected(true);
                            c4litsener.setSelected(false);

                            c1.setEffect(null);
                            c2.setEffect(null);
                            c3.setEffect(effectBG_DropShadow);
                            c3.setStyle("-fx-background-color: #00c853; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                            c4.setEffect(null);

                        }
                        else if (c == 4) {

                            c1litsener.setSelected(false);
                            c3litsener.setSelected(false);
                            c2litsener.setSelected(false);
                            c4litsener.setSelected(true);

                            c1.setEffect(null);
                            c2.setEffect(null);
                            c3.setEffect(null);
                            c4.setEffect(effectBG_DropShadow);
                            c4.setStyle("-fx-background-color: #d50000; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");

                        }
                    }

                    p1.setGraphic(svgIconDisplay);
                    p2.setGraphic(svgIconSound);
                    p3.setGraphic(svgIconTheme);

                    backButton.setGraphic(svgIconSetting);

                    Panel1.setEffect(effectBG_DropShadow);
                    Panel2.setEffect(effectBG_DropShadow);
                    Panel3.setEffect(effectBG_DropShadow);
                    Panel4.setEffect(effectBG_DropShadow);

                    b1.addEventHandler(MouseEvent.MOUSE_ENTERED, e-> b1.setEffect(effectBG_DropShadow));
                    b1.addEventHandler(MouseEvent.MOUSE_EXITED, e->{

                        if (r1litsener.isSelected()) {
                            b1.setEffect(effectBG_DropShadow);
                        } else {
                            b1.setEffect(null);
                        }

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
                        r1litsener.setSelected(true);
                        r2litsener.setSelected(false);
                        r3litsener.setSelected(false);
                        b1.setEffect(effectBG_DropShadow);
                        b1.setTextFill(Color.web(color2));
                        b1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");

                    });

                    b2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> b2.setEffect(effectBG_DropShadow));
                    b2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r2litsener.isSelected()) {
                            b2.setEffect(effectBG_DropShadow);
                        } else {
                            b2.setEffect(null);
                        }
                    });
                    b2.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
                        b2.setEffect(effectBG_DropShadow);
                        b2.setTextFill(Color.web(color2));
                        b2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");

                        r1litsener.setSelected(false);
                        r2litsener.setSelected(true);
                        r3litsener.setSelected(false);

                    });

                    b3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> b3.setEffect(effectBG_DropShadow));
                    b3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r3litsener.isSelected()) {
                            b3.setEffect(effectBG_DropShadow);
                        } else {
                            b3.setEffect(null);
                        }
                    });
                    b3.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        b3.setEffect(effectBG_DropShadow);
                        b3.setTextFill(Color.web(color2));
                        b3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");
                        r1litsener.setSelected(false);
                        r2litsener.setSelected(false);
                        r3litsener.setSelected(true);
                    });

                    t1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> t1.setEffect(effectBG_DropShadow));
                    t1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t1litsener.isSelected()) {
                            t1.setEffect(effectBG_DropShadow);
                        } else {
                            t1.setEffect(null);
                        }
                    });
                    t1.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1litsener.setSelected(true);
                        t2litsener.setSelected(false);

                        t1.setEffect(effectBG_DropShadow);
                        t1.setStyle("-fx-background-color: #f3f5f7; -fx-background-radius: 50%; -fx-border-color: "+color2+"; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                        t2.setEffect(null);

                    });

                    t2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> t2.setEffect(effectBG_DropShadow));
                    t2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t2litsener.isSelected()) {
                            t2.setEffect(effectBG_DropShadow);
                        } else {
                            t2.setEffect(null);
                        }
                    });
                    t2.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1litsener.setSelected(false);
                        t2litsener.setSelected(true);

                        t1.setEffect(null);
                        t2.setEffect(effectBG_DropShadow);
                        t2.setStyle("-fx-background-color: #000; -fx-background-radius: 50%; -fx-border-color: "+color2+"; -fx-border-radius: 50%; -fx-border-width: 3  ;");

                    });

                    c1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> t1.setEffect(effectBG_DropShadow));
                    c1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (c1litsener.isSelected()) {
                            c1.setEffect(effectBG_DropShadow);
                        } else {
                            c1.setEffect(null);
                        }
                    });
                    c1.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        c1litsener.setSelected(true);
                        c2litsener.setSelected(false);
                        c3litsener.setSelected(false);
                        c4litsener.setSelected(false);

                        c1.setEffect(effectBG_DropShadow);
                        c1.setStyle("-fx-background-color: #007aff; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                        c2.setEffect(null);
                        c3.setEffect(null);
                        c4.setEffect(null);

                    });

                    c2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> c2.setEffect(effectBG_DropShadow));
                    c2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (c2litsener.isSelected()) {
                            c2.setEffect(effectBG_DropShadow);
                        } else {
                            c2.setEffect(null);
                        }
                    });
                    c2.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        c1.setEffect(null);
                        c2.setEffect(effectBG_DropShadow);
                        c2.setStyle("-fx-background-color: #fff44f; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                        c3.setEffect(null);
                        c4.setEffect(null);

                        c1litsener.setSelected(false);
                        c2litsener.setSelected(true);
                        c3litsener.setSelected(false);
                        c4litsener.setSelected(false);

                    });

                    c3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> t1.setEffect(effectBG_DropShadow));
                    c3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (c3litsener.isSelected()) {
                            c3.setEffect(effectBG_DropShadow);
                        } else {
                            c3.setEffect(null);
                        }
                    });
                    c3.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        c1litsener.setSelected(false);
                        c2litsener.setSelected(false);
                        c3litsener.setSelected(true);
                        c4litsener.setSelected(false);

                        c1.setEffect(null);
                        c2.setEffect(null);
                        c3.setEffect(effectBG_DropShadow);
                        c3.setStyle("-fx-background-color: #00c853; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                        c4.setEffect(null);

                    });

                    c4.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> c4.setEffect(effectBG_DropShadow));
                    c4.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (c4litsener.isSelected()) {
                            c4.setEffect(effectBG_DropShadow);
                        } else {
                            c4.setEffect(null);
                        }
                    });
                    c4.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        c1litsener.setSelected(false);
                        c3litsener.setSelected(false);
                        c2litsener.setSelected(false);
                        c4litsener.setSelected(true);

                        c1.setEffect(null);
                        c2.setEffect(null);
                        c3.setEffect(null);
                        c4.setEffect(effectBG_DropShadow);
                        c4.setStyle("-fx-background-color: #d50000; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");

                    });

                    resetGame.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> resetGame.setEffect(effectBG_DropShadow));
                    resetGame.addEventHandler(MouseEvent.MOUSE_EXITED, e -> resetGame.setEffect(null));
                    resetGame.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> resetGame.setEffect(effectBG_DropShadow));

                    resetSetting.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> resetSetting.setEffect(effectBG_DropShadow));
                    resetSetting.addEventHandler(MouseEvent.MOUSE_EXITED, e -> resetSetting.setEffect(null));
                    resetSetting.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> resetSetting.setEffect(effectBG_DropShadow));

                    Panel1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        p1.setGraphic(svgIconDisplay_Hover);
                        b1.setVisible(true);
                        b2.setVisible(true);
                        b3.setVisible(true);

                        fadeIn5.play();
                        fadeIn5_1.play();
                        fadeIn5_2.play();

                        Panel1.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> {
                            fadeIn5.stop();
                            fadeIn5_1.stop();
                            fadeIn5_2.stop();
                        });

                    });
                    Panel1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        p1.setGraphic(svgIconDisplay);

                        b1.setVisible(true);
                        b2.setVisible(true);
                        b3.setVisible(true);

                        fadeOut5.play();
                        fadeOut5_1.play();
                        fadeOut5_2.play();

                        Panel1.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> {
                            fadeOut5.stop();
                            fadeOut5_1.stop();
                            fadeOut5_2.stop();
                        });

                    });

                    Panel2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        p2.setGraphic(svgIconSound_Hover);
                    });
                    Panel2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        p2.setGraphic(svgIconSound);
                    });

                    Panel3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        p3.setGraphic(svgIconTheme_Hover);

                        lt1.setVisible(true);
                        lt2.setVisible(true);
                        t1.setVisible(true);
                        t2.setVisible(true);
                        c1.setVisible(true);
                        c2.setVisible(true);
                        c3.setVisible(true);
                        c4.setVisible(true);

                        fadeIn6.play();
                        fadeIn6_1.play();
                        fadeIn7.play();
                        fadeIn7_1.play();
                        fadeIn7_2.play();
                        fadeIn7_3.play();
                        fadeIn8.play();
                        fadeIn8_1.play();

                        Panel3.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> {

                            fadeIn6.stop();
                            fadeIn6_1.stop();
                            fadeIn7.stop();
                            fadeIn7_1.stop();
                            fadeIn7_2.stop();
                            fadeIn7_3.stop();
                            fadeIn8.stop();
                            fadeIn8_1.stop();
                        });

                    });
                    Panel3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        p3.setGraphic(svgIconTheme);

                        fadeOut6.play();
                        fadeOut6_1.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();
                        fadeOut7_3.play();
                        fadeOut8.play();
                        fadeOut8_1.play();

                        Panel3.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> {

                            fadeOut6.stop();
                            fadeOut6_1.stop();
                            fadeOut7.stop();
                            fadeOut7_1.stop();
                            fadeOut7_2.stop();
                            fadeOut7_3.stop();
                            fadeOut8.stop();
                            fadeOut8_1.stop();

                        });

                    });

                    Panel4.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        p3.setGraphic(svgIconTheme_Hover);

                        resetGame.setVisible(true);
                        resetSetting.setVisible(true);

                        fadeIn9.play();
                        fadeIn9_1.play();

                        Panel4.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> {

                            fadeIn9.stop();
                            fadeIn9_1.stop();

                        });

                    });
                    Panel4.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        p3.setGraphic(svgIconTheme);

                        fadeOut9.play();
                        fadeOut9_1.play();

                        Panel4.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> {

                            fadeOut9.stop();
                            fadeOut9_1.stop();

                        });

                    });

                    Panelex2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        backButton.setGraphic(svgIconSetting_Hover);

                    });
                    Panelex2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        backButton.setGraphic(svgIconSetting);
                    });

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        backButton.setEffect(effectC_DropShadow);
                        backButton.setGraphic(svgIconBack);
                        l2.setText("Back to Home");
                        l1.setText("");
                        l3.setText("");
                        Panelg1.setEffect(blur);
                        Panelg2.setEffect(blur);
                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        backButton.setEffect(null);
                        backButton.setGraphic(svgIconSetting);
                        l1.setText("MEMORY");
                        l2.setText("GAME");
                        l3.setText("Setting");
                        Panelg1.setEffect(null);
                        Panelg2.setEffect(null);
                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        backButton.setGraphic(svgIconSetting);

                        fadeOut.play();
                        fadeOut2.play();
                        fadeOut3.play();
                        fadeOut10.play();
                        fadeOut11.play();

                        backButton.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.stop();
                            fadeOut2.stop();
                            fadeOut3.stop();
                            fadeOut10.stop();
                            fadeOut11.stop();

                        });

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            closeSettings();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });


                }
                else if (tColor==2) {

                    color2 = "#fff44f";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.web("#d9cf43"), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.web("#ffff5b"), 10, 0, -5, -5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.web("#d9cf43"), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.web("#ffff5b"), 10, 0, -5, -5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);


                    svgFileBack = getClass().getResourceAsStream("../../../resources/svg/left-arrow_yellow.svg");//

                    svgFileDisplay = getClass().getResourceAsStream("../../../resources/svg/resolution.svg");
                    svgFileDisplay_Hover = getClass().getResourceAsStream("../../../resources/svg/resolution_yellow.svg");

                    svgFileTheme = getClass().getResourceAsStream("../../../resources/svg/theme.svg");
                    svgFileTheme_Hover = getClass().getResourceAsStream("../../../resources/svg/theme_yellow.svg");

                    svgFileSetting = getClass().getResourceAsStream("../../../resources/svg/menu/menu.svg");
                    svgFileSetting_Hover = getClass().getResourceAsStream("../../../resources/svg/menu/menu_yellow.svg");

                    svgFileSound = getClass().getResourceAsStream("../../../resources/svg/volume.svg");
                    svgFileSound_Hover = getClass().getResourceAsStream("../../../resources/svg/volume_yellow.svg");

                    Group svgBack = loader.loadSvg(svgFileBack);
                    Group svgSetting = loader.loadSvg(svgFileSetting);
                    Group svgSetting_Hover = loader.loadSvg(svgFileSetting_Hover);

                    Group svgDisplay = loader.loadSvg(svgFileDisplay);
                    Group svgDisplay_Hover = loader.loadSvg(svgFileDisplay_Hover);

                    Group svgSound = loader.loadSvg(svgFileSound);
                    Group svgSound_Hover = loader.loadSvg(svgFileSound_Hover);

                    Group svgTheme = loader.loadSvg(svgFileTheme);
                    Group svgTheme_Hover = loader.loadSvg(svgFileTheme_Hover);

                    svgBack.setScaleX(.04);
                    svgBack.setScaleY(.04);

                    svgSetting.setScaleX(.04);
                    svgSetting.setScaleY(.04);

                    svgSetting_Hover.setScaleX(.04);
                    svgSetting_Hover.setScaleY(.04);

                    svgDisplay.setScaleX(.25);
                    svgDisplay.setScaleY(.25);

                    svgDisplay_Hover.setScaleX(.25);
                    svgDisplay_Hover.setScaleY(.25);

                    svgSound.setScaleX(.25);
                    svgSound.setScaleY(.25);

                    svgSound_Hover.setScaleX(.25);
                    svgSound_Hover.setScaleY(.25);

                    svgTheme.setScaleX(.25);
                    svgTheme.setScaleY(.25);

                    svgTheme_Hover.setScaleX(.25);
                    svgTheme_Hover.setScaleY(.25);

                    Group svgIconBack = new Group(svgBack);
                    Group svgIconSetting = new Group(svgSetting);
                    Group svgIconSetting_Hover = new Group(svgSetting_Hover);

                    Group svgIconDisplay = new Group(svgDisplay);
                    Group svgIconDisplay_Hover = new Group(svgDisplay_Hover);

                    Group svgIconSound = new Group(svgSound);
                    Group svgIconSound_Hover = new Group(svgSound_Hover);

                    Group svgIconTheme = new Group(svgTheme);
                    Group svgIconTheme_Hover = new Group(svgTheme_Hover);

                    if (f.exists()) {
                        properties.load(input);

                        int width = Integer.parseInt(properties.getProperty("width"));
                        if (width == 999) {
                            r3litsener.setSelected(true);
                            b3.setEffect(effectBG_DropShadow);
                            b3.setTextFill(Color.web(color2));
                            b3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");

                            t1.setPrefSize(128, 128);
                            t2.setPrefSize(128, 128);

                            c1.setPrefSize(128, 128);
                            c2.setPrefSize(128, 128);
                            c3.setPrefSize(128, 128);
                            c4.setPrefSize(128, 128);
                        }
                        else if (width == 1600) {
                            r2litsener.setSelected(true);
                            b2.setEffect(effectBG_DropShadow);
                            b2.setTextFill(Color.web(color2));
                            b2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");

                            t1.setPrefSize(96, 96);
                            t2.setPrefSize(96, 96);

                            c1.setPrefSize(96, 96);
                            c2.setPrefSize(96, 96);
                            c3.setPrefSize(96, 96);
                            c4.setPrefSize(96, 96);
                        }
                        else if (width == 1280) {
                            r1litsener.setSelected(true);
                            b1.setEffect(effectBG_DropShadow);
                            b1.setTextFill(Color.web(color2));
                            b1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");
                        }

                        int t = Integer.parseInt(properties.getProperty("TMode"));
                        if (t == 1) {

                            t1litsener.setSelected(true);
                            t2litsener.setSelected(false);

                            t1.setEffect(effectBG_DropShadow);
                            t1.setStyle("-fx-background-color: #f3f5f7; -fx-background-radius: 50%; -fx-border-color: "+color2+"; -fx-border-radius: 50%; -fx-border-width: 3  ;");

                            t2.setEffect(null);

                        }
                        else {

                            t1litsener.setSelected(false);
                            t2litsener.setSelected(true);

                            t1.setEffect(null);
                            t2.setEffect(effectBG_DropShadow);
                            t2.setStyle("-fx-background-color: #000; -fx-background-radius: 50%; -fx-border-color: "+color2+"; -fx-border-radius: 50%; -fx-border-width: 3  ;");


                        }

                        int c = Integer.parseInt(properties.getProperty("TColor"));
                        if (c == 1) {

                            c1litsener.setSelected(true);
                            c2litsener.setSelected(false);
                            c3litsener.setSelected(false);
                            c4litsener.setSelected(false);

                            c1.setEffect(effectBG_DropShadow);
                            c1.setStyle("-fx-background-color: #007aff; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                            c2.setEffect(null);
                            c3.setEffect(null);
                            c4.setEffect(null);

                        }
                        else if (c == 2) {

                            c1.setEffect(null);
                            c2.setEffect(effectBG_DropShadow);
                            c2.setStyle("-fx-background-color: #fff44f; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                            c3.setEffect(null);
                            c4.setEffect(null);

                            c1litsener.setSelected(false);
                            c2litsener.setSelected(true);
                            c3litsener.setSelected(false);
                            c4litsener.setSelected(false);

                        }
                        else if (c == 3) {

                            c1litsener.setSelected(false);
                            c2litsener.setSelected(false);
                            c3litsener.setSelected(true);
                            c4litsener.setSelected(false);

                            c1.setEffect(null);
                            c2.setEffect(null);
                            c3.setEffect(effectBG_DropShadow);
                            c3.setStyle("-fx-background-color: #00c853; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                            c4.setEffect(null);

                        }
                        else if (c == 4) {

                            c1litsener.setSelected(false);
                            c3litsener.setSelected(false);
                            c2litsener.setSelected(false);
                            c4litsener.setSelected(true);

                            c1.setEffect(null);
                            c2.setEffect(null);
                            c3.setEffect(null);
                            c4.setEffect(effectBG_DropShadow);
                            c4.setStyle("-fx-background-color: #d50000; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");

                        }
                    }

                    p1.setGraphic(svgIconDisplay);
                    p2.setGraphic(svgIconSound);
                    p3.setGraphic(svgIconTheme);

                    backButton.setGraphic(svgIconSetting);

                    Panel1.setEffect(effectBG_DropShadow);
                    Panel2.setEffect(effectBG_DropShadow);
                    Panel3.setEffect(effectBG_DropShadow);
                    Panel4.setEffect(effectBG_DropShadow);

                    b1.addEventHandler(MouseEvent.MOUSE_ENTERED, e-> b1.setEffect(effectBG_DropShadow));
                    b1.addEventHandler(MouseEvent.MOUSE_EXITED, e->{

                        if (r1litsener.isSelected()) {
                            b1.setEffect(effectBG_DropShadow);
                        } else {
                            b1.setEffect(null);
                        }

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
                        r1litsener.setSelected(true);
                        r2litsener.setSelected(false);
                        r3litsener.setSelected(false);
                        b1.setEffect(effectBG_DropShadow);
                        b1.setTextFill(Color.web(color2));
                        b1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");

                    });

                    b2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> b2.setEffect(effectBG_DropShadow));
                    b2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r2litsener.isSelected()) {
                            b2.setEffect(effectBG_DropShadow);
                        } else {
                            b2.setEffect(null);
                        }
                    });
                    b2.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
                        b2.setEffect(effectBG_DropShadow);
                        b2.setTextFill(Color.web(color2));
                        b2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");

                        r1litsener.setSelected(false);
                        r2litsener.setSelected(true);
                        r3litsener.setSelected(false);

                    });

                    b3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> b3.setEffect(effectBG_DropShadow));
                    b3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r3litsener.isSelected()) {
                            b3.setEffect(effectBG_DropShadow);
                        } else {
                            b3.setEffect(null);
                        }
                    });
                    b3.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        b3.setEffect(effectBG_DropShadow);
                        b3.setTextFill(Color.web(color2));
                        b3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");
                        r1litsener.setSelected(false);
                        r2litsener.setSelected(false);
                        r3litsener.setSelected(true);
                    });

                    t1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> t1.setEffect(effectBG_DropShadow));
                    t1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t1litsener.isSelected()) {
                            t1.setEffect(effectBG_DropShadow);
                        } else {
                            t1.setEffect(null);
                        }
                    });
                    t1.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1litsener.setSelected(true);
                        t2litsener.setSelected(false);

                        t1.setEffect(effectBG_DropShadow);
                        t1.setStyle("-fx-background-color: #f3f5f7; -fx-background-radius: 50%; -fx-border-color: "+color2+"; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                        t2.setEffect(null);

                    });

                    t2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> t2.setEffect(effectBG_DropShadow));
                    t2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t2litsener.isSelected()) {
                            t2.setEffect(effectBG_DropShadow);
                        } else {
                            t2.setEffect(null);
                        }
                    });
                    t2.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1litsener.setSelected(false);
                        t2litsener.setSelected(true);

                        t1.setEffect(null);
                        t2.setEffect(effectBG_DropShadow);
                        t2.setStyle("-fx-background-color: #000; -fx-background-radius: 50%; -fx-border-color: "+color2+"; -fx-border-radius: 50%; -fx-border-width: 3  ;");

                    });

                    c1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> t1.setEffect(effectBG_DropShadow));
                    c1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (c1litsener.isSelected()) {
                            c1.setEffect(effectBG_DropShadow);
                        } else {
                            c1.setEffect(null);
                        }
                    });
                    c1.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        c1litsener.setSelected(true);
                        c2litsener.setSelected(false);
                        c3litsener.setSelected(false);
                        c4litsener.setSelected(false);

                        c1.setEffect(effectBG_DropShadow);
                        c1.setStyle("-fx-background-color: #007aff; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                        c2.setEffect(null);
                        c3.setEffect(null);
                        c4.setEffect(null);

                    });

                    c2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> c2.setEffect(effectBG_DropShadow));
                    c2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (c2litsener.isSelected()) {
                            c2.setEffect(effectBG_DropShadow);
                        } else {
                            c2.setEffect(null);
                        }
                    });
                    c2.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        c1.setEffect(null);
                        c2.setEffect(effectBG_DropShadow);
                        c2.setStyle("-fx-background-color: #fff44f; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                        c3.setEffect(null);
                        c4.setEffect(null);

                        c1litsener.setSelected(false);
                        c2litsener.setSelected(true);
                        c3litsener.setSelected(false);
                        c4litsener.setSelected(false);

                    });

                    c3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> t1.setEffect(effectBG_DropShadow));
                    c3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (c3litsener.isSelected()) {
                            c3.setEffect(effectBG_DropShadow);
                        } else {
                            c3.setEffect(null);
                        }
                    });
                    c3.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        c1litsener.setSelected(false);
                        c2litsener.setSelected(false);
                        c3litsener.setSelected(true);
                        c4litsener.setSelected(false);

                        c1.setEffect(null);
                        c2.setEffect(null);
                        c3.setEffect(effectBG_DropShadow);
                        c3.setStyle("-fx-background-color: #00c853; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                        c4.setEffect(null);

                    });

                    c4.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> c4.setEffect(effectBG_DropShadow));
                    c4.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (c4litsener.isSelected()) {
                            c4.setEffect(effectBG_DropShadow);
                        } else {
                            c4.setEffect(null);
                        }
                    });
                    c4.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        c1litsener.setSelected(false);
                        c3litsener.setSelected(false);
                        c2litsener.setSelected(false);
                        c4litsener.setSelected(true);

                        c1.setEffect(null);
                        c2.setEffect(null);
                        c3.setEffect(null);
                        c4.setEffect(effectBG_DropShadow);
                        c4.setStyle("-fx-background-color: #d50000; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");

                    });

                    resetGame.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> resetGame.setEffect(effectBG_DropShadow));
                    resetGame.addEventHandler(MouseEvent.MOUSE_EXITED, e -> resetGame.setEffect(null));
                    resetGame.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> resetGame.setEffect(effectBG_DropShadow));

                    resetSetting.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> resetSetting.setEffect(effectBG_DropShadow));
                    resetSetting.addEventHandler(MouseEvent.MOUSE_EXITED, e -> resetSetting.setEffect(null));
                    resetSetting.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> resetSetting.setEffect(effectBG_DropShadow));

                    Panel1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        p1.setGraphic(svgIconDisplay_Hover);
                        b1.setVisible(true);
                        b2.setVisible(true);
                        b3.setVisible(true);

                        fadeIn5.play();
                        fadeIn5_1.play();
                        fadeIn5_2.play();

                        Panel1.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> {
                            fadeIn5.stop();
                            fadeIn5_1.stop();
                            fadeIn5_2.stop();
                        });

                    });
                    Panel1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        p1.setGraphic(svgIconDisplay);

                        b1.setVisible(true);
                        b2.setVisible(true);
                        b3.setVisible(true);

                        fadeOut5.play();
                        fadeOut5_1.play();
                        fadeOut5_2.play();

                        Panel1.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> {
                            fadeOut5.stop();
                            fadeOut5_1.stop();
                            fadeOut5_2.stop();
                        });

                    });

                    Panel2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        p2.setGraphic(svgIconSound_Hover);
                    });
                    Panel2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        p2.setGraphic(svgIconSound);
                    });

                    Panel3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        p3.setGraphic(svgIconTheme_Hover);

                        lt1.setVisible(true);
                        lt2.setVisible(true);
                        t1.setVisible(true);
                        t2.setVisible(true);
                        c1.setVisible(true);
                        c2.setVisible(true);
                        c3.setVisible(true);
                        c4.setVisible(true);

                        fadeIn6.play();
                        fadeIn6_1.play();
                        fadeIn7.play();
                        fadeIn7_1.play();
                        fadeIn7_2.play();
                        fadeIn7_3.play();
                        fadeIn8.play();
                        fadeIn8_1.play();

                        Panel3.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> {

                            fadeIn6.stop();
                            fadeIn6_1.stop();
                            fadeIn7.stop();
                            fadeIn7_1.stop();
                            fadeIn7_2.stop();
                            fadeIn7_3.stop();
                            fadeIn8.stop();
                            fadeIn8_1.stop();
                        });

                    });
                    Panel3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        p3.setGraphic(svgIconTheme);

                        fadeOut6.play();
                        fadeOut6_1.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();
                        fadeOut7_3.play();
                        fadeOut8.play();
                        fadeOut8_1.play();

                        Panel3.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> {

                            fadeOut6.stop();
                            fadeOut6_1.stop();
                            fadeOut7.stop();
                            fadeOut7_1.stop();
                            fadeOut7_2.stop();
                            fadeOut7_3.stop();
                            fadeOut8.stop();
                            fadeOut8_1.stop();

                        });

                    });

                    Panel4.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        p3.setGraphic(svgIconTheme_Hover);

                        resetGame.setVisible(true);
                        resetSetting.setVisible(true);

                        fadeIn9.play();
                        fadeIn9_1.play();

                        Panel4.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> {

                            fadeIn9.stop();
                            fadeIn9_1.stop();

                        });

                    });
                    Panel4.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        p3.setGraphic(svgIconTheme);

                        fadeOut9.play();
                        fadeOut9_1.play();

                        Panel4.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> {

                            fadeOut9.stop();
                            fadeOut9_1.stop();

                        });

                    });

                    Panelex2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        backButton.setGraphic(svgIconSetting_Hover);

                    });
                    Panelex2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        backButton.setGraphic(svgIconSetting);
                    });

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        backButton.setEffect(effectC_DropShadow);
                        backButton.setGraphic(svgIconBack);
                        l2.setText("Back to Home");
                        l1.setText("");
                        l3.setText("");
                        Panelg1.setEffect(blur);
                        Panelg2.setEffect(blur);
                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        backButton.setEffect(null);
                        backButton.setGraphic(svgIconSetting);
                        l1.setText("MEMORY");
                        l2.setText("GAME");
                        l3.setText("Setting");
                        Panelg1.setEffect(null);
                        Panelg2.setEffect(null);
                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        backButton.setGraphic(svgIconSetting);

                        fadeOut.play();
                        fadeOut2.play();
                        fadeOut3.play();
                        fadeOut10.play();
                        fadeOut11.play();

                        backButton.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.stop();
                            fadeOut2.stop();
                            fadeOut3.stop();
                            fadeOut10.stop();
                            fadeOut11.stop();

                        });

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            closeSettings();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                }
                else if (tColor==3) {

                    color2 = "#00c853";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,200,83), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,230,95), 10, 0, -5, -5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,200,83), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,230,95), 10, 0, -5, -5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);


                    svgFileBack = getClass().getResourceAsStream("../../../resources/svg/left-arrow_green.svg");//

                    svgFileDisplay = getClass().getResourceAsStream("../../../resources/svg/resolution.svg");
                    svgFileDisplay_Hover = getClass().getResourceAsStream("../../../resources/svg/resolution_green.svg");

                    svgFileTheme = getClass().getResourceAsStream("../../../resources/svg/theme.svg");
                    svgFileTheme_Hover = getClass().getResourceAsStream("../../../resources/svg/theme_green.svg");

                    svgFileSetting = getClass().getResourceAsStream("../../../resources/svg/menu/menu.svg");
                    svgFileSetting_Hover = getClass().getResourceAsStream("../../../resources/svg/menu/menu_green.svg");

                    svgFileSound = getClass().getResourceAsStream("../../../resources/svg/volume.svg");
                    svgFileSound_Hover = getClass().getResourceAsStream("../../../resources/svg/volume_green.svg");

                    Group svgBack = loader.loadSvg(svgFileBack);
                    Group svgSetting = loader.loadSvg(svgFileSetting);
                    Group svgSetting_Hover = loader.loadSvg(svgFileSetting_Hover);

                    Group svgDisplay = loader.loadSvg(svgFileDisplay);
                    Group svgDisplay_Hover = loader.loadSvg(svgFileDisplay_Hover);

                    Group svgSound = loader.loadSvg(svgFileSound);
                    Group svgSound_Hover = loader.loadSvg(svgFileSound_Hover);

                    Group svgTheme = loader.loadSvg(svgFileTheme);
                    Group svgTheme_Hover = loader.loadSvg(svgFileTheme_Hover);

                    svgBack.setScaleX(.04);
                    svgBack.setScaleY(.04);

                    svgSetting.setScaleX(.04);
                    svgSetting.setScaleY(.04);

                    svgSetting_Hover.setScaleX(.04);
                    svgSetting_Hover.setScaleY(.04);

                    svgDisplay.setScaleX(.25);
                    svgDisplay.setScaleY(.25);

                    svgDisplay_Hover.setScaleX(.25);
                    svgDisplay_Hover.setScaleY(.25);

                    svgSound.setScaleX(.25);
                    svgSound.setScaleY(.25);

                    svgSound_Hover.setScaleX(.25);
                    svgSound_Hover.setScaleY(.25);

                    svgTheme.setScaleX(.25);
                    svgTheme.setScaleY(.25);

                    svgTheme_Hover.setScaleX(.25);
                    svgTheme_Hover.setScaleY(.25);

                    Group svgIconBack = new Group(svgBack);
                    Group svgIconSetting = new Group(svgSetting);
                    Group svgIconSetting_Hover = new Group(svgSetting_Hover);

                    Group svgIconDisplay = new Group(svgDisplay);
                    Group svgIconDisplay_Hover = new Group(svgDisplay_Hover);

                    Group svgIconSound = new Group(svgSound);
                    Group svgIconSound_Hover = new Group(svgSound_Hover);

                    Group svgIconTheme = new Group(svgTheme);
                    Group svgIconTheme_Hover = new Group(svgTheme_Hover);

                    if (f.exists()) {
                        properties.load(input);

                        int width = Integer.parseInt(properties.getProperty("width"));
                        if (width == 999) {
                            r3litsener.setSelected(true);
                            b3.setEffect(effectBG_DropShadow);
                            b3.setTextFill(Color.web(color2));
                            b3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");

                            t1.setPrefSize(128, 128);
                            t2.setPrefSize(128, 128);

                            c1.setPrefSize(128, 128);
                            c2.setPrefSize(128, 128);
                            c3.setPrefSize(128, 128);
                            c4.setPrefSize(128, 128);
                        }
                        else if (width == 1600) {
                            r2litsener.setSelected(true);
                            b2.setEffect(effectBG_DropShadow);
                            b2.setTextFill(Color.web(color2));
                            b2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");

                            t1.setPrefSize(96, 96);
                            t2.setPrefSize(96, 96);

                            c1.setPrefSize(96, 96);
                            c2.setPrefSize(96, 96);
                            c3.setPrefSize(96, 96);
                            c4.setPrefSize(96, 96);
                        }
                        else if (width == 1280) {
                            r1litsener.setSelected(true);
                            b1.setEffect(effectBG_DropShadow);
                            b1.setTextFill(Color.web(color2));
                            b1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");
                        }

                        int t = Integer.parseInt(properties.getProperty("TMode"));
                        if (t == 1) {

                            t1litsener.setSelected(true);
                            t2litsener.setSelected(false);

                            t1.setEffect(effectBG_DropShadow);
                            t1.setStyle("-fx-background-color: #f3f5f7; -fx-background-radius: 50%; -fx-border-color: "+color2+"; -fx-border-radius: 50%; -fx-border-width: 3  ;");

                            t2.setEffect(null);

                        }
                        else {

                            t1litsener.setSelected(false);
                            t2litsener.setSelected(true);

                            t1.setEffect(null);
                            t2.setEffect(effectBG_DropShadow);
                            t2.setStyle("-fx-background-color: #000; -fx-background-radius: 50%; -fx-border-color: "+color2+"; -fx-border-radius: 50%; -fx-border-width: 3  ;");


                        }

                        int c = Integer.parseInt(properties.getProperty("TColor"));
                        if (c == 1) {

                            c1litsener.setSelected(true);
                            c2litsener.setSelected(false);
                            c3litsener.setSelected(false);
                            c4litsener.setSelected(false);

                            c1.setEffect(effectBG_DropShadow);
                            c1.setStyle("-fx-background-color: #007aff; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                            c2.setEffect(null);
                            c3.setEffect(null);
                            c4.setEffect(null);

                        }
                        else if (c == 2) {

                            c1.setEffect(null);
                            c2.setEffect(effectBG_DropShadow);
                            c2.setStyle("-fx-background-color: #fff44f; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                            c3.setEffect(null);
                            c4.setEffect(null);

                            c1litsener.setSelected(false);
                            c2litsener.setSelected(true);
                            c3litsener.setSelected(false);
                            c4litsener.setSelected(false);

                        }
                        else if (c == 3) {

                            c1litsener.setSelected(false);
                            c2litsener.setSelected(false);
                            c3litsener.setSelected(true);
                            c4litsener.setSelected(false);

                            c1.setEffect(null);
                            c2.setEffect(null);
                            c3.setEffect(effectBG_DropShadow);
                            c3.setStyle("-fx-background-color: #00c853; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                            c4.setEffect(null);

                        }
                        else if (c == 4) {

                            c1litsener.setSelected(false);
                            c3litsener.setSelected(false);
                            c2litsener.setSelected(false);
                            c4litsener.setSelected(true);

                            c1.setEffect(null);
                            c2.setEffect(null);
                            c3.setEffect(null);
                            c4.setEffect(effectBG_DropShadow);
                            c4.setStyle("-fx-background-color: #d50000; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");

                        }
                    }

                    p1.setGraphic(svgIconDisplay);
                    p2.setGraphic(svgIconSound);
                    p3.setGraphic(svgIconTheme);

                    backButton.setGraphic(svgIconSetting);

                    Panel1.setEffect(effectBG_DropShadow);
                    Panel2.setEffect(effectBG_DropShadow);
                    Panel3.setEffect(effectBG_DropShadow);
                    Panel4.setEffect(effectBG_DropShadow);

                    b1.addEventHandler(MouseEvent.MOUSE_ENTERED, e-> b1.setEffect(effectBG_DropShadow));
                    b1.addEventHandler(MouseEvent.MOUSE_EXITED, e->{

                        if (r1litsener.isSelected()) {
                            b1.setEffect(effectBG_DropShadow);
                        } else {
                            b1.setEffect(null);
                        }

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
                        r1litsener.setSelected(true);
                        r2litsener.setSelected(false);
                        r3litsener.setSelected(false);
                        b1.setEffect(effectBG_DropShadow);
                        b1.setTextFill(Color.web(color2));
                        b1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");

                    });

                    b2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> b2.setEffect(effectBG_DropShadow));
                    b2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r2litsener.isSelected()) {
                            b2.setEffect(effectBG_DropShadow);
                        } else {
                            b2.setEffect(null);
                        }
                    });
                    b2.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
                        b2.setEffect(effectBG_DropShadow);
                        b2.setTextFill(Color.web(color2));
                        b2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");

                        r1litsener.setSelected(false);
                        r2litsener.setSelected(true);
                        r3litsener.setSelected(false);

                    });

                    b3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> b3.setEffect(effectBG_DropShadow));
                    b3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r3litsener.isSelected()) {
                            b3.setEffect(effectBG_DropShadow);
                        } else {
                            b3.setEffect(null);
                        }
                    });
                    b3.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        b3.setEffect(effectBG_DropShadow);
                        b3.setTextFill(Color.web(color2));
                        b3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");
                        r1litsener.setSelected(false);
                        r2litsener.setSelected(false);
                        r3litsener.setSelected(true);
                    });

                    t1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> t1.setEffect(effectBG_DropShadow));
                    t1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t1litsener.isSelected()) {
                            t1.setEffect(effectBG_DropShadow);
                        } else {
                            t1.setEffect(null);
                        }
                    });
                    t1.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1litsener.setSelected(true);
                        t2litsener.setSelected(false);

                        t1.setEffect(effectBG_DropShadow);
                        t1.setStyle("-fx-background-color: #f3f5f7; -fx-background-radius: 50%; -fx-border-color: "+color2+"; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                        t2.setEffect(null);

                    });

                    t2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> t2.setEffect(effectBG_DropShadow));
                    t2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t2litsener.isSelected()) {
                            t2.setEffect(effectBG_DropShadow);
                        } else {
                            t2.setEffect(null);
                        }
                    });
                    t2.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1litsener.setSelected(false);
                        t2litsener.setSelected(true);

                        t1.setEffect(null);
                        t2.setEffect(effectBG_DropShadow);
                        t2.setStyle("-fx-background-color: #000; -fx-background-radius: 50%; -fx-border-color: "+color2+"; -fx-border-radius: 50%; -fx-border-width: 3  ;");

                    });

                    c1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> t1.setEffect(effectBG_DropShadow));
                    c1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (c1litsener.isSelected()) {
                            c1.setEffect(effectBG_DropShadow);
                        } else {
                            c1.setEffect(null);
                        }
                    });
                    c1.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        c1litsener.setSelected(true);
                        c2litsener.setSelected(false);
                        c3litsener.setSelected(false);
                        c4litsener.setSelected(false);

                        c1.setEffect(effectBG_DropShadow);
                        c1.setStyle("-fx-background-color: #007aff; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                        c2.setEffect(null);
                        c3.setEffect(null);
                        c4.setEffect(null);

                    });

                    c2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> c2.setEffect(effectBG_DropShadow));
                    c2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (c2litsener.isSelected()) {
                            c2.setEffect(effectBG_DropShadow);
                        } else {
                            c2.setEffect(null);
                        }
                    });
                    c2.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        c1.setEffect(null);
                        c2.setEffect(effectBG_DropShadow);
                        c2.setStyle("-fx-background-color: #fff44f; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                        c3.setEffect(null);
                        c4.setEffect(null);

                        c1litsener.setSelected(false);
                        c2litsener.setSelected(true);
                        c3litsener.setSelected(false);
                        c4litsener.setSelected(false);

                    });

                    c3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> t1.setEffect(effectBG_DropShadow));
                    c3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (c3litsener.isSelected()) {
                            c3.setEffect(effectBG_DropShadow);
                        } else {
                            c3.setEffect(null);
                        }
                    });
                    c3.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        c1litsener.setSelected(false);
                        c2litsener.setSelected(false);
                        c3litsener.setSelected(true);
                        c4litsener.setSelected(false);

                        c1.setEffect(null);
                        c2.setEffect(null);
                        c3.setEffect(effectBG_DropShadow);
                        c3.setStyle("-fx-background-color: #00c853; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                        c4.setEffect(null);

                    });

                    c4.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> c4.setEffect(effectBG_DropShadow));
                    c4.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (c4litsener.isSelected()) {
                            c4.setEffect(effectBG_DropShadow);
                        } else {
                            c4.setEffect(null);
                        }
                    });
                    c4.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        c1litsener.setSelected(false);
                        c3litsener.setSelected(false);
                        c2litsener.setSelected(false);
                        c4litsener.setSelected(true);

                        c1.setEffect(null);
                        c2.setEffect(null);
                        c3.setEffect(null);
                        c4.setEffect(effectBG_DropShadow);
                        c4.setStyle("-fx-background-color: #d50000; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");

                    });

                    resetGame.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> resetGame.setEffect(effectBG_DropShadow));
                    resetGame.addEventHandler(MouseEvent.MOUSE_EXITED, e -> resetGame.setEffect(null));
                    resetGame.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> resetGame.setEffect(effectBG_DropShadow));

                    resetSetting.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> resetSetting.setEffect(effectBG_DropShadow));
                    resetSetting.addEventHandler(MouseEvent.MOUSE_EXITED, e -> resetSetting.setEffect(null));
                    resetSetting.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> resetSetting.setEffect(effectBG_DropShadow));

                    Panel1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        p1.setGraphic(svgIconDisplay_Hover);
                        b1.setVisible(true);
                        b2.setVisible(true);
                        b3.setVisible(true);

                        fadeIn5.play();
                        fadeIn5_1.play();
                        fadeIn5_2.play();

                        Panel1.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> {
                            fadeIn5.stop();
                            fadeIn5_1.stop();
                            fadeIn5_2.stop();
                        });

                    });
                    Panel1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        p1.setGraphic(svgIconDisplay);

                        b1.setVisible(true);
                        b2.setVisible(true);
                        b3.setVisible(true);

                        fadeOut5.play();
                        fadeOut5_1.play();
                        fadeOut5_2.play();

                        Panel1.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> {
                            fadeOut5.stop();
                            fadeOut5_1.stop();
                            fadeOut5_2.stop();
                        });

                    });

                    Panel2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        p2.setGraphic(svgIconSound_Hover);
                    });
                    Panel2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        p2.setGraphic(svgIconSound);
                    });

                    Panel3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        p3.setGraphic(svgIconTheme_Hover);

                        lt1.setVisible(true);
                        lt2.setVisible(true);
                        t1.setVisible(true);
                        t2.setVisible(true);
                        c1.setVisible(true);
                        c2.setVisible(true);
                        c3.setVisible(true);
                        c4.setVisible(true);

                        fadeIn6.play();
                        fadeIn6_1.play();
                        fadeIn7.play();
                        fadeIn7_1.play();
                        fadeIn7_2.play();
                        fadeIn7_3.play();
                        fadeIn8.play();
                        fadeIn8_1.play();

                        Panel3.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> {

                            fadeIn6.stop();
                            fadeIn6_1.stop();
                            fadeIn7.stop();
                            fadeIn7_1.stop();
                            fadeIn7_2.stop();
                            fadeIn7_3.stop();
                            fadeIn8.stop();
                            fadeIn8_1.stop();
                        });

                    });
                    Panel3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        p3.setGraphic(svgIconTheme);

                        fadeOut6.play();
                        fadeOut6_1.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();
                        fadeOut7_3.play();
                        fadeOut8.play();
                        fadeOut8_1.play();

                        Panel3.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> {

                            fadeOut6.stop();
                            fadeOut6_1.stop();
                            fadeOut7.stop();
                            fadeOut7_1.stop();
                            fadeOut7_2.stop();
                            fadeOut7_3.stop();
                            fadeOut8.stop();
                            fadeOut8_1.stop();

                        });

                    });

                    Panel4.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        p3.setGraphic(svgIconTheme_Hover);

                        resetGame.setVisible(true);
                        resetSetting.setVisible(true);

                        fadeIn9.play();
                        fadeIn9_1.play();

                        Panel4.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> {

                            fadeIn9.stop();
                            fadeIn9_1.stop();

                        });

                    });
                    Panel4.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        p3.setGraphic(svgIconTheme);

                        fadeOut9.play();
                        fadeOut9_1.play();

                        Panel4.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> {

                            fadeOut9.stop();
                            fadeOut9_1.stop();

                        });

                    });

                    Panelex2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        backButton.setGraphic(svgIconSetting_Hover);

                    });
                    Panelex2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        backButton.setGraphic(svgIconSetting);
                    });

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        backButton.setEffect(effectC_DropShadow);
                        backButton.setGraphic(svgIconBack);
                        l2.setText("Back to Home");
                        l1.setText("");
                        l3.setText("");
                        Panelg1.setEffect(blur);
                        Panelg2.setEffect(blur);
                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        backButton.setEffect(null);
                        backButton.setGraphic(svgIconSetting);
                        l1.setText("MEMORY");
                        l2.setText("GAME");
                        l3.setText("Setting");
                        Panelg1.setEffect(null);
                        Panelg2.setEffect(null);
                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        backButton.setGraphic(svgIconSetting);

                        fadeOut.play();
                        fadeOut2.play();
                        fadeOut3.play();
                        fadeOut10.play();
                        fadeOut11.play();

                        backButton.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.stop();
                            fadeOut2.stop();
                            fadeOut3.stop();
                            fadeOut10.stop();
                            fadeOut11.stop();

                        });

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            closeSettings();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                }
                else if (tColor==4) {

                    color2 = "#d50000";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(181,0,0), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(245,0,0), 10, 0, -5, -5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(181,0,0), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(245,0,0), 10, 0, -5, -5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);


                    svgFileBack = getClass().getResourceAsStream("../../../resources/svg/left-arrow_red.svg");//

                    svgFileDisplay = getClass().getResourceAsStream("../../../resources/svg/resolution.svg");
                    svgFileDisplay_Hover = getClass().getResourceAsStream("../../../resources/svg/resolution_red.svg");

                    svgFileTheme = getClass().getResourceAsStream("../../../resources/svg/theme.svg");
                    svgFileTheme_Hover = getClass().getResourceAsStream("../../../resources/svg/theme_red.svg");

                    svgFileSetting = getClass().getResourceAsStream("../../../resources/svg/menu/menu.svg");
                    svgFileSetting_Hover = getClass().getResourceAsStream("../../../resources/svg/menu/menu_red.svg");

                    svgFileSound = getClass().getResourceAsStream("../../../resources/svg/volume.svg");
                    svgFileSound_Hover = getClass().getResourceAsStream("../../../resources/svg/volume_red.svg");

                    Group svgBack = loader.loadSvg(svgFileBack);
                    Group svgSetting = loader.loadSvg(svgFileSetting);
                    Group svgSetting_Hover = loader.loadSvg(svgFileSetting_Hover);

                    Group svgDisplay = loader.loadSvg(svgFileDisplay);
                    Group svgDisplay_Hover = loader.loadSvg(svgFileDisplay_Hover);

                    Group svgSound = loader.loadSvg(svgFileSound);
                    Group svgSound_Hover = loader.loadSvg(svgFileSound_Hover);

                    Group svgTheme = loader.loadSvg(svgFileTheme);
                    Group svgTheme_Hover = loader.loadSvg(svgFileTheme_Hover);

                    svgBack.setScaleX(.04);
                    svgBack.setScaleY(.04);

                    svgSetting.setScaleX(.04);
                    svgSetting.setScaleY(.04);

                    svgSetting_Hover.setScaleX(.04);
                    svgSetting_Hover.setScaleY(.04);

                    svgDisplay.setScaleX(.25);
                    svgDisplay.setScaleY(.25);

                    svgDisplay_Hover.setScaleX(.25);
                    svgDisplay_Hover.setScaleY(.25);

                    svgSound.setScaleX(.25);
                    svgSound.setScaleY(.25);

                    svgSound_Hover.setScaleX(.25);
                    svgSound_Hover.setScaleY(.25);

                    svgTheme.setScaleX(.25);
                    svgTheme.setScaleY(.25);

                    svgTheme_Hover.setScaleX(.25);
                    svgTheme_Hover.setScaleY(.25);

                    Group svgIconBack = new Group(svgBack);
                    Group svgIconSetting = new Group(svgSetting);
                    Group svgIconSetting_Hover = new Group(svgSetting_Hover);

                    Group svgIconDisplay = new Group(svgDisplay);
                    Group svgIconDisplay_Hover = new Group(svgDisplay_Hover);

                    Group svgIconSound = new Group(svgSound);
                    Group svgIconSound_Hover = new Group(svgSound_Hover);

                    Group svgIconTheme = new Group(svgTheme);
                    Group svgIconTheme_Hover = new Group(svgTheme_Hover);

                    if (f.exists()) {
                        properties.load(input);

                        int width = Integer.parseInt(properties.getProperty("width"));
                        if (width == 999) {
                            r3litsener.setSelected(true);
                            b3.setEffect(effectBG_DropShadow);
                            b3.setTextFill(Color.web(color2));
                            b3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");

                            t1.setPrefSize(128, 128);
                            t2.setPrefSize(128, 128);

                            c1.setPrefSize(128, 128);
                            c2.setPrefSize(128, 128);
                            c3.setPrefSize(128, 128);
                            c4.setPrefSize(128, 128);
                        }
                        else if (width == 1600) {
                            r2litsener.setSelected(true);
                            b2.setEffect(effectBG_DropShadow);
                            b2.setTextFill(Color.web(color2));
                            b2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");

                            t1.setPrefSize(96, 96);
                            t2.setPrefSize(96, 96);

                            c1.setPrefSize(96, 96);
                            c2.setPrefSize(96, 96);
                            c3.setPrefSize(96, 96);
                            c4.setPrefSize(96, 96);
                        }
                        else if (width == 1280) {
                            r1litsener.setSelected(true);
                            b1.setEffect(effectBG_DropShadow);
                            b1.setTextFill(Color.web(color2));
                            b1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");
                        }

                        int t = Integer.parseInt(properties.getProperty("TMode"));
                        if (t == 1) {

                            t1litsener.setSelected(true);
                            t2litsener.setSelected(false);

                            t1.setEffect(effectBG_DropShadow);
                            t1.setStyle("-fx-background-color: #f3f5f7; -fx-background-radius: 50%; -fx-border-color: "+color2+"; -fx-border-radius: 50%; -fx-border-width: 3  ;");

                            t2.setEffect(null);

                        }
                        else {

                            t1litsener.setSelected(false);
                            t2litsener.setSelected(true);

                            t1.setEffect(null);
                            t2.setEffect(effectBG_DropShadow);
                            t2.setStyle("-fx-background-color: #000; -fx-background-radius: 50%; -fx-border-color: "+color2+"; -fx-border-radius: 50%; -fx-border-width: 3  ;");


                        }

                        int c = Integer.parseInt(properties.getProperty("TColor"));
                        if (c == 1) {

                            c1litsener.setSelected(true);
                            c2litsener.setSelected(false);
                            c3litsener.setSelected(false);
                            c4litsener.setSelected(false);

                            c1.setEffect(effectBG_DropShadow);
                            c1.setStyle("-fx-background-color: #007aff; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                            c2.setEffect(null);
                            c3.setEffect(null);
                            c4.setEffect(null);

                        }
                        else if (c == 2) {

                            c1.setEffect(null);
                            c2.setEffect(effectBG_DropShadow);
                            c2.setStyle("-fx-background-color: #fff44f; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                            c3.setEffect(null);
                            c4.setEffect(null);

                            c1litsener.setSelected(false);
                            c2litsener.setSelected(true);
                            c3litsener.setSelected(false);
                            c4litsener.setSelected(false);

                        }
                        else if (c == 3) {

                            c1litsener.setSelected(false);
                            c2litsener.setSelected(false);
                            c3litsener.setSelected(true);
                            c4litsener.setSelected(false);

                            c1.setEffect(null);
                            c2.setEffect(null);
                            c3.setEffect(effectBG_DropShadow);
                            c3.setStyle("-fx-background-color: #00c853; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                            c4.setEffect(null);

                        }
                        else if (c == 4) {

                            c1litsener.setSelected(false);
                            c3litsener.setSelected(false);
                            c2litsener.setSelected(false);
                            c4litsener.setSelected(true);

                            c1.setEffect(null);
                            c2.setEffect(null);
                            c3.setEffect(null);
                            c4.setEffect(effectBG_DropShadow);
                            c4.setStyle("-fx-background-color: #d50000; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");

                        }
                    }

                    p1.setGraphic(svgIconDisplay);
                    p2.setGraphic(svgIconSound);
                    p3.setGraphic(svgIconTheme);

                    backButton.setGraphic(svgIconSetting);

                    Panel1.setEffect(effectBG_DropShadow);
                    Panel2.setEffect(effectBG_DropShadow);
                    Panel3.setEffect(effectBG_DropShadow);
                    Panel4.setEffect(effectBG_DropShadow);

                    b1.addEventHandler(MouseEvent.MOUSE_ENTERED, e-> b1.setEffect(effectBG_DropShadow));
                    b1.addEventHandler(MouseEvent.MOUSE_EXITED, e->{

                        if (r1litsener.isSelected()) {
                            b1.setEffect(effectBG_DropShadow);
                        } else {
                            b1.setEffect(null);
                        }

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
                        r1litsener.setSelected(true);
                        r2litsener.setSelected(false);
                        r3litsener.setSelected(false);
                        b1.setEffect(effectBG_DropShadow);
                        b1.setTextFill(Color.web(color2));
                        b1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");

                    });

                    b2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> b2.setEffect(effectBG_DropShadow));
                    b2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r2litsener.isSelected()) {
                            b2.setEffect(effectBG_DropShadow);
                        } else {
                            b2.setEffect(null);
                        }
                    });
                    b2.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
                        b2.setEffect(effectBG_DropShadow);
                        b2.setTextFill(Color.web(color2));
                        b2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");

                        r1litsener.setSelected(false);
                        r2litsener.setSelected(true);
                        r3litsener.setSelected(false);

                    });

                    b3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> b3.setEffect(effectBG_DropShadow));
                    b3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r3litsener.isSelected()) {
                            b3.setEffect(effectBG_DropShadow);
                        } else {
                            b3.setEffect(null);
                        }
                    });
                    b3.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        b3.setEffect(effectBG_DropShadow);
                        b3.setTextFill(Color.web(color2));
                        b3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");
                        r1litsener.setSelected(false);
                        r2litsener.setSelected(false);
                        r3litsener.setSelected(true);
                    });

                    t1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> t1.setEffect(effectBG_DropShadow));
                    t1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t1litsener.isSelected()) {
                            t1.setEffect(effectBG_DropShadow);
                        } else {
                            t1.setEffect(null);
                        }
                    });
                    t1.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1litsener.setSelected(true);
                        t2litsener.setSelected(false);

                        t1.setEffect(effectBG_DropShadow);
                        t1.setStyle("-fx-background-color: #f3f5f7; -fx-background-radius: 50%; -fx-border-color: "+color2+"; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                        t2.setEffect(null);

                    });

                    t2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> t2.setEffect(effectBG_DropShadow));
                    t2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t2litsener.isSelected()) {
                            t2.setEffect(effectBG_DropShadow);
                        } else {
                            t2.setEffect(null);
                        }
                    });
                    t2.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1litsener.setSelected(false);
                        t2litsener.setSelected(true);

                        t1.setEffect(null);
                        t2.setEffect(effectBG_DropShadow);
                        t2.setStyle("-fx-background-color: #000; -fx-background-radius: 50%; -fx-border-color: "+color2+"; -fx-border-radius: 50%; -fx-border-width: 3  ;");

                    });

                    c1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> t1.setEffect(effectBG_DropShadow));
                    c1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (c1litsener.isSelected()) {
                            c1.setEffect(effectBG_DropShadow);
                        } else {
                            c1.setEffect(null);
                        }
                    });
                    c1.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        c1litsener.setSelected(true);
                        c2litsener.setSelected(false);
                        c3litsener.setSelected(false);
                        c4litsener.setSelected(false);

                        c1.setEffect(effectBG_DropShadow);
                        c1.setStyle("-fx-background-color: #007aff; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                        c2.setEffect(null);
                        c3.setEffect(null);
                        c4.setEffect(null);

                    });

                    c2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> c2.setEffect(effectBG_DropShadow));
                    c2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (c2litsener.isSelected()) {
                            c2.setEffect(effectBG_DropShadow);
                        } else {
                            c2.setEffect(null);
                        }
                    });
                    c2.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        c1.setEffect(null);
                        c2.setEffect(effectBG_DropShadow);
                        c2.setStyle("-fx-background-color: #fff44f; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                        c3.setEffect(null);
                        c4.setEffect(null);

                        c1litsener.setSelected(false);
                        c2litsener.setSelected(true);
                        c3litsener.setSelected(false);
                        c4litsener.setSelected(false);

                    });

                    c3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> t1.setEffect(effectBG_DropShadow));
                    c3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (c3litsener.isSelected()) {
                            c3.setEffect(effectBG_DropShadow);
                        } else {
                            c3.setEffect(null);
                        }
                    });
                    c3.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        c1litsener.setSelected(false);
                        c2litsener.setSelected(false);
                        c3litsener.setSelected(true);
                        c4litsener.setSelected(false);

                        c1.setEffect(null);
                        c2.setEffect(null);
                        c3.setEffect(effectBG_DropShadow);
                        c3.setStyle("-fx-background-color: #00c853; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                        c4.setEffect(null);

                    });

                    c4.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> c4.setEffect(effectBG_DropShadow));
                    c4.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (c4litsener.isSelected()) {
                            c4.setEffect(effectBG_DropShadow);
                        } else {
                            c4.setEffect(null);
                        }
                    });
                    c4.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        c1litsener.setSelected(false);
                        c3litsener.setSelected(false);
                        c2litsener.setSelected(false);
                        c4litsener.setSelected(true);

                        c1.setEffect(null);
                        c2.setEffect(null);
                        c3.setEffect(null);
                        c4.setEffect(effectBG_DropShadow);
                        c4.setStyle("-fx-background-color: #d50000; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");

                    });

                    resetGame.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> resetGame.setEffect(effectBG_DropShadow));
                    resetGame.addEventHandler(MouseEvent.MOUSE_EXITED, e -> resetGame.setEffect(null));
                    resetGame.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> resetGame.setEffect(effectBG_DropShadow));

                    resetSetting.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> resetSetting.setEffect(effectBG_DropShadow));
                    resetSetting.addEventHandler(MouseEvent.MOUSE_EXITED, e -> resetSetting.setEffect(null));
                    resetSetting.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> resetSetting.setEffect(effectBG_DropShadow));

                    Panel1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        p1.setGraphic(svgIconDisplay_Hover);
                        b1.setVisible(true);
                        b2.setVisible(true);
                        b3.setVisible(true);

                        fadeIn5.play();
                        fadeIn5_1.play();
                        fadeIn5_2.play();

                        Panel1.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> {
                            fadeIn5.stop();
                            fadeIn5_1.stop();
                            fadeIn5_2.stop();
                        });

                    });
                    Panel1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        p1.setGraphic(svgIconDisplay);

                        b1.setVisible(true);
                        b2.setVisible(true);
                        b3.setVisible(true);

                        fadeOut5.play();
                        fadeOut5_1.play();
                        fadeOut5_2.play();

                        Panel1.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> {
                            fadeOut5.stop();
                            fadeOut5_1.stop();
                            fadeOut5_2.stop();
                        });

                    });

                    Panel2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        p2.setGraphic(svgIconSound_Hover);
                    });
                    Panel2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        p2.setGraphic(svgIconSound);
                    });

                    Panel3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        p3.setGraphic(svgIconTheme_Hover);

                        lt1.setVisible(true);
                        lt2.setVisible(true);
                        t1.setVisible(true);
                        t2.setVisible(true);
                        c1.setVisible(true);
                        c2.setVisible(true);
                        c3.setVisible(true);
                        c4.setVisible(true);

                        fadeIn6.play();
                        fadeIn6_1.play();
                        fadeIn7.play();
                        fadeIn7_1.play();
                        fadeIn7_2.play();
                        fadeIn7_3.play();
                        fadeIn8.play();
                        fadeIn8_1.play();

                        Panel3.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> {

                            fadeIn6.stop();
                            fadeIn6_1.stop();
                            fadeIn7.stop();
                            fadeIn7_1.stop();
                            fadeIn7_2.stop();
                            fadeIn7_3.stop();
                            fadeIn8.stop();
                            fadeIn8_1.stop();
                        });

                    });
                    Panel3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        p3.setGraphic(svgIconTheme);

                        fadeOut6.play();
                        fadeOut6_1.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();
                        fadeOut7_3.play();
                        fadeOut8.play();
                        fadeOut8_1.play();

                        Panel3.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> {

                            fadeOut6.stop();
                            fadeOut6_1.stop();
                            fadeOut7.stop();
                            fadeOut7_1.stop();
                            fadeOut7_2.stop();
                            fadeOut7_3.stop();
                            fadeOut8.stop();
                            fadeOut8_1.stop();

                        });

                    });

                    Panel4.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        p3.setGraphic(svgIconTheme_Hover);

                        resetGame.setVisible(true);
                        resetSetting.setVisible(true);

                        fadeIn9.play();
                        fadeIn9_1.play();

                        Panel4.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> {

                            fadeIn9.stop();
                            fadeIn9_1.stop();

                        });

                    });
                    Panel4.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        p3.setGraphic(svgIconTheme);

                        fadeOut9.play();
                        fadeOut9_1.play();

                        Panel4.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> {

                            fadeOut9.stop();
                            fadeOut9_1.stop();

                        });

                    });

                    Panelex2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        backButton.setGraphic(svgIconSetting_Hover);

                    });
                    Panelex2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        backButton.setGraphic(svgIconSetting);
                    });

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        backButton.setEffect(effectC_DropShadow);
                        backButton.setGraphic(svgIconBack);
                        l2.setText("Back to Home");
                        l1.setText("");
                        l3.setText("");
                        Panelg1.setEffect(blur);
                        Panelg2.setEffect(blur);
                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        backButton.setEffect(null);
                        backButton.setGraphic(svgIconSetting);
                        l1.setText("MEMORY");
                        l2.setText("GAME");
                        l3.setText("Setting");
                        Panelg1.setEffect(null);
                        Panelg2.setEffect(null);
                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        backButton.setGraphic(svgIconSetting);

                        fadeOut.play();
                        fadeOut2.play();
                        fadeOut3.play();
                        fadeOut10.play();
                        fadeOut11.play();

                        backButton.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.stop();
                            fadeOut2.stop();
                            fadeOut3.stop();
                            fadeOut10.stop();
                            fadeOut11.stop();

                        });

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            closeSettings();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                }

            }
            else if(theme==2){

                color = "#181818";

                effectBG_DropShadowADD = new DropShadow(BlurType.GAUSSIAN, Color.rgb(20,20,20), 10, 0, 5,5);
                effectBG_DropShadow = new DropShadow(BlurType.GAUSSIAN, Color.rgb(28,28,28), 10, 0, -5,-5);
                effectBG_DropShadow.setInput(effectBG_DropShadowADD);

                effectBG_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(20,20,20), 10, 0, 5,5);
                effectBG_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(20,20,20), 10, 0, -5,-5);
                effectBG_InnerShadow.setInput(effectBG_InnerShadowADD);

                if (tColor==1) {

                    color2 = "#004fcb";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,67,173), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,91,233), 10, 0, -5, -5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,67,173), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,91,233), 10, 0, -5, -5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBack = getClass().getResourceAsStream("../../../resources/svg/left-arrow_dblue.svg");//

                    svgFileDisplay = getClass().getResourceAsStream("../../../resources/svg/resolution_d.svg");
                    svgFileDisplay_Hover = getClass().getResourceAsStream("../../../resources/svg/resolution_dblue.svg");

                    svgFileTheme = getClass().getResourceAsStream("../../../resources/svg/theme_d.svg");
                    svgFileTheme_Hover = getClass().getResourceAsStream("../../../resources/svg/theme_dblue.svg");

                    svgFileSetting = getClass().getResourceAsStream("../../../resources/svg/menu/menu_d.svg");
                    svgFileSetting_Hover = getClass().getResourceAsStream("../../../resources/svg/menu/menu_dblue.svg");

                    svgFileSound = getClass().getResourceAsStream("../../../resources/svg/volume_d.svg");
                    svgFileSound_Hover = getClass().getResourceAsStream("../../../resources/svg/volume_dblue.svg");

                    Group svgBack = loader.loadSvg(svgFileBack);
                    Group svgSetting = loader.loadSvg(svgFileSetting);
                    Group svgSetting_Hover = loader.loadSvg(svgFileSetting_Hover);

                    Group svgDisplay = loader.loadSvg(svgFileDisplay);
                    Group svgDisplay_Hover = loader.loadSvg(svgFileDisplay_Hover);

                    Group svgSound = loader.loadSvg(svgFileSound);
                    Group svgSound_Hover = loader.loadSvg(svgFileSound_Hover);

                    Group svgTheme = loader.loadSvg(svgFileTheme);
                    Group svgTheme_Hover = loader.loadSvg(svgFileTheme_Hover);

                    svgBack.setScaleX(.04);
                    svgBack.setScaleY(.04);

                    svgSetting.setScaleX(.04);
                    svgSetting.setScaleY(.04);

                    svgSetting_Hover.setScaleX(.04);
                    svgSetting_Hover.setScaleY(.04);

                    svgDisplay.setScaleX(.25);
                    svgDisplay.setScaleY(.25);

                    svgDisplay_Hover.setScaleX(.25);
                    svgDisplay_Hover.setScaleY(.25);

                    svgSound.setScaleX(.25);
                    svgSound.setScaleY(.25);

                    svgSound_Hover.setScaleX(.25);
                    svgSound_Hover.setScaleY(.25);

                    svgTheme.setScaleX(.25);
                    svgTheme.setScaleY(.25);

                    svgTheme_Hover.setScaleX(.25);
                    svgTheme_Hover.setScaleY(.25);

                    Group svgIconBack = new Group(svgBack);
                    Group svgIconSetting = new Group(svgSetting);
                    Group svgIconSetting_Hover = new Group(svgSetting_Hover);

                    Group svgIconDisplay = new Group(svgDisplay);
                    Group svgIconDisplay_Hover = new Group(svgDisplay_Hover);

                    Group svgIconSound = new Group(svgSound);
                    Group svgIconSound_Hover = new Group(svgSound_Hover);

                    Group svgIconTheme = new Group(svgTheme);
                    Group svgIconTheme_Hover = new Group(svgTheme_Hover);

                    if (f.exists()) {
                        properties.load(input);

                        int width = Integer.parseInt(properties.getProperty("width"));
                        if (width == 999) {
                            r3litsener.setSelected(true);
                            b3.setEffect(effectBG_DropShadow);
                            b3.setTextFill(Color.web(color2));
                            b3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");

                            t1.setPrefSize(128, 128);
                            t2.setPrefSize(128, 128);

                            c1.setPrefSize(128, 128);
                            c2.setPrefSize(128, 128);
                            c3.setPrefSize(128, 128);
                            c4.setPrefSize(128, 128);
                        }
                        else if (width == 1600) {
                            r2litsener.setSelected(true);
                            b2.setEffect(effectBG_DropShadow);
                            b2.setTextFill(Color.web(color2));
                            b2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");

                            t1.setPrefSize(96, 96);
                            t2.setPrefSize(96, 96);

                            c1.setPrefSize(96, 96);
                            c2.setPrefSize(96, 96);
                            c3.setPrefSize(96, 96);
                            c4.setPrefSize(96, 96);
                        }
                        else if (width == 1280) {
                            r1litsener.setSelected(true);
                            b1.setEffect(effectBG_DropShadow);
                            b1.setTextFill(Color.web(color2));
                            b1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");
                        }

                        int t = Integer.parseInt(properties.getProperty("TMode"));
                        if (t == 1) {

                            t1litsener.setSelected(true);
                            t2litsener.setSelected(false);

                            t1.setEffect(effectBG_DropShadow);
                            t1.setStyle("-fx-background-color: #f3f5f7; -fx-background-radius: 50%; -fx-border-color: "+color2+"; -fx-border-radius: 50%; -fx-border-width: 3  ;");

                            t2.setEffect(null);

                        }
                        else {

                            t1litsener.setSelected(false);
                            t2litsener.setSelected(true);

                            t1.setEffect(null);
                            t2.setEffect(effectBG_DropShadow);
                            t2.setStyle("-fx-background-color: #000; -fx-background-radius: 50%; -fx-border-color: "+color2+"; -fx-border-radius: 50%; -fx-border-width: 3  ;");


                        }

                        int c = Integer.parseInt(properties.getProperty("TColor"));
                        if (c == 1) {

                            c1litsener.setSelected(true);
                            c2litsener.setSelected(false);
                            c3litsener.setSelected(false);
                            c4litsener.setSelected(false);

                            c1.setEffect(effectBG_DropShadow);
                            c1.setStyle("-fx-background-color: #004fcb; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                            c2.setEffect(null);
                            c3.setEffect(null);
                            c4.setEffect(null);

                        }
                        else if (c == 2) {

                            c1.setEffect(null);
                            c2.setEffect(effectBG_DropShadow);
                            c2.setStyle("-fx-background-color: #c9c208; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                            c3.setEffect(null);
                            c4.setEffect(null);

                            c1litsener.setSelected(false);
                            c2litsener.setSelected(true);
                            c3litsener.setSelected(false);
                            c4litsener.setSelected(false);

                        }
                        else if (c == 3) {

                            c1litsener.setSelected(false);
                            c2litsener.setSelected(false);
                            c3litsener.setSelected(true);
                            c4litsener.setSelected(false);

                            c1.setEffect(null);
                            c2.setEffect(null);
                            c3.setEffect(effectBG_DropShadow);
                            c3.setStyle("-fx-background-color: #006500; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                            c4.setEffect(null);

                        }
                        else if (c == 4) {

                            c1litsener.setSelected(false);
                            c3litsener.setSelected(false);
                            c2litsener.setSelected(false);
                            c4litsener.setSelected(true);

                            c1.setEffect(null);
                            c2.setEffect(null);
                            c3.setEffect(null);
                            c4.setEffect(effectBG_DropShadow);
                            c4.setStyle("-fx-background-color: #9b0000; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");

                        }
                    }

                    p1.setGraphic(svgIconDisplay);
                    p2.setGraphic(svgIconSound);
                    p3.setGraphic(svgIconTheme);

                    backButton.setGraphic(svgIconSetting);

                    Panel1.setEffect(effectBG_DropShadow);
                    Panel2.setEffect(effectBG_DropShadow);
                    Panel3.setEffect(effectBG_DropShadow);
                    Panel4.setEffect(effectBG_DropShadow);

                    b1.addEventHandler(MouseEvent.MOUSE_ENTERED, e-> b1.setEffect(effectBG_DropShadow));
                    b1.addEventHandler(MouseEvent.MOUSE_EXITED, e->{

                        if (r1litsener.isSelected()) {
                            b1.setEffect(effectBG_DropShadow);
                        } else {
                            b1.setEffect(null);
                        }

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
                        r1litsener.setSelected(true);
                        r2litsener.setSelected(false);
                        r3litsener.setSelected(false);
                        b1.setEffect(effectBG_DropShadow);
                        b1.setTextFill(Color.web(color2));
                        b1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");

                    });

                    b2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> b2.setEffect(effectBG_DropShadow));
                    b2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r2litsener.isSelected()) {
                            b2.setEffect(effectBG_DropShadow);
                        } else {
                            b2.setEffect(null);
                        }
                    });
                    b2.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
                        b2.setEffect(effectBG_DropShadow);
                        b2.setTextFill(Color.web(color2));
                        b2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");

                        r1litsener.setSelected(false);
                        r2litsener.setSelected(true);
                        r3litsener.setSelected(false);

                    });

                    b3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> b3.setEffect(effectBG_DropShadow));
                    b3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r3litsener.isSelected()) {
                            b3.setEffect(effectBG_DropShadow);
                        } else {
                            b3.setEffect(null);
                        }
                    });
                    b3.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        b3.setEffect(effectBG_DropShadow);
                        b3.setTextFill(Color.web(color2));
                        b3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");
                        r1litsener.setSelected(false);
                        r2litsener.setSelected(false);
                        r3litsener.setSelected(true);
                    });

                    t1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> t1.setEffect(effectBG_DropShadow));
                    t1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t1litsener.isSelected()) {
                            t1.setEffect(effectBG_DropShadow);
                        } else {
                            t1.setEffect(null);
                        }
                    });
                    t1.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1litsener.setSelected(true);
                        t2litsener.setSelected(false);

                        t1.setEffect(effectBG_DropShadow);
                        t1.setStyle("-fx-background-color: #f3f5f7; -fx-background-radius: 50%; -fx-border-color: "+color2+"; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                        t2.setEffect(null);

                    });

                    t2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> t2.setEffect(effectBG_DropShadow));
                    t2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t2litsener.isSelected()) {
                            t2.setEffect(effectBG_DropShadow);
                        } else {
                            t2.setEffect(null);
                        }
                    });
                    t2.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1litsener.setSelected(false);
                        t2litsener.setSelected(true);

                        t1.setEffect(null);
                        t2.setEffect(effectBG_DropShadow);
                        t2.setStyle("-fx-background-color: #000; -fx-background-radius: 50%; -fx-border-color: "+color2+"; -fx-border-radius: 50%; -fx-border-width: 3  ;");

                    });

                    c1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> t1.setEffect(effectBG_DropShadow));
                    c1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (c1litsener.isSelected()) {
                            c1.setEffect(effectBG_DropShadow);
                        } else {
                            c1.setEffect(null);
                        }
                    });
                    c1.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        c1litsener.setSelected(true);
                        c2litsener.setSelected(false);
                        c3litsener.setSelected(false);
                        c4litsener.setSelected(false);

                        c1.setEffect(effectBG_DropShadow);
                        c1.setStyle("-fx-background-color: #004fcb; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                        c2.setEffect(null);
                        c3.setEffect(null);
                        c4.setEffect(null);

                    });

                    c2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> c2.setEffect(effectBG_DropShadow));
                    c2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (c2litsener.isSelected()) {
                            c2.setEffect(effectBG_DropShadow);
                        } else {
                            c2.setEffect(null);
                        }
                    });
                    c2.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        c1.setEffect(null);
                        c2.setEffect(effectBG_DropShadow);
                        c2.setStyle("-fx-background-color: #c9c208; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                        c3.setEffect(null);
                        c4.setEffect(null);

                        c1litsener.setSelected(false);
                        c2litsener.setSelected(true);
                        c3litsener.setSelected(false);
                        c4litsener.setSelected(false);

                    });

                    c3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> t1.setEffect(effectBG_DropShadow));
                    c3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (c3litsener.isSelected()) {
                            c3.setEffect(effectBG_DropShadow);
                        } else {
                            c3.setEffect(null);
                        }
                    });
                    c3.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        c1litsener.setSelected(false);
                        c2litsener.setSelected(false);
                        c3litsener.setSelected(true);
                        c4litsener.setSelected(false);

                        c1.setEffect(null);
                        c2.setEffect(null);
                        c3.setEffect(effectBG_DropShadow);
                        c3.setStyle("-fx-background-color: #006500; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                        c4.setEffect(null);

                    });

                    c4.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> c4.setEffect(effectBG_DropShadow));
                    c4.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (c4litsener.isSelected()) {
                            c4.setEffect(effectBG_DropShadow);
                        } else {
                            c4.setEffect(null);
                        }
                    });
                    c4.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        c1litsener.setSelected(false);
                        c3litsener.setSelected(false);
                        c2litsener.setSelected(false);
                        c4litsener.setSelected(true);

                        c1.setEffect(null);
                        c2.setEffect(null);
                        c3.setEffect(null);
                        c4.setEffect(effectBG_DropShadow);
                        c4.setStyle("-fx-background-color: #9b0000; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");

                    });

                    resetGame.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> resetGame.setEffect(effectBG_DropShadow));
                    resetGame.addEventHandler(MouseEvent.MOUSE_EXITED, e -> resetGame.setEffect(null));
                    resetGame.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> resetGame.setEffect(effectBG_DropShadow));

                    resetSetting.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> resetSetting.setEffect(effectBG_DropShadow));
                    resetSetting.addEventHandler(MouseEvent.MOUSE_EXITED, e -> resetSetting.setEffect(null));
                    resetSetting.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> resetSetting.setEffect(effectBG_DropShadow));

                    Panel1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        p1.setGraphic(svgIconDisplay_Hover);
                        b1.setVisible(true);
                        b2.setVisible(true);
                        b3.setVisible(true);

                        fadeIn5.play();
                        fadeIn5_1.play();
                        fadeIn5_2.play();

                        Panel1.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> {
                            fadeIn5.stop();
                            fadeIn5_1.stop();
                            fadeIn5_2.stop();
                        });

                    });
                    Panel1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        p1.setGraphic(svgIconDisplay);

                        b1.setVisible(true);
                        b2.setVisible(true);
                        b3.setVisible(true);

                        fadeOut5.play();
                        fadeOut5_1.play();
                        fadeOut5_2.play();

                        Panel1.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> {
                            fadeOut5.stop();
                            fadeOut5_1.stop();
                            fadeOut5_2.stop();
                        });

                    });

                    Panel2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        p2.setGraphic(svgIconSound_Hover);
                    });
                    Panel2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        p2.setGraphic(svgIconSound);
                    });

                    Panel3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        p3.setGraphic(svgIconTheme_Hover);

                        lt1.setVisible(true);
                        lt2.setVisible(true);
                        t1.setVisible(true);
                        t2.setVisible(true);
                        c1.setVisible(true);
                        c2.setVisible(true);
                        c3.setVisible(true);
                        c4.setVisible(true);

                        fadeIn6.play();
                        fadeIn6_1.play();
                        fadeIn7.play();
                        fadeIn7_1.play();
                        fadeIn7_2.play();
                        fadeIn7_3.play();
                        fadeIn8.play();
                        fadeIn8_1.play();

                        Panel3.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> {

                            fadeIn6.stop();
                            fadeIn6_1.stop();
                            fadeIn7.stop();
                            fadeIn7_1.stop();
                            fadeIn7_2.stop();
                            fadeIn7_3.stop();
                            fadeIn8.stop();
                            fadeIn8_1.stop();
                        });

                    });
                    Panel3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        p3.setGraphic(svgIconTheme);

                        fadeOut6.play();
                        fadeOut6_1.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();
                        fadeOut7_3.play();
                        fadeOut8.play();
                        fadeOut8_1.play();

                        Panel3.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> {

                            fadeOut6.stop();
                            fadeOut6_1.stop();
                            fadeOut7.stop();
                            fadeOut7_1.stop();
                            fadeOut7_2.stop();
                            fadeOut7_3.stop();
                            fadeOut8.stop();
                            fadeOut8_1.stop();

                        });

                    });

                    Panel4.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        p3.setGraphic(svgIconTheme_Hover);

                        resetGame.setVisible(true);
                        resetSetting.setVisible(true);

                        fadeIn9.play();
                        fadeIn9_1.play();

                        Panel4.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> {

                            fadeIn9.stop();
                            fadeIn9_1.stop();

                        });

                    });
                    Panel4.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        p3.setGraphic(svgIconTheme);

                        fadeOut9.play();
                        fadeOut9_1.play();

                        Panel4.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> {

                            fadeOut9.stop();
                            fadeOut9_1.stop();

                        });

                    });

                    Panelex2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        backButton.setGraphic(svgIconSetting_Hover);

                    });
                    Panelex2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        backButton.setGraphic(svgIconSetting);
                    });

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        backButton.setEffect(effectC_DropShadow);
                        backButton.setGraphic(svgIconBack);
                        l2.setText("Back to Home");
                        l1.setText("");
                        l3.setText("");
                        Panelg1.setEffect(blur);
                        Panelg2.setEffect(blur);
                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        backButton.setEffect(null);
                        backButton.setGraphic(svgIconSetting);
                        l1.setText("MEMORY");
                        l2.setText("GAME");
                        l3.setText("Setting");
                        Panelg1.setEffect(null);
                        Panelg2.setEffect(null);
                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        backButton.setGraphic(svgIconSetting);

                        fadeOut.play();
                        fadeOut2.play();
                        fadeOut3.play();
                        fadeOut10.play();
                        fadeOut11.play();

                        backButton.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.stop();
                            fadeOut2.stop();
                            fadeOut3.stop();
                            fadeOut10.stop();
                            fadeOut11.stop();

                        });

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            closeSettings();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                }
                else if (tColor==2) {

                    color2 = "#c9c208";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.web("#aba507"), 10, 0, 5,5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.web("#e7df09"), 10, 0, -5,-5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.web("#aba507"), 10, 0, 5,5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.web("#e7df09"), 10, 0, -5,-5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBack = getClass().getResourceAsStream("../../../resources/svg/left-arrow_dyellow.svg");//

                    svgFileDisplay = getClass().getResourceAsStream("../../../resources/svg/resolution_d.svg");
                    svgFileDisplay_Hover = getClass().getResourceAsStream("../../../resources/svg/resolution_dyellow.svg");

                    svgFileTheme = getClass().getResourceAsStream("../../../resources/svg/theme_d.svg");
                    svgFileTheme_Hover = getClass().getResourceAsStream("../../../resources/svg/theme_dyellow.svg");

                    svgFileSetting = getClass().getResourceAsStream("../../../resources/svg/menu/menu_d.svg");
                    svgFileSetting_Hover = getClass().getResourceAsStream("../../../resources/svg/menu/menu_dyellow.svg");

                    svgFileSound = getClass().getResourceAsStream("../../../resources/svg/volume_d.svg");
                    svgFileSound_Hover = getClass().getResourceAsStream("../../../resources/svg/volume_dyellow.svg");

                    Group svgBack = loader.loadSvg(svgFileBack);
                    Group svgSetting = loader.loadSvg(svgFileSetting);
                    Group svgSetting_Hover = loader.loadSvg(svgFileSetting_Hover);

                    Group svgDisplay = loader.loadSvg(svgFileDisplay);
                    Group svgDisplay_Hover = loader.loadSvg(svgFileDisplay_Hover);

                    Group svgSound = loader.loadSvg(svgFileSound);
                    Group svgSound_Hover = loader.loadSvg(svgFileSound_Hover);

                    Group svgTheme = loader.loadSvg(svgFileTheme);
                    Group svgTheme_Hover = loader.loadSvg(svgFileTheme_Hover);

                    svgBack.setScaleX(.04);
                    svgBack.setScaleY(.04);

                    svgSetting.setScaleX(.04);
                    svgSetting.setScaleY(.04);

                    svgSetting_Hover.setScaleX(.04);
                    svgSetting_Hover.setScaleY(.04);

                    svgDisplay.setScaleX(.25);
                    svgDisplay.setScaleY(.25);

                    svgDisplay_Hover.setScaleX(.25);
                    svgDisplay_Hover.setScaleY(.25);

                    svgSound.setScaleX(.25);
                    svgSound.setScaleY(.25);

                    svgSound_Hover.setScaleX(.25);
                    svgSound_Hover.setScaleY(.25);

                    svgTheme.setScaleX(.25);
                    svgTheme.setScaleY(.25);

                    svgTheme_Hover.setScaleX(.25);
                    svgTheme_Hover.setScaleY(.25);

                    Group svgIconBack = new Group(svgBack);
                    Group svgIconSetting = new Group(svgSetting);
                    Group svgIconSetting_Hover = new Group(svgSetting_Hover);

                    Group svgIconDisplay = new Group(svgDisplay);
                    Group svgIconDisplay_Hover = new Group(svgDisplay_Hover);

                    Group svgIconSound = new Group(svgSound);
                    Group svgIconSound_Hover = new Group(svgSound_Hover);

                    Group svgIconTheme = new Group(svgTheme);
                    Group svgIconTheme_Hover = new Group(svgTheme_Hover);

                    if (f.exists()) {
                        properties.load(input);

                        int width = Integer.parseInt(properties.getProperty("width"));
                        if (width == 999) {
                            r3litsener.setSelected(true);
                            b3.setEffect(effectBG_DropShadow);
                            b3.setTextFill(Color.web(color2));
                            b3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");

                            t1.setPrefSize(128, 128);
                            t2.setPrefSize(128, 128);

                            c1.setPrefSize(128, 128);
                            c2.setPrefSize(128, 128);
                            c3.setPrefSize(128, 128);
                            c4.setPrefSize(128, 128);
                        }
                        else if (width == 1600) {
                            r2litsener.setSelected(true);
                            b2.setEffect(effectBG_DropShadow);
                            b2.setTextFill(Color.web(color2));
                            b2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");

                            t1.setPrefSize(96, 96);
                            t2.setPrefSize(96, 96);

                            c1.setPrefSize(96, 96);
                            c2.setPrefSize(96, 96);
                            c3.setPrefSize(96, 96);
                            c4.setPrefSize(96, 96);
                        }
                        else if (width == 1280) {
                            r1litsener.setSelected(true);
                            b1.setEffect(effectBG_DropShadow);
                            b1.setTextFill(Color.web(color2));
                            b1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");
                        }

                        int t = Integer.parseInt(properties.getProperty("TMode"));
                        if (t == 1) {

                            t1litsener.setSelected(true);
                            t2litsener.setSelected(false);

                            t1.setEffect(effectBG_DropShadow);
                            t1.setStyle("-fx-background-color: #f3f5f7; -fx-background-radius: 50%; -fx-border-color: "+color2+"; -fx-border-radius: 50%; -fx-border-width: 3  ;");

                            t2.setEffect(null);

                        }
                        else {

                            t1litsener.setSelected(false);
                            t2litsener.setSelected(true);

                            t1.setEffect(null);
                            t2.setEffect(effectBG_DropShadow);
                            t2.setStyle("-fx-background-color: #000; -fx-background-radius: 50%; -fx-border-color: "+color2+"; -fx-border-radius: 50%; -fx-border-width: 3  ;");


                        }

                        int c = Integer.parseInt(properties.getProperty("TColor"));
                        if (c == 1) {

                            c1litsener.setSelected(true);
                            c2litsener.setSelected(false);
                            c3litsener.setSelected(false);
                            c4litsener.setSelected(false);

                            c1.setEffect(effectBG_DropShadow);
                            c1.setStyle("-fx-background-color: #004fcb; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                            c2.setEffect(null);
                            c3.setEffect(null);
                            c4.setEffect(null);

                        }
                        else if (c == 2) {

                            c1.setEffect(null);
                            c2.setEffect(effectBG_DropShadow);
                            c2.setStyle("-fx-background-color: #c9c208; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                            c3.setEffect(null);
                            c4.setEffect(null);

                            c1litsener.setSelected(false);
                            c2litsener.setSelected(true);
                            c3litsener.setSelected(false);
                            c4litsener.setSelected(false);

                        }
                        else if (c == 3) {

                            c1litsener.setSelected(false);
                            c2litsener.setSelected(false);
                            c3litsener.setSelected(true);
                            c4litsener.setSelected(false);

                            c1.setEffect(null);
                            c2.setEffect(null);
                            c3.setEffect(effectBG_DropShadow);
                            c3.setStyle("-fx-background-color: #006500; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                            c4.setEffect(null);

                        }
                        else if (c == 4) {

                            c1litsener.setSelected(false);
                            c3litsener.setSelected(false);
                            c2litsener.setSelected(false);
                            c4litsener.setSelected(true);

                            c1.setEffect(null);
                            c2.setEffect(null);
                            c3.setEffect(null);
                            c4.setEffect(effectBG_DropShadow);
                            c4.setStyle("-fx-background-color: #9b0000; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");

                        }
                    }

                    p1.setGraphic(svgIconDisplay);
                    p2.setGraphic(svgIconSound);
                    p3.setGraphic(svgIconTheme);

                    backButton.setGraphic(svgIconSetting);

                    Panel1.setEffect(effectBG_DropShadow);
                    Panel2.setEffect(effectBG_DropShadow);
                    Panel3.setEffect(effectBG_DropShadow);
                    Panel4.setEffect(effectBG_DropShadow);

                    b1.addEventHandler(MouseEvent.MOUSE_ENTERED, e-> b1.setEffect(effectBG_DropShadow));
                    b1.addEventHandler(MouseEvent.MOUSE_EXITED, e->{

                        if (r1litsener.isSelected()) {
                            b1.setEffect(effectBG_DropShadow);
                        } else {
                            b1.setEffect(null);
                        }

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
                        r1litsener.setSelected(true);
                        r2litsener.setSelected(false);
                        r3litsener.setSelected(false);
                        b1.setEffect(effectBG_DropShadow);
                        b1.setTextFill(Color.web(color2));
                        b1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");

                    });

                    b2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> b2.setEffect(effectBG_DropShadow));
                    b2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r2litsener.isSelected()) {
                            b2.setEffect(effectBG_DropShadow);
                        } else {
                            b2.setEffect(null);
                        }
                    });
                    b2.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
                        b2.setEffect(effectBG_DropShadow);
                        b2.setTextFill(Color.web(color2));
                        b2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");

                        r1litsener.setSelected(false);
                        r2litsener.setSelected(true);
                        r3litsener.setSelected(false);

                    });

                    b3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> b3.setEffect(effectBG_DropShadow));
                    b3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r3litsener.isSelected()) {
                            b3.setEffect(effectBG_DropShadow);
                        } else {
                            b3.setEffect(null);
                        }
                    });
                    b3.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        b3.setEffect(effectBG_DropShadow);
                        b3.setTextFill(Color.web(color2));
                        b3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");
                        r1litsener.setSelected(false);
                        r2litsener.setSelected(false);
                        r3litsener.setSelected(true);
                    });

                    t1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> t1.setEffect(effectBG_DropShadow));
                    t1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t1litsener.isSelected()) {
                            t1.setEffect(effectBG_DropShadow);
                        } else {
                            t1.setEffect(null);
                        }
                    });
                    t1.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1litsener.setSelected(true);
                        t2litsener.setSelected(false);

                        t1.setEffect(effectBG_DropShadow);
                        t1.setStyle("-fx-background-color: #f3f5f7; -fx-background-radius: 50%; -fx-border-color: "+color2+"; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                        t2.setEffect(null);

                    });

                    t2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> t2.setEffect(effectBG_DropShadow));
                    t2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t2litsener.isSelected()) {
                            t2.setEffect(effectBG_DropShadow);
                        } else {
                            t2.setEffect(null);
                        }
                    });
                    t2.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1litsener.setSelected(false);
                        t2litsener.setSelected(true);

                        t1.setEffect(null);
                        t2.setEffect(effectBG_DropShadow);
                        t2.setStyle("-fx-background-color: #000; -fx-background-radius: 50%; -fx-border-color: "+color2+"; -fx-border-radius: 50%; -fx-border-width: 3  ;");

                    });

                    c1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> t1.setEffect(effectBG_DropShadow));
                    c1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (c1litsener.isSelected()) {
                            c1.setEffect(effectBG_DropShadow);
                        } else {
                            c1.setEffect(null);
                        }
                    });
                    c1.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        c1litsener.setSelected(true);
                        c2litsener.setSelected(false);
                        c3litsener.setSelected(false);
                        c4litsener.setSelected(false);

                        c1.setEffect(effectBG_DropShadow);
                        c1.setStyle("-fx-background-color: #004fcb; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                        c2.setEffect(null);
                        c3.setEffect(null);
                        c4.setEffect(null);

                    });

                    c2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> c2.setEffect(effectBG_DropShadow));
                    c2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (c2litsener.isSelected()) {
                            c2.setEffect(effectBG_DropShadow);
                        } else {
                            c2.setEffect(null);
                        }
                    });
                    c2.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        c1.setEffect(null);
                        c2.setEffect(effectBG_DropShadow);
                        c2.setStyle("-fx-background-color: #c9c208; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                        c3.setEffect(null);
                        c4.setEffect(null);

                        c1litsener.setSelected(false);
                        c2litsener.setSelected(true);
                        c3litsener.setSelected(false);
                        c4litsener.setSelected(false);

                    });

                    c3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> t1.setEffect(effectBG_DropShadow));
                    c3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (c3litsener.isSelected()) {
                            c3.setEffect(effectBG_DropShadow);
                        } else {
                            c3.setEffect(null);
                        }
                    });
                    c3.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        c1litsener.setSelected(false);
                        c2litsener.setSelected(false);
                        c3litsener.setSelected(true);
                        c4litsener.setSelected(false);

                        c1.setEffect(null);
                        c2.setEffect(null);
                        c3.setEffect(effectBG_DropShadow);
                        c3.setStyle("-fx-background-color: #006500; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                        c4.setEffect(null);

                    });

                    c4.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> c4.setEffect(effectBG_DropShadow));
                    c4.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (c4litsener.isSelected()) {
                            c4.setEffect(effectBG_DropShadow);
                        } else {
                            c4.setEffect(null);
                        }
                    });
                    c4.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        c1litsener.setSelected(false);
                        c3litsener.setSelected(false);
                        c2litsener.setSelected(false);
                        c4litsener.setSelected(true);

                        c1.setEffect(null);
                        c2.setEffect(null);
                        c3.setEffect(null);
                        c4.setEffect(effectBG_DropShadow);
                        c4.setStyle("-fx-background-color: #9b0000; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");

                    });

                    resetGame.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> resetGame.setEffect(effectBG_DropShadow));
                    resetGame.addEventHandler(MouseEvent.MOUSE_EXITED, e -> resetGame.setEffect(null));
                    resetGame.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> resetGame.setEffect(effectBG_DropShadow));

                    resetSetting.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> resetSetting.setEffect(effectBG_DropShadow));
                    resetSetting.addEventHandler(MouseEvent.MOUSE_EXITED, e -> resetSetting.setEffect(null));
                    resetSetting.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> resetSetting.setEffect(effectBG_DropShadow));

                    Panel1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        p1.setGraphic(svgIconDisplay_Hover);
                        b1.setVisible(true);
                        b2.setVisible(true);
                        b3.setVisible(true);

                        fadeIn5.play();
                        fadeIn5_1.play();
                        fadeIn5_2.play();

                        Panel1.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> {
                            fadeIn5.stop();
                            fadeIn5_1.stop();
                            fadeIn5_2.stop();
                        });

                    });
                    Panel1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        p1.setGraphic(svgIconDisplay);

                        b1.setVisible(true);
                        b2.setVisible(true);
                        b3.setVisible(true);

                        fadeOut5.play();
                        fadeOut5_1.play();
                        fadeOut5_2.play();

                        Panel1.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> {
                            fadeOut5.stop();
                            fadeOut5_1.stop();
                            fadeOut5_2.stop();
                        });

                    });

                    Panel2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        p2.setGraphic(svgIconSound_Hover);
                    });
                    Panel2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        p2.setGraphic(svgIconSound);
                    });

                    Panel3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        p3.setGraphic(svgIconTheme_Hover);

                        lt1.setVisible(true);
                        lt2.setVisible(true);
                        t1.setVisible(true);
                        t2.setVisible(true);
                        c1.setVisible(true);
                        c2.setVisible(true);
                        c3.setVisible(true);
                        c4.setVisible(true);

                        fadeIn6.play();
                        fadeIn6_1.play();
                        fadeIn7.play();
                        fadeIn7_1.play();
                        fadeIn7_2.play();
                        fadeIn7_3.play();
                        fadeIn8.play();
                        fadeIn8_1.play();

                        Panel3.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> {

                            fadeIn6.stop();
                            fadeIn6_1.stop();
                            fadeIn7.stop();
                            fadeIn7_1.stop();
                            fadeIn7_2.stop();
                            fadeIn7_3.stop();
                            fadeIn8.stop();
                            fadeIn8_1.stop();
                        });

                    });
                    Panel3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        p3.setGraphic(svgIconTheme);

                        fadeOut6.play();
                        fadeOut6_1.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();
                        fadeOut7_3.play();
                        fadeOut8.play();
                        fadeOut8_1.play();

                        Panel3.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> {

                            fadeOut6.stop();
                            fadeOut6_1.stop();
                            fadeOut7.stop();
                            fadeOut7_1.stop();
                            fadeOut7_2.stop();
                            fadeOut7_3.stop();
                            fadeOut8.stop();
                            fadeOut8_1.stop();

                        });

                    });

                    Panel4.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        p3.setGraphic(svgIconTheme_Hover);

                        resetGame.setVisible(true);
                        resetSetting.setVisible(true);

                        fadeIn9.play();
                        fadeIn9_1.play();

                        Panel4.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> {

                            fadeIn9.stop();
                            fadeIn9_1.stop();

                        });

                    });
                    Panel4.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        p3.setGraphic(svgIconTheme);

                        fadeOut9.play();
                        fadeOut9_1.play();

                        Panel4.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> {

                            fadeOut9.stop();
                            fadeOut9_1.stop();

                        });

                    });

                    Panelex2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        backButton.setGraphic(svgIconSetting_Hover);

                    });
                    Panelex2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        backButton.setGraphic(svgIconSetting);
                    });

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        backButton.setEffect(effectC_DropShadow);
                        backButton.setGraphic(svgIconBack);
                        l2.setText("Back to Home");
                        l1.setText("");
                        l3.setText("");
                        Panelg1.setEffect(blur);
                        Panelg2.setEffect(blur);
                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        backButton.setEffect(null);
                        backButton.setGraphic(svgIconSetting);
                        l1.setText("MEMORY");
                        l2.setText("GAME");
                        l3.setText("Setting");
                        Panelg1.setEffect(null);
                        Panelg2.setEffect(null);
                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        backButton.setGraphic(svgIconSetting);

                        fadeOut.play();
                        fadeOut2.play();
                        fadeOut3.play();
                        fadeOut10.play();
                        fadeOut11.play();

                        backButton.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.stop();
                            fadeOut2.stop();
                            fadeOut3.stop();
                            fadeOut10.stop();
                            fadeOut11.stop();

                        });

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            closeSettings();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                }
                else if (tColor==3) {

                    color2 = "#006500";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,86,0), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,116,0), 10, 0, -5, -5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,86,0), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,116,0), 10, 0, -5, -5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBack = getClass().getResourceAsStream("../../../resources/svg/left-arrow_dgreen.svg");//

                    svgFileDisplay = getClass().getResourceAsStream("../../../resources/svg/resolution_d.svg");
                    svgFileDisplay_Hover = getClass().getResourceAsStream("../../../resources/svg/resolution_dgreen.svg");

                    svgFileTheme = getClass().getResourceAsStream("../../../resources/svg/theme_d.svg");
                    svgFileTheme_Hover = getClass().getResourceAsStream("../../../resources/svg/theme_dgreen.svg");

                    svgFileSetting = getClass().getResourceAsStream("../../../resources/svg/menu/menu_d.svg");
                    svgFileSetting_Hover = getClass().getResourceAsStream("../../../resources/svg/menu/menu_dgreen.svg");

                    svgFileSound = getClass().getResourceAsStream("../../../resources/svg/volume_d.svg");
                    svgFileSound_Hover = getClass().getResourceAsStream("../../../resources/svg/volume_dgreen.svg");

                    Group svgBack = loader.loadSvg(svgFileBack);
                    Group svgSetting = loader.loadSvg(svgFileSetting);
                    Group svgSetting_Hover = loader.loadSvg(svgFileSetting_Hover);

                    Group svgDisplay = loader.loadSvg(svgFileDisplay);
                    Group svgDisplay_Hover = loader.loadSvg(svgFileDisplay_Hover);

                    Group svgSound = loader.loadSvg(svgFileSound);
                    Group svgSound_Hover = loader.loadSvg(svgFileSound_Hover);

                    Group svgTheme = loader.loadSvg(svgFileTheme);
                    Group svgTheme_Hover = loader.loadSvg(svgFileTheme_Hover);

                    svgBack.setScaleX(.04);
                    svgBack.setScaleY(.04);

                    svgSetting.setScaleX(.04);
                    svgSetting.setScaleY(.04);

                    svgSetting_Hover.setScaleX(.04);
                    svgSetting_Hover.setScaleY(.04);

                    svgDisplay.setScaleX(.25);
                    svgDisplay.setScaleY(.25);

                    svgDisplay_Hover.setScaleX(.25);
                    svgDisplay_Hover.setScaleY(.25);

                    svgSound.setScaleX(.25);
                    svgSound.setScaleY(.25);

                    svgSound_Hover.setScaleX(.25);
                    svgSound_Hover.setScaleY(.25);

                    svgTheme.setScaleX(.25);
                    svgTheme.setScaleY(.25);

                    svgTheme_Hover.setScaleX(.25);
                    svgTheme_Hover.setScaleY(.25);

                    Group svgIconBack = new Group(svgBack);
                    Group svgIconSetting = new Group(svgSetting);
                    Group svgIconSetting_Hover = new Group(svgSetting_Hover);

                    Group svgIconDisplay = new Group(svgDisplay);
                    Group svgIconDisplay_Hover = new Group(svgDisplay_Hover);

                    Group svgIconSound = new Group(svgSound);
                    Group svgIconSound_Hover = new Group(svgSound_Hover);

                    Group svgIconTheme = new Group(svgTheme);
                    Group svgIconTheme_Hover = new Group(svgTheme_Hover);

                    if (f.exists()) {
                        properties.load(input);

                        int width = Integer.parseInt(properties.getProperty("width"));
                        if (width == 999) {
                            r3litsener.setSelected(true);
                            b3.setEffect(effectBG_DropShadow);
                            b3.setTextFill(Color.web(color2));
                            b3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");

                            t1.setPrefSize(128, 128);
                            t2.setPrefSize(128, 128);

                            c1.setPrefSize(128, 128);
                            c2.setPrefSize(128, 128);
                            c3.setPrefSize(128, 128);
                            c4.setPrefSize(128, 128);
                        }
                        else if (width == 1600) {
                            r2litsener.setSelected(true);
                            b2.setEffect(effectBG_DropShadow);
                            b2.setTextFill(Color.web(color2));
                            b2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");

                            t1.setPrefSize(96, 96);
                            t2.setPrefSize(96, 96);

                            c1.setPrefSize(96, 96);
                            c2.setPrefSize(96, 96);
                            c3.setPrefSize(96, 96);
                            c4.setPrefSize(96, 96);
                        }
                        else if (width == 1280) {
                            r1litsener.setSelected(true);
                            b1.setEffect(effectBG_DropShadow);
                            b1.setTextFill(Color.web(color2));
                            b1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");
                        }

                        int t = Integer.parseInt(properties.getProperty("TMode"));
                        if (t == 1) {

                            t1litsener.setSelected(true);
                            t2litsener.setSelected(false);

                            t1.setEffect(effectBG_DropShadow);
                            t1.setStyle("-fx-background-color: #f3f5f7; -fx-background-radius: 50%; -fx-border-color: "+color2+"; -fx-border-radius: 50%; -fx-border-width: 3  ;");

                            t2.setEffect(null);

                        }
                        else {

                            t1litsener.setSelected(false);
                            t2litsener.setSelected(true);

                            t1.setEffect(null);
                            t2.setEffect(effectBG_DropShadow);
                            t2.setStyle("-fx-background-color: #000; -fx-background-radius: 50%; -fx-border-color: "+color2+"; -fx-border-radius: 50%; -fx-border-width: 3  ;");


                        }

                        int c = Integer.parseInt(properties.getProperty("TColor"));
                        if (c == 1) {

                            c1litsener.setSelected(true);
                            c2litsener.setSelected(false);
                            c3litsener.setSelected(false);
                            c4litsener.setSelected(false);

                            c1.setEffect(effectBG_DropShadow);
                            c1.setStyle("-fx-background-color: #004fcb; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                            c2.setEffect(null);
                            c3.setEffect(null);
                            c4.setEffect(null);

                        }
                        else if (c == 2) {

                            c1.setEffect(null);
                            c2.setEffect(effectBG_DropShadow);
                            c2.setStyle("-fx-background-color: #c9c208; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                            c3.setEffect(null);
                            c4.setEffect(null);

                            c1litsener.setSelected(false);
                            c2litsener.setSelected(true);
                            c3litsener.setSelected(false);
                            c4litsener.setSelected(false);

                        }
                        else if (c == 3) {

                            c1litsener.setSelected(false);
                            c2litsener.setSelected(false);
                            c3litsener.setSelected(true);
                            c4litsener.setSelected(false);

                            c1.setEffect(null);
                            c2.setEffect(null);
                            c3.setEffect(effectBG_DropShadow);
                            c3.setStyle("-fx-background-color: #006500; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                            c4.setEffect(null);

                        }
                        else if (c == 4) {

                            c1litsener.setSelected(false);
                            c3litsener.setSelected(false);
                            c2litsener.setSelected(false);
                            c4litsener.setSelected(true);

                            c1.setEffect(null);
                            c2.setEffect(null);
                            c3.setEffect(null);
                            c4.setEffect(effectBG_DropShadow);
                            c4.setStyle("-fx-background-color: #9b0000; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");

                        }
                    }

                    p1.setGraphic(svgIconDisplay);
                    p2.setGraphic(svgIconSound);
                    p3.setGraphic(svgIconTheme);

                    backButton.setGraphic(svgIconSetting);

                    Panel1.setEffect(effectBG_DropShadow);
                    Panel2.setEffect(effectBG_DropShadow);
                    Panel3.setEffect(effectBG_DropShadow);
                    Panel4.setEffect(effectBG_DropShadow);

                    b1.addEventHandler(MouseEvent.MOUSE_ENTERED, e-> b1.setEffect(effectBG_DropShadow));
                    b1.addEventHandler(MouseEvent.MOUSE_EXITED, e->{

                        if (r1litsener.isSelected()) {
                            b1.setEffect(effectBG_DropShadow);
                        } else {
                            b1.setEffect(null);
                        }

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
                        r1litsener.setSelected(true);
                        r2litsener.setSelected(false);
                        r3litsener.setSelected(false);
                        b1.setEffect(effectBG_DropShadow);
                        b1.setTextFill(Color.web(color2));
                        b1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");

                    });

                    b2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> b2.setEffect(effectBG_DropShadow));
                    b2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r2litsener.isSelected()) {
                            b2.setEffect(effectBG_DropShadow);
                        } else {
                            b2.setEffect(null);
                        }
                    });
                    b2.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
                        b2.setEffect(effectBG_DropShadow);
                        b2.setTextFill(Color.web(color2));
                        b2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");

                        r1litsener.setSelected(false);
                        r2litsener.setSelected(true);
                        r3litsener.setSelected(false);

                    });

                    b3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> b3.setEffect(effectBG_DropShadow));
                    b3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r3litsener.isSelected()) {
                            b3.setEffect(effectBG_DropShadow);
                        } else {
                            b3.setEffect(null);
                        }
                    });
                    b3.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        b3.setEffect(effectBG_DropShadow);
                        b3.setTextFill(Color.web(color2));
                        b3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");
                        r1litsener.setSelected(false);
                        r2litsener.setSelected(false);
                        r3litsener.setSelected(true);
                    });

                    t1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> t1.setEffect(effectBG_DropShadow));
                    t1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t1litsener.isSelected()) {
                            t1.setEffect(effectBG_DropShadow);
                        } else {
                            t1.setEffect(null);
                        }
                    });
                    t1.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1litsener.setSelected(true);
                        t2litsener.setSelected(false);

                        t1.setEffect(effectBG_DropShadow);
                        t1.setStyle("-fx-background-color: #f3f5f7; -fx-background-radius: 50%; -fx-border-color: "+color2+"; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                        t2.setEffect(null);

                    });

                    t2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> t2.setEffect(effectBG_DropShadow));
                    t2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t2litsener.isSelected()) {
                            t2.setEffect(effectBG_DropShadow);
                        } else {
                            t2.setEffect(null);
                        }
                    });
                    t2.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1litsener.setSelected(false);
                        t2litsener.setSelected(true);

                        t1.setEffect(null);
                        t2.setEffect(effectBG_DropShadow);
                        t2.setStyle("-fx-background-color: #000; -fx-background-radius: 50%; -fx-border-color: "+color2+"; -fx-border-radius: 50%; -fx-border-width: 3  ;");

                    });

                    c1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> t1.setEffect(effectBG_DropShadow));
                    c1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (c1litsener.isSelected()) {
                            c1.setEffect(effectBG_DropShadow);
                        } else {
                            c1.setEffect(null);
                        }
                    });
                    c1.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        c1litsener.setSelected(true);
                        c2litsener.setSelected(false);
                        c3litsener.setSelected(false);
                        c4litsener.setSelected(false);

                        c1.setEffect(effectBG_DropShadow);
                        c1.setStyle("-fx-background-color: #004fcb; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                        c2.setEffect(null);
                        c3.setEffect(null);
                        c4.setEffect(null);

                    });

                    c2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> c2.setEffect(effectBG_DropShadow));
                    c2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (c2litsener.isSelected()) {
                            c2.setEffect(effectBG_DropShadow);
                        } else {
                            c2.setEffect(null);
                        }
                    });
                    c2.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        c1.setEffect(null);
                        c2.setEffect(effectBG_DropShadow);
                        c2.setStyle("-fx-background-color: #c9c208; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                        c3.setEffect(null);
                        c4.setEffect(null);

                        c1litsener.setSelected(false);
                        c2litsener.setSelected(true);
                        c3litsener.setSelected(false);
                        c4litsener.setSelected(false);

                    });

                    c3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> t1.setEffect(effectBG_DropShadow));
                    c3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (c3litsener.isSelected()) {
                            c3.setEffect(effectBG_DropShadow);
                        } else {
                            c3.setEffect(null);
                        }
                    });
                    c3.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        c1litsener.setSelected(false);
                        c2litsener.setSelected(false);
                        c3litsener.setSelected(true);
                        c4litsener.setSelected(false);

                        c1.setEffect(null);
                        c2.setEffect(null);
                        c3.setEffect(effectBG_DropShadow);
                        c3.setStyle("-fx-background-color: #006500; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                        c4.setEffect(null);

                    });

                    c4.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> c4.setEffect(effectBG_DropShadow));
                    c4.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (c4litsener.isSelected()) {
                            c4.setEffect(effectBG_DropShadow);
                        } else {
                            c4.setEffect(null);
                        }
                    });
                    c4.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        c1litsener.setSelected(false);
                        c3litsener.setSelected(false);
                        c2litsener.setSelected(false);
                        c4litsener.setSelected(true);

                        c1.setEffect(null);
                        c2.setEffect(null);
                        c3.setEffect(null);
                        c4.setEffect(effectBG_DropShadow);
                        c4.setStyle("-fx-background-color: #9b0000; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");

                    });

                    resetGame.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> resetGame.setEffect(effectBG_DropShadow));
                    resetGame.addEventHandler(MouseEvent.MOUSE_EXITED, e -> resetGame.setEffect(null));
                    resetGame.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> resetGame.setEffect(effectBG_DropShadow));

                    resetSetting.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> resetSetting.setEffect(effectBG_DropShadow));
                    resetSetting.addEventHandler(MouseEvent.MOUSE_EXITED, e -> resetSetting.setEffect(null));
                    resetSetting.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> resetSetting.setEffect(effectBG_DropShadow));

                    Panel1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        p1.setGraphic(svgIconDisplay_Hover);
                        b1.setVisible(true);
                        b2.setVisible(true);
                        b3.setVisible(true);

                        fadeIn5.play();
                        fadeIn5_1.play();
                        fadeIn5_2.play();

                        Panel1.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> {
                            fadeIn5.stop();
                            fadeIn5_1.stop();
                            fadeIn5_2.stop();
                        });

                    });
                    Panel1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        p1.setGraphic(svgIconDisplay);

                        b1.setVisible(true);
                        b2.setVisible(true);
                        b3.setVisible(true);

                        fadeOut5.play();
                        fadeOut5_1.play();
                        fadeOut5_2.play();

                        Panel1.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> {
                            fadeOut5.stop();
                            fadeOut5_1.stop();
                            fadeOut5_2.stop();
                        });

                    });

                    Panel2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        p2.setGraphic(svgIconSound_Hover);
                    });
                    Panel2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        p2.setGraphic(svgIconSound);
                    });

                    Panel3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        p3.setGraphic(svgIconTheme_Hover);

                        lt1.setVisible(true);
                        lt2.setVisible(true);
                        t1.setVisible(true);
                        t2.setVisible(true);
                        c1.setVisible(true);
                        c2.setVisible(true);
                        c3.setVisible(true);
                        c4.setVisible(true);

                        fadeIn6.play();
                        fadeIn6_1.play();
                        fadeIn7.play();
                        fadeIn7_1.play();
                        fadeIn7_2.play();
                        fadeIn7_3.play();
                        fadeIn8.play();
                        fadeIn8_1.play();

                        Panel3.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> {

                            fadeIn6.stop();
                            fadeIn6_1.stop();
                            fadeIn7.stop();
                            fadeIn7_1.stop();
                            fadeIn7_2.stop();
                            fadeIn7_3.stop();
                            fadeIn8.stop();
                            fadeIn8_1.stop();
                        });

                    });
                    Panel3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        p3.setGraphic(svgIconTheme);

                        fadeOut6.play();
                        fadeOut6_1.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();
                        fadeOut7_3.play();
                        fadeOut8.play();
                        fadeOut8_1.play();

                        Panel3.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> {

                            fadeOut6.stop();
                            fadeOut6_1.stop();
                            fadeOut7.stop();
                            fadeOut7_1.stop();
                            fadeOut7_2.stop();
                            fadeOut7_3.stop();
                            fadeOut8.stop();
                            fadeOut8_1.stop();

                        });

                    });

                    Panel4.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        p3.setGraphic(svgIconTheme_Hover);

                        resetGame.setVisible(true);
                        resetSetting.setVisible(true);

                        fadeIn9.play();
                        fadeIn9_1.play();

                        Panel4.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> {

                            fadeIn9.stop();
                            fadeIn9_1.stop();

                        });

                    });
                    Panel4.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        p3.setGraphic(svgIconTheme);

                        fadeOut9.play();
                        fadeOut9_1.play();

                        Panel4.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> {

                            fadeOut9.stop();
                            fadeOut9_1.stop();

                        });

                    });

                    Panelex2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        backButton.setGraphic(svgIconSetting_Hover);

                    });
                    Panelex2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        backButton.setGraphic(svgIconSetting);
                    });

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        backButton.setEffect(effectC_DropShadow);
                        backButton.setGraphic(svgIconBack);
                        l2.setText("Back to Home");
                        l1.setText("");
                        l3.setText("");
                        Panelg1.setEffect(blur);
                        Panelg2.setEffect(blur);
                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        backButton.setEffect(null);
                        backButton.setGraphic(svgIconSetting);
                        l1.setText("MEMORY");
                        l2.setText("GAME");
                        l3.setText("Setting");
                        Panelg1.setEffect(null);
                        Panelg2.setEffect(null);
                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        backButton.setGraphic(svgIconSetting);

                        fadeOut.play();
                        fadeOut2.play();
                        fadeOut3.play();
                        fadeOut10.play();
                        fadeOut11.play();

                        backButton.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.stop();
                            fadeOut2.stop();
                            fadeOut3.stop();
                            fadeOut10.stop();
                            fadeOut11.stop();

                        });

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            closeSettings();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                }
                else if (tColor==4) {

                    color2 = "#9b0000";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(155,0,0), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(178,0,0), 10, 0, -5, -5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(155,0,0), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(178,0,0), 10, 0, -5, -5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBack = getClass().getResourceAsStream("../../../resources/svg/left-arrow_dred.svg");//

                    svgFileDisplay = getClass().getResourceAsStream("../../../resources/svg/resolution_d.svg");
                    svgFileDisplay_Hover = getClass().getResourceAsStream("../../../resources/svg/resolution_dred.svg");

                    svgFileTheme = getClass().getResourceAsStream("../../../resources/svg/theme_d.svg");
                    svgFileTheme_Hover = getClass().getResourceAsStream("../../../resources/svg/theme_dred.svg");

                    svgFileSetting = getClass().getResourceAsStream("../../../resources/svg/menu/menu_d.svg");
                    svgFileSetting_Hover = getClass().getResourceAsStream("../../../resources/svg/menu/menu_dred.svg");

                    svgFileSound = getClass().getResourceAsStream("../../../resources/svg/volume_d.svg");
                    svgFileSound_Hover = getClass().getResourceAsStream("../../../resources/svg/volume_dred.svg");

                    Group svgBack = loader.loadSvg(svgFileBack);
                    Group svgSetting = loader.loadSvg(svgFileSetting);
                    Group svgSetting_Hover = loader.loadSvg(svgFileSetting_Hover);

                    Group svgDisplay = loader.loadSvg(svgFileDisplay);
                    Group svgDisplay_Hover = loader.loadSvg(svgFileDisplay_Hover);

                    Group svgSound = loader.loadSvg(svgFileSound);
                    Group svgSound_Hover = loader.loadSvg(svgFileSound_Hover);

                    Group svgTheme = loader.loadSvg(svgFileTheme);
                    Group svgTheme_Hover = loader.loadSvg(svgFileTheme_Hover);

                    svgBack.setScaleX(.04);
                    svgBack.setScaleY(.04);

                    svgSetting.setScaleX(.04);
                    svgSetting.setScaleY(.04);

                    svgSetting_Hover.setScaleX(.04);
                    svgSetting_Hover.setScaleY(.04);

                    svgDisplay.setScaleX(.25);
                    svgDisplay.setScaleY(.25);

                    svgDisplay_Hover.setScaleX(.25);
                    svgDisplay_Hover.setScaleY(.25);

                    svgSound.setScaleX(.25);
                    svgSound.setScaleY(.25);

                    svgSound_Hover.setScaleX(.25);
                    svgSound_Hover.setScaleY(.25);

                    svgTheme.setScaleX(.25);
                    svgTheme.setScaleY(.25);

                    svgTheme_Hover.setScaleX(.25);
                    svgTheme_Hover.setScaleY(.25);

                    Group svgIconBack = new Group(svgBack);
                    Group svgIconSetting = new Group(svgSetting);
                    Group svgIconSetting_Hover = new Group(svgSetting_Hover);

                    Group svgIconDisplay = new Group(svgDisplay);
                    Group svgIconDisplay_Hover = new Group(svgDisplay_Hover);

                    Group svgIconSound = new Group(svgSound);
                    Group svgIconSound_Hover = new Group(svgSound_Hover);

                    Group svgIconTheme = new Group(svgTheme);
                    Group svgIconTheme_Hover = new Group(svgTheme_Hover);

                    if (f.exists()) {
                        properties.load(input);

                        int width = Integer.parseInt(properties.getProperty("width"));
                        if (width == 999) {
                            r3litsener.setSelected(true);
                            b3.setEffect(effectBG_DropShadow);
                            b3.setTextFill(Color.web(color2));
                            b3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");

                            t1.setPrefSize(128, 128);
                            t2.setPrefSize(128, 128);

                            c1.setPrefSize(128, 128);
                            c2.setPrefSize(128, 128);
                            c3.setPrefSize(128, 128);
                            c4.setPrefSize(128, 128);
                        }
                        else if (width == 1600) {
                            r2litsener.setSelected(true);
                            b2.setEffect(effectBG_DropShadow);
                            b2.setTextFill(Color.web(color2));
                            b2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");

                            t1.setPrefSize(96, 96);
                            t2.setPrefSize(96, 96);

                            c1.setPrefSize(96, 96);
                            c2.setPrefSize(96, 96);
                            c3.setPrefSize(96, 96);
                            c4.setPrefSize(96, 96);
                        }
                        else if (width == 1280) {
                            r1litsener.setSelected(true);
                            b1.setEffect(effectBG_DropShadow);
                            b1.setTextFill(Color.web(color2));
                            b1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");
                        }

                        int t = Integer.parseInt(properties.getProperty("TMode"));
                        if (t == 1) {

                            t1litsener.setSelected(true);
                            t2litsener.setSelected(false);

                            t1.setEffect(effectBG_DropShadow);
                            t1.setStyle("-fx-background-color: #f3f5f7; -fx-background-radius: 50%; -fx-border-color: "+color2+"; -fx-border-radius: 50%; -fx-border-width: 3  ;");

                            t2.setEffect(null);

                        }
                        else {

                            t1litsener.setSelected(false);
                            t2litsener.setSelected(true);

                            t1.setEffect(null);
                            t2.setEffect(effectBG_DropShadow);
                            t2.setStyle("-fx-background-color: #000; -fx-background-radius: 50%; -fx-border-color: "+color2+"; -fx-border-radius: 50%; -fx-border-width: 3  ;");


                        }

                        int c = Integer.parseInt(properties.getProperty("TColor"));
                        if (c == 1) {

                            c1litsener.setSelected(true);
                            c2litsener.setSelected(false);
                            c3litsener.setSelected(false);
                            c4litsener.setSelected(false);

                            c1.setEffect(effectBG_DropShadow);
                            c1.setStyle("-fx-background-color: #004fcb; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                            c2.setEffect(null);
                            c3.setEffect(null);
                            c4.setEffect(null);

                        }
                        else if (c == 2) {

                            c1.setEffect(null);
                            c2.setEffect(effectBG_DropShadow);
                            c2.setStyle("-fx-background-color: #c9c208; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                            c3.setEffect(null);
                            c4.setEffect(null);

                            c1litsener.setSelected(false);
                            c2litsener.setSelected(true);
                            c3litsener.setSelected(false);
                            c4litsener.setSelected(false);

                        }
                        else if (c == 3) {

                            c1litsener.setSelected(false);
                            c2litsener.setSelected(false);
                            c3litsener.setSelected(true);
                            c4litsener.setSelected(false);

                            c1.setEffect(null);
                            c2.setEffect(null);
                            c3.setEffect(effectBG_DropShadow);
                            c3.setStyle("-fx-background-color: #006500; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                            c4.setEffect(null);

                        }
                        else if (c == 4) {

                            c1litsener.setSelected(false);
                            c3litsener.setSelected(false);
                            c2litsener.setSelected(false);
                            c4litsener.setSelected(true);

                            c1.setEffect(null);
                            c2.setEffect(null);
                            c3.setEffect(null);
                            c4.setEffect(effectBG_DropShadow);
                            c4.setStyle("-fx-background-color: #9b0000; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");

                        }
                    }

                    p1.setGraphic(svgIconDisplay);
                    p2.setGraphic(svgIconSound);
                    p3.setGraphic(svgIconTheme);

                    backButton.setGraphic(svgIconSetting);

                    Panel1.setEffect(effectBG_DropShadow);
                    Panel2.setEffect(effectBG_DropShadow);
                    Panel3.setEffect(effectBG_DropShadow);
                    Panel4.setEffect(effectBG_DropShadow);

                    b1.addEventHandler(MouseEvent.MOUSE_ENTERED, e-> b1.setEffect(effectBG_DropShadow));
                    b1.addEventHandler(MouseEvent.MOUSE_EXITED, e->{

                        if (r1litsener.isSelected()) {
                            b1.setEffect(effectBG_DropShadow);
                        } else {
                            b1.setEffect(null);
                        }

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
                        r1litsener.setSelected(true);
                        r2litsener.setSelected(false);
                        r3litsener.setSelected(false);
                        b1.setEffect(effectBG_DropShadow);
                        b1.setTextFill(Color.web(color2));
                        b1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");

                    });

                    b2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> b2.setEffect(effectBG_DropShadow));
                    b2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r2litsener.isSelected()) {
                            b2.setEffect(effectBG_DropShadow);
                        } else {
                            b2.setEffect(null);
                        }
                    });
                    b2.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
                        b2.setEffect(effectBG_DropShadow);
                        b2.setTextFill(Color.web(color2));
                        b2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");

                        r1litsener.setSelected(false);
                        r2litsener.setSelected(true);
                        r3litsener.setSelected(false);

                    });

                    b3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> b3.setEffect(effectBG_DropShadow));
                    b3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r3litsener.isSelected()) {
                            b3.setEffect(effectBG_DropShadow);
                        } else {
                            b3.setEffect(null);
                        }
                    });
                    b3.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        b3.setEffect(effectBG_DropShadow);
                        b3.setTextFill(Color.web(color2));
                        b3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24 24 24 24; -fx-border-color: "+color2+"; -fx-border-radius: 24 24 24 24; -fx-border-width: 3  ;");
                        r1litsener.setSelected(false);
                        r2litsener.setSelected(false);
                        r3litsener.setSelected(true);
                    });

                    t1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> t1.setEffect(effectBG_DropShadow));
                    t1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t1litsener.isSelected()) {
                            t1.setEffect(effectBG_DropShadow);
                        } else {
                            t1.setEffect(null);
                        }
                    });
                    t1.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1litsener.setSelected(true);
                        t2litsener.setSelected(false);

                        t1.setEffect(effectBG_DropShadow);
                        t1.setStyle("-fx-background-color: #f3f5f7; -fx-background-radius: 50%; -fx-border-color: "+color2+"; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                        t2.setEffect(null);

                    });

                    t2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> t2.setEffect(effectBG_DropShadow));
                    t2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t2litsener.isSelected()) {
                            t2.setEffect(effectBG_DropShadow);
                        } else {
                            t2.setEffect(null);
                        }
                    });
                    t2.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1litsener.setSelected(false);
                        t2litsener.setSelected(true);

                        t1.setEffect(null);
                        t2.setEffect(effectBG_DropShadow);
                        t2.setStyle("-fx-background-color: #000; -fx-background-radius: 50%; -fx-border-color: "+color2+"; -fx-border-radius: 50%; -fx-border-width: 3  ;");

                    });

                    c1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> t1.setEffect(effectBG_DropShadow));
                    c1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (c1litsener.isSelected()) {
                            c1.setEffect(effectBG_DropShadow);
                        } else {
                            c1.setEffect(null);
                        }
                    });
                    c1.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        c1litsener.setSelected(true);
                        c2litsener.setSelected(false);
                        c3litsener.setSelected(false);
                        c4litsener.setSelected(false);

                        c1.setEffect(effectBG_DropShadow);
                        c1.setStyle("-fx-background-color: #004fcb; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                        c2.setEffect(null);
                        c3.setEffect(null);
                        c4.setEffect(null);

                    });

                    c2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> c2.setEffect(effectBG_DropShadow));
                    c2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (c2litsener.isSelected()) {
                            c2.setEffect(effectBG_DropShadow);
                        } else {
                            c2.setEffect(null);
                        }
                    });
                    c2.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        c1.setEffect(null);
                        c2.setEffect(effectBG_DropShadow);
                        c2.setStyle("-fx-background-color: #c9c208; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                        c3.setEffect(null);
                        c4.setEffect(null);

                        c1litsener.setSelected(false);
                        c2litsener.setSelected(true);
                        c3litsener.setSelected(false);
                        c4litsener.setSelected(false);

                    });

                    c3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> t1.setEffect(effectBG_DropShadow));
                    c3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (c3litsener.isSelected()) {
                            c3.setEffect(effectBG_DropShadow);
                        } else {
                            c3.setEffect(null);
                        }
                    });
                    c3.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        c1litsener.setSelected(false);
                        c2litsener.setSelected(false);
                        c3litsener.setSelected(true);
                        c4litsener.setSelected(false);

                        c1.setEffect(null);
                        c2.setEffect(null);
                        c3.setEffect(effectBG_DropShadow);
                        c3.setStyle("-fx-background-color: #006500; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");
                        c4.setEffect(null);

                    });

                    c4.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> c4.setEffect(effectBG_DropShadow));
                    c4.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (c4litsener.isSelected()) {
                            c4.setEffect(effectBG_DropShadow);
                        } else {
                            c4.setEffect(null);
                        }
                    });
                    c4.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        c1litsener.setSelected(false);
                        c3litsener.setSelected(false);
                        c2litsener.setSelected(false);
                        c4litsener.setSelected(true);

                        c1.setEffect(null);
                        c2.setEffect(null);
                        c3.setEffect(null);
                        c4.setEffect(effectBG_DropShadow);
                        c4.setStyle("-fx-background-color: #9b0000; -fx-background-radius: 50%; -fx-border-color: #000; -fx-border-radius: 50%; -fx-border-width: 3  ;");

                    });

                    resetGame.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> resetGame.setEffect(effectBG_DropShadow));
                    resetGame.addEventHandler(MouseEvent.MOUSE_EXITED, e -> resetGame.setEffect(null));
                    resetGame.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> resetGame.setEffect(effectBG_DropShadow));

                    resetSetting.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> resetSetting.setEffect(effectBG_DropShadow));
                    resetSetting.addEventHandler(MouseEvent.MOUSE_EXITED, e -> resetSetting.setEffect(null));
                    resetSetting.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> resetSetting.setEffect(effectBG_DropShadow));

                    Panel1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        p1.setGraphic(svgIconDisplay_Hover);
                        b1.setVisible(true);
                        b2.setVisible(true);
                        b3.setVisible(true);

                        fadeIn5.play();
                        fadeIn5_1.play();
                        fadeIn5_2.play();

                        Panel1.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> {
                            fadeIn5.stop();
                            fadeIn5_1.stop();
                            fadeIn5_2.stop();
                        });

                    });
                    Panel1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        p1.setGraphic(svgIconDisplay);

                        b1.setVisible(true);
                        b2.setVisible(true);
                        b3.setVisible(true);

                        fadeOut5.play();
                        fadeOut5_1.play();
                        fadeOut5_2.play();

                        Panel1.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> {
                            fadeOut5.stop();
                            fadeOut5_1.stop();
                            fadeOut5_2.stop();
                        });

                    });

                    Panel2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        p2.setGraphic(svgIconSound_Hover);
                    });
                    Panel2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        p2.setGraphic(svgIconSound);
                    });

                    Panel3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        p3.setGraphic(svgIconTheme_Hover);

                        lt1.setVisible(true);
                        lt2.setVisible(true);
                        t1.setVisible(true);
                        t2.setVisible(true);
                        c1.setVisible(true);
                        c2.setVisible(true);
                        c3.setVisible(true);
                        c4.setVisible(true);

                        fadeIn6.play();
                        fadeIn6_1.play();
                        fadeIn7.play();
                        fadeIn7_1.play();
                        fadeIn7_2.play();
                        fadeIn7_3.play();
                        fadeIn8.play();
                        fadeIn8_1.play();

                        Panel3.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> {

                            fadeIn6.stop();
                            fadeIn6_1.stop();
                            fadeIn7.stop();
                            fadeIn7_1.stop();
                            fadeIn7_2.stop();
                            fadeIn7_3.stop();
                            fadeIn8.stop();
                            fadeIn8_1.stop();
                        });

                    });
                    Panel3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        p3.setGraphic(svgIconTheme);

                        fadeOut6.play();
                        fadeOut6_1.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();
                        fadeOut7_3.play();
                        fadeOut8.play();
                        fadeOut8_1.play();

                        Panel3.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> {

                            fadeOut6.stop();
                            fadeOut6_1.stop();
                            fadeOut7.stop();
                            fadeOut7_1.stop();
                            fadeOut7_2.stop();
                            fadeOut7_3.stop();
                            fadeOut8.stop();
                            fadeOut8_1.stop();

                        });

                    });

                    Panel4.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        p3.setGraphic(svgIconTheme_Hover);

                        resetGame.setVisible(true);
                        resetSetting.setVisible(true);

                        fadeIn9.play();
                        fadeIn9_1.play();

                        Panel4.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> {

                            fadeIn9.stop();
                            fadeIn9_1.stop();

                        });

                    });
                    Panel4.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        p3.setGraphic(svgIconTheme);

                        fadeOut9.play();
                        fadeOut9_1.play();

                        Panel4.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> {

                            fadeOut9.stop();
                            fadeOut9_1.stop();

                        });

                    });

                    Panelex2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        backButton.setGraphic(svgIconSetting_Hover);

                    });
                    Panelex2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        backButton.setGraphic(svgIconSetting);
                    });

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        backButton.setEffect(effectC_DropShadow);
                        backButton.setGraphic(svgIconBack);
                        l2.setText("Back to Home");
                        l1.setText("");
                        l3.setText("");
                        Panelg1.setEffect(blur);
                        Panelg2.setEffect(blur);
                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        backButton.setEffect(null);
                        backButton.setGraphic(svgIconSetting);
                        l1.setText("MEMORY");
                        l2.setText("GAME");
                        l3.setText("Setting");
                        Panelg1.setEffect(null);
                        Panelg2.setEffect(null);
                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        backButton.setGraphic(svgIconSetting);

                        fadeOut.play();
                        fadeOut2.play();
                        fadeOut3.play();
                        fadeOut10.play();
                        fadeOut11.play();

                        backButton.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.stop();
                            fadeOut2.stop();
                            fadeOut3.stop();
                            fadeOut10.stop();
                            fadeOut11.stop();

                        });

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            closeSettings();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                }

            }

        }

    }

    private void closeSettings() throws IOException{

        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        output = new FileOutputStream("config.properties");
        properties.setProperty("MenuSelected", "1");
        properties.store(output, null);

        Parent root = FXMLLoader.load(getClass().getResource("../../../resources/view/MainMenu.fxml"));
        Stage stage = (Stage) backButton.getScene().getWindow();
        stage.getScene().setRoot(root);

        File f = new File("config.properties");
        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }
    }

    @FXML
    private void clearProgressClicked() throws IOException{

        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        File f2 =new File("score.properties");

        if(f2.exists()){
            input2 = new FileInputStream("score.properties");
            properties2.load(input2);

            output2 = new FileOutputStream("score.properties");
            properties2.setProperty("MultiplayerWins1","0");
            properties2.setProperty("MultiplayerWins2","0");
            properties2.setProperty("MultiplayerWins3","0");
            properties2.setProperty("MultiplayerWins4","0");
            properties2.setProperty("SingleModeHighScore1","0");
            properties2.setProperty("SingleModeHighScore2","0");
            properties2.setProperty("SingleModeHighScore3","0");
            properties2.setProperty("SingleModeHighScore4","0");
            properties2.setProperty("BattleWins","0");
            properties2.store(output2,null);
        }

    }

    @FXML
    private void clearSettingClicked() throws IOException{

        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        File f = new File("config.properties");

        if(f.exists()){
            input = new FileInputStream("config.properties");
            properties.load(input);

            output = new FileOutputStream("config.properties");
            properties.setProperty("width","1280");
            properties.setProperty("height","720");
            properties.setProperty("resolution", "1280x720");
            properties.setProperty("fullScreen","false");
            properties.setProperty("sound","enabled");
            properties.setProperty("TMode","1");
            properties.setProperty("TColor","1");
            properties.setProperty("MenuSelected","1");
            properties.store(output,null);
        }
        Parent root = FXMLLoader.load(getClass().getResource("../../../resources/view/SettingsPane.fxml"));
        Stage stage = (Stage) resetSetting.getScene().getWindow();
        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){
                stage.setWidth(1920);
                stage.setHeight(1080);
                stage.setFullScreen(true);
            }
            else if(width == 1600 ){
                stage.setWidth(1600);
                stage.setHeight(900);
            }
            else if(width == 1280 ){
                stage.setWidth(1280);
                stage.setHeight(720);
            }

        }
        stage.getScene().setRoot(root);

        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }

    }

    @FXML
    private void lightSelected() throws IOException {

        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        File f = new File("config.properties");
        output = new FileOutputStream("config.properties");
        properties.setProperty("TMode", "1");
        properties.store(output, null);

        Parent root = FXMLLoader.load(getClass().getResource("../../../resources/view/SettingsPane.fxml"));
        Stage stage = (Stage) b2.getScene().getWindow();
        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){
                stage.setWidth(1920);
                stage.setHeight(1080);
                stage.setFullScreen(true);
            }
            else if(width == 1600 ){
                stage.setWidth(1600);
                stage.setHeight(900);
            }
            else if(width == 1280 ){
                stage.setWidth(1280);
                stage.setHeight(720);
            }

        }
        stage.getScene().setRoot(root);

        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }

    }
    @FXML
    private void darkSelected() throws IOException {

        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        File f = new File("config.properties");
        output = new FileOutputStream("config.properties");
        properties.setProperty("TMode", "2");
        properties.store(output, null);

        Parent root = FXMLLoader.load(getClass().getResource("../../../resources/view/SettingsPane.fxml"));
        Stage stage = (Stage) b2.getScene().getWindow();
        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){
                stage.setWidth(1920);
                stage.setHeight(1080);
                stage.setFullScreen(true);
            }
            else if(width == 1600 ){
                stage.setWidth(1600);
                stage.setHeight(900);
            }
            else if(width == 1280 ){
                stage.setWidth(1280);
                stage.setHeight(720);
            }

        }
        stage.getScene().setRoot(root);

        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }

    }

    @FXML
    private void blueSelected() throws IOException {

        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        File f = new File("config.properties");
        output = new FileOutputStream("config.properties");
        properties.setProperty("TColor", "1");
        properties.store(output, null);

        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int theme = Integer.parseInt(properties.getProperty("TMode"));
            if(theme == 1 ){
                output = new FileOutputStream("config.properties");
                properties.setProperty("TMode", "1");
                properties.store(output, null);
            }else {
                output = new FileOutputStream("config.properties");
                properties.setProperty("TMode", "2");
                properties.store(output, null);
            }

        }

        Parent root = FXMLLoader.load(getClass().getResource("../../../resources/view/SettingsPane.fxml"));
        Stage stage = (Stage) c1.getScene().getWindow();
        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){
                stage.setWidth(1920);
                stage.setHeight(1080);
                stage.setFullScreen(true);
            }
            else if(width == 1600 ){
                stage.setWidth(1600);
                stage.setHeight(900);
            }
            else if(width == 1280 ){
                stage.setWidth(1280);
                stage.setHeight(720);
            }

        }
        stage.getScene().setRoot(root);

        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }

    }
    @FXML
    private void yellowSelected() throws IOException {

        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        File f = new File("config.properties");
        output = new FileOutputStream("config.properties");
        properties.setProperty("TColor", "2");
        properties.store(output, null);

        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int theme = Integer.parseInt(properties.getProperty("TMode"));
            if(theme == 1 ){
                output = new FileOutputStream("config.properties");
                properties.setProperty("TMode", "1");
                properties.store(output, null);
            }else {
                output = new FileOutputStream("config.properties");
                properties.setProperty("TMode", "2");
                properties.store(output, null);
            }

        }

        Parent root = FXMLLoader.load(getClass().getResource("../../../resources/view/SettingsPane.fxml"));
        Stage stage = (Stage) c2.getScene().getWindow();

        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){
                stage.setWidth(1920);
                stage.setHeight(1080);
                stage.setFullScreen(true);
            }
            else if(width == 1600 ){
                stage.setWidth(1600);
                stage.setHeight(900);
            }
            else if(width == 1280 ){
                stage.setWidth(1280);
                stage.setHeight(720);
            }

        }

        stage.getScene().setRoot(root);

        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }

    }
    @FXML
    private void greenSelected() throws IOException {

        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        File f = new File("config.properties");
        output = new FileOutputStream("config.properties");
        properties.setProperty("TColor", "3");
        properties.store(output, null);

        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int theme = Integer.parseInt(properties.getProperty("TMode"));
            if(theme == 1 ){
                output = new FileOutputStream("config.properties");
                properties.setProperty("TMode", "1");
                properties.store(output, null);
            }else {
                output = new FileOutputStream("config.properties");
                properties.setProperty("TMode", "2");
                properties.store(output, null);
            }

        }

        Parent root = FXMLLoader.load(getClass().getResource("../../../resources/view/SettingsPane.fxml"));
        Stage stage = (Stage) c3.getScene().getWindow();

        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){
                stage.setWidth(1920);
                stage.setHeight(1080);
                stage.setFullScreen(true);
            }
            else if(width == 1600 ){
                stage.setWidth(1600);
                stage.setHeight(900);
            }
            else if(width == 1280 ){
                stage.setWidth(1280);
                stage.setHeight(720);
            }

        }

        stage.getScene().setRoot(root);

        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }

    }
    @FXML
    private void amberSelected() throws IOException {

        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        File f = new File("config.properties");
        output = new FileOutputStream("config.properties");
        properties.setProperty("TColor", "4");
        properties.store(output, null);

        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int theme = Integer.parseInt(properties.getProperty("TMode"));
            if(theme == 1 ){
                output = new FileOutputStream("config.properties");
                properties.setProperty("TMode", "1");
                properties.store(output, null);
            }else {
                output = new FileOutputStream("config.properties");
                properties.setProperty("TMode", "2");
                properties.store(output, null);
            }

        }

        Parent root = FXMLLoader.load(getClass().getResource("../../../resources/view/SettingsPane.fxml"));
        Stage stage = (Stage) c4.getScene().getWindow();

        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){
                stage.setWidth(1920);
                stage.setHeight(1080);
                stage.setFullScreen(true);
            }
            else if(width == 1600 ){
                stage.setWidth(1600);
                stage.setHeight(900);
            }
            else if(width == 1280 ){
                stage.setWidth(1280);
                stage.setHeight(720);
            }

        }

        stage.getScene().setRoot(root);

        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }

    }

    @FXML
    private void x1280Selected() throws IOException {

        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        output = new FileOutputStream("config.properties");
        properties.setProperty("resolution", "1280x720");
        properties.setProperty("fullScreen", "false");
        properties.setProperty("width", "1280");
        properties.setProperty("height", "720");
        properties.store(output, null);

        Parent root = FXMLLoader.load(getClass().getResource("../../../resources/view/SettingsPane.fxml"));
        Stage stage = (Stage) b2.getScene().getWindow();

        stage.setWidth(1280);
        stage.setHeight(720);
        stage.getScene().setRoot(root);
        stage.setFullScreen(false);

        File f = new File("config.properties");
        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }

    }
    @FXML
    private void x1600Selected() throws IOException {

        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        output = new FileOutputStream("config.properties");
        properties.setProperty("resolution", "1600x900");
        properties.setProperty("fullScreen", "false");
        properties.setProperty("width", "1600");
        properties.setProperty("height", "900");
        properties.store(output, null);

        Parent root = FXMLLoader.load(getClass().getResource("../../../resources/view/SettingsPane.fxml"));
        Stage stage = (Stage) b2.getScene().getWindow();

        stage.setWidth(1600);
        stage.setHeight(900);
        stage.getScene().setRoot(root);
        stage.setFullScreen(false);

        File f = new File("config.properties");
        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }

    }
    @FXML
    private void fullScreenSelected() throws IOException {

        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        output = new FileOutputStream("config.properties");
        properties.setProperty("fullScreen", "true");
        properties.setProperty("width", "999");
        properties.setProperty("height", "999");
        properties.setProperty("resolution", "FullScreen");
        properties.store(output, null);

        Parent root = FXMLLoader.load(getClass().getResource("../../../resources/view/SettingsPane.fxml"));
        Stage stage = (Stage) b3.getScene().getWindow();
        stage.setWidth(1920);
        stage.setHeight(1080);
        stage.setFullScreen(true);
        stage.getScene().setRoot(root);

        File f = new File("config.properties");
        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }

    }

}
