package main.javafx.controllers.mainmenu;

import javafx.animation.FadeTransition;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.effect.BlurType;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.effect.InnerShadow;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;
import main.javafx.util.SvgLoader;
import main.javafx.util.SvgStyleTools;

import java.io.*;
import java.util.Locale;
import java.util.Objects;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class MainMenu {

    @FXML
    private Button exit_btn,highScore_btn,light,dark;

    @FXML
    private AnchorPane mainMenu;

    @FXML
    private BorderPane Panel1,ex;

    @FXML
    private VBox labelPanel,ex1;

    @FXML
    private HBox Panelex;

    @FXML
    private AnchorPane Panel2;

    @FXML
    private Button playMulti_btn;
    @FXML
    private Button playSingle_btn;
    @FXML
    private Button option_btn;

    @FXML
    private Label l1,l2,l3,t1,t2,bt1,bt2;

    private double xOffset = 0;
    private double yOffset = 0;
    private Properties properties = new Properties();
    private Properties properties2 = new Properties();
    private Properties properties3 = new Properties();
    private OutputStream output = null;
    private OutputStream output2 = null;
    private OutputStream output3 = null;
    private MediaPlayer mediaPlayer;

    final SvgLoader loader = new SvgLoader();

    DropShadow effectBG_DropShadowADD,effectBG_DropShadow,effectC_DropShadowADD,effectC_DropShadow,effect_BGPANEL;

    String color,color2;
    InnerShadow effectBG_InnerShadowADD,effectBG_InnerShadow,effectC_InnerShadowADD,effectC_InnerShadow,effect_BGPANELLABEL,effect_BGPANELLABELADD;
    InputStream svgFileExitButton,svgFileExitButton_Hover,svgFileHighScore,svgFileHighScore_Hover,svgFileOption,svgFileOption_Hover,svgFilePlayMulti,svgFilePlayMulti_Hover,svgFilePlaySingle,svgFilePlaySingle_Hover;

    public MainMenu(){
        Media buttonSound = new Media(new File("src/main/resources/Sounds/buttonSound.wav").toURI().toString());
        mediaPlayer = new MediaPlayer(buttonSound);
    }

    @FXML
    private void initialize() throws IOException{
        File f = new File("config.properties");
        File f2 =new File("score.properties");
        File f3 =new File("gamemode.properties");

        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            int theme = Integer.parseInt(properties.getProperty("TMode"));
            int tColor = Integer.parseInt(properties.getProperty("TColor"));

            if (width == 999) {

                exit_btn.setPrefSize(64, 64);
                option_btn.setPrefSize(64, 64);

                playSingle_btn.setPrefSize(128, 128);
                playMulti_btn.setPrefSize(128, 128);
                highScore_btn.setPrefSize(128, 128);

                labelPanel.setSpacing(64);

                if (theme == 1) {

                    color = "#f3f5f7";

                    if (tColor == 1) {

                        color2 = "#007aff";

                        t1.setTextFill(Color.web(color2));
                        t2.setTextFill(Color.web(color2));

                        exit_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 0 0 0;");
                        Panel2.setStyle("-fx-background-color: " + color2 + ";");
                        option_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");

                    } else if (tColor == 2) {

                        color2 = "#fff44f";

                        t1.setTextFill(Color.web(color2));
                        t2.setTextFill(Color.web(color2));

                        exit_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 0 0 0;");
                        Panel2.setStyle("-fx-background-color: " + color2 + ";");
                        option_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");

                    } else if (tColor == 3) {

                        color2 = "#00c853";

                        t1.setTextFill(Color.web(color2));
                        t2.setTextFill(Color.web(color2));

                        exit_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 0 0 0;");
                        Panel2.setStyle("-fx-background-color: " + color2 + ";");
                        option_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");

                    } else if (tColor == 4) {

                        color2 = "#d50000";

                        t1.setTextFill(Color.web(color2));
                        t2.setTextFill(Color.web(color2));

                        exit_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 0 0 0;");
                        Panel2.setStyle("-fx-background-color: " + color2 + ";");
                        option_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");

                    }

                    //LABEL
                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));
                    l3.setTextFill(Color.web(color));

                    //PANEL
                    Panel1.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 0 36 36 0;");

                    //BUTTON

                    playSingle_btn.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 50%;");
                    playMulti_btn.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 50%;");
                    highScore_btn.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 50%;");

                }
                else if (theme == 2) {

                    color = "#121212";

                    if (tColor == 1) {

                        color2 = "#004fcb";

                        t1.setTextFill(Color.web(color2));
                        t2.setTextFill(Color.web(color2));

                        exit_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 0 0 0;");
                        Panel2.setStyle("-fx-background-color: " + color2 + ";");
                        option_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");

                    } else if (tColor == 2) {

                        color2 = "#c9c208";

                        t1.setTextFill(Color.web(color2));
                        t2.setTextFill(Color.web(color2));

                        exit_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 0 0 0;");
                        Panel2.setStyle("-fx-background-color: " + color2 + ";");
                        option_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");

                    } else if (tColor == 3) {

                        color2 = "#006500";

                        t1.setTextFill(Color.web(color2));
                        t2.setTextFill(Color.web(color2));

                        exit_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 0 0 0;");
                        Panel2.setStyle("-fx-background-color: " + color2 + ";");
                        option_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");

                    } else if (tColor == 4) {

                        color2 = "#9b0000";

                        t1.setTextFill(Color.web(color2));
                        t2.setTextFill(Color.web(color2));

                        exit_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 0 0 0;");
                        Panel2.setStyle("-fx-background-color: " + color2 + ";");
                        option_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");

                    }

                    //LABEL
                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));
                    l3.setTextFill(Color.web(color));

                    //PANEL
                    Panel1.setStyle("-fx-background-color: #181818; -fx-background-radius: 0 36 36 0;");

                    //BUTTON

                    playSingle_btn.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 50%;");
                    playMulti_btn.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 50%;");
                    highScore_btn.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 50%;");

                }

            }
            else if (width == 1600) {

                exit_btn.setPrefSize(64, 64);
                option_btn.setPrefSize(64, 64);

                playSingle_btn.setPrefSize(128, 128);
                playMulti_btn.setPrefSize(128, 128);
                highScore_btn.setPrefSize(128, 128);

                labelPanel.setSpacing(64);

                if (theme == 1) {

                    color = "#f3f5f7";

                    if (tColor == 1) {

                        color2 = "#007aff";

                        t1.setTextFill(Color.web(color2));
                        t2.setTextFill(Color.web(color2));

                        exit_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 0 36 0;");
                        Panel2.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        option_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");

                    } else if (tColor == 2) {

                        color2 = "#fff44f";

                        t1.setTextFill(Color.web(color2));
                        t2.setTextFill(Color.web(color2));

                        exit_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 0 36 0;");
                        Panel2.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        option_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");

                    } else if (tColor == 3) {

                        color2 = "#00c853";

                        t1.setTextFill(Color.web(color2));
                        t2.setTextFill(Color.web(color2));

                        exit_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 0 36 0;");
                        Panel2.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        option_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");

                    } else if (tColor == 4) {

                        color2 = "#d50000";

                        t1.setTextFill(Color.web(color2));
                        t2.setTextFill(Color.web(color2));

                        exit_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 0 36 0;");
                        Panel2.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        option_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");

                    }

                    //LABEL
                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));
                    l3.setTextFill(Color.web(color));

                    //PANEL
                    Panel1.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 34 36 36 34;");

                    //BUTTON

                    playSingle_btn.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 50%;");
                    playMulti_btn.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 50%;");
                    highScore_btn.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 50%;");

                }
                else if (theme == 2) {

                    color = "#121212";

                    if (tColor == 1) {

                        color2 = "#004fcb";

                        t1.setTextFill(Color.web(color2));
                        t2.setTextFill(Color.web(color2));

                        exit_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 0 36 0;");
                        Panel2.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        option_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");

                    }
                    else if (tColor == 2) {

                        color2 = "#c9c208";

                        t1.setTextFill(Color.web(color2));
                        t2.setTextFill(Color.web(color2));

                        exit_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 0 36 0;");
                        Panel2.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        option_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");

                    }
                    else if (tColor == 3) {

                        color2 = "#006500";

                        t1.setTextFill(Color.web(color2));
                        t2.setTextFill(Color.web(color2));

                        exit_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 0 36 0;");
                        Panel2.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        option_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");

                    }
                    else if (tColor == 4) {

                        color2 = "#9b0000";

                        t1.setTextFill(Color.web(color2));
                        t2.setTextFill(Color.web(color2));

                        exit_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 0 36 0;");
                        Panel2.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        option_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");

                    }

                    //LABEL
                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));
                    l3.setTextFill(Color.web(color));

                    //PANEL
                    Panel1.setStyle("-fx-background-color: #181818; -fx-background-radius: 34 36 36 34;");

                    //BUTTON

                    playSingle_btn.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 50%;");
                    playMulti_btn.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 50%;");
                    highScore_btn.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 50%;");

                }

            }
            else if (width == 1280) {

                if (theme == 1) {

                    color = "#f3f5f7";

                    if (tColor == 1) {

                        color2 = "#007aff";

                        t1.setTextFill(Color.web(color2));
                        t2.setTextFill(Color.web(color2));

                        exit_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 0 36 0;");
                        Panel2.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        option_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");

                    } else if (tColor == 2) {

                        color2 = "#fff44f";

                        t1.setTextFill(Color.web(color2));
                        t2.setTextFill(Color.web(color2));

                        exit_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 0 36 0;");
                        Panel2.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        option_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");

                    } else if (tColor == 3) {

                        color2 = "#00c853";

                        t1.setTextFill(Color.web(color2));
                        t2.setTextFill(Color.web(color2));

                        exit_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 0 36 0;");
                        Panel2.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        option_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");

                    } else if (tColor == 4) {

                        color2 = "#d50000";

                        t1.setTextFill(Color.web(color2));
                        t2.setTextFill(Color.web(color2));

                        exit_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 0 36 0;");
                        Panel2.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        option_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");

                    }

                    //LABEL
                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));
                    l3.setTextFill(Color.web(color));

                    //PANEL
                    Panel1.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 34 36 36 34;");

                    //BUTTON

                    playSingle_btn.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 50%;");
                    playMulti_btn.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 50%;");
                    highScore_btn.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 50%;");

                }
                else if (theme == 2) {

                    color = "#121212";

                    if (tColor == 1) {

                        color2 = "#004fcb";

                        t1.setTextFill(Color.web(color2));
                        t2.setTextFill(Color.web(color2));

                        exit_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 0 36 0;");
                        Panel2.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        option_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");

                    }
                    else if (tColor == 2) {

                        color2 = "#c9c208";

                        t1.setTextFill(Color.web(color2));
                        t2.setTextFill(Color.web(color2));

                        exit_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 0 36 0;");
                        Panel2.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        option_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");

                    }
                    else if (tColor == 3) {

                        color2 = "#006500";

                        t1.setTextFill(Color.web(color2));
                        t2.setTextFill(Color.web(color2));

                        exit_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 0 36 0;");
                        Panel2.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        option_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");

                    }
                    else if (tColor == 4) {

                        color2 = "#9b0000";

                        t1.setTextFill(Color.web(color2));
                        t2.setTextFill(Color.web(color2));

                        exit_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");
                        Panelex.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 0 36 0;");
                        Panel2.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 36 36 36 36;");
                        option_btn.setStyle("-fx-background-color: " + color2 + "; -fx-background-radius: 50%;");

                    }

                    //LABEL
                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));
                    l3.setTextFill(Color.web(color));

                    //PANEL
                    Panel1.setStyle("-fx-background-color: #181818; -fx-background-radius: 34 36 36 34;");

                    //BUTTON

                    playSingle_btn.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 50%;");
                    playMulti_btn.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 50%;");
                    highScore_btn.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 50%;");

                }

            }
        }
        else{
            output = new FileOutputStream("config.properties");
            properties.setProperty("width","1280");
            properties.setProperty("height","720");
            properties.setProperty("resolution", "1280x720");
            properties.setProperty("fullScreen","false");
            properties.setProperty("sound","enabled");
            properties.setProperty("TMode","1");
            properties.setProperty("TColor","1");
            properties.setProperty("MenuSelected","1");
            properties.store(output,null);

        }

        if(f2.exists()){
            InputStream input2 = new FileInputStream("score.properties");
            properties2.load(input2);
        }
        else{
            OutputStream output2 = new FileOutputStream("score.properties");
            properties2.setProperty("MultiplayerWins1","0");
            properties2.setProperty("MultiplayerWins2","0");
            properties2.setProperty("MultiplayerWins3","0");
            properties2.setProperty("MultiplayerWins4","0");
            properties2.setProperty("SingleModeHighScore1","0");
            properties2.setProperty("SingleModeHighScore2","0");
            properties2.setProperty("SingleModeHighScore3","0");
            properties2.setProperty("SingleModeHighScore4","0");
            properties2.store(output2,null);
        }

        if(f3.exists()){
            output3 = new FileOutputStream("gamemode.properties");
            properties3.setProperty("RMode","0");
            properties3.setProperty("RSelected","0");
            properties3.setProperty("TSelected","0");
            properties3.setProperty("TFSelected","0");
            properties3.setProperty("TBSelected","0");
            properties3.setProperty("PSelected","0");
            properties3.setProperty("GSelected","0");
            properties3.store(output3,null);

            InputStream input3 = new FileInputStream("gamemode.properties");
            properties3.load(input3);
        }
        else{
            output3 = new FileOutputStream("gamemode.properties");
            properties3.setProperty("RMode","0");
            properties3.setProperty("RSelected","0");
            properties3.setProperty("TSelected","0");
            properties3.setProperty("TFSelected","0");
            properties3.setProperty("TBSelected","0");
            properties3.setProperty("PSelected","0");
            properties3.setProperty("GSelected","0");
            properties3.store(output3,null);
        }

        themeHandler();

    }

    private void themeHandler() throws IOException {

        ex1.setVisible(false);
        Panel1.setVisible(false);

        FadeTransition fadeIn = new FadeTransition();//exit_btn
        FadeTransition fadeIn2 = new FadeTransition();//option
        FadeTransition fadeIn3 = new FadeTransition();//bgpanel
        FadeTransition fadeIn4 = new FadeTransition();//bl1
        FadeTransition fadeIn4_1 = new FadeTransition();//bl2
        FadeTransition fadeIn5 = new FadeTransition();//panel
        FadeTransition fadeIn6 = new FadeTransition();//s
        FadeTransition fadeIn6_1 = new FadeTransition();//m
        FadeTransition fadeIn6_2 = new FadeTransition();//h
        FadeTransition fadeIn7 = new FadeTransition();//l1
        FadeTransition fadeIn7_1 = new FadeTransition();//l2
        FadeTransition fadeIn7_2 = new FadeTransition();//l3
        FadeTransition fadeIn8 = new FadeTransition();//t1
        FadeTransition fadeIn8_1 = new FadeTransition();//t2

        FadeTransition fadeOut = new FadeTransition();//exit_btn
        FadeTransition fadeOut2 = new FadeTransition();//option
        FadeTransition fadeOut3 = new FadeTransition();//bgpanel
        FadeTransition fadeOut4 = new FadeTransition();//bl1
        FadeTransition fadeOut4_1 = new FadeTransition();//bl2
        FadeTransition fadeOut5 = new FadeTransition();//panel
        FadeTransition fadeOut6 = new FadeTransition();//s
        FadeTransition fadeOut6_1 = new FadeTransition();//m
        FadeTransition fadeOut6_2 = new FadeTransition();//h
        FadeTransition fadeOut7 = new FadeTransition();//l1
        FadeTransition fadeOut7_1 = new FadeTransition();//l2
        FadeTransition fadeOut7_2 = new FadeTransition();//l3
        FadeTransition fadeOut8 = new FadeTransition();//t1
        FadeTransition fadeOut8_1 = new FadeTransition();//t2

        fadeIn.setDuration(Duration.millis(500));
        fadeIn2.setDuration(Duration.millis(500));
        fadeIn3.setDuration(Duration.millis(500));
        fadeIn4.setDuration(Duration.millis(500));
        fadeIn4_1.setDuration(Duration.millis(500));
        fadeIn5.setDuration(Duration.millis(500));
        fadeIn6.setDuration(Duration.millis(500));
        fadeIn6_1.setDuration(Duration.millis(500));
        fadeIn6_2.setDuration(Duration.millis(500));
        fadeIn7.setDuration(Duration.millis(500));
        fadeIn7_1.setDuration(Duration.millis(500));
        fadeIn7_2.setDuration(Duration.millis(500));
        fadeIn8.setDuration(Duration.millis(500));
        fadeIn8_1.setDuration(Duration.millis(500));

        fadeOut.setDuration(Duration.millis(1));
        fadeOut2.setDuration(Duration.millis(500));
        fadeOut3.setDuration(Duration.millis(500));
        fadeOut4.setDuration(Duration.millis(500));
        fadeOut4_1.setDuration(Duration.millis(500));
        fadeOut5.setDuration(Duration.millis(500));
        fadeOut6.setDuration(Duration.millis(500));
        fadeOut6_1.setDuration(Duration.millis(500));
        fadeOut6_2.setDuration(Duration.millis(500));
        fadeOut7.setDuration(Duration.millis(500));
        fadeOut7_1.setDuration(Duration.millis(500));
        fadeOut7_2.setDuration(Duration.millis(500));
        fadeOut8.setDuration(Duration.millis(500));
        fadeOut8_1.setDuration(Duration.millis(500));

        fadeIn.setFromValue(0);
        fadeIn.setToValue(10);
        fadeIn2.setFromValue(0);
        fadeIn2.setToValue(10);
        fadeIn3.setFromValue(0);
        fadeIn3.setToValue(10);
        fadeIn4.setFromValue(0);
        fadeIn4.setToValue(10);
        fadeIn4_1.setFromValue(0);
        fadeIn4_1.setToValue(10);
        fadeIn5.setFromValue(0);
        fadeIn5.setToValue(10);
        fadeIn6.setFromValue(0);
        fadeIn6.setToValue(10);
        fadeIn6_1.setFromValue(0);
        fadeIn6_1.setToValue(10);
        fadeIn6_2.setFromValue(0);
        fadeIn6_2.setToValue(10);
        fadeIn7.setFromValue(0);
        fadeIn7.setToValue(10);
        fadeIn7_1.setFromValue(0);
        fadeIn7_1.setToValue(10);
        fadeIn7_2.setFromValue(0);
        fadeIn7_2.setToValue(10);
        fadeIn8.setFromValue(0);
        fadeIn8.setToValue(10);
        fadeIn8_1.setFromValue(0);
        fadeIn8_1.setToValue(10);

        fadeOut.setFromValue(10);
        fadeOut.setToValue(0);
        fadeOut2.setFromValue(10);
        fadeOut2.setToValue(0);
        fadeOut3.setFromValue(10);
        fadeOut3.setToValue(0);
        fadeOut4.setFromValue(10);
        fadeOut4.setToValue(0);
        fadeOut4_1.setFromValue(10);
        fadeOut4_1.setToValue(0);
        fadeOut5.setFromValue(10);
        fadeOut5.setToValue(0);
        fadeOut6.setFromValue(10);
        fadeOut6.setToValue(0);
        fadeOut6_1.setFromValue(10);
        fadeOut6_1.setToValue(0);
        fadeOut6_2.setFromValue(10);
        fadeOut6_2.setToValue(0);
        fadeOut7.setFromValue(10);
        fadeOut7.setToValue(0);
        fadeOut7_1.setFromValue(10);
        fadeOut7_1.setToValue(0);
        fadeOut7_2.setFromValue(10);
        fadeOut7_2.setToValue(0);
        fadeOut8.setFromValue(10);
        fadeOut8.setToValue(0);
        fadeOut8_1.setFromValue(10);
        fadeOut8_1.setToValue(0);

        fadeIn.setCycleCount(1);
        fadeIn.setCycleCount(1);
        fadeIn2.setCycleCount(1);
        fadeIn2.setCycleCount(1);
        fadeIn3.setCycleCount(1);
        fadeIn3.setCycleCount(1);
        fadeIn4.setCycleCount(1);
        fadeIn4.setCycleCount(1);
        fadeIn4_1.setCycleCount(1);
        fadeIn4_1.setCycleCount(1);
        fadeIn5.setCycleCount(1);
        fadeIn5.setCycleCount(1);
        fadeIn6.setCycleCount(1);
        fadeIn6.setCycleCount(1);
        fadeIn6_1.setCycleCount(1);
        fadeIn6_1.setCycleCount(1);
        fadeIn6_2.setCycleCount(1);
        fadeIn6_2.setCycleCount(1);
        fadeIn7.setCycleCount(1);
        fadeIn7.setCycleCount(1);
        fadeIn7_1.setCycleCount(1);
        fadeIn7_1.setCycleCount(1);
        fadeIn7_2.setCycleCount(1);
        fadeIn7_2.setCycleCount(1);
        fadeIn8.setCycleCount(1);
        fadeIn8.setCycleCount(1);
        fadeIn8_1.setCycleCount(1);
        fadeIn8_1.setCycleCount(1);

        fadeOut.setCycleCount(1);
        fadeOut.setCycleCount(1);
        fadeOut2.setCycleCount(1);
        fadeOut2.setCycleCount(1);
        fadeOut3.setCycleCount(1);
        fadeOut3.setCycleCount(1);
        fadeOut4.setCycleCount(1);
        fadeOut4.setCycleCount(1);
        fadeOut4_1.setCycleCount(1);
        fadeOut4_1.setCycleCount(1);
        fadeOut5.setCycleCount(1);
        fadeOut5.setCycleCount(1);
        fadeOut6.setCycleCount(1);
        fadeOut6.setCycleCount(1);
        fadeOut6_1.setCycleCount(1);
        fadeOut6_1.setCycleCount(1);
        fadeOut6_2.setCycleCount(1);
        fadeOut6_2.setCycleCount(1);
        fadeOut7.setCycleCount(1);
        fadeOut7.setCycleCount(1);
        fadeOut7_1.setCycleCount(1);
        fadeOut7_1.setCycleCount(1);
        fadeOut7_2.setCycleCount(1);
        fadeOut7_2.setCycleCount(1);
        fadeOut8.setCycleCount(1);
        fadeOut8.setCycleCount(1);
        fadeOut8_1.setCycleCount(1);
        fadeOut8_1.setCycleCount(1);

        fadeIn.setNode(exit_btn);//exit_btn
        fadeIn2.setNode(option_btn);//option
        fadeIn3.setNode(Panelex);//bgpanel
        fadeIn4.setNode(bt1);//bl1
        fadeIn4_1.setNode(bt2);//bl2
        fadeIn5.setNode(Panel1);//panel
        fadeIn6.setNode(playSingle_btn);//s
        fadeIn6_1.setNode(playMulti_btn);//m
        fadeIn6_2.setNode(highScore_btn);//h
        fadeIn7.setNode(l1);//l1
        fadeIn7_1.setNode(l2);//l2
        fadeIn7_2.setNode(l3);//l3
        fadeIn8.setNode(t1);//t1
        fadeIn8_1.setNode(t2);//t2

        fadeOut.setNode(exit_btn);//exit_btn
        fadeOut2.setNode(option_btn);//option
        fadeOut3.setNode(Panelex);//bgpanel
        fadeOut4.setNode(bt1);//bl1
        fadeOut4_1.setNode(bt2);//bl2
        fadeOut5.setNode(Panel1);//panel
        fadeOut6.setNode(playSingle_btn);//s
        fadeOut6_1.setNode(playMulti_btn);//m
        fadeOut6_2.setNode(highScore_btn);//h
        fadeOut7.setNode(l1);//l1
        fadeOut7_1.setNode(l2);//l2
        fadeOut7_2.setNode(l3);//l3
        fadeOut8.setNode(t1);//t1
        fadeOut8_1.setNode(t2);//t2

        ex.setVisible(true);
        mainMenu.setDisable(false);

        File f = new File("config.properties");
        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int theme = Integer.parseInt(properties.getProperty("TMode"));
            int tColor = Integer.parseInt(properties.getProperty("TColor"));
            int menuSelected = Integer.parseInt(properties.getProperty("MenuSelected"));

            if (theme == 1) {

                color = "#f3f5f7";

                effectBG_DropShadowADD = new DropShadow(BlurType.GAUSSIAN, Color.rgb(206,207,210), 36, 0, 9, 9);
                effectBG_DropShadow = new DropShadow(BlurType.GAUSSIAN, Color.rgb(255,255,255), 18, 0, -9, -9);
                effectBG_DropShadow.setInput(effectBG_DropShadowADD);

                effectBG_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(206,207,210), 18, 0, 9, 9);
                effectBG_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(255,255,255), 18, 0, -9, -9);
                effectBG_InnerShadow.setInput(effectBG_InnerShadowADD);

                if (tColor == 1) {

                    color2 = "#007aff";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,104,217), 18, 0, 9, 9);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,140,255), 18, 0, -9, -9);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,104,217), 18, 0, 9, 9);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,140,255), 18, 0, -9, -9);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    effect_BGPANEL = new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,140,255), 40, 0, -20, -20);

                    effect_BGPANELLABELADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,104,217), 9, 0, 2,2);
                    effect_BGPANELLABEL = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,140,255), 9, 0, -2,-2);
                    effect_BGPANELLABEL.setInput(effect_BGPANELLABELADD);

                    svgFileExitButton = getClass().getResourceAsStream("../../../resources/svg/delete/delete.svg");
                    svgFileExitButton_Hover = getClass().getResourceAsStream("../../../resources/svg/delete/delete_blue.svg");

                    svgFileHighScore = getClass().getResourceAsStream("../../../resources/svg/podium/podium.svg");
                    svgFileHighScore_Hover = getClass().getResourceAsStream("../../../resources/svg/podium/podium_blue.svg");

                    svgFileOption = getClass().getResourceAsStream("../../../resources/svg/settings.svg");
                    svgFileOption_Hover = getClass().getResourceAsStream("../../../resources/svg/settings_dblue.svg");

                    svgFilePlayMulti = getClass().getResourceAsStream("../../../resources/svg/group/group.svg");
                    svgFilePlayMulti_Hover = getClass().getResourceAsStream("../../../resources/svg/group/group_blue.svg");

                    svgFilePlaySingle = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlaySingle_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");

                    Group svgImageExitButton = loader.loadSvg(svgFileExitButton);
                    Group svgImageExitButton_Hover = loader.loadSvg(svgFileExitButton_Hover);

                    Group svgImageHighScore = loader.loadSvg(svgFileHighScore);
                    Group svgImageHighScore_Hover = loader.loadSvg(svgFileHighScore_Hover);

                    Group svgImageOption = loader.loadSvg(svgFileOption);
                    Group svgImageOption_Hover = loader.loadSvg(svgFileOption_Hover);

                    Group svgImagePlayMulti = loader.loadSvg(svgFilePlayMulti);
                    Group svgImagePlayMulti_Hover = loader.loadSvg(svgFilePlayMulti_Hover);

                    Group svgImagePlaySingle = loader.loadSvg(svgFilePlaySingle);
                    Group svgImagePlaySingle_Hover = loader.loadSvg(svgFilePlaySingle_Hover);

                    svgImageExitButton.setScaleX(.03);
                    svgImageExitButton.setScaleY(.03);
                    svgImageExitButton_Hover.setScaleX(.03);
                    svgImageExitButton_Hover.setScaleY(.03);

                    svgImageHighScore.setScaleX(.06);
                    svgImageHighScore.setScaleY(.06);
                    svgImageHighScore_Hover.setScaleX(.06);
                    svgImageHighScore_Hover.setScaleY(.06);

                    svgImageOption.setScaleX(.04);
                    svgImageOption.setScaleY(.04);
                    svgImageOption_Hover.setScaleX(.04);
                    svgImageOption_Hover.setScaleY(.04);

                    svgImagePlayMulti.setScaleX(.1);
                    svgImagePlayMulti.setScaleY(.1);
                    svgImagePlayMulti_Hover.setScaleX(.1);
                    svgImagePlayMulti_Hover.setScaleY(.1);

                    svgImagePlaySingle.setScaleX(.06);
                    svgImagePlaySingle.setScaleY(.06);
                    svgImagePlaySingle_Hover.setScaleX(.06);
                    svgImagePlaySingle_Hover.setScaleY(.06);

                    Group svgIconExitButton = new Group(svgImageExitButton);
                    Group svgIconExitButton_Hover = new Group(svgImageExitButton_Hover);

                    Group svgIconHighScore = new Group(svgImageHighScore);
                    Group svgIconHighScore_Hover = new Group(svgImageHighScore_Hover);

                    Group svgIconOption = new Group(svgImageOption);
                    Group svgIconOption_Hover = new Group(svgImageOption_Hover);

                    Group svgIconPlayMulti = new Group(svgImagePlayMulti);
                    Group svgIconPlayMulti_Hover = new Group(svgImagePlayMulti_Hover);

                    Group svgIconPlaySingle = new Group(svgImagePlaySingle);
                    Group svgIconPlaySingle_Hover = new Group(svgImagePlaySingle_Hover);

                    exit_btn.setGraphic(svgIconExitButton);
                    highScore_btn.setGraphic(svgIconHighScore);
                    option_btn.setGraphic(svgIconOption);
                    playMulti_btn.setGraphic(svgIconPlayMulti);
                    playSingle_btn.setGraphic(svgIconPlaySingle);

                    Panelex.setEffect(effect_BGPANEL);

                    bt1.setEffect(effect_BGPANELLABEL);
                    bt2.setEffect(effect_BGPANELLABEL);
                    bt1.setTextFill(Color.web(color2));
                    bt2.setTextFill(Color.web(color2));

                    highScore_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        highScore_btn.setGraphic(svgIconHighScore_Hover);
                        highScore_btn.setEffect(effectBG_DropShadow);
                        exit_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        fadeIn7_2.play();

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l3.setEffect(effectC_DropShadow);
                        l3.setVisible(true);

                        highScore_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> fadeIn7_2.stop());
                        highScore_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e1 -> fadeIn7_2.stop());

                    });
                    highScore_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        highScore_btn.setGraphic(svgIconHighScore);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        fadeOut7_2.play();

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l3.setEffect(null);
                        l3.setVisible(false);

                        highScore_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> fadeOut7_2.stop());

                    });
                    highScore_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.setDuration(Duration.millis(1));
                        fadeOut2.setDuration(Duration.millis(1));
                        fadeOut3.setDuration(Duration.millis(200));
                        fadeOut5.setDuration(Duration.millis(200));
                        fadeOut6.setDuration(Duration.millis(200));
                        fadeOut6_1.setDuration(Duration.millis(200));
                        fadeOut6_2.setDuration(Duration.millis(200));
                        fadeOut7_2.setDuration(Duration.millis(200));

                        fadeOut.play();//exit
                        fadeOut2.play();//op
                        fadeOut3.play();//bgpanel
                        fadeOut7_2.play();//l3
                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        highScore_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.stop();//exit
                            fadeOut2.stop();//op
                            fadeOut3.stop();//bgpanel

                            fadeOut7_2.stop();//l3
                            fadeOut5.stop();//panel
                            fadeOut6.stop();//s
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                            fadeOut.setDuration(Duration.millis(1));
                            fadeOut2.setDuration(Duration.millis(500));
                            fadeOut3.setDuration(Duration.millis(500));
                            fadeOut5.setDuration(Duration.millis(500));
                            fadeOut6.setDuration(Duration.millis(500));
                            fadeOut6_1.setDuration(Duration.millis(500));
                            fadeOut6_2.setDuration(Duration.millis(500));
                            fadeOut7_2.setDuration(Duration.millis(500));

                        });

                    });
                    highScore_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {
                        try {
                            highScore_Clicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    playMulti_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        playMulti_btn.setGraphic(svgIconPlayMulti_Hover);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(effectBG_DropShadow);
                        playSingle_btn.setEffect(null);

                        fadeIn7_1.play();

                        l1.setEffect(null);
                        l2.setEffect(effectC_DropShadow);
                        l2.setVisible(true);
                        l3.setEffect(null);

                        playMulti_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> fadeIn7_1.stop());
                        playMulti_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e1 -> fadeIn7_1.stop());

                    });
                    playMulti_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        playMulti_btn.setGraphic(svgIconPlayMulti);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        fadeOut7_1.play();

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l2.setVisible(false);
                        l3.setEffect(null);

                        playMulti_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> fadeOut7_1.stop());



                    });
                    playMulti_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.setDuration(Duration.millis(1));
                        fadeOut2.setDuration(Duration.millis(1));
                        fadeOut3.setDuration(Duration.millis(200));
                        fadeOut5.setDuration(Duration.millis(200));
                        fadeOut6.setDuration(Duration.millis(200));
                        fadeOut6_1.setDuration(Duration.millis(200));
                        fadeOut6_2.setDuration(Duration.millis(200));
                        fadeOut7_1.setDuration(Duration.millis(200));

                        fadeOut.play();//exit_btn
                        fadeOut2.play();//exit_btn
                        fadeOut3.play();//bgpanel
                        fadeOut7_1.play();//l2
                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        playMulti_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.stop();//exit_btn
                            fadeOut2.stop();//exit_btn
                            fadeOut3.stop();//bgpanel
                            fadeOut7_1.stop();//l2
                            fadeOut5.stop();//panel
                            fadeOut6.stop();//s
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                            fadeOut.setDuration(Duration.millis(1));
                            fadeOut2.setDuration(Duration.millis(500));
                            fadeOut3.setDuration(Duration.millis(500));
                            fadeOut5.setDuration(Duration.millis(500));
                            fadeOut6.setDuration(Duration.millis(500));
                            fadeOut6_1.setDuration(Duration.millis(500));
                            fadeOut6_2.setDuration(Duration.millis(500));
                            fadeOut7_1.setDuration(Duration.millis(500));

                        });

                    });
                    playMulti_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {playMulti_Clicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    });

                    playSingle_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        playSingle_btn.setGraphic(svgIconPlaySingle_Hover);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(effectBG_DropShadow);

                        fadeIn7.play();

                        l1.setEffect(effectC_DropShadow);
                        l1.setVisible(true);
                        l2.setEffect(null);
                        l3.setEffect(null);

                        playSingle_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> fadeIn7.stop());
                        playSingle_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e1 -> fadeIn7.stop());

                    });
                    playSingle_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        playSingle_btn.setGraphic(svgIconPlaySingle);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        fadeOut7.play();

                        l1.setEffect(null);
                        l1.setVisible(false);
                        l2.setEffect(null);
                        l3.setEffect(null);

                        playSingle_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> fadeOut7.stop());

                    });
                    playSingle_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.setDuration(Duration.millis(1));
                        fadeOut2.setDuration(Duration.millis(1));
                        fadeOut3.setDuration(Duration.millis(200));
                        fadeOut5.setDuration(Duration.millis(200));
                        fadeOut6.setDuration(Duration.millis(200));
                        fadeOut6_1.setDuration(Duration.millis(200));
                        fadeOut6_2.setDuration(Duration.millis(200));
                        fadeOut7.setDuration(Duration.millis(200));

                        fadeOut.play();//exit
                        fadeOut2.play();//op
                        fadeOut3.play();//bgpanel
                        fadeOut7.play();//l1
                        fadeOut6.play();//s
                        fadeOut5.play();//panel
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        playSingle_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.stop();//exit
                            fadeOut2.stop();//op
                            fadeIn3.stop();//bgpanel
                            fadeOut7.stop();//l1
                            fadeOut6.stop();//s
                            fadeOut5.stop();//panel
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                            fadeOut.setDuration(Duration.millis(1));
                            fadeOut2.setDuration(Duration.millis(500));
                            fadeOut3.setDuration(Duration.millis(500));
                            fadeOut5.setDuration(Duration.millis(500));
                            fadeOut6.setDuration(Duration.millis(500));
                            fadeOut6_1.setDuration(Duration.millis(500));
                            fadeOut6_2.setDuration(Duration.millis(500));
                            fadeOut7.setDuration(Duration.millis(500));

                        });

                    });
                    playSingle_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {playSingle_Clicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    });

                    mainMenu.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        ex1.setVisible(true);
                        Panel1.setVisible(true);

                        fadeIn.play();//exit_btn
                        exit_btn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");

                        fadeOut4.play();//bl1
                        fadeOut4_1.play();//bl2
                        fadeOut3.play();//bgpanel

                        fadeIn5.play();//panel
                        fadeIn6.play();//s
                        fadeIn6_1.play();//m
                        fadeIn6_2.play();//h

                        mainMenu.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> {

                            fadeIn.stop();//exit_btn
                            fadeOut4.stop();//bl1
                            fadeOut4_1.stop();//bl2
                            fadeOut3.stop();//bgpanel

                            fadeIn5.stop();//panel
                            fadeIn6.stop();//s
                            fadeIn6_1.stop();//m
                            fadeIn6_2.stop();//h

                        });

                    });
                    mainMenu.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        fadeIn.play();//exit_btn
                        fadeIn4.play();//bl1
                        fadeIn4_1.play();//bl2
                        fadeIn3.play();//bgpanel

                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        exit_btn.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                        mainMenu.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> {

                            fadeIn.stop();//exit_btn
                            fadeIn4.stop();//bl1
                            fadeIn4_1.stop();//bl2
                            fadeIn3.stop();//bgpanel

                            fadeOut5.stop();//panel
                            fadeOut6.stop();//s
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                        });

                    });

                    option_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        option_btn.setGraphic(svgIconOption_Hover);
                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(effectC_InnerShadow);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l3.setEffect(null);
                    });
                    option_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        option_btn.setGraphic(svgIconOption);
                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l3.setEffect(null);
                    });
                    option_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.setDuration(Duration.millis(1));
                        fadeOut2.setDuration(Duration.millis(1));
                        fadeOut5.setDuration(Duration.millis(200));
                        fadeOut6.setDuration(Duration.millis(200));
                        fadeOut6_1.setDuration(Duration.millis(200));
                        fadeOut6_2.setDuration(Duration.millis(200));

                        fadeOut.play();//exit_btn
                        fadeOut2.play();//option
                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        option_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.setDuration(Duration.millis(1));
                            fadeOut2.setDuration(Duration.millis(1));
                            fadeOut5.setDuration(Duration.millis(500));
                            fadeOut6.setDuration(Duration.millis(500));
                            fadeOut6_1.setDuration(Duration.millis(500));
                            fadeOut6_2.setDuration(Duration.millis(500));

                            fadeOut.stop();//exit_btn
                            fadeOut2.stop();//option
                            fadeOut5.stop();//panel
                            fadeOut6.stop();//s
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                        });
                    });
                    option_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            settingsClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    });

                    exit_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        exit_btn.setGraphic(svgIconExitButton_Hover);

                        exit_btn.setEffect(effectC_DropShadow);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                    });
                    exit_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        exit_btn.setGraphic(svgIconExitButton);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                    });
                    exit_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut4.play();//bl1
                        fadeOut4_1.play();//bl2
                        fadeOut3.play();//bgpanel

                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        exit_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                        });

                    });

                }
                else if (tColor == 2) {

                    color2 = "#fff44f";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.web("#d9cf43"), 18, 0, 9, 9);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.web("#ffff5b"), 18, 0, -9, -9);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.web("#d9cf43"), 18, 0, 9, 9);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.web("#ffff5b"), 18, 0, -9, -9);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    effect_BGPANEL = new DropShadow(BlurType.GAUSSIAN, Color.web("#ffff5b"), 40, 0, -20, -20);

                    effect_BGPANELLABELADD = new InnerShadow(BlurType.GAUSSIAN, Color.web("#d9cf43"), 9, 0, 2,2);
                    effect_BGPANELLABEL = new InnerShadow(BlurType.GAUSSIAN,Color.web("#ffff5b"), 9, 0, -2,-2);
                    effect_BGPANELLABEL.setInput(effect_BGPANELLABELADD);

                    svgFileExitButton = getClass().getResourceAsStream("../../../resources/svg/delete/delete.svg");
                    svgFileExitButton_Hover = getClass().getResourceAsStream("../../../resources/svg/delete/delete_yellow.svg");

                    svgFileHighScore = getClass().getResourceAsStream("../../../resources/svg/podium/podium.svg");
                    svgFileHighScore_Hover = getClass().getResourceAsStream("../../../resources/svg/podium/podium_yellow.svg");

                    svgFileOption = getClass().getResourceAsStream("../../../resources/svg/settings.svg");
                    svgFileOption_Hover = getClass().getResourceAsStream("../../../resources/svg/settings_dyellow.svg");

                    svgFilePlayMulti = getClass().getResourceAsStream("../../../resources/svg/group/group.svg");
                    svgFilePlayMulti_Hover = getClass().getResourceAsStream("../../../resources/svg/group/group_yellow.svg");

                    svgFilePlaySingle = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlaySingle_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_yellow.svg");

                    Group svgImageExitButton = loader.loadSvg(svgFileExitButton);
                    Group svgImageExitButton_Hover = loader.loadSvg(svgFileExitButton_Hover);

                    Group svgImageHighScore = loader.loadSvg(svgFileHighScore);
                    Group svgImageHighScore_Hover = loader.loadSvg(svgFileHighScore_Hover);

                    Group svgImageOption = loader.loadSvg(svgFileOption);
                    Group svgImageOption_Hover = loader.loadSvg(svgFileOption_Hover);

                    Group svgImagePlayMulti = loader.loadSvg(svgFilePlayMulti);
                    Group svgImagePlayMulti_Hover = loader.loadSvg(svgFilePlayMulti_Hover);

                    Group svgImagePlaySingle = loader.loadSvg(svgFilePlaySingle);
                    Group svgImagePlaySingle_Hover = loader.loadSvg(svgFilePlaySingle_Hover);

                    svgImageExitButton.setScaleX(.03);
                    svgImageExitButton.setScaleY(.03);
                    svgImageExitButton_Hover.setScaleX(.03);
                    svgImageExitButton_Hover.setScaleY(.03);

                    svgImageHighScore.setScaleX(.06);
                    svgImageHighScore.setScaleY(.06);
                    svgImageHighScore_Hover.setScaleX(.06);
                    svgImageHighScore_Hover.setScaleY(.06);

                    svgImageOption.setScaleX(.04);
                    svgImageOption.setScaleY(.04);
                    svgImageOption_Hover.setScaleX(.04);
                    svgImageOption_Hover.setScaleY(.04);

                    svgImagePlayMulti.setScaleX(.1);
                    svgImagePlayMulti.setScaleY(.1);
                    svgImagePlayMulti_Hover.setScaleX(.1);
                    svgImagePlayMulti_Hover.setScaleY(.1);

                    svgImagePlaySingle.setScaleX(.06);
                    svgImagePlaySingle.setScaleY(.06);
                    svgImagePlaySingle_Hover.setScaleX(.06);
                    svgImagePlaySingle_Hover.setScaleY(.06);

                    Group svgIconExitButton = new Group(svgImageExitButton);
                    Group svgIconExitButton_Hover = new Group(svgImageExitButton_Hover);

                    Group svgIconHighScore = new Group(svgImageHighScore);
                    Group svgIconHighScore_Hover = new Group(svgImageHighScore_Hover);

                    Group svgIconOption = new Group(svgImageOption);
                    Group svgIconOption_Hover = new Group(svgImageOption_Hover);

                    Group svgIconPlayMulti = new Group(svgImagePlayMulti);
                    Group svgIconPlayMulti_Hover = new Group(svgImagePlayMulti_Hover);

                    Group svgIconPlaySingle = new Group(svgImagePlaySingle);
                    Group svgIconPlaySingle_Hover = new Group(svgImagePlaySingle_Hover);

                    exit_btn.setGraphic(svgIconExitButton);
                    highScore_btn.setGraphic(svgIconHighScore);
                    option_btn.setGraphic(svgIconOption);
                    playMulti_btn.setGraphic(svgIconPlayMulti);
                    playSingle_btn.setGraphic(svgIconPlaySingle);

                    Panelex.setEffect(effect_BGPANEL);

                    bt1.setEffect(effect_BGPANELLABEL);
                    bt2.setEffect(effect_BGPANELLABEL);
                    bt1.setTextFill(Color.web(color2));
                    bt2.setTextFill(Color.web(color2));

                    highScore_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        highScore_btn.setGraphic(svgIconHighScore_Hover);
                        highScore_btn.setEffect(effectBG_DropShadow);
                        exit_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        fadeIn7_2.play();

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l3.setEffect(effectC_DropShadow);
                        l3.setVisible(true);

                        highScore_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> fadeIn7_2.stop());
                        highScore_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e1 -> fadeIn7_2.stop());

                    });
                    highScore_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        highScore_btn.setGraphic(svgIconHighScore);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        fadeOut7_2.play();

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l3.setEffect(null);
                        l3.setVisible(false);

                        highScore_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> fadeOut7_2.stop());

                    });
                    highScore_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.setDuration(Duration.millis(1));
                        fadeOut2.setDuration(Duration.millis(1));
                        fadeOut3.setDuration(Duration.millis(200));
                        fadeOut5.setDuration(Duration.millis(200));
                        fadeOut6.setDuration(Duration.millis(200));
                        fadeOut6_1.setDuration(Duration.millis(200));
                        fadeOut6_2.setDuration(Duration.millis(200));
                        fadeOut7_2.setDuration(Duration.millis(200));

                        fadeOut.play();//exit
                        fadeOut2.play();//op
                        fadeOut3.play();//bgpanel
                        fadeOut7_2.play();//l3
                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        highScore_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.stop();//exit
                            fadeOut2.stop();//op
                            fadeOut3.stop();//bgpanel

                            fadeOut7_2.stop();//l3
                            fadeOut5.stop();//panel
                            fadeOut6.stop();//s
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                            fadeOut.setDuration(Duration.millis(1));
                            fadeOut2.setDuration(Duration.millis(500));
                            fadeOut3.setDuration(Duration.millis(500));
                            fadeOut5.setDuration(Duration.millis(500));
                            fadeOut6.setDuration(Duration.millis(500));
                            fadeOut6_1.setDuration(Duration.millis(500));
                            fadeOut6_2.setDuration(Duration.millis(500));
                            fadeOut7_2.setDuration(Duration.millis(500));

                        });

                    });
                    highScore_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            highScore_Clicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    });

                    playMulti_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        playMulti_btn.setGraphic(svgIconPlayMulti_Hover);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(effectBG_DropShadow);
                        playSingle_btn.setEffect(null);

                        fadeIn7_1.play();

                        l1.setEffect(null);
                        l2.setEffect(effectC_DropShadow);
                        l2.setVisible(true);
                        l3.setEffect(null);

                        playMulti_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> fadeIn7_1.stop());
                        playMulti_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e1 -> fadeIn7_1.stop());

                    });
                    playMulti_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        playMulti_btn.setGraphic(svgIconPlayMulti);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        fadeOut7_1.play();

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l2.setVisible(false);
                        l3.setEffect(null);

                        playMulti_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> fadeOut7_1.stop());



                    });
                    playMulti_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.setDuration(Duration.millis(1));
                        fadeOut2.setDuration(Duration.millis(1));
                        fadeOut3.setDuration(Duration.millis(200));
                        fadeOut5.setDuration(Duration.millis(200));
                        fadeOut6.setDuration(Duration.millis(200));
                        fadeOut6_1.setDuration(Duration.millis(200));
                        fadeOut6_2.setDuration(Duration.millis(200));
                        fadeOut7_1.setDuration(Duration.millis(200));

                        fadeOut.play();//exit_btn
                        fadeOut2.play();//exit_btn
                        fadeOut3.play();//bgpanel
                        fadeOut7_1.play();//l2
                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        playMulti_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.stop();//exit_btn
                            fadeOut2.stop();//exit_btn
                            fadeOut3.stop();//bgpanel
                            fadeOut7_1.stop();//l2
                            fadeOut5.stop();//panel
                            fadeOut6.stop();//s
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                            fadeOut.setDuration(Duration.millis(1));
                            fadeOut2.setDuration(Duration.millis(500));
                            fadeOut3.setDuration(Duration.millis(500));
                            fadeOut5.setDuration(Duration.millis(500));
                            fadeOut6.setDuration(Duration.millis(500));
                            fadeOut6_1.setDuration(Duration.millis(500));
                            fadeOut6_2.setDuration(Duration.millis(500));
                            fadeOut7_1.setDuration(Duration.millis(500));

                        });

                    });
                    playMulti_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {playMulti_Clicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    });

                    playSingle_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        playSingle_btn.setGraphic(svgIconPlaySingle_Hover);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(effectBG_DropShadow);

                        fadeIn7.play();

                        l1.setEffect(effectC_DropShadow);
                        l1.setVisible(true);
                        l2.setEffect(null);
                        l3.setEffect(null);

                        playSingle_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> fadeIn7.stop());
                        playSingle_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e1 -> fadeIn7.stop());

                    });
                    playSingle_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        playSingle_btn.setGraphic(svgIconPlaySingle);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        fadeOut7.play();

                        l1.setEffect(null);
                        l1.setVisible(false);
                        l2.setEffect(null);
                        l3.setEffect(null);

                        playSingle_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> fadeOut7.stop());

                    });
                    playSingle_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.setDuration(Duration.millis(1));
                        fadeOut2.setDuration(Duration.millis(1));
                        fadeOut3.setDuration(Duration.millis(200));
                        fadeOut5.setDuration(Duration.millis(200));
                        fadeOut6.setDuration(Duration.millis(200));
                        fadeOut6_1.setDuration(Duration.millis(200));
                        fadeOut6_2.setDuration(Duration.millis(200));
                        fadeOut7.setDuration(Duration.millis(200));

                        fadeOut.play();//exit
                        fadeOut2.play();//op
                        fadeOut3.play();//bgpanel
                        fadeOut7.play();//l1
                        fadeOut6.play();//s
                        fadeOut5.play();//panel
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        playSingle_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.stop();//exit
                            fadeOut2.stop();//op
                            fadeIn3.stop();//bgpanel
                            fadeOut7.stop();//l1
                            fadeOut6.stop();//s
                            fadeOut5.stop();//panel
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                            fadeOut.setDuration(Duration.millis(1));
                            fadeOut2.setDuration(Duration.millis(500));
                            fadeOut3.setDuration(Duration.millis(500));
                            fadeOut5.setDuration(Duration.millis(500));
                            fadeOut6.setDuration(Duration.millis(500));
                            fadeOut6_1.setDuration(Duration.millis(500));
                            fadeOut6_2.setDuration(Duration.millis(500));
                            fadeOut7.setDuration(Duration.millis(500));

                        });

                    });
                    playSingle_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {playSingle_Clicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    });

                    mainMenu.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        ex1.setVisible(true);
                        Panel1.setVisible(true);

                        fadeIn.play();//exit_btn
                        exit_btn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");

                        fadeOut4.play();//bl1
                        fadeOut4_1.play();//bl2
                        fadeOut3.play();//bgpanel

                        fadeIn5.play();//panel
                        fadeIn6.play();//s
                        fadeIn6_1.play();//m
                        fadeIn6_2.play();//h

                        mainMenu.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> {

                            fadeIn.stop();//exit_btn
                            fadeOut4.stop();//bl1
                            fadeOut4_1.stop();//bl2
                            fadeOut3.stop();//bgpanel

                            fadeIn5.stop();//panel
                            fadeIn6.stop();//s
                            fadeIn6_1.stop();//m
                            fadeIn6_2.stop();//h

                        });

                    });
                    mainMenu.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        fadeIn.play();//exit_btn
                        fadeIn4.play();//bl1
                        fadeIn4_1.play();//bl2
                        fadeIn3.play();//bgpanel

                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        exit_btn.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                        mainMenu.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> {

                            fadeIn.stop();//exit_btn
                            fadeIn4.stop();//bl1
                            fadeIn4_1.stop();//bl2
                            fadeIn3.stop();//bgpanel

                            fadeOut5.stop();//panel
                            fadeOut6.stop();//s
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                        });

                    });

                    option_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        option_btn.setGraphic(svgIconOption_Hover);
                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(effectC_InnerShadow);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l3.setEffect(null);
                    });
                    option_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        option_btn.setGraphic(svgIconOption);
                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l3.setEffect(null);
                    });
                    option_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.setDuration(Duration.millis(1));
                        fadeOut2.setDuration(Duration.millis(1));
                        fadeOut5.setDuration(Duration.millis(200));
                        fadeOut6.setDuration(Duration.millis(200));
                        fadeOut6_1.setDuration(Duration.millis(200));
                        fadeOut6_2.setDuration(Duration.millis(200));

                        fadeOut.play();//exit_btn
                        fadeOut2.play();//option
                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        option_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.setDuration(Duration.millis(1));
                            fadeOut2.setDuration(Duration.millis(1));
                            fadeOut5.setDuration(Duration.millis(500));
                            fadeOut6.setDuration(Duration.millis(500));
                            fadeOut6_1.setDuration(Duration.millis(500));
                            fadeOut6_2.setDuration(Duration.millis(500));

                            fadeOut.stop();//exit_btn
                            fadeOut2.stop();//option
                            fadeOut5.stop();//panel
                            fadeOut6.stop();//s
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                        });
                    });
                    option_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            settingsClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    });

                    exit_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        exit_btn.setGraphic(svgIconExitButton_Hover);

                        exit_btn.setEffect(effectC_DropShadow);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                    });
                    exit_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        exit_btn.setGraphic(svgIconExitButton);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                    });
                    exit_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut4.play();//bl1
                        fadeOut4_1.play();//bl2
                        fadeOut3.play();//bgpanel

                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        exit_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                        });

                    });


                }
                else if (tColor == 3) {

                    color2 = "#00c853";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,200,83), 18, 0, 9, 9);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,230,95), 18, 0, -9, -9);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,200,83), 18, 0, 9, 9);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,230,95), 18, 0, -9, -9);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    effect_BGPANEL = new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,230,95), 40, 0, -20, -20);

                    effect_BGPANELLABELADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,200,83), 9, 0, 2,2);
                    effect_BGPANELLABEL = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,230,95), 9, 0, -2,-2);
                    effect_BGPANELLABEL.setInput(effect_BGPANELLABELADD);

                    svgFileExitButton = getClass().getResourceAsStream("../../../resources/svg/delete/delete.svg");
                    svgFileExitButton_Hover = getClass().getResourceAsStream("../../../resources/svg/delete/delete_green.svg");

                    svgFileHighScore = getClass().getResourceAsStream("../../../resources/svg/podium/podium.svg");
                    svgFileHighScore_Hover = getClass().getResourceAsStream("../../../resources/svg/podium/podium_green.svg");

                    svgFileOption = getClass().getResourceAsStream("../../../resources/svg/settings.svg");
                    svgFileOption_Hover = getClass().getResourceAsStream("../../../resources/svg/settings_dgreen.svg");

                    svgFilePlayMulti = getClass().getResourceAsStream("../../../resources/svg/group/group.svg");
                    svgFilePlayMulti_Hover = getClass().getResourceAsStream("../../../resources/svg/group/group_green.svg");

                    svgFilePlaySingle = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlaySingle_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_green.svg");

                    Group svgImageExitButton = loader.loadSvg(svgFileExitButton);
                    Group svgImageExitButton_Hover = loader.loadSvg(svgFileExitButton_Hover);

                    Group svgImageHighScore = loader.loadSvg(svgFileHighScore);
                    Group svgImageHighScore_Hover = loader.loadSvg(svgFileHighScore_Hover);

                    Group svgImageOption = loader.loadSvg(svgFileOption);
                    Group svgImageOption_Hover = loader.loadSvg(svgFileOption_Hover);

                    Group svgImagePlayMulti = loader.loadSvg(svgFilePlayMulti);
                    Group svgImagePlayMulti_Hover = loader.loadSvg(svgFilePlayMulti_Hover);

                    Group svgImagePlaySingle = loader.loadSvg(svgFilePlaySingle);
                    Group svgImagePlaySingle_Hover = loader.loadSvg(svgFilePlaySingle_Hover);

                    svgImageExitButton.setScaleX(.03);
                    svgImageExitButton.setScaleY(.03);
                    svgImageExitButton_Hover.setScaleX(.03);
                    svgImageExitButton_Hover.setScaleY(.03);

                    svgImageHighScore.setScaleX(.06);
                    svgImageHighScore.setScaleY(.06);
                    svgImageHighScore_Hover.setScaleX(.06);
                    svgImageHighScore_Hover.setScaleY(.06);

                    svgImageOption.setScaleX(.04);
                    svgImageOption.setScaleY(.04);
                    svgImageOption_Hover.setScaleX(.04);
                    svgImageOption_Hover.setScaleY(.04);

                    svgImagePlayMulti.setScaleX(.1);
                    svgImagePlayMulti.setScaleY(.1);
                    svgImagePlayMulti_Hover.setScaleX(.1);
                    svgImagePlayMulti_Hover.setScaleY(.1);

                    svgImagePlaySingle.setScaleX(.06);
                    svgImagePlaySingle.setScaleY(.06);
                    svgImagePlaySingle_Hover.setScaleX(.06);
                    svgImagePlaySingle_Hover.setScaleY(.06);

                    Group svgIconExitButton = new Group(svgImageExitButton);
                    Group svgIconExitButton_Hover = new Group(svgImageExitButton_Hover);

                    Group svgIconHighScore = new Group(svgImageHighScore);
                    Group svgIconHighScore_Hover = new Group(svgImageHighScore_Hover);

                    Group svgIconOption = new Group(svgImageOption);
                    Group svgIconOption_Hover = new Group(svgImageOption_Hover);

                    Group svgIconPlayMulti = new Group(svgImagePlayMulti);
                    Group svgIconPlayMulti_Hover = new Group(svgImagePlayMulti_Hover);

                    Group svgIconPlaySingle = new Group(svgImagePlaySingle);
                    Group svgIconPlaySingle_Hover = new Group(svgImagePlaySingle_Hover);

                    exit_btn.setGraphic(svgIconExitButton);
                    highScore_btn.setGraphic(svgIconHighScore);
                    option_btn.setGraphic(svgIconOption);
                    playMulti_btn.setGraphic(svgIconPlayMulti);
                    playSingle_btn.setGraphic(svgIconPlaySingle);

                    Panelex.setEffect(effect_BGPANEL);

                    bt1.setEffect(effect_BGPANELLABEL);
                    bt2.setEffect(effect_BGPANELLABEL);
                    bt1.setTextFill(Color.web(color2));
                    bt2.setTextFill(Color.web(color2));

                    highScore_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        highScore_btn.setGraphic(svgIconHighScore_Hover);
                        highScore_btn.setEffect(effectBG_DropShadow);
                        exit_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        fadeIn7_2.play();

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l3.setEffect(effectC_DropShadow);
                        l3.setVisible(true);

                        highScore_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> fadeIn7_2.stop());
                        highScore_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e1 -> fadeIn7_2.stop());

                    });
                    highScore_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        highScore_btn.setGraphic(svgIconHighScore);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        fadeOut7_2.play();

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l3.setEffect(null);
                        l3.setVisible(false);

                        highScore_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> fadeOut7_2.stop());

                    });
                    highScore_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.setDuration(Duration.millis(1));
                        fadeOut2.setDuration(Duration.millis(1));
                        fadeOut3.setDuration(Duration.millis(200));
                        fadeOut5.setDuration(Duration.millis(200));
                        fadeOut6.setDuration(Duration.millis(200));
                        fadeOut6_1.setDuration(Duration.millis(200));
                        fadeOut6_2.setDuration(Duration.millis(200));
                        fadeOut7_2.setDuration(Duration.millis(200));

                        fadeOut.play();//exit
                        fadeOut2.play();//op
                        fadeOut3.play();//bgpanel
                        fadeOut7_2.play();//l3
                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        highScore_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.stop();//exit
                            fadeOut2.stop();//op
                            fadeOut3.stop();//bgpanel

                            fadeOut7_2.stop();//l3
                            fadeOut5.stop();//panel
                            fadeOut6.stop();//s
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                            fadeOut.setDuration(Duration.millis(1));
                            fadeOut2.setDuration(Duration.millis(500));
                            fadeOut3.setDuration(Duration.millis(500));
                            fadeOut5.setDuration(Duration.millis(500));
                            fadeOut6.setDuration(Duration.millis(500));
                            fadeOut6_1.setDuration(Duration.millis(500));
                            fadeOut6_2.setDuration(Duration.millis(500));
                            fadeOut7_2.setDuration(Duration.millis(500));

                        });

                    });
                    highScore_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            highScore_Clicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    });

                    playMulti_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        playMulti_btn.setGraphic(svgIconPlayMulti_Hover);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(effectBG_DropShadow);
                        playSingle_btn.setEffect(null);

                        fadeIn7_1.play();

                        l1.setEffect(null);
                        l2.setEffect(effectC_DropShadow);
                        l2.setVisible(true);
                        l3.setEffect(null);

                        playMulti_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> fadeIn7_1.stop());
                        playMulti_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e1 -> fadeIn7_1.stop());

                    });
                    playMulti_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        playMulti_btn.setGraphic(svgIconPlayMulti);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        fadeOut7_1.play();

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l2.setVisible(false);
                        l3.setEffect(null);

                        playMulti_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> fadeOut7_1.stop());



                    });
                    playMulti_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.setDuration(Duration.millis(1));
                        fadeOut2.setDuration(Duration.millis(1));
                        fadeOut3.setDuration(Duration.millis(200));
                        fadeOut5.setDuration(Duration.millis(200));
                        fadeOut6.setDuration(Duration.millis(200));
                        fadeOut6_1.setDuration(Duration.millis(200));
                        fadeOut6_2.setDuration(Duration.millis(200));
                        fadeOut7_1.setDuration(Duration.millis(200));

                        fadeOut.play();//exit_btn
                        fadeOut2.play();//exit_btn
                        fadeOut3.play();//bgpanel
                        fadeOut7_1.play();//l2
                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        playMulti_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.stop();//exit_btn
                            fadeOut2.stop();//exit_btn
                            fadeOut3.stop();//bgpanel
                            fadeOut7_1.stop();//l2
                            fadeOut5.stop();//panel
                            fadeOut6.stop();//s
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                            fadeOut.setDuration(Duration.millis(1));
                            fadeOut2.setDuration(Duration.millis(500));
                            fadeOut3.setDuration(Duration.millis(500));
                            fadeOut5.setDuration(Duration.millis(500));
                            fadeOut6.setDuration(Duration.millis(500));
                            fadeOut6_1.setDuration(Duration.millis(500));
                            fadeOut6_2.setDuration(Duration.millis(500));
                            fadeOut7_1.setDuration(Duration.millis(500));

                        });

                    });
                    playMulti_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {playMulti_Clicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    });

                    playSingle_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        playSingle_btn.setGraphic(svgIconPlaySingle_Hover);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(effectBG_DropShadow);

                        fadeIn7.play();

                        l1.setEffect(effectC_DropShadow);
                        l1.setVisible(true);
                        l2.setEffect(null);
                        l3.setEffect(null);

                        playSingle_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> fadeIn7.stop());
                        playSingle_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e1 -> fadeIn7.stop());

                    });
                    playSingle_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        playSingle_btn.setGraphic(svgIconPlaySingle);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        fadeOut7.play();

                        l1.setEffect(null);
                        l1.setVisible(false);
                        l2.setEffect(null);
                        l3.setEffect(null);

                        playSingle_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> fadeOut7.stop());

                    });
                    playSingle_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.setDuration(Duration.millis(1));
                        fadeOut2.setDuration(Duration.millis(1));
                        fadeOut3.setDuration(Duration.millis(200));
                        fadeOut5.setDuration(Duration.millis(200));
                        fadeOut6.setDuration(Duration.millis(200));
                        fadeOut6_1.setDuration(Duration.millis(200));
                        fadeOut6_2.setDuration(Duration.millis(200));
                        fadeOut7.setDuration(Duration.millis(200));

                        fadeOut.play();//exit
                        fadeOut2.play();//op
                        fadeOut3.play();//bgpanel
                        fadeOut7.play();//l1
                        fadeOut6.play();//s
                        fadeOut5.play();//panel
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        playSingle_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.stop();//exit
                            fadeOut2.stop();//op
                            fadeIn3.stop();//bgpanel
                            fadeOut7.stop();//l1
                            fadeOut6.stop();//s
                            fadeOut5.stop();//panel
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                            fadeOut.setDuration(Duration.millis(1));
                            fadeOut2.setDuration(Duration.millis(500));
                            fadeOut3.setDuration(Duration.millis(500));
                            fadeOut5.setDuration(Duration.millis(500));
                            fadeOut6.setDuration(Duration.millis(500));
                            fadeOut6_1.setDuration(Duration.millis(500));
                            fadeOut6_2.setDuration(Duration.millis(500));
                            fadeOut7.setDuration(Duration.millis(500));

                        });

                    });
                    playSingle_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {playSingle_Clicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    });

                    mainMenu.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        ex1.setVisible(true);
                        Panel1.setVisible(true);

                        fadeIn.play();//exit_btn
                        exit_btn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");

                        fadeOut4.play();//bl1
                        fadeOut4_1.play();//bl2
                        fadeOut3.play();//bgpanel

                        fadeIn5.play();//panel
                        fadeIn6.play();//s
                        fadeIn6_1.play();//m
                        fadeIn6_2.play();//h

                        mainMenu.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> {

                            fadeIn.stop();//exit_btn
                            fadeOut4.stop();//bl1
                            fadeOut4_1.stop();//bl2
                            fadeOut3.stop();//bgpanel

                            fadeIn5.stop();//panel
                            fadeIn6.stop();//s
                            fadeIn6_1.stop();//m
                            fadeIn6_2.stop();//h

                        });

                    });
                    mainMenu.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        fadeIn.play();//exit_btn
                        fadeIn4.play();//bl1
                        fadeIn4_1.play();//bl2
                        fadeIn3.play();//bgpanel

                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        exit_btn.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                        mainMenu.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> {

                            fadeIn.stop();//exit_btn
                            fadeIn4.stop();//bl1
                            fadeIn4_1.stop();//bl2
                            fadeIn3.stop();//bgpanel

                            fadeOut5.stop();//panel
                            fadeOut6.stop();//s
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                        });

                    });

                    option_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        option_btn.setGraphic(svgIconOption_Hover);
                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(effectC_InnerShadow);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l3.setEffect(null);
                    });
                    option_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        option_btn.setGraphic(svgIconOption);
                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l3.setEffect(null);
                    });
                    option_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.setDuration(Duration.millis(1));
                        fadeOut2.setDuration(Duration.millis(1));
                        fadeOut5.setDuration(Duration.millis(200));
                        fadeOut6.setDuration(Duration.millis(200));
                        fadeOut6_1.setDuration(Duration.millis(200));
                        fadeOut6_2.setDuration(Duration.millis(200));

                        fadeOut.play();//exit_btn
                        fadeOut2.play();//option
                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        option_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.setDuration(Duration.millis(1));
                            fadeOut2.setDuration(Duration.millis(1));
                            fadeOut5.setDuration(Duration.millis(500));
                            fadeOut6.setDuration(Duration.millis(500));
                            fadeOut6_1.setDuration(Duration.millis(500));
                            fadeOut6_2.setDuration(Duration.millis(500));

                            fadeOut.stop();//exit_btn
                            fadeOut2.stop();//option
                            fadeOut5.stop();//panel
                            fadeOut6.stop();//s
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                        });
                    });
                    option_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            settingsClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    });

                    exit_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        exit_btn.setGraphic(svgIconExitButton_Hover);

                        exit_btn.setEffect(effectC_DropShadow);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                    });
                    exit_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        exit_btn.setGraphic(svgIconExitButton);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                    });
                    exit_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut4.play();//bl1
                        fadeOut4_1.play();//bl2
                        fadeOut3.play();//bgpanel

                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        exit_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                        });

                    });

                }
                else if (tColor == 4) {

                    color2 = "#d50000";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(181,0,0), 18, 0, 9, 9);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(245,0,0), 18, 0, -9, -9);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(181,0,0), 18, 0, 9, 9);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(245,0,0), 18, 0, -9, -9);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    effect_BGPANEL = new DropShadow(BlurType.GAUSSIAN, Color.rgb(245,0,0), 40, 0, -20, -20);

                    effect_BGPANELLABELADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(181,0,0), 9, 0, 2,2);
                    effect_BGPANELLABEL = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(245,0,0), 9, 0, -2,-2);
                    effect_BGPANELLABEL.setInput(effect_BGPANELLABELADD);

                    svgFileExitButton = getClass().getResourceAsStream("../../../resources/svg/delete/delete.svg");
                    svgFileExitButton_Hover = getClass().getResourceAsStream("../../../resources/svg/delete/delete_red.svg");

                    svgFileHighScore = getClass().getResourceAsStream("../../../resources/svg/podium/podium.svg");
                    svgFileHighScore_Hover = getClass().getResourceAsStream("../../../resources/svg/podium/podium.svg");

                    svgFileOption = getClass().getResourceAsStream("../../../resources/svg/settings.svg");
                    svgFileOption_Hover = getClass().getResourceAsStream("../../../resources/svg/settings_dred.svg");

                    svgFilePlayMulti = getClass().getResourceAsStream("../../../resources/svg/group/group.svg");
                    svgFilePlayMulti_Hover = getClass().getResourceAsStream("../../../resources/svg/group/group_red.svg");

                    svgFilePlaySingle = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlaySingle_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_red.svg");

                    Group svgImageExitButton = loader.loadSvg(svgFileExitButton);
                    Group svgImageExitButton_Hover = loader.loadSvg(svgFileExitButton_Hover);

                    Group svgImageHighScore = loader.loadSvg(svgFileHighScore);
                    Group svgImageHighScore_Hover = loader.loadSvg(svgFileHighScore_Hover);

                    Group svgImageOption = loader.loadSvg(svgFileOption);
                    Group svgImageOption_Hover = loader.loadSvg(svgFileOption_Hover);

                    Group svgImagePlayMulti = loader.loadSvg(svgFilePlayMulti);
                    Group svgImagePlayMulti_Hover = loader.loadSvg(svgFilePlayMulti_Hover);

                    Group svgImagePlaySingle = loader.loadSvg(svgFilePlaySingle);
                    Group svgImagePlaySingle_Hover = loader.loadSvg(svgFilePlaySingle_Hover);

                    svgImageExitButton.setScaleX(.03);
                    svgImageExitButton.setScaleY(.03);
                    svgImageExitButton_Hover.setScaleX(.03);
                    svgImageExitButton_Hover.setScaleY(.03);

                    svgImageHighScore.setScaleX(.06);
                    svgImageHighScore.setScaleY(.06);
                    svgImageHighScore_Hover.setScaleX(.06);
                    svgImageHighScore_Hover.setScaleY(.06);

                    svgImageOption.setScaleX(.04);
                    svgImageOption.setScaleY(.04);
                    svgImageOption_Hover.setScaleX(.04);
                    svgImageOption_Hover.setScaleY(.04);

                    svgImagePlayMulti.setScaleX(.1);
                    svgImagePlayMulti.setScaleY(.1);
                    svgImagePlayMulti_Hover.setScaleX(.1);
                    svgImagePlayMulti_Hover.setScaleY(.1);

                    svgImagePlaySingle.setScaleX(.06);
                    svgImagePlaySingle.setScaleY(.06);
                    svgImagePlaySingle_Hover.setScaleX(.06);
                    svgImagePlaySingle_Hover.setScaleY(.06);

                    Group svgIconExitButton = new Group(svgImageExitButton);
                    Group svgIconExitButton_Hover = new Group(svgImageExitButton_Hover);

                    Group svgIconHighScore = new Group(svgImageHighScore);
                    Group svgIconHighScore_Hover = new Group(svgImageHighScore_Hover);

                    Group svgIconOption = new Group(svgImageOption);
                    Group svgIconOption_Hover = new Group(svgImageOption_Hover);

                    Group svgIconPlayMulti = new Group(svgImagePlayMulti);
                    Group svgIconPlayMulti_Hover = new Group(svgImagePlayMulti_Hover);

                    Group svgIconPlaySingle = new Group(svgImagePlaySingle);
                    Group svgIconPlaySingle_Hover = new Group(svgImagePlaySingle_Hover);

                    exit_btn.setGraphic(svgIconExitButton);
                    highScore_btn.setGraphic(svgIconHighScore);
                    option_btn.setGraphic(svgIconOption);
                    playMulti_btn.setGraphic(svgIconPlayMulti);
                    playSingle_btn.setGraphic(svgIconPlaySingle);

                    Panelex.setEffect(effect_BGPANEL);

                    bt1.setEffect(effect_BGPANELLABEL);
                    bt2.setEffect(effect_BGPANELLABEL);
                    bt1.setTextFill(Color.web(color2));
                    bt2.setTextFill(Color.web(color2));

                    highScore_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        highScore_btn.setGraphic(svgIconHighScore_Hover);
                        highScore_btn.setEffect(effectBG_DropShadow);
                        exit_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        fadeIn7_2.play();

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l3.setEffect(effectC_DropShadow);
                        l3.setVisible(true);

                        highScore_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> fadeIn7_2.stop());
                        highScore_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e1 -> fadeIn7_2.stop());

                    });
                    highScore_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        highScore_btn.setGraphic(svgIconHighScore);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        fadeOut7_2.play();

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l3.setEffect(null);
                        l3.setVisible(false);

                        highScore_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> fadeOut7_2.stop());

                    });
                    highScore_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.setDuration(Duration.millis(1));
                        fadeOut2.setDuration(Duration.millis(1));
                        fadeOut3.setDuration(Duration.millis(200));
                        fadeOut5.setDuration(Duration.millis(200));
                        fadeOut6.setDuration(Duration.millis(200));
                        fadeOut6_1.setDuration(Duration.millis(200));
                        fadeOut6_2.setDuration(Duration.millis(200));
                        fadeOut7_2.setDuration(Duration.millis(200));

                        fadeOut.play();//exit
                        fadeOut2.play();//op
                        fadeOut3.play();//bgpanel
                        fadeOut7_2.play();//l3
                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        highScore_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.stop();//exit
                            fadeOut2.stop();//op
                            fadeOut3.stop();//bgpanel

                            fadeOut7_2.stop();//l3
                            fadeOut5.stop();//panel
                            fadeOut6.stop();//s
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                            fadeOut.setDuration(Duration.millis(1));
                            fadeOut2.setDuration(Duration.millis(500));
                            fadeOut3.setDuration(Duration.millis(500));
                            fadeOut5.setDuration(Duration.millis(500));
                            fadeOut6.setDuration(Duration.millis(500));
                            fadeOut6_1.setDuration(Duration.millis(500));
                            fadeOut6_2.setDuration(Duration.millis(500));
                            fadeOut7_2.setDuration(Duration.millis(500));

                        });

                    });
                    highScore_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            highScore_Clicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    });

                    playMulti_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        playMulti_btn.setGraphic(svgIconPlayMulti_Hover);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(effectBG_DropShadow);
                        playSingle_btn.setEffect(null);

                        fadeIn7_1.play();

                        l1.setEffect(null);
                        l2.setEffect(effectC_DropShadow);
                        l2.setVisible(true);
                        l3.setEffect(null);

                        playMulti_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> fadeIn7_1.stop());
                        playMulti_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e1 -> fadeIn7_1.stop());

                    });
                    playMulti_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        playMulti_btn.setGraphic(svgIconPlayMulti);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        fadeOut7_1.play();

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l2.setVisible(false);
                        l3.setEffect(null);

                        playMulti_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> fadeOut7_1.stop());



                    });
                    playMulti_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.setDuration(Duration.millis(1));
                        fadeOut2.setDuration(Duration.millis(1));
                        fadeOut3.setDuration(Duration.millis(200));
                        fadeOut5.setDuration(Duration.millis(200));
                        fadeOut6.setDuration(Duration.millis(200));
                        fadeOut6_1.setDuration(Duration.millis(200));
                        fadeOut6_2.setDuration(Duration.millis(200));
                        fadeOut7_1.setDuration(Duration.millis(200));

                        fadeOut.play();//exit_btn
                        fadeOut2.play();//exit_btn
                        fadeOut3.play();//bgpanel
                        fadeOut7_1.play();//l2
                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        playMulti_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.stop();//exit_btn
                            fadeOut2.stop();//exit_btn
                            fadeOut3.stop();//bgpanel
                            fadeOut7_1.stop();//l2
                            fadeOut5.stop();//panel
                            fadeOut6.stop();//s
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                            fadeOut.setDuration(Duration.millis(1));
                            fadeOut2.setDuration(Duration.millis(500));
                            fadeOut3.setDuration(Duration.millis(500));
                            fadeOut5.setDuration(Duration.millis(500));
                            fadeOut6.setDuration(Duration.millis(500));
                            fadeOut6_1.setDuration(Duration.millis(500));
                            fadeOut6_2.setDuration(Duration.millis(500));
                            fadeOut7_1.setDuration(Duration.millis(500));

                        });

                    });
                    playMulti_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {playMulti_Clicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    });

                    playSingle_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        playSingle_btn.setGraphic(svgIconPlaySingle_Hover);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(effectBG_DropShadow);

                        fadeIn7.play();

                        l1.setEffect(effectC_DropShadow);
                        l1.setVisible(true);
                        l2.setEffect(null);
                        l3.setEffect(null);

                        playSingle_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> fadeIn7.stop());
                        playSingle_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e1 -> fadeIn7.stop());

                    });
                    playSingle_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        playSingle_btn.setGraphic(svgIconPlaySingle);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        fadeOut7.play();

                        l1.setEffect(null);
                        l1.setVisible(false);
                        l2.setEffect(null);
                        l3.setEffect(null);

                        playSingle_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> fadeOut7.stop());

                    });
                    playSingle_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.setDuration(Duration.millis(1));
                        fadeOut2.setDuration(Duration.millis(1));
                        fadeOut3.setDuration(Duration.millis(200));
                        fadeOut5.setDuration(Duration.millis(200));
                        fadeOut6.setDuration(Duration.millis(200));
                        fadeOut6_1.setDuration(Duration.millis(200));
                        fadeOut6_2.setDuration(Duration.millis(200));
                        fadeOut7.setDuration(Duration.millis(200));

                        fadeOut.play();//exit
                        fadeOut2.play();//op
                        fadeOut3.play();//bgpanel
                        fadeOut7.play();//l1
                        fadeOut6.play();//s
                        fadeOut5.play();//panel
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        playSingle_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.stop();//exit
                            fadeOut2.stop();//op
                            fadeIn3.stop();//bgpanel
                            fadeOut7.stop();//l1
                            fadeOut6.stop();//s
                            fadeOut5.stop();//panel
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                            fadeOut.setDuration(Duration.millis(1));
                            fadeOut2.setDuration(Duration.millis(500));
                            fadeOut3.setDuration(Duration.millis(500));
                            fadeOut5.setDuration(Duration.millis(500));
                            fadeOut6.setDuration(Duration.millis(500));
                            fadeOut6_1.setDuration(Duration.millis(500));
                            fadeOut6_2.setDuration(Duration.millis(500));
                            fadeOut7.setDuration(Duration.millis(500));

                        });

                    });
                    playSingle_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {playSingle_Clicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    });

                    mainMenu.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        ex1.setVisible(true);
                        Panel1.setVisible(true);

                        fadeIn.play();//exit_btn
                        exit_btn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");

                        fadeOut4.play();//bl1
                        fadeOut4_1.play();//bl2
                        fadeOut3.play();//bgpanel

                        fadeIn5.play();//panel
                        fadeIn6.play();//s
                        fadeIn6_1.play();//m
                        fadeIn6_2.play();//h

                        mainMenu.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> {

                            fadeIn.stop();//exit_btn
                            fadeOut4.stop();//bl1
                            fadeOut4_1.stop();//bl2
                            fadeOut3.stop();//bgpanel

                            fadeIn5.stop();//panel
                            fadeIn6.stop();//s
                            fadeIn6_1.stop();//m
                            fadeIn6_2.stop();//h

                        });

                    });
                    mainMenu.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        fadeIn.play();//exit_btn
                        fadeIn4.play();//bl1
                        fadeIn4_1.play();//bl2
                        fadeIn3.play();//bgpanel

                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        exit_btn.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                        mainMenu.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> {

                            fadeIn.stop();//exit_btn
                            fadeIn4.stop();//bl1
                            fadeIn4_1.stop();//bl2
                            fadeIn3.stop();//bgpanel

                            fadeOut5.stop();//panel
                            fadeOut6.stop();//s
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                        });

                    });

                    option_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        option_btn.setGraphic(svgIconOption_Hover);
                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(effectC_InnerShadow);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l3.setEffect(null);
                    });
                    option_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        option_btn.setGraphic(svgIconOption);
                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l3.setEffect(null);
                    });
                    option_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.setDuration(Duration.millis(1));
                        fadeOut2.setDuration(Duration.millis(1));
                        fadeOut5.setDuration(Duration.millis(200));
                        fadeOut6.setDuration(Duration.millis(200));
                        fadeOut6_1.setDuration(Duration.millis(200));
                        fadeOut6_2.setDuration(Duration.millis(200));

                        fadeOut.play();//exit_btn
                        fadeOut2.play();//option
                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        option_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.setDuration(Duration.millis(1));
                            fadeOut2.setDuration(Duration.millis(1));
                            fadeOut5.setDuration(Duration.millis(500));
                            fadeOut6.setDuration(Duration.millis(500));
                            fadeOut6_1.setDuration(Duration.millis(500));
                            fadeOut6_2.setDuration(Duration.millis(500));

                            fadeOut.stop();//exit_btn
                            fadeOut2.stop();//option
                            fadeOut5.stop();//panel
                            fadeOut6.stop();//s
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                        });
                    });
                    option_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            settingsClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    });

                    exit_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        exit_btn.setGraphic(svgIconExitButton_Hover);

                        exit_btn.setEffect(effectC_DropShadow);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                    });
                    exit_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        exit_btn.setGraphic(svgIconExitButton);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                    });
                    exit_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut4.play();//bl1
                        fadeOut4_1.play();//bl2
                        fadeOut3.play();//bgpanel

                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        exit_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                        });

                    });

                }

            }
            else if (theme == 2) {

                color = "#181818";

                effectBG_DropShadowADD = new DropShadow(BlurType.GAUSSIAN, Color.rgb(20,20,20), 18, 0, 9, 9);
                effectBG_DropShadow = new DropShadow(BlurType.GAUSSIAN, Color.rgb(28,28,28), 18, 0, -9, -9);
                effectBG_DropShadow.setInput(effectBG_DropShadowADD);

                effectBG_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(20,20,20), 18, 0, 9, 9);
                effectBG_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(20,20,20), 18, 0, -9, -9);
                effectBG_InnerShadow.setInput(effectBG_InnerShadowADD);

                if (tColor == 1) {

                    color2 = "#004fcb";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,67,173), 24, 0, 9, 9);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,91,233), 24, 0, -9, -9);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,67,173), 18, 0, 9, 9);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,91,233), 18, 0, -9, -9);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    effect_BGPANEL = new DropShadow(BlurType.GAUSSIAN,Color.rgb(0,91,233), 40, 0, -20, -20);

                    effect_BGPANELLABELADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,67,173), 9, 0, 2,2);
                    effect_BGPANELLABEL = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,91,233), 9, 0, -2,-2);
                    effect_BGPANELLABEL.setInput(effect_BGPANELLABELADD);

                    svgFileExitButton = getClass().getResourceAsStream("../../../resources/svg/delete/delete_d.svg");
                    svgFileExitButton_Hover = getClass().getResourceAsStream("../../../resources/svg/delete/delete_dblue.svg");

                    svgFileHighScore = getClass().getResourceAsStream("../../../resources/svg/podium/podium_d.svg");
                    svgFileHighScore_Hover = getClass().getResourceAsStream("../../../resources/svg/podium/podium_dblue.svg");

                    svgFileOption = getClass().getResourceAsStream("../../../resources/svg/settings_d.svg");
                    svgFileOption_Hover = getClass().getResourceAsStream("../../../resources/svg/settings_blue.svg");

                    svgFilePlayMulti = getClass().getResourceAsStream("../../../resources/svg/group/group_d.svg");
                    svgFilePlayMulti_Hover = getClass().getResourceAsStream("../../../resources/svg/group/group_dblue.svg");

                    svgFilePlaySingle = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlaySingle_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");

                    Group svgImageExitButton = loader.loadSvg(svgFileExitButton);
                    Group svgImageExitButton_Hover = loader.loadSvg(svgFileExitButton_Hover);

                    Group svgImageHighScore = loader.loadSvg(svgFileHighScore);
                    Group svgImageHighScore_Hover = loader.loadSvg(svgFileHighScore_Hover);

                    Group svgImageOption = loader.loadSvg(svgFileOption);
                    Group svgImageOption_Hover = loader.loadSvg(svgFileOption_Hover);

                    Group svgImagePlayMulti = loader.loadSvg(svgFilePlayMulti);
                    Group svgImagePlayMulti_Hover = loader.loadSvg(svgFilePlayMulti_Hover);

                    Group svgImagePlaySingle = loader.loadSvg(svgFilePlaySingle);
                    Group svgImagePlaySingle_Hover = loader.loadSvg(svgFilePlaySingle_Hover);

                    svgImageExitButton.setScaleX(.03);
                    svgImageExitButton.setScaleY(.03);
                    svgImageExitButton_Hover.setScaleX(.03);
                    svgImageExitButton_Hover.setScaleY(.03);

                    svgImageHighScore.setScaleX(.06);
                    svgImageHighScore.setScaleY(.06);
                    svgImageHighScore_Hover.setScaleX(.06);
                    svgImageHighScore_Hover.setScaleY(.06);

                    svgImageOption.setScaleX(.04);
                    svgImageOption.setScaleY(.04);
                    svgImageOption_Hover.setScaleX(.04);
                    svgImageOption_Hover.setScaleY(.04);

                    svgImagePlayMulti.setScaleX(.1);
                    svgImagePlayMulti.setScaleY(.1);
                    svgImagePlayMulti_Hover.setScaleX(.1);
                    svgImagePlayMulti_Hover.setScaleY(.1);

                    svgImagePlaySingle.setScaleX(.06);
                    svgImagePlaySingle.setScaleY(.06);
                    svgImagePlaySingle_Hover.setScaleX(.06);
                    svgImagePlaySingle_Hover.setScaleY(.06);

                    Group svgIconExitButton = new Group(svgImageExitButton);
                    Group svgIconExitButton_Hover = new Group(svgImageExitButton_Hover);

                    Group svgIconHighScore = new Group(svgImageHighScore);
                    Group svgIconHighScore_Hover = new Group(svgImageHighScore_Hover);

                    Group svgIconOption = new Group(svgImageOption);
                    Group svgIconOption_Hover = new Group(svgImageOption_Hover);

                    Group svgIconPlayMulti = new Group(svgImagePlayMulti);
                    Group svgIconPlayMulti_Hover = new Group(svgImagePlayMulti_Hover);

                    Group svgIconPlaySingle = new Group(svgImagePlaySingle);
                    Group svgIconPlaySingle_Hover = new Group(svgImagePlaySingle_Hover);

                    exit_btn.setGraphic(svgIconExitButton);
                    highScore_btn.setGraphic(svgIconHighScore);
                    option_btn.setGraphic(svgIconOption);
                    playMulti_btn.setGraphic(svgIconPlayMulti);
                    playSingle_btn.setGraphic(svgIconPlaySingle);

                    Panelex.setEffect(effect_BGPANEL);

                    bt1.setEffect(effect_BGPANELLABEL);
                    bt2.setEffect(effect_BGPANELLABEL);
                    bt1.setTextFill(Color.web(color2));
                    bt2.setTextFill(Color.web(color2));

                    highScore_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        highScore_btn.setGraphic(svgIconHighScore_Hover);
                        highScore_btn.setEffect(effectBG_DropShadow);
                        exit_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        fadeIn7_2.play();

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l3.setEffect(effectC_DropShadow);
                        l3.setVisible(true);

                        highScore_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> fadeIn7_2.stop());
                        highScore_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e1 -> fadeIn7_2.stop());

                    });
                    highScore_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        highScore_btn.setGraphic(svgIconHighScore);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        fadeOut7_2.play();

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l3.setEffect(null);
                        l3.setVisible(false);

                        highScore_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> fadeOut7_2.stop());

                    });
                    highScore_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.setDuration(Duration.millis(1));
                        fadeOut2.setDuration(Duration.millis(1));
                        fadeOut3.setDuration(Duration.millis(200));
                        fadeOut5.setDuration(Duration.millis(200));
                        fadeOut6.setDuration(Duration.millis(200));
                        fadeOut6_1.setDuration(Duration.millis(200));
                        fadeOut6_2.setDuration(Duration.millis(200));
                        fadeOut7_2.setDuration(Duration.millis(200));

                        fadeOut.play();//exit
                        fadeOut2.play();//op
                        fadeOut3.play();//bgpanel
                        fadeOut7_2.play();//l3
                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        highScore_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.stop();//exit
                            fadeOut2.stop();//op
                            fadeOut3.stop();//bgpanel

                            fadeOut7_2.stop();//l3
                            fadeOut5.stop();//panel
                            fadeOut6.stop();//s
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                            fadeOut.setDuration(Duration.millis(1));
                            fadeOut2.setDuration(Duration.millis(500));
                            fadeOut3.setDuration(Duration.millis(500));
                            fadeOut5.setDuration(Duration.millis(500));
                            fadeOut6.setDuration(Duration.millis(500));
                            fadeOut6_1.setDuration(Duration.millis(500));
                            fadeOut6_2.setDuration(Duration.millis(500));
                            fadeOut7_2.setDuration(Duration.millis(500));

                        });

                    });
                    highScore_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            highScore_Clicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    });

                    playMulti_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        playMulti_btn.setGraphic(svgIconPlayMulti_Hover);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(effectBG_DropShadow);
                        playSingle_btn.setEffect(null);

                        fadeIn7_1.play();

                        l1.setEffect(null);
                        l2.setEffect(effectC_DropShadow);
                        l2.setVisible(true);
                        l3.setEffect(null);

                        playMulti_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> fadeIn7_1.stop());
                        playMulti_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e1 -> fadeIn7_1.stop());

                    });
                    playMulti_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        playMulti_btn.setGraphic(svgIconPlayMulti);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        fadeOut7_1.play();

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l2.setVisible(false);
                        l3.setEffect(null);

                        playMulti_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> fadeOut7_1.stop());



                    });
                    playMulti_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.setDuration(Duration.millis(1));
                        fadeOut2.setDuration(Duration.millis(1));
                        fadeOut3.setDuration(Duration.millis(200));
                        fadeOut5.setDuration(Duration.millis(200));
                        fadeOut6.setDuration(Duration.millis(200));
                        fadeOut6_1.setDuration(Duration.millis(200));
                        fadeOut6_2.setDuration(Duration.millis(200));
                        fadeOut7_1.setDuration(Duration.millis(200));

                        fadeOut.play();//exit_btn
                        fadeOut2.play();//exit_btn
                        fadeOut3.play();//bgpanel
                        fadeOut7_1.play();//l2
                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        playMulti_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.stop();//exit_btn
                            fadeOut2.stop();//exit_btn
                            fadeOut3.stop();//bgpanel
                            fadeOut7_1.stop();//l2
                            fadeOut5.stop();//panel
                            fadeOut6.stop();//s
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                            fadeOut.setDuration(Duration.millis(1));
                            fadeOut2.setDuration(Duration.millis(500));
                            fadeOut3.setDuration(Duration.millis(500));
                            fadeOut5.setDuration(Duration.millis(500));
                            fadeOut6.setDuration(Duration.millis(500));
                            fadeOut6_1.setDuration(Duration.millis(500));
                            fadeOut6_2.setDuration(Duration.millis(500));
                            fadeOut7_1.setDuration(Duration.millis(500));

                        });

                    });
                    playMulti_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {playMulti_Clicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    });

                    playSingle_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        playSingle_btn.setGraphic(svgIconPlaySingle_Hover);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(effectBG_DropShadow);

                        fadeIn7.play();

                        l1.setEffect(effectC_DropShadow);
                        l1.setVisible(true);
                        l2.setEffect(null);
                        l3.setEffect(null);

                        playSingle_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> fadeIn7.stop());
                        playSingle_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e1 -> fadeIn7.stop());

                    });
                    playSingle_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        playSingle_btn.setGraphic(svgIconPlaySingle);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        fadeOut7.play();

                        l1.setEffect(null);
                        l1.setVisible(false);
                        l2.setEffect(null);
                        l3.setEffect(null);

                        playSingle_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> fadeOut7.stop());

                    });
                    playSingle_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.setDuration(Duration.millis(1));
                        fadeOut2.setDuration(Duration.millis(1));
                        fadeOut3.setDuration(Duration.millis(200));
                        fadeOut5.setDuration(Duration.millis(200));
                        fadeOut6.setDuration(Duration.millis(200));
                        fadeOut6_1.setDuration(Duration.millis(200));
                        fadeOut6_2.setDuration(Duration.millis(200));
                        fadeOut7.setDuration(Duration.millis(200));

                        fadeOut.play();//exit
                        fadeOut2.play();//op
                        fadeOut3.play();//bgpanel
                        fadeOut7.play();//l1
                        fadeOut6.play();//s
                        fadeOut5.play();//panel
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        playSingle_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.stop();//exit
                            fadeOut2.stop();//op
                            fadeIn3.stop();//bgpanel
                            fadeOut7.stop();//l1
                            fadeOut6.stop();//s
                            fadeOut5.stop();//panel
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                            fadeOut.setDuration(Duration.millis(1));
                            fadeOut2.setDuration(Duration.millis(500));
                            fadeOut3.setDuration(Duration.millis(500));
                            fadeOut5.setDuration(Duration.millis(500));
                            fadeOut6.setDuration(Duration.millis(500));
                            fadeOut6_1.setDuration(Duration.millis(500));
                            fadeOut6_2.setDuration(Duration.millis(500));
                            fadeOut7.setDuration(Duration.millis(500));

                        });

                    });
                    playSingle_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {playSingle_Clicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    });

                    mainMenu.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        ex1.setVisible(true);
                        Panel1.setVisible(true);

                        fadeIn.play();//exit_btn
                        exit_btn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");

                        fadeOut4.play();//bl1
                        fadeOut4_1.play();//bl2
                        fadeOut3.play();//bgpanel

                        fadeIn5.play();//panel
                        fadeIn6.play();//s
                        fadeIn6_1.play();//m
                        fadeIn6_2.play();//h

                        mainMenu.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> {

                            fadeIn.stop();//exit_btn
                            fadeOut4.stop();//bl1
                            fadeOut4_1.stop();//bl2
                            fadeOut3.stop();//bgpanel

                            fadeIn5.stop();//panel
                            fadeIn6.stop();//s
                            fadeIn6_1.stop();//m
                            fadeIn6_2.stop();//h

                        });

                    });
                    mainMenu.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        fadeIn.play();//exit_btn
                        fadeIn4.play();//bl1
                        fadeIn4_1.play();//bl2
                        fadeIn3.play();//bgpanel

                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        exit_btn.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                        mainMenu.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> {

                            fadeIn.stop();//exit_btn
                            fadeIn4.stop();//bl1
                            fadeIn4_1.stop();//bl2
                            fadeIn3.stop();//bgpanel

                            fadeOut5.stop();//panel
                            fadeOut6.stop();//s
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                        });

                    });

                    option_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        option_btn.setGraphic(svgIconOption_Hover);
                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(effectC_InnerShadow);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l3.setEffect(null);
                    });
                    option_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        option_btn.setGraphic(svgIconOption);
                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l3.setEffect(null);
                    });
                    option_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.setDuration(Duration.millis(1));
                        fadeOut2.setDuration(Duration.millis(1));
                        fadeOut5.setDuration(Duration.millis(200));
                        fadeOut6.setDuration(Duration.millis(200));
                        fadeOut6_1.setDuration(Duration.millis(200));
                        fadeOut6_2.setDuration(Duration.millis(200));

                        fadeOut.play();//exit_btn
                        fadeOut2.play();//option
                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        option_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.setDuration(Duration.millis(1));
                            fadeOut2.setDuration(Duration.millis(1));
                            fadeOut5.setDuration(Duration.millis(500));
                            fadeOut6.setDuration(Duration.millis(500));
                            fadeOut6_1.setDuration(Duration.millis(500));
                            fadeOut6_2.setDuration(Duration.millis(500));

                            fadeOut.stop();//exit_btn
                            fadeOut2.stop();//option
                            fadeOut5.stop();//panel
                            fadeOut6.stop();//s
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                        });
                    });
                    option_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            settingsClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    });

                    exit_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        exit_btn.setGraphic(svgIconExitButton_Hover);

                        exit_btn.setEffect(effectC_DropShadow);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                    });
                    exit_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        exit_btn.setGraphic(svgIconExitButton);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                    });
                    exit_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut4.play();//bl1
                        fadeOut4_1.play();//bl2
                        fadeOut3.play();//bgpanel

                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        exit_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                        });

                    });

                }
                else if (tColor == 2) {

                    color2 = "#c9c208";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.web("#aba507"), 18, 0, 9, 9);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.web("#e7df09"), 18, 0, -9, -9);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.web("#aba507"), 18, 0, 9, 9);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.web("#e7df09"), 18, 0, -9, -9);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    effect_BGPANEL = new DropShadow(BlurType.GAUSSIAN, Color.web("#e7df09"), 40, 0, -20, -20);

                    effect_BGPANELLABELADD = new InnerShadow(BlurType.GAUSSIAN, Color.web("#aba507"), 9, 0, 2,2);
                    effect_BGPANELLABEL = new InnerShadow(BlurType.GAUSSIAN, Color.web("#e7df09"), 9, 0, -2,-2);
                    effect_BGPANELLABEL.setInput(effect_BGPANELLABELADD);

                    svgFileExitButton = getClass().getResourceAsStream("../../../resources/svg/delete/delete_d.svg");
                    svgFileExitButton_Hover = getClass().getResourceAsStream("../../../resources/svg/delete/delete_dyellow.svg");

                    svgFileHighScore = getClass().getResourceAsStream("../../../resources/svg/podium/podium_d.svg");
                    svgFileHighScore_Hover = getClass().getResourceAsStream("../../../resources/svg/podium/podium_dyellow.svg");

                    svgFileOption = getClass().getResourceAsStream("../../../resources/svg/settings_d.svg");
                    svgFileOption_Hover = getClass().getResourceAsStream("../../../resources/svg/settings_yellow.svg");

                    svgFilePlayMulti = getClass().getResourceAsStream("../../../resources/svg/group/group_d.svg");
                    svgFilePlayMulti_Hover = getClass().getResourceAsStream("../../../resources/svg/group/group_dyellow.svg");

                    svgFilePlaySingle = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlaySingle_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dyellow.svg");

                    Group svgImageExitButton = loader.loadSvg(svgFileExitButton);
                    Group svgImageExitButton_Hover = loader.loadSvg(svgFileExitButton_Hover);

                    Group svgImageHighScore = loader.loadSvg(svgFileHighScore);
                    Group svgImageHighScore_Hover = loader.loadSvg(svgFileHighScore_Hover);

                    Group svgImageOption = loader.loadSvg(svgFileOption);
                    Group svgImageOption_Hover = loader.loadSvg(svgFileOption_Hover);

                    Group svgImagePlayMulti = loader.loadSvg(svgFilePlayMulti);
                    Group svgImagePlayMulti_Hover = loader.loadSvg(svgFilePlayMulti_Hover);

                    Group svgImagePlaySingle = loader.loadSvg(svgFilePlaySingle);
                    Group svgImagePlaySingle_Hover = loader.loadSvg(svgFilePlaySingle_Hover);

                    svgImageExitButton.setScaleX(.03);
                    svgImageExitButton.setScaleY(.03);
                    svgImageExitButton_Hover.setScaleX(.03);
                    svgImageExitButton_Hover.setScaleY(.03);

                    svgImageHighScore.setScaleX(.06);
                    svgImageHighScore.setScaleY(.06);
                    svgImageHighScore_Hover.setScaleX(.06);
                    svgImageHighScore_Hover.setScaleY(.06);

                    svgImageOption.setScaleX(.04);
                    svgImageOption.setScaleY(.04);
                    svgImageOption_Hover.setScaleX(.04);
                    svgImageOption_Hover.setScaleY(.04);

                    svgImagePlayMulti.setScaleX(.1);
                    svgImagePlayMulti.setScaleY(.1);
                    svgImagePlayMulti_Hover.setScaleX(.1);
                    svgImagePlayMulti_Hover.setScaleY(.1);

                    svgImagePlaySingle.setScaleX(.06);
                    svgImagePlaySingle.setScaleY(.06);
                    svgImagePlaySingle_Hover.setScaleX(.06);
                    svgImagePlaySingle_Hover.setScaleY(.06);

                    Group svgIconExitButton = new Group(svgImageExitButton);
                    Group svgIconExitButton_Hover = new Group(svgImageExitButton_Hover);

                    Group svgIconHighScore = new Group(svgImageHighScore);
                    Group svgIconHighScore_Hover = new Group(svgImageHighScore_Hover);

                    Group svgIconOption = new Group(svgImageOption);
                    Group svgIconOption_Hover = new Group(svgImageOption_Hover);

                    Group svgIconPlayMulti = new Group(svgImagePlayMulti);
                    Group svgIconPlayMulti_Hover = new Group(svgImagePlayMulti_Hover);

                    Group svgIconPlaySingle = new Group(svgImagePlaySingle);
                    Group svgIconPlaySingle_Hover = new Group(svgImagePlaySingle_Hover);

                    exit_btn.setGraphic(svgIconExitButton);
                    highScore_btn.setGraphic(svgIconHighScore);
                    option_btn.setGraphic(svgIconOption);
                    playMulti_btn.setGraphic(svgIconPlayMulti);
                    playSingle_btn.setGraphic(svgIconPlaySingle);

                    Panelex.setEffect(effect_BGPANEL);

                    bt1.setEffect(effect_BGPANELLABEL);
                    bt2.setEffect(effect_BGPANELLABEL);
                    bt1.setTextFill(Color.web(color2));
                    bt2.setTextFill(Color.web(color2));

                    highScore_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        highScore_btn.setGraphic(svgIconHighScore_Hover);
                        highScore_btn.setEffect(effectBG_DropShadow);
                        exit_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        fadeIn7_2.play();

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l3.setEffect(effectC_DropShadow);
                        l3.setVisible(true);

                        highScore_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> fadeIn7_2.stop());
                        highScore_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e1 -> fadeIn7_2.stop());

                    });
                    highScore_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        highScore_btn.setGraphic(svgIconHighScore);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        fadeOut7_2.play();

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l3.setEffect(null);
                        l3.setVisible(false);

                        highScore_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> fadeOut7_2.stop());

                    });
                    highScore_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.setDuration(Duration.millis(1));
                        fadeOut2.setDuration(Duration.millis(1));
                        fadeOut3.setDuration(Duration.millis(200));
                        fadeOut5.setDuration(Duration.millis(200));
                        fadeOut6.setDuration(Duration.millis(200));
                        fadeOut6_1.setDuration(Duration.millis(200));
                        fadeOut6_2.setDuration(Duration.millis(200));
                        fadeOut7_2.setDuration(Duration.millis(200));

                        fadeOut.play();//exit
                        fadeOut2.play();//op
                        fadeOut3.play();//bgpanel
                        fadeOut7_2.play();//l3
                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        highScore_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.stop();//exit
                            fadeOut2.stop();//op
                            fadeOut3.stop();//bgpanel

                            fadeOut7_2.stop();//l3
                            fadeOut5.stop();//panel
                            fadeOut6.stop();//s
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                            fadeOut.setDuration(Duration.millis(1));
                            fadeOut2.setDuration(Duration.millis(500));
                            fadeOut3.setDuration(Duration.millis(500));
                            fadeOut5.setDuration(Duration.millis(500));
                            fadeOut6.setDuration(Duration.millis(500));
                            fadeOut6_1.setDuration(Duration.millis(500));
                            fadeOut6_2.setDuration(Duration.millis(500));
                            fadeOut7_2.setDuration(Duration.millis(500));

                        });

                    });
                    highScore_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            highScore_Clicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    });

                    playMulti_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        playMulti_btn.setGraphic(svgIconPlayMulti_Hover);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(effectBG_DropShadow);
                        playSingle_btn.setEffect(null);

                        fadeIn7_1.play();

                        l1.setEffect(null);
                        l2.setEffect(effectC_DropShadow);
                        l2.setVisible(true);
                        l3.setEffect(null);

                        playMulti_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> fadeIn7_1.stop());
                        playMulti_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e1 -> fadeIn7_1.stop());

                    });
                    playMulti_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        playMulti_btn.setGraphic(svgIconPlayMulti);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        fadeOut7_1.play();

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l2.setVisible(false);
                        l3.setEffect(null);

                        playMulti_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> fadeOut7_1.stop());



                    });
                    playMulti_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.setDuration(Duration.millis(1));
                        fadeOut2.setDuration(Duration.millis(1));
                        fadeOut3.setDuration(Duration.millis(200));
                        fadeOut5.setDuration(Duration.millis(200));
                        fadeOut6.setDuration(Duration.millis(200));
                        fadeOut6_1.setDuration(Duration.millis(200));
                        fadeOut6_2.setDuration(Duration.millis(200));
                        fadeOut7_1.setDuration(Duration.millis(200));

                        fadeOut.play();//exit_btn
                        fadeOut2.play();//exit_btn
                        fadeOut3.play();//bgpanel
                        fadeOut7_1.play();//l2
                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        playMulti_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.stop();//exit_btn
                            fadeOut2.stop();//exit_btn
                            fadeOut3.stop();//bgpanel
                            fadeOut7_1.stop();//l2
                            fadeOut5.stop();//panel
                            fadeOut6.stop();//s
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                            fadeOut.setDuration(Duration.millis(1));
                            fadeOut2.setDuration(Duration.millis(500));
                            fadeOut3.setDuration(Duration.millis(500));
                            fadeOut5.setDuration(Duration.millis(500));
                            fadeOut6.setDuration(Duration.millis(500));
                            fadeOut6_1.setDuration(Duration.millis(500));
                            fadeOut6_2.setDuration(Duration.millis(500));
                            fadeOut7_1.setDuration(Duration.millis(500));

                        });

                    });
                    playMulti_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {playMulti_Clicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    });

                    playSingle_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        playSingle_btn.setGraphic(svgIconPlaySingle_Hover);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(effectBG_DropShadow);

                        fadeIn7.play();

                        l1.setEffect(effectC_DropShadow);
                        l1.setVisible(true);
                        l2.setEffect(null);
                        l3.setEffect(null);

                        playSingle_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> fadeIn7.stop());
                        playSingle_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e1 -> fadeIn7.stop());

                    });
                    playSingle_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        playSingle_btn.setGraphic(svgIconPlaySingle);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        fadeOut7.play();

                        l1.setEffect(null);
                        l1.setVisible(false);
                        l2.setEffect(null);
                        l3.setEffect(null);

                        playSingle_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> fadeOut7.stop());

                    });
                    playSingle_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.setDuration(Duration.millis(1));
                        fadeOut2.setDuration(Duration.millis(1));
                        fadeOut3.setDuration(Duration.millis(200));
                        fadeOut5.setDuration(Duration.millis(200));
                        fadeOut6.setDuration(Duration.millis(200));
                        fadeOut6_1.setDuration(Duration.millis(200));
                        fadeOut6_2.setDuration(Duration.millis(200));
                        fadeOut7.setDuration(Duration.millis(200));

                        fadeOut.play();//exit
                        fadeOut2.play();//op
                        fadeOut3.play();//bgpanel
                        fadeOut7.play();//l1
                        fadeOut6.play();//s
                        fadeOut5.play();//panel
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        playSingle_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.stop();//exit
                            fadeOut2.stop();//op
                            fadeIn3.stop();//bgpanel
                            fadeOut7.stop();//l1
                            fadeOut6.stop();//s
                            fadeOut5.stop();//panel
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                            fadeOut.setDuration(Duration.millis(1));
                            fadeOut2.setDuration(Duration.millis(500));
                            fadeOut3.setDuration(Duration.millis(500));
                            fadeOut5.setDuration(Duration.millis(500));
                            fadeOut6.setDuration(Duration.millis(500));
                            fadeOut6_1.setDuration(Duration.millis(500));
                            fadeOut6_2.setDuration(Duration.millis(500));
                            fadeOut7.setDuration(Duration.millis(500));

                        });

                    });
                    playSingle_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {playSingle_Clicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    });

                    mainMenu.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        ex1.setVisible(true);
                        Panel1.setVisible(true);

                        fadeIn.play();//exit_btn
                        exit_btn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");

                        fadeOut4.play();//bl1
                        fadeOut4_1.play();//bl2
                        fadeOut3.play();//bgpanel

                        fadeIn5.play();//panel
                        fadeIn6.play();//s
                        fadeIn6_1.play();//m
                        fadeIn6_2.play();//h

                        mainMenu.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> {

                            fadeIn.stop();//exit_btn
                            fadeOut4.stop();//bl1
                            fadeOut4_1.stop();//bl2
                            fadeOut3.stop();//bgpanel

                            fadeIn5.stop();//panel
                            fadeIn6.stop();//s
                            fadeIn6_1.stop();//m
                            fadeIn6_2.stop();//h

                        });

                    });
                    mainMenu.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        fadeIn.play();//exit_btn
                        fadeIn4.play();//bl1
                        fadeIn4_1.play();//bl2
                        fadeIn3.play();//bgpanel

                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        exit_btn.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                        mainMenu.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> {

                            fadeIn.stop();//exit_btn
                            fadeIn4.stop();//bl1
                            fadeIn4_1.stop();//bl2
                            fadeIn3.stop();//bgpanel

                            fadeOut5.stop();//panel
                            fadeOut6.stop();//s
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                        });

                    });

                    option_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        option_btn.setGraphic(svgIconOption_Hover);
                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(effectC_InnerShadow);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l3.setEffect(null);
                    });
                    option_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        option_btn.setGraphic(svgIconOption);
                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l3.setEffect(null);
                    });
                    option_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.setDuration(Duration.millis(1));
                        fadeOut2.setDuration(Duration.millis(1));
                        fadeOut5.setDuration(Duration.millis(200));
                        fadeOut6.setDuration(Duration.millis(200));
                        fadeOut6_1.setDuration(Duration.millis(200));
                        fadeOut6_2.setDuration(Duration.millis(200));

                        fadeOut.play();//exit_btn
                        fadeOut2.play();//option
                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        option_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.setDuration(Duration.millis(1));
                            fadeOut2.setDuration(Duration.millis(1));
                            fadeOut5.setDuration(Duration.millis(500));
                            fadeOut6.setDuration(Duration.millis(500));
                            fadeOut6_1.setDuration(Duration.millis(500));
                            fadeOut6_2.setDuration(Duration.millis(500));

                            fadeOut.stop();//exit_btn
                            fadeOut2.stop();//option
                            fadeOut5.stop();//panel
                            fadeOut6.stop();//s
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                        });
                    });
                    option_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            settingsClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    });

                    exit_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        exit_btn.setGraphic(svgIconExitButton_Hover);

                        exit_btn.setEffect(effectC_DropShadow);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                    });
                    exit_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        exit_btn.setGraphic(svgIconExitButton);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                    });
                    exit_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut4.play();//bl1
                        fadeOut4_1.play();//bl2
                        fadeOut3.play();//bgpanel

                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        exit_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                        });

                    });

                }
                else if (tColor == 3) {

                    color2 = "#006500";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,86,0), 18, 0, 9, 9);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,116,0), 18, 0, -9, -9);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,86,0), 18, 0, 9, 9);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,116,0), 18, 0, -9, -9);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    effect_BGPANEL = new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,116,0), 40, 0, -20, -20);

                    effect_BGPANELLABELADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,86,0), 9, 0, 2,2);
                    effect_BGPANELLABEL = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,116,0), 9, 0, -2,-2);
                    effect_BGPANELLABEL.setInput(effect_BGPANELLABELADD);

                    svgFileExitButton = getClass().getResourceAsStream("../../../resources/svg/delete/delete_d.svg");
                    svgFileExitButton_Hover = getClass().getResourceAsStream("../../../resources/svg/delete/delete_dgreen.svg");

                    svgFileHighScore = getClass().getResourceAsStream("../../../resources/svg/podium/podium_d.svg");
                    svgFileHighScore_Hover = getClass().getResourceAsStream("../../../resources/svg/podium/podium_dgreen.svg");

                    svgFileOption = getClass().getResourceAsStream("../../../resources/svg/settings_d.svg");
                    svgFileOption_Hover = getClass().getResourceAsStream("../../../resources/svg/settings_green.svg");

                    svgFilePlayMulti = getClass().getResourceAsStream("../../../resources/svg/group/group_d.svg");
                    svgFilePlayMulti_Hover = getClass().getResourceAsStream("../../../resources/svg/group/group_d.svg");

                    svgFilePlaySingle = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlaySingle_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dgreen.svg");

                    Group svgImageExitButton = loader.loadSvg(svgFileExitButton);
                    Group svgImageExitButton_Hover = loader.loadSvg(svgFileExitButton_Hover);

                    Group svgImageHighScore = loader.loadSvg(svgFileHighScore);
                    Group svgImageHighScore_Hover = loader.loadSvg(svgFileHighScore_Hover);

                    Group svgImageOption = loader.loadSvg(svgFileOption);
                    Group svgImageOption_Hover = loader.loadSvg(svgFileOption_Hover);

                    Group svgImagePlayMulti = loader.loadSvg(svgFilePlayMulti);
                    Group svgImagePlayMulti_Hover = loader.loadSvg(svgFilePlayMulti_Hover);

                    Group svgImagePlaySingle = loader.loadSvg(svgFilePlaySingle);
                    Group svgImagePlaySingle_Hover = loader.loadSvg(svgFilePlaySingle_Hover);

                    svgImageExitButton.setScaleX(.03);
                    svgImageExitButton.setScaleY(.03);
                    svgImageExitButton_Hover.setScaleX(.03);
                    svgImageExitButton_Hover.setScaleY(.03);

                    svgImageHighScore.setScaleX(.06);
                    svgImageHighScore.setScaleY(.06);
                    svgImageHighScore_Hover.setScaleX(.06);
                    svgImageHighScore_Hover.setScaleY(.06);

                    svgImageOption.setScaleX(.04);
                    svgImageOption.setScaleY(.04);
                    svgImageOption_Hover.setScaleX(.04);
                    svgImageOption_Hover.setScaleY(.04);

                    svgImagePlayMulti.setScaleX(.1);
                    svgImagePlayMulti.setScaleY(.1);
                    svgImagePlayMulti_Hover.setScaleX(.1);
                    svgImagePlayMulti_Hover.setScaleY(.1);

                    svgImagePlaySingle.setScaleX(.06);
                    svgImagePlaySingle.setScaleY(.06);
                    svgImagePlaySingle_Hover.setScaleX(.06);
                    svgImagePlaySingle_Hover.setScaleY(.06);

                    Group svgIconExitButton = new Group(svgImageExitButton);
                    Group svgIconExitButton_Hover = new Group(svgImageExitButton_Hover);

                    Group svgIconHighScore = new Group(svgImageHighScore);
                    Group svgIconHighScore_Hover = new Group(svgImageHighScore_Hover);

                    Group svgIconOption = new Group(svgImageOption);
                    Group svgIconOption_Hover = new Group(svgImageOption_Hover);

                    Group svgIconPlayMulti = new Group(svgImagePlayMulti);
                    Group svgIconPlayMulti_Hover = new Group(svgImagePlayMulti_Hover);

                    Group svgIconPlaySingle = new Group(svgImagePlaySingle);
                    Group svgIconPlaySingle_Hover = new Group(svgImagePlaySingle_Hover);

                    exit_btn.setGraphic(svgIconExitButton);
                    highScore_btn.setGraphic(svgIconHighScore);
                    option_btn.setGraphic(svgIconOption);
                    playMulti_btn.setGraphic(svgIconPlayMulti);
                    playSingle_btn.setGraphic(svgIconPlaySingle);

                    Panelex.setEffect(effect_BGPANEL);

                    bt1.setEffect(effect_BGPANELLABEL);
                    bt2.setEffect(effect_BGPANELLABEL);
                    bt1.setTextFill(Color.web(color2));
                    bt2.setTextFill(Color.web(color2));

                    highScore_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        highScore_btn.setGraphic(svgIconHighScore_Hover);
                        highScore_btn.setEffect(effectBG_DropShadow);
                        exit_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        fadeIn7_2.play();

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l3.setEffect(effectC_DropShadow);
                        l3.setVisible(true);

                        highScore_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> fadeIn7_2.stop());
                        highScore_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e1 -> fadeIn7_2.stop());

                    });
                    highScore_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        highScore_btn.setGraphic(svgIconHighScore);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        fadeOut7_2.play();

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l3.setEffect(null);
                        l3.setVisible(false);

                        highScore_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> fadeOut7_2.stop());

                    });
                    highScore_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.setDuration(Duration.millis(1));
                        fadeOut2.setDuration(Duration.millis(1));
                        fadeOut3.setDuration(Duration.millis(200));
                        fadeOut5.setDuration(Duration.millis(200));
                        fadeOut6.setDuration(Duration.millis(200));
                        fadeOut6_1.setDuration(Duration.millis(200));
                        fadeOut6_2.setDuration(Duration.millis(200));
                        fadeOut7_2.setDuration(Duration.millis(200));

                        fadeOut.play();//exit
                        fadeOut2.play();//op
                        fadeOut3.play();//bgpanel
                        fadeOut7_2.play();//l3
                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        highScore_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.stop();//exit
                            fadeOut2.stop();//op
                            fadeOut3.stop();//bgpanel

                            fadeOut7_2.stop();//l3
                            fadeOut5.stop();//panel
                            fadeOut6.stop();//s
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                            fadeOut.setDuration(Duration.millis(1));
                            fadeOut2.setDuration(Duration.millis(500));
                            fadeOut3.setDuration(Duration.millis(500));
                            fadeOut5.setDuration(Duration.millis(500));
                            fadeOut6.setDuration(Duration.millis(500));
                            fadeOut6_1.setDuration(Duration.millis(500));
                            fadeOut6_2.setDuration(Duration.millis(500));
                            fadeOut7_2.setDuration(Duration.millis(500));

                        });

                    });
                    highScore_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            highScore_Clicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    });

                    playMulti_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        playMulti_btn.setGraphic(svgIconPlayMulti_Hover);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(effectBG_DropShadow);
                        playSingle_btn.setEffect(null);

                        fadeIn7_1.play();

                        l1.setEffect(null);
                        l2.setEffect(effectC_DropShadow);
                        l2.setVisible(true);
                        l3.setEffect(null);

                        playMulti_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> fadeIn7_1.stop());
                        playMulti_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e1 -> fadeIn7_1.stop());

                    });
                    playMulti_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        playMulti_btn.setGraphic(svgIconPlayMulti);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        fadeOut7_1.play();

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l2.setVisible(false);
                        l3.setEffect(null);

                        playMulti_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> fadeOut7_1.stop());



                    });
                    playMulti_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.setDuration(Duration.millis(1));
                        fadeOut2.setDuration(Duration.millis(1));
                        fadeOut3.setDuration(Duration.millis(200));
                        fadeOut5.setDuration(Duration.millis(200));
                        fadeOut6.setDuration(Duration.millis(200));
                        fadeOut6_1.setDuration(Duration.millis(200));
                        fadeOut6_2.setDuration(Duration.millis(200));
                        fadeOut7_1.setDuration(Duration.millis(200));

                        fadeOut.play();//exit_btn
                        fadeOut2.play();//exit_btn
                        fadeOut3.play();//bgpanel
                        fadeOut7_1.play();//l2
                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        playMulti_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.stop();//exit_btn
                            fadeOut2.stop();//exit_btn
                            fadeOut3.stop();//bgpanel
                            fadeOut7_1.stop();//l2
                            fadeOut5.stop();//panel
                            fadeOut6.stop();//s
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                            fadeOut.setDuration(Duration.millis(1));
                            fadeOut2.setDuration(Duration.millis(500));
                            fadeOut3.setDuration(Duration.millis(500));
                            fadeOut5.setDuration(Duration.millis(500));
                            fadeOut6.setDuration(Duration.millis(500));
                            fadeOut6_1.setDuration(Duration.millis(500));
                            fadeOut6_2.setDuration(Duration.millis(500));
                            fadeOut7_1.setDuration(Duration.millis(500));

                        });

                    });
                    playMulti_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {playMulti_Clicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    });

                    playSingle_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        playSingle_btn.setGraphic(svgIconPlaySingle_Hover);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(effectBG_DropShadow);

                        fadeIn7.play();

                        l1.setEffect(effectC_DropShadow);
                        l1.setVisible(true);
                        l2.setEffect(null);
                        l3.setEffect(null);

                        playSingle_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> fadeIn7.stop());
                        playSingle_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e1 -> fadeIn7.stop());

                    });
                    playSingle_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        playSingle_btn.setGraphic(svgIconPlaySingle);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        fadeOut7.play();

                        l1.setEffect(null);
                        l1.setVisible(false);
                        l2.setEffect(null);
                        l3.setEffect(null);

                        playSingle_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> fadeOut7.stop());

                    });
                    playSingle_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.setDuration(Duration.millis(1));
                        fadeOut2.setDuration(Duration.millis(1));
                        fadeOut3.setDuration(Duration.millis(200));
                        fadeOut5.setDuration(Duration.millis(200));
                        fadeOut6.setDuration(Duration.millis(200));
                        fadeOut6_1.setDuration(Duration.millis(200));
                        fadeOut6_2.setDuration(Duration.millis(200));
                        fadeOut7.setDuration(Duration.millis(200));

                        fadeOut.play();//exit
                        fadeOut2.play();//op
                        fadeOut3.play();//bgpanel
                        fadeOut7.play();//l1
                        fadeOut6.play();//s
                        fadeOut5.play();//panel
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        playSingle_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.stop();//exit
                            fadeOut2.stop();//op
                            fadeIn3.stop();//bgpanel
                            fadeOut7.stop();//l1
                            fadeOut6.stop();//s
                            fadeOut5.stop();//panel
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                            fadeOut.setDuration(Duration.millis(1));
                            fadeOut2.setDuration(Duration.millis(500));
                            fadeOut3.setDuration(Duration.millis(500));
                            fadeOut5.setDuration(Duration.millis(500));
                            fadeOut6.setDuration(Duration.millis(500));
                            fadeOut6_1.setDuration(Duration.millis(500));
                            fadeOut6_2.setDuration(Duration.millis(500));
                            fadeOut7.setDuration(Duration.millis(500));

                        });

                    });
                    playSingle_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {playSingle_Clicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    });

                    mainMenu.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        ex1.setVisible(true);
                        Panel1.setVisible(true);

                        fadeIn.play();//exit_btn
                        exit_btn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");

                        fadeOut4.play();//bl1
                        fadeOut4_1.play();//bl2
                        fadeOut3.play();//bgpanel

                        fadeIn5.play();//panel
                        fadeIn6.play();//s
                        fadeIn6_1.play();//m
                        fadeIn6_2.play();//h

                        mainMenu.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> {

                            fadeIn.stop();//exit_btn
                            fadeOut4.stop();//bl1
                            fadeOut4_1.stop();//bl2
                            fadeOut3.stop();//bgpanel

                            fadeIn5.stop();//panel
                            fadeIn6.stop();//s
                            fadeIn6_1.stop();//m
                            fadeIn6_2.stop();//h

                        });

                    });
                    mainMenu.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        fadeIn.play();//exit_btn
                        fadeIn4.play();//bl1
                        fadeIn4_1.play();//bl2
                        fadeIn3.play();//bgpanel

                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        exit_btn.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                        mainMenu.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> {

                            fadeIn.stop();//exit_btn
                            fadeIn4.stop();//bl1
                            fadeIn4_1.stop();//bl2
                            fadeIn3.stop();//bgpanel

                            fadeOut5.stop();//panel
                            fadeOut6.stop();//s
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                        });

                    });

                    option_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        option_btn.setGraphic(svgIconOption_Hover);
                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(effectC_InnerShadow);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l3.setEffect(null);
                    });
                    option_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        option_btn.setGraphic(svgIconOption);
                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l3.setEffect(null);
                    });
                    option_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.setDuration(Duration.millis(1));
                        fadeOut2.setDuration(Duration.millis(1));
                        fadeOut5.setDuration(Duration.millis(200));
                        fadeOut6.setDuration(Duration.millis(200));
                        fadeOut6_1.setDuration(Duration.millis(200));
                        fadeOut6_2.setDuration(Duration.millis(200));

                        fadeOut.play();//exit_btn
                        fadeOut2.play();//option
                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        option_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.setDuration(Duration.millis(1));
                            fadeOut2.setDuration(Duration.millis(1));
                            fadeOut5.setDuration(Duration.millis(500));
                            fadeOut6.setDuration(Duration.millis(500));
                            fadeOut6_1.setDuration(Duration.millis(500));
                            fadeOut6_2.setDuration(Duration.millis(500));

                            fadeOut.stop();//exit_btn
                            fadeOut2.stop();//option
                            fadeOut5.stop();//panel
                            fadeOut6.stop();//s
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                        });
                    });
                    option_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            settingsClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    });

                    exit_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        exit_btn.setGraphic(svgIconExitButton_Hover);

                        exit_btn.setEffect(effectC_DropShadow);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                    });
                    exit_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        exit_btn.setGraphic(svgIconExitButton);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                    });
                    exit_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut4.play();//bl1
                        fadeOut4_1.play();//bl2
                        fadeOut3.play();//bgpanel

                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        exit_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                        });

                    });

                }
                else if (tColor == 4) {

                    color2 = "#9b0000";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(155,0,0), 18, 0, 9, 9);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(178,0,0), 18, 0, -9, -9);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(155,0,0), 18, 0, 9, 9);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(178,0,0), 18, 0, -9, -9);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    effect_BGPANEL = new DropShadow(BlurType.GAUSSIAN, Color.rgb(178,0,0), 40, 0, -20, -20);

                    effect_BGPANELLABELADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(155,0,0), 9, 0, 2,2);
                    effect_BGPANELLABEL = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(178,0,0), 9, 0, -2,-2);
                    effect_BGPANELLABEL.setInput(effect_BGPANELLABELADD);

                    svgFileExitButton = getClass().getResourceAsStream("../../../resources/svg/delete/delete_d.svg");
                    svgFileExitButton_Hover = getClass().getResourceAsStream("../../../resources/svg/delete/delete_dred.svg");

                    svgFileHighScore = getClass().getResourceAsStream("../../../resources/svg/podium/podium_d.svg");
                    svgFileHighScore_Hover = getClass().getResourceAsStream("../../../resources/svg/podium/podium_dred.svg");

                    svgFileOption = getClass().getResourceAsStream("../../../resources/svg/settings_d.svg");
                    svgFileOption_Hover = getClass().getResourceAsStream("../../../resources/svg/settings_red.svg");

                    svgFilePlayMulti = getClass().getResourceAsStream("../../../resources/svg/group/group_d.svg");
                    svgFilePlayMulti_Hover = getClass().getResourceAsStream("../../../resources/svg/group/group_dred.svg");

                    svgFilePlaySingle = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlaySingle_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dred.svg");

                    Group svgImageExitButton = loader.loadSvg(svgFileExitButton);
                    Group svgImageExitButton_Hover = loader.loadSvg(svgFileExitButton_Hover);

                    Group svgImageHighScore = loader.loadSvg(svgFileHighScore);
                    Group svgImageHighScore_Hover = loader.loadSvg(svgFileHighScore_Hover);

                    Group svgImageOption = loader.loadSvg(svgFileOption);
                    Group svgImageOption_Hover = loader.loadSvg(svgFileOption_Hover);

                    Group svgImagePlayMulti = loader.loadSvg(svgFilePlayMulti);
                    Group svgImagePlayMulti_Hover = loader.loadSvg(svgFilePlayMulti_Hover);

                    Group svgImagePlaySingle = loader.loadSvg(svgFilePlaySingle);
                    Group svgImagePlaySingle_Hover = loader.loadSvg(svgFilePlaySingle_Hover);

                    svgImageExitButton.setScaleX(.03);
                    svgImageExitButton.setScaleY(.03);
                    svgImageExitButton_Hover.setScaleX(.03);
                    svgImageExitButton_Hover.setScaleY(.03);

                    svgImageHighScore.setScaleX(.06);
                    svgImageHighScore.setScaleY(.06);
                    svgImageHighScore_Hover.setScaleX(.06);
                    svgImageHighScore_Hover.setScaleY(.06);

                    svgImageOption.setScaleX(.04);
                    svgImageOption.setScaleY(.04);
                    svgImageOption_Hover.setScaleX(.04);
                    svgImageOption_Hover.setScaleY(.04);

                    svgImagePlayMulti.setScaleX(.1);
                    svgImagePlayMulti.setScaleY(.1);
                    svgImagePlayMulti_Hover.setScaleX(.1);
                    svgImagePlayMulti_Hover.setScaleY(.1);

                    svgImagePlaySingle.setScaleX(.06);
                    svgImagePlaySingle.setScaleY(.06);
                    svgImagePlaySingle_Hover.setScaleX(.06);
                    svgImagePlaySingle_Hover.setScaleY(.06);

                    Group svgIconExitButton = new Group(svgImageExitButton);
                    Group svgIconExitButton_Hover = new Group(svgImageExitButton_Hover);

                    Group svgIconHighScore = new Group(svgImageHighScore);
                    Group svgIconHighScore_Hover = new Group(svgImageHighScore_Hover);

                    Group svgIconOption = new Group(svgImageOption);
                    Group svgIconOption_Hover = new Group(svgImageOption_Hover);

                    Group svgIconPlayMulti = new Group(svgImagePlayMulti);
                    Group svgIconPlayMulti_Hover = new Group(svgImagePlayMulti_Hover);

                    Group svgIconPlaySingle = new Group(svgImagePlaySingle);
                    Group svgIconPlaySingle_Hover = new Group(svgImagePlaySingle_Hover);

                    exit_btn.setGraphic(svgIconExitButton);
                    highScore_btn.setGraphic(svgIconHighScore);
                    option_btn.setGraphic(svgIconOption);
                    playMulti_btn.setGraphic(svgIconPlayMulti);
                    playSingle_btn.setGraphic(svgIconPlaySingle);

                    Panelex.setEffect(effect_BGPANEL);

                    bt1.setEffect(effect_BGPANELLABEL);
                    bt2.setEffect(effect_BGPANELLABEL);
                    bt1.setTextFill(Color.web(color2));
                    bt2.setTextFill(Color.web(color2));

                    highScore_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        highScore_btn.setGraphic(svgIconHighScore_Hover);
                        highScore_btn.setEffect(effectBG_DropShadow);
                        exit_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        fadeIn7_2.play();

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l3.setEffect(effectC_DropShadow);
                        l3.setVisible(true);

                        highScore_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> fadeIn7_2.stop());
                        highScore_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e1 -> fadeIn7_2.stop());

                    });
                    highScore_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        highScore_btn.setGraphic(svgIconHighScore);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        fadeOut7_2.play();

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l3.setEffect(null);
                        l3.setVisible(false);

                        highScore_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> fadeOut7_2.stop());

                    });
                    highScore_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.setDuration(Duration.millis(1));
                        fadeOut2.setDuration(Duration.millis(1));
                        fadeOut3.setDuration(Duration.millis(200));
                        fadeOut5.setDuration(Duration.millis(200));
                        fadeOut6.setDuration(Duration.millis(200));
                        fadeOut6_1.setDuration(Duration.millis(200));
                        fadeOut6_2.setDuration(Duration.millis(200));
                        fadeOut7_2.setDuration(Duration.millis(200));

                        fadeOut.play();//exit
                        fadeOut2.play();//op
                        fadeOut3.play();//bgpanel
                        fadeOut7_2.play();//l3
                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        highScore_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.stop();//exit
                            fadeOut2.stop();//op
                            fadeOut3.stop();//bgpanel

                            fadeOut7_2.stop();//l3
                            fadeOut5.stop();//panel
                            fadeOut6.stop();//s
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                            fadeOut.setDuration(Duration.millis(1));
                            fadeOut2.setDuration(Duration.millis(500));
                            fadeOut3.setDuration(Duration.millis(500));
                            fadeOut5.setDuration(Duration.millis(500));
                            fadeOut6.setDuration(Duration.millis(500));
                            fadeOut6_1.setDuration(Duration.millis(500));
                            fadeOut6_2.setDuration(Duration.millis(500));
                            fadeOut7_2.setDuration(Duration.millis(500));

                        });

                    });
                    highScore_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            highScore_Clicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    });

                    playMulti_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        playMulti_btn.setGraphic(svgIconPlayMulti_Hover);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(effectBG_DropShadow);
                        playSingle_btn.setEffect(null);

                        fadeIn7_1.play();

                        l1.setEffect(null);
                        l2.setEffect(effectC_DropShadow);
                        l2.setVisible(true);
                        l3.setEffect(null);

                        playMulti_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> fadeIn7_1.stop());
                        playMulti_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e1 -> fadeIn7_1.stop());

                    });
                    playMulti_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        playMulti_btn.setGraphic(svgIconPlayMulti);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        fadeOut7_1.play();

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l2.setVisible(false);
                        l3.setEffect(null);

                        playMulti_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> fadeOut7_1.stop());



                    });
                    playMulti_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.setDuration(Duration.millis(1));
                        fadeOut2.setDuration(Duration.millis(1));
                        fadeOut3.setDuration(Duration.millis(200));
                        fadeOut5.setDuration(Duration.millis(200));
                        fadeOut6.setDuration(Duration.millis(200));
                        fadeOut6_1.setDuration(Duration.millis(200));
                        fadeOut6_2.setDuration(Duration.millis(200));
                        fadeOut7_1.setDuration(Duration.millis(200));

                        fadeOut.play();//exit_btn
                        fadeOut2.play();//exit_btn
                        fadeOut3.play();//bgpanel
                        fadeOut7_1.play();//l2
                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        playMulti_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.stop();//exit_btn
                            fadeOut2.stop();//exit_btn
                            fadeOut3.stop();//bgpanel
                            fadeOut7_1.stop();//l2
                            fadeOut5.stop();//panel
                            fadeOut6.stop();//s
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                            fadeOut.setDuration(Duration.millis(1));
                            fadeOut2.setDuration(Duration.millis(500));
                            fadeOut3.setDuration(Duration.millis(500));
                            fadeOut5.setDuration(Duration.millis(500));
                            fadeOut6.setDuration(Duration.millis(500));
                            fadeOut6_1.setDuration(Duration.millis(500));
                            fadeOut6_2.setDuration(Duration.millis(500));
                            fadeOut7_1.setDuration(Duration.millis(500));

                        });

                    });
                    playMulti_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {playMulti_Clicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    });

                    playSingle_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        playSingle_btn.setGraphic(svgIconPlaySingle_Hover);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(effectBG_DropShadow);

                        fadeIn7.play();

                        l1.setEffect(effectC_DropShadow);
                        l1.setVisible(true);
                        l2.setEffect(null);
                        l3.setEffect(null);

                        playSingle_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> fadeIn7.stop());
                        playSingle_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e1 -> fadeIn7.stop());

                    });
                    playSingle_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        playSingle_btn.setGraphic(svgIconPlaySingle);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        fadeOut7.play();

                        l1.setEffect(null);
                        l1.setVisible(false);
                        l2.setEffect(null);
                        l3.setEffect(null);

                        playSingle_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> fadeOut7.stop());

                    });
                    playSingle_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.setDuration(Duration.millis(1));
                        fadeOut2.setDuration(Duration.millis(1));
                        fadeOut3.setDuration(Duration.millis(200));
                        fadeOut5.setDuration(Duration.millis(200));
                        fadeOut6.setDuration(Duration.millis(200));
                        fadeOut6_1.setDuration(Duration.millis(200));
                        fadeOut6_2.setDuration(Duration.millis(200));
                        fadeOut7.setDuration(Duration.millis(200));

                        fadeOut.play();//exit
                        fadeOut2.play();//op
                        fadeOut3.play();//bgpanel
                        fadeOut7.play();//l1
                        fadeOut6.play();//s
                        fadeOut5.play();//panel
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        playSingle_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.stop();//exit
                            fadeOut2.stop();//op
                            fadeIn3.stop();//bgpanel
                            fadeOut7.stop();//l1
                            fadeOut6.stop();//s
                            fadeOut5.stop();//panel
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                            fadeOut.setDuration(Duration.millis(1));
                            fadeOut2.setDuration(Duration.millis(500));
                            fadeOut3.setDuration(Duration.millis(500));
                            fadeOut5.setDuration(Duration.millis(500));
                            fadeOut6.setDuration(Duration.millis(500));
                            fadeOut6_1.setDuration(Duration.millis(500));
                            fadeOut6_2.setDuration(Duration.millis(500));
                            fadeOut7.setDuration(Duration.millis(500));

                        });

                    });
                    playSingle_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {playSingle_Clicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    });

                    mainMenu.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        ex1.setVisible(true);
                        Panel1.setVisible(true);

                        fadeIn.play();//exit_btn
                        exit_btn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");

                        fadeOut4.play();//bl1
                        fadeOut4_1.play();//bl2
                        fadeOut3.play();//bgpanel

                        fadeIn5.play();//panel
                        fadeIn6.play();//s
                        fadeIn6_1.play();//m
                        fadeIn6_2.play();//h

                        mainMenu.addEventHandler(MouseEvent.MOUSE_EXITED, e1 -> {

                            fadeIn.stop();//exit_btn
                            fadeOut4.stop();//bl1
                            fadeOut4_1.stop();//bl2
                            fadeOut3.stop();//bgpanel

                            fadeIn5.stop();//panel
                            fadeIn6.stop();//s
                            fadeIn6_1.stop();//m
                            fadeIn6_2.stop();//h

                        });

                    });
                    mainMenu.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        fadeIn.play();//exit_btn
                        fadeIn4.play();//bl1
                        fadeIn4_1.play();//bl2
                        fadeIn3.play();//bgpanel

                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        exit_btn.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                        mainMenu.addEventHandler(MouseEvent.MOUSE_ENTERED, e1 -> {

                            fadeIn.stop();//exit_btn
                            fadeIn4.stop();//bl1
                            fadeIn4_1.stop();//bl2
                            fadeIn3.stop();//bgpanel

                            fadeOut5.stop();//panel
                            fadeOut6.stop();//s
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                        });

                    });

                    option_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        option_btn.setGraphic(svgIconOption_Hover);
                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(effectC_InnerShadow);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l3.setEffect(null);
                    });
                    option_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        option_btn.setGraphic(svgIconOption);
                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                        l1.setEffect(null);
                        l2.setEffect(null);
                        l3.setEffect(null);
                    });
                    option_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.setDuration(Duration.millis(1));
                        fadeOut2.setDuration(Duration.millis(1));
                        fadeOut5.setDuration(Duration.millis(200));
                        fadeOut6.setDuration(Duration.millis(200));
                        fadeOut6_1.setDuration(Duration.millis(200));
                        fadeOut6_2.setDuration(Duration.millis(200));

                        fadeOut.play();//exit_btn
                        fadeOut2.play();//option
                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        option_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                            fadeOut.setDuration(Duration.millis(1));
                            fadeOut2.setDuration(Duration.millis(1));
                            fadeOut5.setDuration(Duration.millis(500));
                            fadeOut6.setDuration(Duration.millis(500));
                            fadeOut6_1.setDuration(Duration.millis(500));
                            fadeOut6_2.setDuration(Duration.millis(500));

                            fadeOut.stop();//exit_btn
                            fadeOut2.stop();//option
                            fadeOut5.stop();//panel
                            fadeOut6.stop();//s
                            fadeOut6_1.stop();//m
                            fadeOut6_2.stop();//h

                        });
                    });
                    option_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            settingsClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    });

                    exit_btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        exit_btn.setGraphic(svgIconExitButton_Hover);

                        exit_btn.setEffect(effectC_DropShadow);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                    });
                    exit_btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        exit_btn.setGraphic(svgIconExitButton);

                        exit_btn.setEffect(null);
                        highScore_btn.setEffect(null);
                        option_btn.setEffect(null);
                        playMulti_btn.setEffect(null);
                        playSingle_btn.setEffect(null);

                    });
                    exit_btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut4.play();//bl1
                        fadeOut4_1.play();//bl2
                        fadeOut3.play();//bgpanel

                        fadeOut5.play();//panel
                        fadeOut6.play();//s
                        fadeOut6_1.play();//m
                        fadeOut6_2.play();//h

                        exit_btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e1 -> {

                        });

                    });

                }

            }

        }

    }

    private void playMulti_Clicked() throws IOException{
        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("../../../resources/view/MultiplayerSettings.fxml")));
        Stage stage = (Stage) playMulti_btn.getScene().getWindow();
        stage.getScene().setRoot(root);

        File f = new File("config.properties");
        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }
    }

    private void playSingle_Clicked() throws IOException{
        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("../../../resources/view/SingleModeSettings.fxml")));
        Stage stage = (Stage) playSingle_btn.getScene().getWindow();
        stage.getScene().setFill(Color.TRANSPARENT);
        stage.getScene().setRoot(root);

        File f = new File("config.properties");
        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }

    }

    private void settingsClicked() throws IOException{
        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        Parent root = FXMLLoader.load(getClass().getResource("../../../resources/view/SettingsPane.fxml"));
        Stage stage = (Stage) playSingle_btn.getScene().getWindow();
        stage.getScene().setRoot(root);
        stage.setResizable(false);
        stage.show();

        File f = new File("config.properties");
        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }
    }

    private void highScore_Clicked() throws IOException{
        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("../../../resources/view/HighScore.fxml")));
        Stage stage = (Stage) highScore_btn.getScene().getWindow();
        stage.getScene().setRoot(root);

        File f = new File("config.properties");
        if(f.exists()) {
            InputStream input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }

    }

    @FXML
    private void exitClicked() throws Exception{
        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        Stage primaryStage = (Stage) exit_btn.getScene().getWindow();

        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("../../../resources/view/Dialog.fxml")));

        Stage dialog = new Stage();
        dialog.setTitle("Exit");

        Scene scene = new Scene(root);
        scene.setFill(Color.TRANSPARENT);
        dialog.setScene(scene);
        dialog.initModality(Modality.WINDOW_MODAL);
        dialog.initOwner(primaryStage);
        dialog.initStyle(StageStyle.TRANSPARENT);
        dialog.setResizable(false);

        double centerXPosition = primaryStage.getX() + primaryStage.getWidth()/2d;
        double centerYPosition = primaryStage.getY() + primaryStage.getHeight()/2d;

        dialog.setOnShowing(event -> dialog.hide());

        dialog.setOnShown(event -> {
            dialog.setX(centerXPosition - dialog.getWidth()/2d);
            dialog.setY(centerYPosition - dialog.getHeight()/2d);
            dialog.show();
        });

        dialog.show();

    }




}
