package main.javafx.controllers.multiplayer;

import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.effect.*;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;
import main.javafx.model.GameMode;
import main.javafx.util.SvgLoader;

import java.io.*;
import java.util.Objects;
import java.util.Properties;

public class MultiplayerSettings {

    @FXML
    private BorderPane Panel1,Panel2,Panel3,gg1;
    @FXML
    private Pane Panelex,Panelex3;
    @FXML
    private Button backButton,multiplayer;
    @FXML
    private Button doubleMode,singleMode,hardModebtn,hellModebtn;
    @FXML
    private Button r1,r2,r3;
    @FXML
    private Button FrontlightTheme,FrontblackTheme,FrontredTheme,BacklightTheme,BackblackTheme,BackredTheme,UNOTheme;
    @FXML
    private Button start;
    @FXML
    private CheckBox g1listener,g2listener,g3listener,g4listener;
    @FXML
    private CheckBox r1listener,r2listener,r3listener;
    @FXML
    private CheckBox t1alistener,t2alistener,t3alistener,t1blistener,t2blistener,t3blistener,t4listener;
    @FXML
    private GridPane Panelg1,Panelex2,Panelex4;
    @FXML
    private Label gamemodeLabel,themesLabel,rivalsLabel,l1,l2,l3;
    private int clicks,random1,random2,random3,wins1,wins2,wins3,wins4;
    private GameMode mode;
    private Image theme;
    private String goldfish,kangaroo,elephant;
    private double xOffset = 0;
    private double yOffset = 0;
    private Properties properties = new Properties();
    private Properties properties2 = new Properties();
    private Properties properties3 = new Properties();

    private InputStream input = null;
    private InputStream input2 = null;
    private InputStream input3 = null;
    private OutputStream output = null;
    private OutputStream output2 = null;
    private OutputStream output3 = null;

    private MediaPlayer mediaPlayer;
    String color,color2;
    public MultiplayerSettings(){
        mode = new GameMode();
        Media buttonSound = new Media(new File("src/main/resources/Sounds/buttonSound.wav").toURI().toString());
        mediaPlayer = new MediaPlayer(buttonSound);
    }

    @FXML
    public void initialize()throws IOException{
        File f2 =new File("score.properties");
        File f =new File("config.properties");

        if(f.exists()) {
            input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            int theme = Integer.parseInt(properties.getProperty("TMode"));
            int tColor = Integer.parseInt(properties.getProperty("TColor"));

            if(width == 999 ){

                backButton.setPrefSize(64,64);

                if(theme==1){
                    color = "#f3f5f7";

                    if (tColor==1){
                        color2 = "#007aff";

                        gg1.setStyle("-fx-background-color: "+color2+";");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 0 0 0;");
                        Panelex3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==2){
                        color2 = "#fff44f";

                        gg1.setStyle("-fx-background-color: "+color2+";");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 0 0 0;");
                        Panelex3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==3){
                        color2 = "#00c853";
                        gg1.setStyle("-fx-background-color: "+color2+";");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 0 0 0;");
                        Panelex3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==4){
                        color2 = "#d50000";
                        gg1.setStyle("-fx-background-color: "+color2+";");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 0 0 0;");
                        Panelex3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }

                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));

                    Panelex.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 0 0;");
                    Panelg1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 0 0;");
                    Panelex4.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 0 36;");

                    //BUTTON
                    backButton.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");

                }
                else if(theme==2){
                    color = "#181818";

                    if (tColor==1){
                        color2 = "#004fcb";

                        gg1.setStyle("-fx-background-color: "+color2+";");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 0 0 0;");
                        Panelex3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==2){
                        color2 = "#c9c208";

                        gg1.setStyle("-fx-background-color: "+color2+";");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 0 0 0;");
                        Panelex3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==3){
                        color2 = "#006500";

                        gg1.setStyle("-fx-background-color: "+color2+";");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 0 0 0;");
                        Panelex3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==4){
                        color2 = "#9b0000";

                        gg1.setStyle("-fx-background-color: "+color2+";");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 0 0 0;");
                        Panelex3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }

                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));

                    Panel1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");
                    Panel2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");
                    Panel3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");

                    doubleMode.setStyle("-fx-background-color: #121212; -fx-background-radius: 36 36 36 36");
                    singleMode.setStyle("-fx-background-color: #121212; -fx-background-radius: 36 36 36 36");
                    hardModebtn.setStyle("-fx-background-color: #121212; -fx-background-radius: 36 36 36 36");
                    hellModebtn.setStyle("-fx-background-color: #121212; -fx-background-radius: 36 36 36 36");
                    r1.setStyle("-fx-background-color: #121212; -fx-background-radius: 16 16 16 16");
                    r2.setStyle("-fx-background-color: #121212; -fx-background-radius: 16 16 16 16");
                    r3.setStyle("-fx-background-color: #121212; -fx-background-radius: 16 16 16 16");
                    multiplayer.setStyle("-fx-background-color: #121212; -fx-background-radius: 36 36 36 36");

                    Panelex.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 0 0;");
                    Panelg1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 0 0;");
                    Panelex4.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 0 36;");

                    //BUTTON
                    backButton.setStyle("-fx-background-color: #121212; -fx-background-radius: 50%;");

                }

            }
            else if(width == 1600 ){
                backButton.setPrefSize(64,64);

                if(theme==1){
                    color = "#f3f5f7";

                    if (tColor==1){
                        color2 = "#007aff";

                        gg1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 0 0;");
                        Panelex3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                    }
                    else if (tColor==2){
                        color2 = "#fff44f";

                        gg1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 0 0;");
                        Panelex3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                    }
                    else if (tColor==3){
                        color2 = "#00c853";
                        gg1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 0 0;");
                        Panelex3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                    }
                    else if (tColor==4){
                        color2 = "#d50000";

                        gg1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 0 0;");
                        Panelex3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                    }

                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));

                    Panelex.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 34 0 0;");
                    Panelg1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 34 34");
                    Panelex4.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 0 36;");

                    //BUTTON
                    backButton.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");


                }
                else if(theme==2){
                    color = "#181818";

                    if (tColor==1){
                        color2 = "#004fcb";

                        gg1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 0 0;");
                        Panelex3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==2){
                        color2 = "#c9c208";

                        gg1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 0 0;");
                        Panelex3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==3){
                        color2 = "#006500";

                        gg1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 0 0;");
                        Panelex3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==4){
                        color2 = "#9b0000";

                        gg1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 0 0;");
                        Panelex3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }

                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));

                    Panelex.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 34 34 0 0;");
                    Panelg1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 34 34;");
                    Panelex4.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 0 36;");

                    Panel1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");
                    Panel2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");
                    Panel3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");

                    doubleMode.setStyle("-fx-background-color: #121212; -fx-background-radius: 36 36 36 36");
                    singleMode.setStyle("-fx-background-color: #121212; -fx-background-radius: 36 36 36 36");
                    hardModebtn.setStyle("-fx-background-color: #121212; -fx-background-radius: 36 36 36 36");
                    hellModebtn.setStyle("-fx-background-color: #121212; -fx-background-radius: 36 36 36 36");
                    r1.setStyle("-fx-background-color: #121212; -fx-background-radius: 16 16 16 16");
                    r2.setStyle("-fx-background-color: #121212; -fx-background-radius: 16 16 16 16");
                    r3.setStyle("-fx-background-color: #121212; -fx-background-radius: 16 16 16 16");
                    multiplayer.setStyle("-fx-background-color: #121212; -fx-background-radius: 36 36 36 36");

                    //BUTTON
                    backButton.setStyle("-fx-background-color: #121212; -fx-background-radius: 50%;");

                }

            }
            else if(width == 1280){

                if(theme==1){
                    color = "#f3f5f7";

                    if (tColor==1){
                        color2 = "#007aff";

                        gg1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 0 0;");
                        Panelex3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                    }
                    else if (tColor==2){
                        color2 = "#fff44f";

                        gg1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 0 0;");
                        Panelex3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                    }
                    else if (tColor==3){
                        color2 = "#00c853";
                        gg1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 0 0;");
                        Panelex3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                    }
                    else if (tColor==4){
                        color2 = "#d50000";

                        gg1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 0 0;");
                        Panelex3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                    }

                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));

                    Panelex.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 34 0 0;");
                    Panelg1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 34 34");
                    Panelex4.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 0 36;");

                    //BUTTON
                    backButton.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");


                }
                else if(theme==2){
                    color = "#181818";

                    if (tColor==1){
                        color2 = "#004fcb";

                        gg1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 0 0;");
                        Panelex3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==2){
                        color2 = "#c9c208";

                        gg1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 0 0;");
                        Panelex3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==3){
                        color2 = "#006500";

                        gg1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 0 0;");
                        Panelex3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==4){
                        color2 = "#9b0000";

                        gg1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        Panelex2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 0 0;");
                        Panelex3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }

                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));

                    Panelex.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 34 34 0 0;");
                    Panelg1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 34 34;");
                    Panelex4.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 0 36;");

                    Panel1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");
                    Panel2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");
                    Panel3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36;");

                    doubleMode.setStyle("-fx-background-color: #121212; -fx-background-radius: 36 36 36 36");
                    singleMode.setStyle("-fx-background-color: #121212; -fx-background-radius: 36 36 36 36");
                    hardModebtn.setStyle("-fx-background-color: #121212; -fx-background-radius: 36 36 36 36");
                    hellModebtn.setStyle("-fx-background-color: #121212; -fx-background-radius: 36 36 36 36");
                    r1.setStyle("-fx-background-color: #121212; -fx-background-radius: 16 16 16 16");
                    r2.setStyle("-fx-background-color: #121212; -fx-background-radius: 16 16 16 16");
                    r3.setStyle("-fx-background-color: #121212; -fx-background-radius: 16 16 16 16");
                    multiplayer.setStyle("-fx-background-color: #121212; -fx-background-radius: 36 36 36 36");

                    //BUTTON
                    backButton.setStyle("-fx-background-color: #121212; -fx-background-radius: 50%;");

                }
            }

        }

        if(f2.exists()){
            input2 = new FileInputStream("score.properties");
            properties2.load(input2);
            wins1 = Integer.parseInt(properties2.getProperty("MultiplayerWins1"));
            wins2 = Integer.parseInt(properties2.getProperty("MultiplayerWins2"));
            wins3 = Integer.parseInt(properties2.getProperty("MultiplayerWins3"));
            wins4 = Integer.parseInt(properties2.getProperty("MultiplayerWins4"));
        }
        themeHandler();
    }
    private void themeHandler() throws IOException {

        DropShadow effectBG_DropShadowADD,effectBG_DropShadow,effectC_DropShadowADD,effectC_DropShadow;

        FadeTransition fadeIn = new FadeTransition();//exit_btn
        FadeTransition fadeIn2 = new FadeTransition();//l1
        FadeTransition fadeIn3 = new FadeTransition();//l2
        FadeTransition fadeIn4 = new FadeTransition();//l3
        FadeTransition fadeIn5 = new FadeTransition();//body
        FadeTransition fadeIn5_1 = new FadeTransition();//body
        FadeTransition fadeIn5_2 = new FadeTransition();//body
        FadeTransition fadeIn6 = new FadeTransition();//p1
        FadeTransition fadeIn7 = new FadeTransition();//p2
        FadeTransition fadeIn8 = new FadeTransition();//p3
        FadeTransition fadeIn9 = new FadeTransition();//button
        FadeTransition fadeIn9_1 = new FadeTransition();//button
        FadeTransition fadeIn9_2 = new FadeTransition();//button
        FadeTransition fadeIn9_3 = new FadeTransition();//button
        FadeTransition fadeIn9_4 = new FadeTransition();//button
        FadeTransition fadeIn9_5 = new FadeTransition();//button
        FadeTransition fadeIn9_6 = new FadeTransition();//button
        FadeTransition fadeIn9_7 = new FadeTransition();//button
        FadeTransition fadeIn9_8 = new FadeTransition();//button
        FadeTransition fadeIn9_9 = new FadeTransition();//button
        FadeTransition fadeIn9_10 = new FadeTransition();//button
        FadeTransition fadeIn9_11 = new FadeTransition();//button
        FadeTransition fadeIn9_12 = new FadeTransition();//button
        FadeTransition fadeIn9_13 = new FadeTransition();//button

        FadeTransition fadeOut = new FadeTransition();//exit_btn
        FadeTransition fadeOut2 = new FadeTransition();//l1
        FadeTransition fadeOut3 = new FadeTransition();//l2
        FadeTransition fadeOut4 = new FadeTransition();//l3
        FadeTransition fadeOut5 = new FadeTransition();//body
        FadeTransition fadeOut5_1 = new FadeTransition();//body
        FadeTransition fadeOut5_2 = new FadeTransition();//body
        FadeTransition fadeOut6 = new FadeTransition();//p1
        FadeTransition fadeOut7 = new FadeTransition();//p2
        FadeTransition fadeOut8 = new FadeTransition();//p3
        FadeTransition fadeOut9 = new FadeTransition();//button
        FadeTransition fadeOut9_1 = new FadeTransition();//button
        FadeTransition fadeOut9_2 = new FadeTransition();//button
        FadeTransition fadeOut9_3 = new FadeTransition();//button
        FadeTransition fadeOut9_4 = new FadeTransition();//button
        FadeTransition fadeOut9_5 = new FadeTransition();//button
        FadeTransition fadeOut9_6 = new FadeTransition();//button
        FadeTransition fadeOut9_7 = new FadeTransition();//button
        FadeTransition fadeOut9_8 = new FadeTransition();//button
        FadeTransition fadeOut9_9 = new FadeTransition();//button
        FadeTransition fadeOut9_10 = new FadeTransition();//button
        FadeTransition fadeOut9_11 = new FadeTransition();//button
        FadeTransition fadeOut9_12 = new FadeTransition();//button
        FadeTransition fadeOut9_13 = new FadeTransition();//button

        InnerShadow effectBG_InnerShadowADD,effectBG_InnerShadow,effectC_InnerShadowADD,effectC_InnerShadow;
        InputStream svgFileBackButton, svgFileBackButton_Hover,svgFileOption,svgFileOption_Hover;

        String color,color2;

        final SvgLoader loader = new SvgLoader();

        File f = new File("config.properties");
        File f3 = new File("gamemode.properties");

        GaussianBlur blur = new GaussianBlur(5);

        fadeIn.setDuration(Duration.millis(100));
        fadeIn2.setDuration(Duration.millis(450));
        fadeIn3.setDuration(Duration.millis(450));
        fadeIn4.setDuration(Duration.millis(450));

        fadeIn5.setDuration(Duration.millis(600));
        fadeIn5_1.setDuration(Duration.millis(600));
        fadeIn5_2.setDuration(Duration.millis(600));

        fadeIn6.setDuration(Duration.millis(650));
        fadeIn7.setDuration(Duration.millis(650));
        fadeIn8.setDuration(Duration.millis(650));

        fadeIn9.setDuration(Duration.millis(700));
        fadeIn9_1.setDuration(Duration.millis(800));
        fadeIn9_2.setDuration(Duration.millis(900));
        fadeIn9_3.setDuration(Duration.millis(1000));

        fadeIn9_4.setDuration(Duration.millis(650));
        fadeIn9_5.setDuration(Duration.millis(750));
        fadeIn9_6.setDuration(Duration.millis(1000));

        fadeIn9_7.setDuration(Duration.millis(650));
        fadeIn9_8.setDuration(Duration.millis(750));
        fadeIn9_9.setDuration(Duration.millis(1000));

        fadeIn9_10.setDuration(Duration.millis(1000));

        fadeIn9_11.setDuration(Duration.millis(650));
        fadeIn9_12.setDuration(Duration.millis(750));
        fadeIn9_13.setDuration(Duration.millis(1000));

        fadeOut.setDuration(Duration.millis(100));
        fadeOut2.setDuration(Duration.millis(100));
        fadeOut3.setDuration(Duration.millis(100));
        fadeOut4.setDuration(Duration.millis(100));

        fadeOut5.setDuration(Duration.millis(100));
        fadeOut5_1.setDuration(Duration.millis(100));
        fadeOut5_2.setDuration(Duration.millis(100));

        fadeOut6.setDuration(Duration.millis(100));
        fadeOut7.setDuration(Duration.millis(100));
        fadeOut8.setDuration(Duration.millis(100));

        fadeOut9.setDuration(Duration.millis(100));
        fadeOut9_1.setDuration(Duration.millis(100));
        fadeOut9_2.setDuration(Duration.millis(100));
        fadeOut9_3.setDuration(Duration.millis(100));

        fadeOut9_4.setDuration(Duration.millis(100));
        fadeOut9_5.setDuration(Duration.millis(100));
        fadeOut9_6.setDuration(Duration.millis(100));

        fadeOut9_7.setDuration(Duration.millis(100));
        fadeOut9_8.setDuration(Duration.millis(100));
        fadeOut9_9.setDuration(Duration.millis(100));

        fadeOut9_10.setDuration(Duration.millis(100));

        fadeOut9_11.setDuration(Duration.millis(100));
        fadeOut9_12.setDuration(Duration.millis(100));
        fadeOut9_13.setDuration(Duration.millis(100));

        fadeIn.setFromValue(0);
        fadeIn.setToValue(10);
        fadeIn2.setFromValue(0);
        fadeIn2.setToValue(10);
        fadeIn3.setFromValue(0);
        fadeIn3.setToValue(10);
        fadeIn4.setFromValue(0);
        fadeIn4.setToValue(10);
        fadeIn5.setFromValue(0);
        fadeIn5.setToValue(10);
        fadeIn5_1.setFromValue(0);
        fadeIn5_1.setToValue(10);
        fadeIn5_2.setFromValue(0);
        fadeIn5_2.setToValue(10);

        fadeIn6.setFromValue(0);
        fadeIn6.setToValue(10);
        fadeIn7.setFromValue(0);
        fadeIn7.setToValue(10);
        fadeIn8.setFromValue(0);
        fadeIn8.setToValue(10);

        fadeIn9.setFromValue(0);
        fadeIn9.setToValue(10);
        fadeIn9_1.setFromValue(0);
        fadeIn9_1.setToValue(10);
        fadeIn9_2.setFromValue(0);
        fadeIn9_2.setToValue(10);
        fadeIn9_3.setFromValue(0);
        fadeIn9_3.setToValue(10);
        fadeIn9_4.setFromValue(0);
        fadeIn9_4.setToValue(10);
        fadeIn9_5.setFromValue(0);
        fadeIn9_5.setToValue(10);
        fadeIn9_6.setFromValue(0);
        fadeIn9_6.setToValue(10);
        fadeIn9_7.setFromValue(0);
        fadeIn9_7.setToValue(10);
        fadeIn9_8.setFromValue(0);
        fadeIn9_8.setToValue(10);
        fadeIn9_9.setFromValue(0);
        fadeIn9_9.setToValue(10);
        fadeIn9_10.setFromValue(0);
        fadeIn9_10.setToValue(10);
        fadeIn9_11.setFromValue(0);
        fadeIn9_11.setToValue(10);
        fadeIn9_12.setFromValue(0);
        fadeIn9_12.setToValue(10);
        fadeIn9_13.setFromValue(0);
        fadeIn9_13.setToValue(10);

        fadeOut.setFromValue(10);
        fadeOut.setToValue(0);
        fadeOut2.setFromValue(10);
        fadeOut2.setToValue(0);
        fadeOut3.setFromValue(10);
        fadeOut3.setToValue(0);
        fadeOut4.setFromValue(10);
        fadeOut4.setToValue(0);
        fadeOut5.setFromValue(10);
        fadeOut5.setToValue(0);
        fadeOut5_1.setFromValue(10);
        fadeOut5_1.setToValue(0);
        fadeOut5_2.setFromValue(10);
        fadeOut5_2.setToValue(0);

        fadeOut6.setFromValue(10);
        fadeOut6.setToValue(0);
        fadeOut7.setFromValue(10);
        fadeOut7.setToValue(0);
        fadeOut8.setFromValue(10);
        fadeOut8.setToValue(0);

        fadeOut9.setFromValue(10);
        fadeOut9.setToValue(0);
        fadeOut9_1.setFromValue(10);
        fadeOut9_1.setToValue(0);
        fadeOut9_2.setFromValue(10);
        fadeOut9_2.setToValue(0);
        fadeOut9_3.setFromValue(10);
        fadeOut9_3.setToValue(0);
        fadeOut9_4.setFromValue(10);
        fadeOut9_4.setToValue(0);
        fadeOut9_5.setFromValue(10);
        fadeOut9_5.setToValue(0);
        fadeOut9_6.setFromValue(10);
        fadeOut9_6.setToValue(0);
        fadeOut9_7.setFromValue(10);
        fadeOut9_7.setToValue(0);
        fadeOut9_8.setFromValue(10);
        fadeOut9_8.setToValue(0);
        fadeOut9_9.setFromValue(10);
        fadeOut9_9.setToValue(0);
        fadeOut9_10.setFromValue(10);
        fadeOut9_10.setToValue(0);
        fadeOut9_11.setFromValue(10);
        fadeOut9_11.setToValue(0);
        fadeOut9_12.setFromValue(10);
        fadeOut9_12.setToValue(0);
        fadeOut9_13.setFromValue(10);
        fadeOut9_13.setToValue(0);

        fadeIn.setCycleCount(1);
        fadeIn2.setCycleCount(1);
        fadeIn3.setCycleCount(1);
        fadeIn4.setCycleCount(1);
        fadeIn5.setCycleCount(1);
        fadeIn5_1.setCycleCount(1);
        fadeIn5_2.setCycleCount(1);
        fadeIn6.setCycleCount(1);
        fadeIn7.setCycleCount(1);
        fadeIn8.setCycleCount(1);
        fadeIn9.setCycleCount(1);
        fadeIn9_1.setCycleCount(1);
        fadeIn9_2.setCycleCount(1);
        fadeIn9_3.setCycleCount(1);
        fadeIn9_4.setCycleCount(1);
        fadeIn9_5.setCycleCount(1);
        fadeIn9_6.setCycleCount(1);
        fadeIn9_7.setCycleCount(1);
        fadeIn9_8.setCycleCount(1);
        fadeIn9_9.setCycleCount(1);
        fadeIn9_10.setCycleCount(1);
        fadeIn9_11.setCycleCount(1);
        fadeIn9_12.setCycleCount(1);
        fadeIn9_13.setCycleCount(1);

        fadeOut.setCycleCount(1);
        fadeOut2.setCycleCount(1);
        fadeOut3.setCycleCount(1);
        fadeOut4.setCycleCount(1);
        fadeOut5.setCycleCount(1);
        fadeOut5_1.setCycleCount(1);
        fadeOut5_2.setCycleCount(1);
        fadeOut6.setCycleCount(1);
        fadeOut7.setCycleCount(1);
        fadeOut8.setCycleCount(1);
        fadeOut9.setCycleCount(1);
        fadeOut9_1.setCycleCount(1);
        fadeOut9_2.setCycleCount(1);
        fadeOut9_3.setCycleCount(1);
        fadeOut9_4.setCycleCount(1);
        fadeOut9_5.setCycleCount(1);
        fadeOut9_6.setCycleCount(1);
        fadeOut9_7.setCycleCount(1);
        fadeOut9_8.setCycleCount(1);
        fadeOut9_9.setCycleCount(1);
        fadeOut9_10.setCycleCount(1);
        fadeOut9_11.setCycleCount(1);
        fadeOut9_12.setCycleCount(1);
        fadeOut9_13.setCycleCount(1);

        fadeIn.setNode(backButton);
        fadeIn2.setNode(l1);
        fadeIn3.setNode(l2);
        fadeIn4.setNode(l3);
        fadeIn5.setNode(Panelg1);
        fadeIn5_1.setNode(Panelex);
        fadeIn5_2.setNode(Panelex4);
        fadeIn6.setNode(Panel1);
        fadeIn7.setNode(Panel2);
        fadeIn8.setNode(Panel3);
        fadeIn9.setNode(singleMode);
        fadeIn9_1.setNode(doubleMode);
        fadeIn9_2.setNode(hardModebtn);
        fadeIn9_3.setNode(hellModebtn);
        fadeIn9_4.setNode(FrontlightTheme);
        fadeIn9_5.setNode(FrontblackTheme);
        fadeIn9_6.setNode(FrontredTheme);
        fadeIn9_7.setNode(BacklightTheme);
        fadeIn9_8.setNode(BackblackTheme);
        fadeIn9_9.setNode(BackredTheme);
        fadeIn9_10.setNode(UNOTheme);
        fadeIn9_11.setNode(r1);
        fadeIn9_12.setNode(r2);
        fadeIn9_13.setNode(r3);

        fadeOut5.setNode(Panelg1);
        fadeOut5_1.setNode(Panelex);
        fadeOut5_2.setNode(Panelex4);
        fadeOut.setNode(backButton);
        fadeOut2.setNode(l1);
        fadeOut3.setNode(l2);
        fadeOut4.setNode(l3);
        fadeOut6.setNode(Panel1);
        fadeOut7.setNode(Panel2);
        fadeOut8.setNode(Panel3);
        fadeOut9.setNode(singleMode);
        fadeOut9_1.setNode(doubleMode);
        fadeOut9_2.setNode(hardModebtn);
        fadeOut9_3.setNode(hellModebtn);
        fadeOut9_4.setNode(FrontlightTheme);;
        fadeOut9_5.setNode(FrontblackTheme);
        fadeOut9_6.setNode(FrontredTheme);
        fadeOut9_7.setNode(BacklightTheme);
        fadeOut9_8.setNode(BackblackTheme);
        fadeOut9_9.setNode(BackredTheme);
        fadeOut9_10.setNode(UNOTheme);
        fadeOut9_11.setNode(r1);
        fadeOut9_12.setNode(r2);
        fadeOut9_13.setNode(r3);

        if(f.exists()) {

            input = new FileInputStream("config.properties");
            properties.load(input);

            int theme = Integer.parseInt(properties.getProperty("TMode"));
            int tColor = Integer.parseInt(properties.getProperty("TColor"));
            int menuSelected = Integer.parseInt(properties.getProperty("MenuSelected"));

            if (menuSelected==1){

                fadeIn5.play();
                fadeIn5_1.play();
                fadeIn5_2.play();
                fadeIn.play();
                fadeIn2.play();
                fadeIn3.play();
                fadeIn4.play();
                fadeIn6.play();
                fadeIn7.play();
                fadeIn8.play();
                fadeIn9.play();
                fadeIn9_1.play();
                fadeIn9_2.play();
                fadeIn9_3.play();
                fadeIn9_4.play();
                fadeIn9_5.play();
                fadeIn9_6.play();
                fadeIn9_7.play();
                fadeIn9_8.play();
                fadeIn9_9.play();
                fadeIn9_10.play();
                fadeIn9_11.play();
                fadeIn9_12.play();
                fadeIn9_13.play();

                output = new FileOutputStream("config.properties");
                properties.setProperty("MenuSelected", "2");
                properties.store(output, null);

            }
            else {

            }

            if (theme == 1) {

                color = "#f3f5f7";

                effectBG_DropShadowADD = new DropShadow(BlurType.GAUSSIAN, Color.rgb(206,207,210), 36, 0, 9, 9);
                effectBG_DropShadow = new DropShadow(BlurType.GAUSSIAN, Color.rgb(255,255,255), 10, 0, 5, 5);
                effectBG_DropShadow.setInput(effectBG_DropShadowADD);

                effectBG_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(206,207,210), 10, 0, 5, 5);
                effectBG_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(255,255,255), 10, 0, 5, 5);
                effectBG_InnerShadow.setInput(effectBG_InnerShadowADD);

                Panel1.setEffect(effectBG_DropShadow);
                Panel2.setEffect(effectBG_DropShadow);
                Panel3.setEffect(effectBG_DropShadow);

                if (tColor == 1) {

                    color2 = "#007aff";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,104,217), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,140,255), 10, 0, 5, 5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,104,217), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,140,255), 10, 0, 5, 5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBackButton = getClass().getResourceAsStream("../../../resources/svg/left_arrow/left-arrow.svg");
                    svgFileBackButton_Hover = getClass().getResourceAsStream("../../../resources/svg/left_arrow/left-arrow_blue.svg");

                    svgFileOption = getClass().getResourceAsStream("../../../resources/svg/menu/menu.svg");
                    svgFileOption_Hover = getClass().getResourceAsStream("../../../resources/svg/menu/menu_blue.svg");

                    Group svgImageBackButton = loader.loadSvg(svgFileBackButton);
                    Group svgImageBackButton_Hover = loader.loadSvg(svgFileBackButton_Hover);

                    Group svgImageOption = loader.loadSvg(svgFileOption);
                    Group svgImageOption_Hover = loader.loadSvg(svgFileOption_Hover);

                    svgImageBackButton.setScaleX(.04);
                    svgImageBackButton.setScaleY(.04);
                    svgImageBackButton_Hover.setScaleX(.04);
                    svgImageBackButton_Hover.setScaleY(.04);

                    svgImageOption.setScaleX(.04);
                    svgImageOption.setScaleY(.04);
                    svgImageOption_Hover.setScaleX(.04);
                    svgImageOption_Hover.setScaleY(.04);

                    Group svgIconBackButton = new Group(svgImageBackButton);
                    Group svgIconBackButton_Hover = new Group(svgImageBackButton_Hover);

                    Group svgIconOption = new Group(svgImageOption);
                    Group svgIconOption_Hover = new Group(svgImageOption_Hover);

                    backButton.setGraphic(svgIconOption);

                    fadeIn.setDuration(Duration.millis(500));
                    fadeOut.setDuration(Duration.millis(200));

                    fadeIn.setFromValue(0);
                    fadeIn.setToValue(10);

                    fadeOut.setFromValue(10);
                    fadeOut.setToValue(0);

                    fadeIn.setCycleCount(1);
                    fadeOut.setCycleCount(1);

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        backButton.setEffect(effectC_DropShadow);
                        backButton.setGraphic(svgIconBackButton);

                        l1.setText("");
                        l2.setText("Back to Home");
                        l3.setText("");

                        Panel1.setEffect(blur);
                        Panel2.setEffect(blur);
                        Panel3.setEffect(blur);
                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        backButton.setEffect(null);
                        backButton.setGraphic(svgIconOption);

                        l1.setText("MEMORY");
                        l2.setText("GAME");
                        l3.setText("Mᴜʟᴛɪ Pʟᴀʏᴇʀ");

                        Panel1.setEffect(effectBG_DropShadow);
                        Panel2.setEffect(effectBG_DropShadow);
                        Panel3.setEffect(effectBG_DropShadow);

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e ->{

                        backButton.setGraphic(svgIconBackButton_Hover);

                        Panel1.setEffect(null);
                        Panel2.setEffect(null);
                        Panel3.setEffect(null);

                        fadeOut5.play();
                        fadeOut5_1.play();
                        fadeOut5_2.play();
                        fadeOut.play();
                        fadeOut2.play();
                        fadeOut3.play();
                        fadeOut4.play();
                        fadeOut6.play();
                        fadeOut7.play();
                        fadeOut8.play();
                        fadeOut9.play();
                        fadeOut9_1.play();
                        fadeOut9_2.play();
                        fadeOut9_3.play();
                        fadeOut9_4.play();
                        fadeOut9_5.play();
                        fadeOut9_6.play();
                        fadeOut9_7.play();
                        fadeOut9_8.play();
                        fadeOut9_9.play();
                        fadeOut9_10.play();
                        fadeOut9_11.play();
                        fadeOut9_12.play();
                        fadeOut9_13.play();

                    });

                    Panelex3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        backButton.setGraphic(svgIconOption_Hover);

                    });
                    Panelex3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        backButton.setGraphic(svgIconOption);

                    });

                    //INIT
                    if(f.exists()) {

                        input = new FileInputStream("config.properties");
                        properties.load(input);

                        int width = Integer.parseInt(properties.getProperty("width"));

                        if (width==999){

                            singleMode.setDisable(false);
                            doubleMode.setDisable(false);
                            hardModebtn.setDisable(false);
                            hellModebtn.setDisable(false);

                            singleMode.setVisible(true);
                            doubleMode.setVisible(true);
                            hardModebtn.setVisible(true);
                            hellModebtn.setVisible(true);

                        }
                        else if (width==1600){

                            singleMode.setDisable(false);
                            doubleMode.setDisable(false);
                            hardModebtn.setDisable(true);
                            hellModebtn.setDisable(true);

                            singleMode.setVisible(true);
                            doubleMode.setVisible(true);
                            hardModebtn.setVisible(false);
                            hellModebtn.setVisible(false);

                        }
                        else if (width==1280){

                            singleMode.setDisable(false);
                            doubleMode.setDisable(false);
                            hardModebtn.setDisable(true);
                            hellModebtn.setDisable(true);

                            singleMode.setVisible(true);
                            doubleMode.setVisible(true);
                            hardModebtn.setVisible(false);
                            hellModebtn.setVisible(false);

                        }
                    }
                    if(f3.exists()) {

                        input3 = new FileInputStream("gamemode.properties");
                        properties3.load(input3);

                        int gSelected = Integer.parseInt(properties3.getProperty("GSelected"));
                        int tSelected = Integer.parseInt(properties3.getProperty("TSelected"));
                        int rSelected = Integer.parseInt(properties3.getProperty("RSelected"));
                        int tfSelected = Integer.parseInt(properties3.getProperty("TFSelected"));
                        int tbSelected = Integer.parseInt(properties3.getProperty("TBSelected"));

                        if (gSelected==0){

                            singleMode.setEffect(null);
                            doubleMode.setEffect(null);
                            hardModebtn.setEffect(null);
                            hellModebtn.setEffect(null);

                            g1listener.setSelected(false);
                            g2listener.setSelected(false);
                            g3listener.setSelected(false);
                            g4listener.setSelected(false);

                        }
                        else if (gSelected==1){

                            singleMode.setEffect(effectBG_DropShadow);
                            singleMode.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                            singleMode.setTextFill(Color.web(color2));
                            doubleMode.setEffect(null);
                            hardModebtn.setEffect(null);
                            hellModebtn.setEffect(null);

                            g1listener.setSelected(true);
                            g2listener.setSelected(false);
                            g3listener.setSelected(false);
                            g4listener.setSelected(false);

                            mode.setMode(1);

                        }
                        else if (gSelected==2){

                            singleMode.setEffect(null);
                            doubleMode.setEffect(effectBG_DropShadow);
                            doubleMode.setTextFill(Color.web(color2));
                            doubleMode.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                            hardModebtn.setEffect(null);
                            hellModebtn.setEffect(null);

                            g1listener.setSelected(false);
                            g2listener.setSelected(true);
                            g3listener.setSelected(false);
                            g4listener.setSelected(false);

                            mode.setMode(2);

                        }
                        else if (gSelected==3){

                            singleMode.setEffect(null);
                            doubleMode.setEffect(null);
                            hardModebtn.setEffect(effectBG_DropShadow);
                            hardModebtn.setTextFill(Color.web(color2));
                            hardModebtn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                            hellModebtn.setEffect(null);

                            g1listener.setSelected(false);
                            g2listener.setSelected(false);
                            g3listener.setSelected(true);
                            g4listener.setSelected(false);

                            mode.setMode(3);

                        }
                        else if (gSelected==4){

                            singleMode.setEffect(null);
                            doubleMode.setEffect(null);
                            hardModebtn.setEffect(null);
                            hellModebtn.setEffect(effectBG_DropShadow);
                            hellModebtn.setTextFill(Color.web(color2));
                            hellModebtn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");

                            g1listener.setSelected(false);
                            g2listener.setSelected(false);
                            g3listener.setSelected(false);
                            g4listener.setSelected(true);

                            mode.setMode(4);

                        }

                        if (tSelected==0){

                            FrontlightTheme.setEffect(null);
                            FrontblackTheme.setEffect(null);
                            FrontredTheme.setEffect(null);
                            BacklightTheme.setEffect(null);
                            BackblackTheme.setEffect(null);
                            BackredTheme.setEffect(null);
                            UNOTheme.setEffect(null);

                            t1alistener.setSelected(false);
                            t1blistener.setSelected(false);
                            t2alistener.setSelected(false);
                            t2blistener.setSelected(false);
                            t3alistener.setSelected(false);
                            t3blistener.setSelected(false);
                            t4listener.setSelected(false);

                        }
                        else if (tSelected==1){

                            if (tfSelected==0) {

                                FrontlightTheme.setEffect(null);
                                FrontblackTheme.setEffect(null);
                                FrontredTheme.setEffect(null);
                                UNOTheme.setEffect(null);

                                t1alistener.setSelected(false);
                                t2alistener.setSelected(false);
                                t3alistener.setSelected(false);
                                t4listener.setSelected(false);


                            }
                            else if (tfSelected==1) {

                                FrontlightTheme.setEffect(effectBG_DropShadow);
                                FrontlightTheme.setTextFill(Color.web(color2));
                                FrontlightTheme.setStyle("-fx-background-color: #f8f8f8; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                FrontblackTheme.setEffect(null);
                                FrontredTheme.setEffect(null);
                                UNOTheme.setEffect(null);

                                t1alistener.setSelected(true);
                                t2alistener.setSelected(false);
                                t3alistener.setSelected(false);
                                t4listener.setSelected(false);


                            }
                            else if (tfSelected==2) {

                                FrontlightTheme.setEffect(null);
                                FrontblackTheme.setEffect(effectBG_DropShadow);
                                FrontblackTheme.setTextFill(Color.web(color2));
                                FrontblackTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                FrontredTheme.setEffect(null);
                                UNOTheme.setEffect(null);

                                t1alistener.setSelected(false);
                                t2alistener.setSelected(true);
                                t3alistener.setSelected(false);
                                t4listener.setSelected(false);

                            }
                            else if (tfSelected==3) {

                                FrontlightTheme.setEffect(null);
                                FrontblackTheme.setEffect(null);
                                FrontredTheme.setEffect(effectBG_DropShadow);
                                FrontredTheme.setTextFill(Color.web(color2));
                                FrontredTheme.setStyle("-fx-background-color: #ff0000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                UNOTheme.setEffect(null);

                                t1alistener.setSelected(false);
                                t2alistener.setSelected(false);
                                t3alistener.setSelected(true);
                                t4listener.setSelected(false);

                            }

                            if (tbSelected == 0) {

                                BacklightTheme.setEffect(null);
                                BackblackTheme.setEffect(null);
                                BackredTheme.setEffect(null);

                                t1blistener.setSelected(false);
                                t2blistener.setSelected(false);
                                t3blistener.setSelected(false);

                            }
                            else if (tbSelected == 1) {

                                BacklightTheme.setEffect(effectBG_DropShadow);
                                BacklightTheme.setTextFill(Color.web(color2));
                                BacklightTheme.setStyle("-fx-background-color: #f8f8f8; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                BackblackTheme.setEffect(null);
                                BackredTheme.setEffect(null);

                                t1blistener.setSelected(true);
                                t2blistener.setSelected(false);
                                t3blistener.setSelected(false);

                            }
                            else if (tbSelected == 2) {

                                BacklightTheme.setEffect(null);
                                BackblackTheme.setEffect(effectBG_DropShadow);
                                BackblackTheme.setTextFill(Color.web(color2));
                                BackblackTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                BackredTheme.setEffect(null);

                                t1blistener.setSelected(false);
                                t2blistener.setSelected(true);
                                t3blistener.setSelected(false);

                            }
                            else if (tbSelected == 3) {

                                BacklightTheme.setEffect(null);
                                BackblackTheme.setEffect(null);
                                BackredTheme.setEffect(effectBG_DropShadow);
                                BackredTheme.setStyle("-fx-background-color: #ff0000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                BackredTheme.setTextFill(Color.web(color2));

                                t1blistener.setSelected(false);
                                t2blistener.setSelected(false);
                                t3blistener.setSelected(true);

                            }

                        }
                        else if (tSelected==2){

                            FrontlightTheme.setEffect(null);
                            FrontblackTheme.setEffect(null);
                            FrontredTheme.setEffect(null);
                            BacklightTheme.setEffect(null);
                            BackblackTheme.setEffect(null);
                            BackredTheme.setEffect(null);
                            UNOTheme.setEffect(effectBG_DropShadow);
                            UNOTheme.setTextFill(Color.web(color2));
                            UNOTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");

                            t1alistener.setSelected(false);
                            t1blistener.setSelected(false);
                            t2alistener.setSelected(false);
                            t2blistener.setSelected(false);
                            t3alistener.setSelected(false);
                            t3blistener.setSelected(false);
                            t4listener.setSelected(true);

                        }

                        if (rSelected==0){

                            r1.setEffect(null);
                            r2.setEffect(null);
                            r3.setEffect(null);

                            r1listener.setSelected(false);
                            r2listener.setSelected(false);
                            r3listener.setSelected(false);

                        }
                        else if (rSelected==1){

                            r1.setEffect(effectBG_DropShadow);
                            r1.setTextFill(Color.web(color2));
                            r1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 16; -fx-border-color: "+color2+"; -fx-border-radius: 16; -fx-border-width: 3 ;");
                            r2.setEffect(null);
                            r3.setEffect(null);

                            r1listener.setSelected(true);
                            r2listener.setSelected(false);
                            r3listener.setSelected(false);

                            mode.setRivalsNumber(1);
                            mode.setRival1("Goldfish");
                            mode.setRival2("");
                            mode.setRival3("");

                        }
                        else if (rSelected==2){

                            r1.setEffect(null);
                            r2.setEffect(effectBG_DropShadow);
                            r2.setTextFill(Color.web(color2));
                            r2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 16; -fx-border-color: "+color2+"; -fx-border-radius: 16; -fx-border-width: 3 ;");
                            r3.setEffect(null);

                            r1listener.setSelected(false);
                            r2listener.setSelected(true);
                            r3listener.setSelected(false);

                            mode.setRivalsNumber(2);
                            mode.setRival1("Goldfish");
                            mode.setRival2("Goldfish");
                            mode.setRival3("");

                        }
                        else if (rSelected==3){

                            r1.setEffect(null);
                            r2.setEffect(null);
                            r3.setEffect(effectBG_DropShadow);
                            r3.setTextFill(Color.web(color2));
                            r3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 16; -fx-border-color: "+color2+"; -fx-border-radius: 16; -fx-border-width: 3 ;");

                            r1listener.setSelected(false);
                            r2listener.setSelected(false);
                            r3listener.setSelected(true);

                            mode.setRivalsNumber(3);
                            mode.setRival1("Goldfish");
                            mode.setRival2("Goldfish");
                            mode.setRival3("Goldfish");

                        }

                        if (gSelected==0||tSelected==0||tfSelected==0||tbSelected==0||rSelected==0){
                            multiplayer.setVisible(false);
                        }else {
                            multiplayer.setVisible(true);
                        }

                    }

                    singleMode.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> singleMode.setEffect(effectBG_DropShadow));
                    singleMode.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (g1listener.isSelected()){
                            singleMode.setEffect(effectBG_DropShadow);}
                        else{singleMode.setEffect(null);}
                    });
                    singleMode.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        g1listener.setSelected(true);
                        g2listener.setSelected(false);
                        g3listener.setSelected(false);
                        g4listener.setSelected(false);

                        singleMode.setEffect(effectBG_DropShadow);
                        singleMode.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        singleMode.setTextFill(Color.web(color2));
                        doubleMode.setEffect(null);
                        hardModebtn.setEffect(null);
                        hellModebtn.setEffect(null);

                    });

                    doubleMode.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> doubleMode.setEffect(effectBG_DropShadow));
                    doubleMode.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (g2listener.isSelected()){
                            doubleMode.setEffect(effectBG_DropShadow);}
                        else{doubleMode.setEffect(null);}
                    });
                    doubleMode.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        g1listener.setSelected(false);
                        g2listener.setSelected(true);
                        g3listener.setSelected(false);
                        g4listener.setSelected(false);

                        singleMode.setEffect(null);
                        doubleMode.setEffect(effectBG_DropShadow);
                        doubleMode.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        doubleMode.setTextFill(Color.web(color2));
                        hardModebtn.setEffect(null);
                        hellModebtn.setEffect(null);

                    });

                    hardModebtn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> hardModebtn.setEffect(effectBG_DropShadow));
                    hardModebtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (g3listener.isSelected()){
                            hardModebtn.setEffect(effectBG_DropShadow);}
                        else{hardModebtn.setEffect(null);}
                    });
                    hardModebtn.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        g1listener.setSelected(false);
                        g2listener.setSelected(false);
                        g3listener.setSelected(true);
                        g4listener.setSelected(false);

                        singleMode.setEffect(null);
                        doubleMode.setEffect(null);
                        hardModebtn.setEffect(effectBG_DropShadow);
                        hardModebtn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        hardModebtn.setTextFill(Color.web(color2));
                        hellModebtn.setEffect(null);

                    });

                    hellModebtn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> hellModebtn.setEffect(effectBG_DropShadow));
                    hellModebtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (g4listener.isSelected()){
                            hellModebtn.setEffect(effectBG_DropShadow);}
                        else{hellModebtn.setEffect(null);}
                    });
                    hellModebtn.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        g1listener.setSelected(false);
                        g2listener.setSelected(false);
                        g3listener.setSelected(false);
                        g4listener.setSelected(true);

                        singleMode.setEffect(null);
                        doubleMode.setEffect(null);
                        hardModebtn.setEffect(null);
                        hellModebtn.setEffect(effectBG_DropShadow);
                        hellModebtn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        hellModebtn.setTextFill(Color.web(color2));

                    });

                    //THEME
                    FrontlightTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> FrontlightTheme.setEffect(effectBG_DropShadow));
                    FrontlightTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t1alistener.isSelected()){
                            FrontlightTheme.setEffect(effectBG_DropShadow);}
                        else{
                            FrontlightTheme.setEffect(null);}
                    });
                    FrontlightTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1alistener.setSelected(true);
                        t2alistener.setSelected(false);
                        t3alistener.setSelected(false);
                        t4listener.setSelected(false);

                        FrontlightTheme.setEffect(effectBG_DropShadow);
                        FrontlightTheme.setStyle("-fx-background-color: #f8f8f8; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        FrontlightTheme.setTextFill(Color.web(color2));
                        FrontblackTheme.setEffect(null);
                        FrontredTheme.setEffect(null);
                        UNOTheme.setEffect(null);

                    });

                    FrontblackTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> FrontblackTheme.setEffect(effectBG_DropShadow));
                    FrontblackTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t2alistener.isSelected()){
                            FrontblackTheme.setEffect(effectBG_DropShadow);}
                        else{
                            FrontblackTheme.setEffect(null);}
                    });
                    FrontblackTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1alistener.setSelected(false);
                        t2alistener.setSelected(true);
                        t3alistener.setSelected(false);
                        t4listener.setSelected(false);

                        FrontlightTheme.setEffect(null);
                        FrontblackTheme.setEffect(effectBG_DropShadow);
                        FrontblackTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        FrontblackTheme.setTextFill(Color.web(color2));
                        FrontredTheme.setEffect(null);
                        UNOTheme.setEffect(null);

                    });

                    FrontredTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> FrontredTheme.setEffect(effectBG_DropShadow));
                    FrontredTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t3alistener.isSelected()){
                            FrontredTheme.setEffect(effectBG_DropShadow);}
                        else{
                            FrontredTheme.setEffect(null);}
                    });
                    FrontredTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1alistener.setSelected(false);
                        t2alistener.setSelected(false);
                        t3alistener.setSelected(true);
                        t4listener.setSelected(false);

                        FrontlightTheme.setEffect(null);
                        FrontblackTheme.setEffect(null);
                        FrontredTheme.setEffect(effectBG_DropShadow);
                        FrontredTheme.setStyle("-fx-background-color: #ff0000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        FrontredTheme.setTextFill(Color.web(color2));
                        UNOTheme.setEffect(null);

                    });

                    BacklightTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> BacklightTheme.setEffect(effectBG_DropShadow));
                    BacklightTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t1blistener.isSelected()){
                            BacklightTheme.setEffect(effectBG_DropShadow);}
                        else{
                            BacklightTheme.setEffect(null);}
                    });
                    BacklightTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1blistener.setSelected(true);
                        t2blistener.setSelected(false);
                        t3blistener.setSelected(false);
                        t4listener.setSelected(false);

                        BacklightTheme.setEffect(effectBG_DropShadow);
                        BacklightTheme.setStyle("-fx-background-color: #f8f8f8; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        BacklightTheme.setTextFill(Color.web(color2));
                        BackblackTheme.setEffect(null);
                        BackredTheme.setEffect(null);
                        UNOTheme.setEffect(null);
                    });

                    BackblackTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> BackblackTheme.setEffect(effectBG_DropShadow));
                    BackblackTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t2blistener.isSelected()){
                            BackblackTheme.setEffect(effectBG_DropShadow);}
                        else{
                            BackblackTheme.setEffect(null);}
                    });
                    BackblackTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1blistener.setSelected(false);
                        t2blistener.setSelected(true);
                        t3blistener.setSelected(false);
                        t4listener.setSelected(false);

                        BacklightTheme.setEffect(null);
                        BackblackTheme.setEffect(effectBG_DropShadow);
                        BackblackTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        BackblackTheme.setTextFill(Color.web(color2));
                        BackredTheme.setEffect(null);
                        UNOTheme.setEffect(null);
                    });

                    BackredTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> BackredTheme.setEffect(effectBG_DropShadow));
                    BackredTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t3blistener.isSelected()){
                            BackredTheme.setEffect(effectBG_DropShadow);}
                        else{
                            BackredTheme.setEffect(null);}
                    });
                    BackredTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1blistener.setSelected(false);
                        t2blistener.setSelected(false);
                        t3blistener.setSelected(true);
                        t4listener.setSelected(false);

                        BacklightTheme.setEffect(null);
                        BackblackTheme.setEffect(null);
                        BackredTheme.setEffect(effectBG_DropShadow);
                        BackredTheme.setStyle("-fx-background-color: #ff0000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        BackredTheme.setTextFill(Color.web(color2));
                        UNOTheme.setEffect(null);

                    });

                    UNOTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> UNOTheme.setEffect(effectBG_DropShadow));
                    UNOTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t4listener.isSelected()){
                            UNOTheme.setEffect(effectBG_DropShadow);}
                        else{
                            UNOTheme.setEffect(null);}
                    });
                    UNOTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1alistener.setSelected(false);
                        t2alistener.setSelected(false);
                        t3alistener.setSelected(false);
                        t1blistener.setSelected(false);
                        t2blistener.setSelected(false);
                        t3blistener.setSelected(false);
                        t4listener.setSelected(true);

                        FrontlightTheme.setEffect(null);
                        FrontblackTheme.setEffect(null);
                        FrontredTheme.setEffect(null);
                        BacklightTheme.setEffect(null);
                        BackblackTheme.setEffect(null);
                        BackredTheme.setEffect(null);
                        UNOTheme.setEffect(effectBG_DropShadow);
                        UNOTheme.setTextFill(Color.web(color2));
                        UNOTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");

                    });

                    //Player Count
                    r1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> r1.setEffect(effectBG_DropShadow));
                    r1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r1listener.isSelected()){
                            r1.setEffect(effectBG_DropShadow);}
                        else{r1.setEffect(null);}
                    });
                    r1.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        r1listener.setSelected(true);
                        r2listener.setSelected(false);
                        r3listener.setSelected(false);

                        r1.setEffect(effectBG_DropShadow);
                        r1.setTextFill(Color.web(color2));
                        r1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24; -fx-border-color: "+color2+"; -fx-border-radius: 24; -fx-border-width: 3 ;");
                        r2.setEffect(null);
                        r3.setEffect(null);

                    });
                    r2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> r2.setEffect(effectBG_DropShadow));
                    r2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r2listener.isSelected()){
                            r2.setEffect(effectBG_DropShadow);}
                        else{r2.setEffect(null);}
                    });
                    r2.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        r1listener.setSelected(false);
                        r2listener.setSelected(true);
                        r3listener.setSelected(false);

                        r1.setEffect(null);
                        r2.setEffect(effectBG_DropShadow);
                        r2.setTextFill(Color.web(color2));
                        r2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24; -fx-border-color: "+color2+"; -fx-border-radius: 24; -fx-border-width: 3 ;");
                        r3.setEffect(null);
                    });
                    r3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> r3.setEffect(effectBG_DropShadow));
                    r3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r3listener.isSelected()){
                            r3.setEffect(effectBG_DropShadow);}
                        else{r3.setEffect(null);}
                    });
                    r3.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        r1listener.setSelected(false);
                        r2listener.setSelected(false);
                        r3listener.setSelected(true);

                        r1.setEffect(null);
                        r2.setEffect(null);
                        r3.setEffect(effectBG_DropShadow);
                        r3.setTextFill(Color.web(color2));
                        r3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24; -fx-border-color: "+color2+"; -fx-border-radius: 24; -fx-border-width: 3 ;");

                    });

                    multiplayer.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> multiplayer.setEffect(effectBG_DropShadow));
                    multiplayer.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        multiplayer.setEffect(null);
                    });
                    multiplayer.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
                        multiplayer.setEffect(effectBG_DropShadow);
                    });

                }
                else if (tColor == 2) {

                    color2 = "#fff44f";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.web("#d9cf43"), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.web("#ffff5b"), 10, 0, 5, 5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.web("#d9cf43"), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.web("#ffff5b"), 10, 0, 5, 5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBackButton = getClass().getResourceAsStream("../../../resources/svg/left_arrow/left-arrow.svg");
                    svgFileBackButton_Hover = getClass().getResourceAsStream("../../../resources/svg/left_arrow/left-arrow_blue.svg");

                    svgFileOption = getClass().getResourceAsStream("../../../resources/svg/menu/menu.svg");
                    svgFileOption_Hover = getClass().getResourceAsStream("../../../resources/svg/menu/menu_blue.svg");

                    Group svgImageBackButton = loader.loadSvg(svgFileBackButton);
                    Group svgImageBackButton_Hover = loader.loadSvg(svgFileBackButton_Hover);

                    Group svgImageOption = loader.loadSvg(svgFileOption);
                    Group svgImageOption_Hover = loader.loadSvg(svgFileOption_Hover);

                    svgImageBackButton.setScaleX(.04);
                    svgImageBackButton.setScaleY(.04);
                    svgImageBackButton_Hover.setScaleX(.04);
                    svgImageBackButton_Hover.setScaleY(.04);

                    svgImageOption.setScaleX(.04);
                    svgImageOption.setScaleY(.04);
                    svgImageOption_Hover.setScaleX(.04);
                    svgImageOption_Hover.setScaleY(.04);

                    Group svgIconBackButton = new Group(svgImageBackButton);
                    Group svgIconBackButton_Hover = new Group(svgImageBackButton_Hover);

                    Group svgIconOption = new Group(svgImageOption);
                    Group svgIconOption_Hover = new Group(svgImageOption_Hover);

                    backButton.setGraphic(svgIconOption);

                    fadeIn.setDuration(Duration.millis(500));
                    fadeOut.setDuration(Duration.millis(200));

                    fadeIn.setFromValue(0);
                    fadeIn.setToValue(10);

                    fadeOut.setFromValue(10);
                    fadeOut.setToValue(0);

                    fadeIn.setCycleCount(1);
                    fadeOut.setCycleCount(1);

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        backButton.setEffect(effectC_DropShadow);
                        backButton.setGraphic(svgIconBackButton);

                        l1.setText("");
                        l2.setText("Back to Home");
                        l3.setText("");

                        Panel1.setEffect(blur);
                        Panel2.setEffect(blur);
                        Panel3.setEffect(blur);
                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        backButton.setEffect(null);
                        backButton.setGraphic(svgIconOption);

                        l1.setText("MEMORY");
                        l2.setText("GAME");
                        l3.setText("Mᴜʟᴛɪ Pʟᴀʏᴇʀ");

                        Panel1.setEffect(effectBG_DropShadow);
                        Panel2.setEffect(effectBG_DropShadow);
                        Panel3.setEffect(effectBG_DropShadow);

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e ->{

                        backButton.setGraphic(svgIconBackButton_Hover);

                        Panel1.setEffect(null);
                        Panel2.setEffect(null);
                        Panel3.setEffect(null);

                        fadeOut5.play();
                        fadeOut5_1.play();
                        fadeOut5_2.play();
                        fadeOut.play();
                        fadeOut2.play();
                        fadeOut3.play();
                        fadeOut4.play();
                        fadeOut6.play();
                        fadeOut7.play();
                        fadeOut8.play();
                        fadeOut9.play();
                        fadeOut9_1.play();
                        fadeOut9_2.play();
                        fadeOut9_3.play();
                        fadeOut9_4.play();
                        fadeOut9_5.play();
                        fadeOut9_6.play();
                        fadeOut9_7.play();
                        fadeOut9_8.play();
                        fadeOut9_9.play();
                        fadeOut9_10.play();
                        fadeOut9_11.play();
                        fadeOut9_12.play();
                        fadeOut9_13.play();

                    });

                    Panelex3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        backButton.setGraphic(svgIconOption_Hover);

                    });
                    Panelex3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        backButton.setGraphic(svgIconOption);

                    });

                    //INIT
                    if(f.exists()) {

                        input = new FileInputStream("config.properties");
                        properties.load(input);

                        int width = Integer.parseInt(properties.getProperty("width"));

                        if (width==999){

                            singleMode.setDisable(false);
                            doubleMode.setDisable(false);
                            hardModebtn.setDisable(false);
                            hellModebtn.setDisable(false);

                            singleMode.setVisible(true);
                            doubleMode.setVisible(true);
                            hardModebtn.setVisible(true);
                            hellModebtn.setVisible(true);

                        }
                        else if (width==1600){

                            singleMode.setDisable(false);
                            doubleMode.setDisable(false);
                            hardModebtn.setDisable(true);
                            hellModebtn.setDisable(true);

                            singleMode.setVisible(true);
                            doubleMode.setVisible(true);
                            hardModebtn.setVisible(false);
                            hellModebtn.setVisible(false);

                        }
                        else if (width==1280){

                            singleMode.setDisable(false);
                            doubleMode.setDisable(false);
                            hardModebtn.setDisable(true);
                            hellModebtn.setDisable(true);

                            singleMode.setVisible(true);
                            doubleMode.setVisible(true);
                            hardModebtn.setVisible(false);
                            hellModebtn.setVisible(false);

                        }
                    }
                    if(f3.exists()) {

                        input3 = new FileInputStream("gamemode.properties");
                        properties3.load(input3);

                        int gSelected = Integer.parseInt(properties3.getProperty("GSelected"));
                        int tSelected = Integer.parseInt(properties3.getProperty("TSelected"));
                        int rSelected = Integer.parseInt(properties3.getProperty("RSelected"));
                        int tfSelected = Integer.parseInt(properties3.getProperty("TFSelected"));
                        int tbSelected = Integer.parseInt(properties3.getProperty("TBSelected"));

                        if (gSelected==0){

                            singleMode.setEffect(null);
                            doubleMode.setEffect(null);
                            hardModebtn.setEffect(null);
                            hellModebtn.setEffect(null);

                            g1listener.setSelected(false);
                            g2listener.setSelected(false);
                            g3listener.setSelected(false);
                            g4listener.setSelected(false);

                        }
                        else if (gSelected==1){

                            singleMode.setEffect(effectBG_DropShadow);
                            singleMode.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                            singleMode.setTextFill(Color.web(color2));
                            doubleMode.setEffect(null);
                            hardModebtn.setEffect(null);
                            hellModebtn.setEffect(null);

                            g1listener.setSelected(true);
                            g2listener.setSelected(false);
                            g3listener.setSelected(false);
                            g4listener.setSelected(false);

                            mode.setMode(1);

                        }
                        else if (gSelected==2){

                            singleMode.setEffect(null);
                            doubleMode.setEffect(effectBG_DropShadow);
                            doubleMode.setTextFill(Color.web(color2));
                            doubleMode.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                            hardModebtn.setEffect(null);
                            hellModebtn.setEffect(null);

                            g1listener.setSelected(false);
                            g2listener.setSelected(true);
                            g3listener.setSelected(false);
                            g4listener.setSelected(false);

                            mode.setMode(2);

                        }
                        else if (gSelected==3){

                            singleMode.setEffect(null);
                            doubleMode.setEffect(null);
                            hardModebtn.setEffect(effectBG_DropShadow);
                            hardModebtn.setTextFill(Color.web(color2));
                            hardModebtn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                            hellModebtn.setEffect(null);

                            g1listener.setSelected(false);
                            g2listener.setSelected(false);
                            g3listener.setSelected(true);
                            g4listener.setSelected(false);

                            mode.setMode(3);

                        }
                        else if (gSelected==4){

                            singleMode.setEffect(null);
                            doubleMode.setEffect(null);
                            hardModebtn.setEffect(null);
                            hellModebtn.setEffect(effectBG_DropShadow);
                            hellModebtn.setTextFill(Color.web(color2));
                            hellModebtn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");

                            g1listener.setSelected(false);
                            g2listener.setSelected(false);
                            g3listener.setSelected(false);
                            g4listener.setSelected(true);

                            mode.setMode(4);

                        }

                        if (tSelected==0){

                            FrontlightTheme.setEffect(null);
                            FrontblackTheme.setEffect(null);
                            FrontredTheme.setEffect(null);
                            BacklightTheme.setEffect(null);
                            BackblackTheme.setEffect(null);
                            BackredTheme.setEffect(null);
                            UNOTheme.setEffect(null);

                            t1alistener.setSelected(false);
                            t1blistener.setSelected(false);
                            t2alistener.setSelected(false);
                            t2blistener.setSelected(false);
                            t3alistener.setSelected(false);
                            t3blistener.setSelected(false);
                            t4listener.setSelected(false);

                        }
                        else if (tSelected==1){

                            if (tfSelected==0) {

                                FrontlightTheme.setEffect(null);
                                FrontblackTheme.setEffect(null);
                                FrontredTheme.setEffect(null);
                                UNOTheme.setEffect(null);

                                t1alistener.setSelected(false);
                                t2alistener.setSelected(false);
                                t3alistener.setSelected(false);
                                t4listener.setSelected(false);


                            }
                            else if (tfSelected==1) {

                                FrontlightTheme.setEffect(effectBG_DropShadow);
                                FrontlightTheme.setTextFill(Color.web(color2));
                                FrontlightTheme.setStyle("-fx-background-color: #f8f8f8; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                FrontblackTheme.setEffect(null);
                                FrontredTheme.setEffect(null);
                                UNOTheme.setEffect(null);

                                t1alistener.setSelected(true);
                                t2alistener.setSelected(false);
                                t3alistener.setSelected(false);
                                t4listener.setSelected(false);


                            }
                            else if (tfSelected==2) {

                                FrontlightTheme.setEffect(null);
                                FrontblackTheme.setEffect(effectBG_DropShadow);
                                FrontblackTheme.setTextFill(Color.web(color2));
                                FrontblackTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                FrontredTheme.setEffect(null);
                                UNOTheme.setEffect(null);

                                t1alistener.setSelected(false);
                                t2alistener.setSelected(true);
                                t3alistener.setSelected(false);
                                t4listener.setSelected(false);

                            }
                            else if (tfSelected==3) {

                                FrontlightTheme.setEffect(null);
                                FrontblackTheme.setEffect(null);
                                FrontredTheme.setEffect(effectBG_DropShadow);
                                FrontredTheme.setTextFill(Color.web(color2));
                                FrontredTheme.setStyle("-fx-background-color: #ff0000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                UNOTheme.setEffect(null);

                                t1alistener.setSelected(false);
                                t2alistener.setSelected(false);
                                t3alistener.setSelected(true);
                                t4listener.setSelected(false);

                            }

                            if (tbSelected == 0) {

                                BacklightTheme.setEffect(null);
                                BackblackTheme.setEffect(null);
                                BackredTheme.setEffect(null);

                                t1blistener.setSelected(false);
                                t2blistener.setSelected(false);
                                t3blistener.setSelected(false);

                            }
                            else if (tbSelected == 1) {

                                BacklightTheme.setEffect(effectBG_DropShadow);
                                BacklightTheme.setTextFill(Color.web(color2));
                                BacklightTheme.setStyle("-fx-background-color: #f8f8f8; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                BackblackTheme.setEffect(null);
                                BackredTheme.setEffect(null);

                                t1blistener.setSelected(true);
                                t2blistener.setSelected(false);
                                t3blistener.setSelected(false);

                            }
                            else if (tbSelected == 2) {

                                BacklightTheme.setEffect(null);
                                BackblackTheme.setEffect(effectBG_DropShadow);
                                BackblackTheme.setTextFill(Color.web(color2));
                                BackblackTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                BackredTheme.setEffect(null);

                                t1blistener.setSelected(false);
                                t2blistener.setSelected(true);
                                t3blistener.setSelected(false);

                            }
                            else if (tbSelected == 3) {

                                BacklightTheme.setEffect(null);
                                BackblackTheme.setEffect(null);
                                BackredTheme.setEffect(effectBG_DropShadow);
                                BackredTheme.setStyle("-fx-background-color: #ff0000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                BackredTheme.setTextFill(Color.web(color2));

                                t1blistener.setSelected(false);
                                t2blistener.setSelected(false);
                                t3blistener.setSelected(true);

                            }

                        }
                        else if (tSelected==2){

                            FrontlightTheme.setEffect(null);
                            FrontblackTheme.setEffect(null);
                            FrontredTheme.setEffect(null);
                            BacklightTheme.setEffect(null);
                            BackblackTheme.setEffect(null);
                            BackredTheme.setEffect(null);
                            UNOTheme.setEffect(effectBG_DropShadow);
                            UNOTheme.setTextFill(Color.web(color2));
                            UNOTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");

                            t1alistener.setSelected(false);
                            t1blistener.setSelected(false);
                            t2alistener.setSelected(false);
                            t2blistener.setSelected(false);
                            t3alistener.setSelected(false);
                            t3blistener.setSelected(false);
                            t4listener.setSelected(true);

                        }

                        if (rSelected==0){

                            r1.setEffect(null);
                            r2.setEffect(null);
                            r3.setEffect(null);

                            r1listener.setSelected(false);
                            r2listener.setSelected(false);
                            r3listener.setSelected(false);

                        }
                        else if (rSelected==1){

                            r1.setEffect(effectBG_DropShadow);
                            r1.setTextFill(Color.web(color2));
                            r1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 16; -fx-border-color: "+color2+"; -fx-border-radius: 16; -fx-border-width: 3 ;");
                            r2.setEffect(null);
                            r3.setEffect(null);

                            r1listener.setSelected(true);
                            r2listener.setSelected(false);
                            r3listener.setSelected(false);

                            mode.setRivalsNumber(1);
                            mode.setRival1("Goldfish");
                            mode.setRival2("");
                            mode.setRival3("");

                        }
                        else if (rSelected==2){

                            r1.setEffect(null);
                            r2.setEffect(effectBG_DropShadow);
                            r2.setTextFill(Color.web(color2));
                            r2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 16; -fx-border-color: "+color2+"; -fx-border-radius: 16; -fx-border-width: 3 ;");
                            r3.setEffect(null);

                            r1listener.setSelected(false);
                            r2listener.setSelected(true);
                            r3listener.setSelected(false);

                            mode.setRivalsNumber(2);
                            mode.setRival1("Goldfish");
                            mode.setRival2("Goldfish");
                            mode.setRival3("");

                        }
                        else if (rSelected==3){

                            r1.setEffect(null);
                            r2.setEffect(null);
                            r3.setEffect(effectBG_DropShadow);
                            r3.setTextFill(Color.web(color2));
                            r3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 16; -fx-border-color: "+color2+"; -fx-border-radius: 16; -fx-border-width: 3 ;");

                            r1listener.setSelected(false);
                            r2listener.setSelected(false);
                            r3listener.setSelected(true);

                            mode.setRivalsNumber(3);
                            mode.setRival1("Goldfish");
                            mode.setRival2("Goldfish");
                            mode.setRival3("Goldfish");

                        }

                        if (gSelected==0||tSelected==0||tfSelected==0||tbSelected==0||rSelected==0){
                            multiplayer.setVisible(false);
                        }else {
                            multiplayer.setVisible(true);
                        }

                    }

                    singleMode.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> singleMode.setEffect(effectBG_DropShadow));
                    singleMode.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (g1listener.isSelected()){
                            singleMode.setEffect(effectBG_DropShadow);}
                        else{singleMode.setEffect(null);}
                    });
                    singleMode.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        g1listener.setSelected(true);
                        g2listener.setSelected(false);
                        g3listener.setSelected(false);
                        g4listener.setSelected(false);

                        singleMode.setEffect(effectBG_DropShadow);
                        singleMode.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        singleMode.setTextFill(Color.web(color2));
                        doubleMode.setEffect(null);
                        hardModebtn.setEffect(null);
                        hellModebtn.setEffect(null);

                    });

                    doubleMode.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> doubleMode.setEffect(effectBG_DropShadow));
                    doubleMode.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (g2listener.isSelected()){
                            doubleMode.setEffect(effectBG_DropShadow);}
                        else{doubleMode.setEffect(null);}
                    });
                    doubleMode.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        g1listener.setSelected(false);
                        g2listener.setSelected(true);
                        g3listener.setSelected(false);
                        g4listener.setSelected(false);

                        singleMode.setEffect(null);
                        doubleMode.setEffect(effectBG_DropShadow);
                        doubleMode.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        doubleMode.setTextFill(Color.web(color2));
                        hardModebtn.setEffect(null);
                        hellModebtn.setEffect(null);

                    });

                    hardModebtn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> hardModebtn.setEffect(effectBG_DropShadow));
                    hardModebtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (g3listener.isSelected()){
                            hardModebtn.setEffect(effectBG_DropShadow);}
                        else{hardModebtn.setEffect(null);}
                    });
                    hardModebtn.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        g1listener.setSelected(false);
                        g2listener.setSelected(false);
                        g3listener.setSelected(true);
                        g4listener.setSelected(false);

                        singleMode.setEffect(null);
                        doubleMode.setEffect(null);
                        hardModebtn.setEffect(effectBG_DropShadow);
                        hardModebtn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        hardModebtn.setTextFill(Color.web(color2));
                        hellModebtn.setEffect(null);

                    });

                    hellModebtn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> hellModebtn.setEffect(effectBG_DropShadow));
                    hellModebtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (g4listener.isSelected()){
                            hellModebtn.setEffect(effectBG_DropShadow);}
                        else{hellModebtn.setEffect(null);}
                    });
                    hellModebtn.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        g1listener.setSelected(false);
                        g2listener.setSelected(false);
                        g3listener.setSelected(false);
                        g4listener.setSelected(true);

                        singleMode.setEffect(null);
                        doubleMode.setEffect(null);
                        hardModebtn.setEffect(null);
                        hellModebtn.setEffect(effectBG_DropShadow);
                        hellModebtn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        hellModebtn.setTextFill(Color.web(color2));

                    });

                    //THEME
                    FrontlightTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> FrontlightTheme.setEffect(effectBG_DropShadow));
                    FrontlightTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t1alistener.isSelected()){
                            FrontlightTheme.setEffect(effectBG_DropShadow);}
                        else{
                            FrontlightTheme.setEffect(null);}
                    });
                    FrontlightTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1alistener.setSelected(true);
                        t2alistener.setSelected(false);
                        t3alistener.setSelected(false);
                        t4listener.setSelected(false);

                        FrontlightTheme.setEffect(effectBG_DropShadow);
                        FrontlightTheme.setStyle("-fx-background-color: #f8f8f8; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        FrontlightTheme.setTextFill(Color.web(color2));
                        FrontblackTheme.setEffect(null);
                        FrontredTheme.setEffect(null);
                        UNOTheme.setEffect(null);

                    });

                    FrontblackTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> FrontblackTheme.setEffect(effectBG_DropShadow));
                    FrontblackTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t2alistener.isSelected()){
                            FrontblackTheme.setEffect(effectBG_DropShadow);}
                        else{
                            FrontblackTheme.setEffect(null);}
                    });
                    FrontblackTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1alistener.setSelected(false);
                        t2alistener.setSelected(true);
                        t3alistener.setSelected(false);
                        t4listener.setSelected(false);

                        FrontlightTheme.setEffect(null);
                        FrontblackTheme.setEffect(effectBG_DropShadow);
                        FrontblackTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        FrontblackTheme.setTextFill(Color.web(color2));
                        FrontredTheme.setEffect(null);
                        UNOTheme.setEffect(null);

                    });

                    FrontredTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> FrontredTheme.setEffect(effectBG_DropShadow));
                    FrontredTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t3alistener.isSelected()){
                            FrontredTheme.setEffect(effectBG_DropShadow);}
                        else{
                            FrontredTheme.setEffect(null);}
                    });
                    FrontredTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1alistener.setSelected(false);
                        t2alistener.setSelected(false);
                        t3alistener.setSelected(true);
                        t4listener.setSelected(false);

                        FrontlightTheme.setEffect(null);
                        FrontblackTheme.setEffect(null);
                        FrontredTheme.setEffect(effectBG_DropShadow);
                        FrontredTheme.setStyle("-fx-background-color: #ff0000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        FrontredTheme.setTextFill(Color.web(color2));
                        UNOTheme.setEffect(null);

                    });

                    BacklightTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> BacklightTheme.setEffect(effectBG_DropShadow));
                    BacklightTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t1blistener.isSelected()){
                            BacklightTheme.setEffect(effectBG_DropShadow);}
                        else{
                            BacklightTheme.setEffect(null);}
                    });
                    BacklightTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1blistener.setSelected(true);
                        t2blistener.setSelected(false);
                        t3blistener.setSelected(false);
                        t4listener.setSelected(false);

                        BacklightTheme.setEffect(effectBG_DropShadow);
                        BacklightTheme.setStyle("-fx-background-color: #f8f8f8; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        BacklightTheme.setTextFill(Color.web(color2));
                        BackblackTheme.setEffect(null);
                        BackredTheme.setEffect(null);
                        UNOTheme.setEffect(null);
                    });

                    BackblackTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> BackblackTheme.setEffect(effectBG_DropShadow));
                    BackblackTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t2blistener.isSelected()){
                            BackblackTheme.setEffect(effectBG_DropShadow);}
                        else{
                            BackblackTheme.setEffect(null);}
                    });
                    BackblackTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1blistener.setSelected(false);
                        t2blistener.setSelected(true);
                        t3blistener.setSelected(false);
                        t4listener.setSelected(false);

                        BacklightTheme.setEffect(null);
                        BackblackTheme.setEffect(effectBG_DropShadow);
                        BackblackTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        BackblackTheme.setTextFill(Color.web(color2));
                        BackredTheme.setEffect(null);
                        UNOTheme.setEffect(null);
                    });

                    BackredTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> BackredTheme.setEffect(effectBG_DropShadow));
                    BackredTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t3blistener.isSelected()){
                            BackredTheme.setEffect(effectBG_DropShadow);}
                        else{
                            BackredTheme.setEffect(null);}
                    });
                    BackredTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1blistener.setSelected(false);
                        t2blistener.setSelected(false);
                        t3blistener.setSelected(true);
                        t4listener.setSelected(false);

                        BacklightTheme.setEffect(null);
                        BackblackTheme.setEffect(null);
                        BackredTheme.setEffect(effectBG_DropShadow);
                        BackredTheme.setStyle("-fx-background-color: #ff0000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        BackredTheme.setTextFill(Color.web(color2));
                        UNOTheme.setEffect(null);

                    });

                    UNOTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> UNOTheme.setEffect(effectBG_DropShadow));
                    UNOTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t4listener.isSelected()){
                            UNOTheme.setEffect(effectBG_DropShadow);}
                        else{
                            UNOTheme.setEffect(null);}
                    });
                    UNOTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1alistener.setSelected(false);
                        t2alistener.setSelected(false);
                        t3alistener.setSelected(false);
                        t1blistener.setSelected(false);
                        t2blistener.setSelected(false);
                        t3blistener.setSelected(false);
                        t4listener.setSelected(true);

                        FrontlightTheme.setEffect(null);
                        FrontblackTheme.setEffect(null);
                        FrontredTheme.setEffect(null);
                        BacklightTheme.setEffect(null);
                        BackblackTheme.setEffect(null);
                        BackredTheme.setEffect(null);
                        UNOTheme.setEffect(effectBG_DropShadow);
                        UNOTheme.setTextFill(Color.web(color2));
                        UNOTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");

                    });

                    //Player Count
                    r1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> r1.setEffect(effectBG_DropShadow));
                    r1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r1listener.isSelected()){
                            r1.setEffect(effectBG_DropShadow);}
                        else{r1.setEffect(null);}
                    });
                    r1.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        r1listener.setSelected(true);
                        r2listener.setSelected(false);
                        r3listener.setSelected(false);

                        r1.setEffect(effectBG_DropShadow);
                        r1.setTextFill(Color.web(color2));
                        r1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24; -fx-border-color: "+color2+"; -fx-border-radius: 24; -fx-border-width: 3 ;");
                        r2.setEffect(null);
                        r3.setEffect(null);

                    });
                    r2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> r2.setEffect(effectBG_DropShadow));
                    r2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r2listener.isSelected()){
                            r2.setEffect(effectBG_DropShadow);}
                        else{r2.setEffect(null);}
                    });
                    r2.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        r1listener.setSelected(false);
                        r2listener.setSelected(true);
                        r3listener.setSelected(false);

                        r1.setEffect(null);
                        r2.setEffect(effectBG_DropShadow);
                        r2.setTextFill(Color.web(color2));
                        r2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24; -fx-border-color: "+color2+"; -fx-border-radius: 24; -fx-border-width: 3 ;");
                        r3.setEffect(null);
                    });
                    r3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> r3.setEffect(effectBG_DropShadow));
                    r3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r3listener.isSelected()){
                            r3.setEffect(effectBG_DropShadow);}
                        else{r3.setEffect(null);}
                    });
                    r3.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        r1listener.setSelected(false);
                        r2listener.setSelected(false);
                        r3listener.setSelected(true);

                        r1.setEffect(null);
                        r2.setEffect(null);
                        r3.setEffect(effectBG_DropShadow);
                        r3.setTextFill(Color.web(color2));
                        r3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24; -fx-border-color: "+color2+"; -fx-border-radius: 24; -fx-border-width: 3 ;");

                    });

                    multiplayer.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> multiplayer.setEffect(effectBG_DropShadow));
                    multiplayer.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        multiplayer.setEffect(null);
                    });
                    multiplayer.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
                        multiplayer.setEffect(effectBG_DropShadow);
                    });

                }
                else if (tColor == 3) {

                    color2 = "#00c853";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,200,83), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,230,95), 10, 0, 5, 5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,200,83), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,230,95), 10, 0, 5, 5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBackButton = getClass().getResourceAsStream("../../../resources/svg/left_arrow/left-arrow.svg");
                    svgFileBackButton_Hover = getClass().getResourceAsStream("../../../resources/svg/left_arrow/left-arrow_blue.svg");

                    svgFileOption = getClass().getResourceAsStream("../../../resources/svg/menu/menu.svg");
                    svgFileOption_Hover = getClass().getResourceAsStream("../../../resources/svg/menu/menu_blue.svg");

                    Group svgImageBackButton = loader.loadSvg(svgFileBackButton);
                    Group svgImageBackButton_Hover = loader.loadSvg(svgFileBackButton_Hover);

                    Group svgImageOption = loader.loadSvg(svgFileOption);
                    Group svgImageOption_Hover = loader.loadSvg(svgFileOption_Hover);

                    svgImageBackButton.setScaleX(.04);
                    svgImageBackButton.setScaleY(.04);
                    svgImageBackButton_Hover.setScaleX(.04);
                    svgImageBackButton_Hover.setScaleY(.04);

                    svgImageOption.setScaleX(.04);
                    svgImageOption.setScaleY(.04);
                    svgImageOption_Hover.setScaleX(.04);
                    svgImageOption_Hover.setScaleY(.04);

                    Group svgIconBackButton = new Group(svgImageBackButton);
                    Group svgIconBackButton_Hover = new Group(svgImageBackButton_Hover);

                    Group svgIconOption = new Group(svgImageOption);
                    Group svgIconOption_Hover = new Group(svgImageOption_Hover);

                    backButton.setGraphic(svgIconOption);

                    fadeIn.setDuration(Duration.millis(500));
                    fadeOut.setDuration(Duration.millis(200));

                    fadeIn.setFromValue(0);
                    fadeIn.setToValue(10);

                    fadeOut.setFromValue(10);
                    fadeOut.setToValue(0);

                    fadeIn.setCycleCount(1);
                    fadeOut.setCycleCount(1);

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        backButton.setEffect(effectC_DropShadow);
                        backButton.setGraphic(svgIconBackButton);

                        l1.setText("");
                        l2.setText("Back to Home");
                        l3.setText("");

                        Panel1.setEffect(blur);
                        Panel2.setEffect(blur);
                        Panel3.setEffect(blur);
                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        backButton.setEffect(null);
                        backButton.setGraphic(svgIconOption);

                        l1.setText("MEMORY");
                        l2.setText("GAME");
                        l3.setText("Mᴜʟᴛɪ Pʟᴀʏᴇʀ");

                        Panel1.setEffect(effectBG_DropShadow);
                        Panel2.setEffect(effectBG_DropShadow);
                        Panel3.setEffect(effectBG_DropShadow);

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e ->{

                        backButton.setGraphic(svgIconBackButton_Hover);

                        Panel1.setEffect(null);
                        Panel2.setEffect(null);
                        Panel3.setEffect(null);

                        fadeOut5.play();
                        fadeOut5_1.play();
                        fadeOut5_2.play();
                        fadeOut.play();
                        fadeOut2.play();
                        fadeOut3.play();
                        fadeOut4.play();
                        fadeOut6.play();
                        fadeOut7.play();
                        fadeOut8.play();
                        fadeOut9.play();
                        fadeOut9_1.play();
                        fadeOut9_2.play();
                        fadeOut9_3.play();
                        fadeOut9_4.play();
                        fadeOut9_5.play();
                        fadeOut9_6.play();
                        fadeOut9_7.play();
                        fadeOut9_8.play();
                        fadeOut9_9.play();
                        fadeOut9_10.play();
                        fadeOut9_11.play();
                        fadeOut9_12.play();
                        fadeOut9_13.play();

                    });

                    Panelex3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        backButton.setGraphic(svgIconOption_Hover);

                    });
                    Panelex3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        backButton.setGraphic(svgIconOption);

                    });

                    //INIT
                    if(f.exists()) {

                        input = new FileInputStream("config.properties");
                        properties.load(input);

                        int width = Integer.parseInt(properties.getProperty("width"));

                        if (width==999){

                            singleMode.setDisable(false);
                            doubleMode.setDisable(false);
                            hardModebtn.setDisable(false);
                            hellModebtn.setDisable(false);

                            singleMode.setVisible(true);
                            doubleMode.setVisible(true);
                            hardModebtn.setVisible(true);
                            hellModebtn.setVisible(true);

                        }
                        else if (width==1600){

                            singleMode.setDisable(false);
                            doubleMode.setDisable(false);
                            hardModebtn.setDisable(true);
                            hellModebtn.setDisable(true);

                            singleMode.setVisible(true);
                            doubleMode.setVisible(true);
                            hardModebtn.setVisible(false);
                            hellModebtn.setVisible(false);

                        }
                        else if (width==1280){

                            singleMode.setDisable(false);
                            doubleMode.setDisable(false);
                            hardModebtn.setDisable(true);
                            hellModebtn.setDisable(true);

                            singleMode.setVisible(true);
                            doubleMode.setVisible(true);
                            hardModebtn.setVisible(false);
                            hellModebtn.setVisible(false);

                        }
                    }
                    if(f3.exists()) {

                        input3 = new FileInputStream("gamemode.properties");
                        properties3.load(input3);

                        int gSelected = Integer.parseInt(properties3.getProperty("GSelected"));
                        int tSelected = Integer.parseInt(properties3.getProperty("TSelected"));
                        int rSelected = Integer.parseInt(properties3.getProperty("RSelected"));
                        int tfSelected = Integer.parseInt(properties3.getProperty("TFSelected"));
                        int tbSelected = Integer.parseInt(properties3.getProperty("TBSelected"));

                        if (gSelected==0){

                            singleMode.setEffect(null);
                            doubleMode.setEffect(null);
                            hardModebtn.setEffect(null);
                            hellModebtn.setEffect(null);

                            g1listener.setSelected(false);
                            g2listener.setSelected(false);
                            g3listener.setSelected(false);
                            g4listener.setSelected(false);

                        }
                        else if (gSelected==1){

                            singleMode.setEffect(effectBG_DropShadow);
                            singleMode.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                            singleMode.setTextFill(Color.web(color2));
                            doubleMode.setEffect(null);
                            hardModebtn.setEffect(null);
                            hellModebtn.setEffect(null);

                            g1listener.setSelected(true);
                            g2listener.setSelected(false);
                            g3listener.setSelected(false);
                            g4listener.setSelected(false);

                            mode.setMode(1);

                        }
                        else if (gSelected==2){

                            singleMode.setEffect(null);
                            doubleMode.setEffect(effectBG_DropShadow);
                            doubleMode.setTextFill(Color.web(color2));
                            doubleMode.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                            hardModebtn.setEffect(null);
                            hellModebtn.setEffect(null);

                            g1listener.setSelected(false);
                            g2listener.setSelected(true);
                            g3listener.setSelected(false);
                            g4listener.setSelected(false);

                            mode.setMode(2);

                        }
                        else if (gSelected==3){

                            singleMode.setEffect(null);
                            doubleMode.setEffect(null);
                            hardModebtn.setEffect(effectBG_DropShadow);
                            hardModebtn.setTextFill(Color.web(color2));
                            hardModebtn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                            hellModebtn.setEffect(null);

                            g1listener.setSelected(false);
                            g2listener.setSelected(false);
                            g3listener.setSelected(true);
                            g4listener.setSelected(false);

                            mode.setMode(3);

                        }
                        else if (gSelected==4){

                            singleMode.setEffect(null);
                            doubleMode.setEffect(null);
                            hardModebtn.setEffect(null);
                            hellModebtn.setEffect(effectBG_DropShadow);
                            hellModebtn.setTextFill(Color.web(color2));
                            hellModebtn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");

                            g1listener.setSelected(false);
                            g2listener.setSelected(false);
                            g3listener.setSelected(false);
                            g4listener.setSelected(true);

                            mode.setMode(4);

                        }

                        if (tSelected==0){

                            FrontlightTheme.setEffect(null);
                            FrontblackTheme.setEffect(null);
                            FrontredTheme.setEffect(null);
                            BacklightTheme.setEffect(null);
                            BackblackTheme.setEffect(null);
                            BackredTheme.setEffect(null);
                            UNOTheme.setEffect(null);

                            t1alistener.setSelected(false);
                            t1blistener.setSelected(false);
                            t2alistener.setSelected(false);
                            t2blistener.setSelected(false);
                            t3alistener.setSelected(false);
                            t3blistener.setSelected(false);
                            t4listener.setSelected(false);

                        }
                        else if (tSelected==1){

                            if (tfSelected==0) {

                                FrontlightTheme.setEffect(null);
                                FrontblackTheme.setEffect(null);
                                FrontredTheme.setEffect(null);
                                UNOTheme.setEffect(null);

                                t1alistener.setSelected(false);
                                t2alistener.setSelected(false);
                                t3alistener.setSelected(false);
                                t4listener.setSelected(false);


                            }
                            else if (tfSelected==1) {

                                FrontlightTheme.setEffect(effectBG_DropShadow);
                                FrontlightTheme.setTextFill(Color.web(color2));
                                FrontlightTheme.setStyle("-fx-background-color: #f8f8f8; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                FrontblackTheme.setEffect(null);
                                FrontredTheme.setEffect(null);
                                UNOTheme.setEffect(null);

                                t1alistener.setSelected(true);
                                t2alistener.setSelected(false);
                                t3alistener.setSelected(false);
                                t4listener.setSelected(false);


                            }
                            else if (tfSelected==2) {

                                FrontlightTheme.setEffect(null);
                                FrontblackTheme.setEffect(effectBG_DropShadow);
                                FrontblackTheme.setTextFill(Color.web(color2));
                                FrontblackTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                FrontredTheme.setEffect(null);
                                UNOTheme.setEffect(null);

                                t1alistener.setSelected(false);
                                t2alistener.setSelected(true);
                                t3alistener.setSelected(false);
                                t4listener.setSelected(false);

                            }
                            else if (tfSelected==3) {

                                FrontlightTheme.setEffect(null);
                                FrontblackTheme.setEffect(null);
                                FrontredTheme.setEffect(effectBG_DropShadow);
                                FrontredTheme.setTextFill(Color.web(color2));
                                FrontredTheme.setStyle("-fx-background-color: #ff0000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                UNOTheme.setEffect(null);

                                t1alistener.setSelected(false);
                                t2alistener.setSelected(false);
                                t3alistener.setSelected(true);
                                t4listener.setSelected(false);

                            }

                            if (tbSelected == 0) {

                                BacklightTheme.setEffect(null);
                                BackblackTheme.setEffect(null);
                                BackredTheme.setEffect(null);

                                t1blistener.setSelected(false);
                                t2blistener.setSelected(false);
                                t3blistener.setSelected(false);

                            }
                            else if (tbSelected == 1) {

                                BacklightTheme.setEffect(effectBG_DropShadow);
                                BacklightTheme.setTextFill(Color.web(color2));
                                BacklightTheme.setStyle("-fx-background-color: #f8f8f8; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                BackblackTheme.setEffect(null);
                                BackredTheme.setEffect(null);

                                t1blistener.setSelected(true);
                                t2blistener.setSelected(false);
                                t3blistener.setSelected(false);

                            }
                            else if (tbSelected == 2) {

                                BacklightTheme.setEffect(null);
                                BackblackTheme.setEffect(effectBG_DropShadow);
                                BackblackTheme.setTextFill(Color.web(color2));
                                BackblackTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                BackredTheme.setEffect(null);

                                t1blistener.setSelected(false);
                                t2blistener.setSelected(true);
                                t3blistener.setSelected(false);

                            }
                            else if (tbSelected == 3) {

                                BacklightTheme.setEffect(null);
                                BackblackTheme.setEffect(null);
                                BackredTheme.setEffect(effectBG_DropShadow);
                                BackredTheme.setStyle("-fx-background-color: #ff0000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                BackredTheme.setTextFill(Color.web(color2));

                                t1blistener.setSelected(false);
                                t2blistener.setSelected(false);
                                t3blistener.setSelected(true);

                            }

                        }
                        else if (tSelected==2){

                            FrontlightTheme.setEffect(null);
                            FrontblackTheme.setEffect(null);
                            FrontredTheme.setEffect(null);
                            BacklightTheme.setEffect(null);
                            BackblackTheme.setEffect(null);
                            BackredTheme.setEffect(null);
                            UNOTheme.setEffect(effectBG_DropShadow);
                            UNOTheme.setTextFill(Color.web(color2));
                            UNOTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");

                            t1alistener.setSelected(false);
                            t1blistener.setSelected(false);
                            t2alistener.setSelected(false);
                            t2blistener.setSelected(false);
                            t3alistener.setSelected(false);
                            t3blistener.setSelected(false);
                            t4listener.setSelected(true);

                        }

                        if (rSelected==0){

                            r1.setEffect(null);
                            r2.setEffect(null);
                            r3.setEffect(null);

                            r1listener.setSelected(false);
                            r2listener.setSelected(false);
                            r3listener.setSelected(false);

                        }
                        else if (rSelected==1){

                            r1.setEffect(effectBG_DropShadow);
                            r1.setTextFill(Color.web(color2));
                            r1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 16; -fx-border-color: "+color2+"; -fx-border-radius: 16; -fx-border-width: 3 ;");
                            r2.setEffect(null);
                            r3.setEffect(null);

                            r1listener.setSelected(true);
                            r2listener.setSelected(false);
                            r3listener.setSelected(false);

                            mode.setRivalsNumber(1);
                            mode.setRival1("Goldfish");
                            mode.setRival2("");
                            mode.setRival3("");

                        }
                        else if (rSelected==2){

                            r1.setEffect(null);
                            r2.setEffect(effectBG_DropShadow);
                            r2.setTextFill(Color.web(color2));
                            r2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 16; -fx-border-color: "+color2+"; -fx-border-radius: 16; -fx-border-width: 3 ;");
                            r3.setEffect(null);

                            r1listener.setSelected(false);
                            r2listener.setSelected(true);
                            r3listener.setSelected(false);

                            mode.setRivalsNumber(2);
                            mode.setRival1("Goldfish");
                            mode.setRival2("Goldfish");
                            mode.setRival3("");

                        }
                        else if (rSelected==3){

                            r1.setEffect(null);
                            r2.setEffect(null);
                            r3.setEffect(effectBG_DropShadow);
                            r3.setTextFill(Color.web(color2));
                            r3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 16; -fx-border-color: "+color2+"; -fx-border-radius: 16; -fx-border-width: 3 ;");

                            r1listener.setSelected(false);
                            r2listener.setSelected(false);
                            r3listener.setSelected(true);

                            mode.setRivalsNumber(3);
                            mode.setRival1("Goldfish");
                            mode.setRival2("Goldfish");
                            mode.setRival3("Goldfish");

                        }

                        if (gSelected==0||tSelected==0||tfSelected==0||tbSelected==0||rSelected==0){
                            multiplayer.setVisible(false);
                        }else {
                            multiplayer.setVisible(true);
                        }

                    }

                    singleMode.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> singleMode.setEffect(effectBG_DropShadow));
                    singleMode.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (g1listener.isSelected()){
                            singleMode.setEffect(effectBG_DropShadow);}
                        else{singleMode.setEffect(null);}
                    });
                    singleMode.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        g1listener.setSelected(true);
                        g2listener.setSelected(false);
                        g3listener.setSelected(false);
                        g4listener.setSelected(false);

                        singleMode.setEffect(effectBG_DropShadow);
                        singleMode.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        singleMode.setTextFill(Color.web(color2));
                        doubleMode.setEffect(null);
                        hardModebtn.setEffect(null);
                        hellModebtn.setEffect(null);

                    });

                    doubleMode.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> doubleMode.setEffect(effectBG_DropShadow));
                    doubleMode.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (g2listener.isSelected()){
                            doubleMode.setEffect(effectBG_DropShadow);}
                        else{doubleMode.setEffect(null);}
                    });
                    doubleMode.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        g1listener.setSelected(false);
                        g2listener.setSelected(true);
                        g3listener.setSelected(false);
                        g4listener.setSelected(false);

                        singleMode.setEffect(null);
                        doubleMode.setEffect(effectBG_DropShadow);
                        doubleMode.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        doubleMode.setTextFill(Color.web(color2));
                        hardModebtn.setEffect(null);
                        hellModebtn.setEffect(null);

                    });

                    hardModebtn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> hardModebtn.setEffect(effectBG_DropShadow));
                    hardModebtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (g3listener.isSelected()){
                            hardModebtn.setEffect(effectBG_DropShadow);}
                        else{hardModebtn.setEffect(null);}
                    });
                    hardModebtn.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        g1listener.setSelected(false);
                        g2listener.setSelected(false);
                        g3listener.setSelected(true);
                        g4listener.setSelected(false);

                        singleMode.setEffect(null);
                        doubleMode.setEffect(null);
                        hardModebtn.setEffect(effectBG_DropShadow);
                        hardModebtn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        hardModebtn.setTextFill(Color.web(color2));
                        hellModebtn.setEffect(null);

                    });

                    hellModebtn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> hellModebtn.setEffect(effectBG_DropShadow));
                    hellModebtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (g4listener.isSelected()){
                            hellModebtn.setEffect(effectBG_DropShadow);}
                        else{hellModebtn.setEffect(null);}
                    });
                    hellModebtn.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        g1listener.setSelected(false);
                        g2listener.setSelected(false);
                        g3listener.setSelected(false);
                        g4listener.setSelected(true);

                        singleMode.setEffect(null);
                        doubleMode.setEffect(null);
                        hardModebtn.setEffect(null);
                        hellModebtn.setEffect(effectBG_DropShadow);
                        hellModebtn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        hellModebtn.setTextFill(Color.web(color2));

                    });

                    //THEME
                    FrontlightTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> FrontlightTheme.setEffect(effectBG_DropShadow));
                    FrontlightTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t1alistener.isSelected()){
                            FrontlightTheme.setEffect(effectBG_DropShadow);}
                        else{
                            FrontlightTheme.setEffect(null);}
                    });
                    FrontlightTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1alistener.setSelected(true);
                        t2alistener.setSelected(false);
                        t3alistener.setSelected(false);
                        t4listener.setSelected(false);

                        FrontlightTheme.setEffect(effectBG_DropShadow);
                        FrontlightTheme.setStyle("-fx-background-color: #f8f8f8; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        FrontlightTheme.setTextFill(Color.web(color2));
                        FrontblackTheme.setEffect(null);
                        FrontredTheme.setEffect(null);
                        UNOTheme.setEffect(null);

                    });

                    FrontblackTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> FrontblackTheme.setEffect(effectBG_DropShadow));
                    FrontblackTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t2alistener.isSelected()){
                            FrontblackTheme.setEffect(effectBG_DropShadow);}
                        else{
                            FrontblackTheme.setEffect(null);}
                    });
                    FrontblackTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1alistener.setSelected(false);
                        t2alistener.setSelected(true);
                        t3alistener.setSelected(false);
                        t4listener.setSelected(false);

                        FrontlightTheme.setEffect(null);
                        FrontblackTheme.setEffect(effectBG_DropShadow);
                        FrontblackTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        FrontblackTheme.setTextFill(Color.web(color2));
                        FrontredTheme.setEffect(null);
                        UNOTheme.setEffect(null);

                    });

                    FrontredTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> FrontredTheme.setEffect(effectBG_DropShadow));
                    FrontredTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t3alistener.isSelected()){
                            FrontredTheme.setEffect(effectBG_DropShadow);}
                        else{
                            FrontredTheme.setEffect(null);}
                    });
                    FrontredTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1alistener.setSelected(false);
                        t2alistener.setSelected(false);
                        t3alistener.setSelected(true);
                        t4listener.setSelected(false);

                        FrontlightTheme.setEffect(null);
                        FrontblackTheme.setEffect(null);
                        FrontredTheme.setEffect(effectBG_DropShadow);
                        FrontredTheme.setStyle("-fx-background-color: #ff0000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        FrontredTheme.setTextFill(Color.web(color2));
                        UNOTheme.setEffect(null);

                    });

                    BacklightTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> BacklightTheme.setEffect(effectBG_DropShadow));
                    BacklightTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t1blistener.isSelected()){
                            BacklightTheme.setEffect(effectBG_DropShadow);}
                        else{
                            BacklightTheme.setEffect(null);}
                    });
                    BacklightTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1blistener.setSelected(true);
                        t2blistener.setSelected(false);
                        t3blistener.setSelected(false);
                        t4listener.setSelected(false);

                        BacklightTheme.setEffect(effectBG_DropShadow);
                        BacklightTheme.setStyle("-fx-background-color: #f8f8f8; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        BacklightTheme.setTextFill(Color.web(color2));
                        BackblackTheme.setEffect(null);
                        BackredTheme.setEffect(null);
                        UNOTheme.setEffect(null);
                    });

                    BackblackTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> BackblackTheme.setEffect(effectBG_DropShadow));
                    BackblackTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t2blistener.isSelected()){
                            BackblackTheme.setEffect(effectBG_DropShadow);}
                        else{
                            BackblackTheme.setEffect(null);}
                    });
                    BackblackTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1blistener.setSelected(false);
                        t2blistener.setSelected(true);
                        t3blistener.setSelected(false);
                        t4listener.setSelected(false);

                        BacklightTheme.setEffect(null);
                        BackblackTheme.setEffect(effectBG_DropShadow);
                        BackblackTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        BackblackTheme.setTextFill(Color.web(color2));
                        BackredTheme.setEffect(null);
                        UNOTheme.setEffect(null);
                    });

                    BackredTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> BackredTheme.setEffect(effectBG_DropShadow));
                    BackredTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t3blistener.isSelected()){
                            BackredTheme.setEffect(effectBG_DropShadow);}
                        else{
                            BackredTheme.setEffect(null);}
                    });
                    BackredTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1blistener.setSelected(false);
                        t2blistener.setSelected(false);
                        t3blistener.setSelected(true);
                        t4listener.setSelected(false);

                        BacklightTheme.setEffect(null);
                        BackblackTheme.setEffect(null);
                        BackredTheme.setEffect(effectBG_DropShadow);
                        BackredTheme.setStyle("-fx-background-color: #ff0000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        BackredTheme.setTextFill(Color.web(color2));
                        UNOTheme.setEffect(null);

                    });

                    UNOTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> UNOTheme.setEffect(effectBG_DropShadow));
                    UNOTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t4listener.isSelected()){
                            UNOTheme.setEffect(effectBG_DropShadow);}
                        else{
                            UNOTheme.setEffect(null);}
                    });
                    UNOTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1alistener.setSelected(false);
                        t2alistener.setSelected(false);
                        t3alistener.setSelected(false);
                        t1blistener.setSelected(false);
                        t2blistener.setSelected(false);
                        t3blistener.setSelected(false);
                        t4listener.setSelected(true);

                        FrontlightTheme.setEffect(null);
                        FrontblackTheme.setEffect(null);
                        FrontredTheme.setEffect(null);
                        BacklightTheme.setEffect(null);
                        BackblackTheme.setEffect(null);
                        BackredTheme.setEffect(null);
                        UNOTheme.setEffect(effectBG_DropShadow);
                        UNOTheme.setTextFill(Color.web(color2));
                        UNOTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");

                    });

                    //Player Count
                    r1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> r1.setEffect(effectBG_DropShadow));
                    r1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r1listener.isSelected()){
                            r1.setEffect(effectBG_DropShadow);}
                        else{r1.setEffect(null);}
                    });
                    r1.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        r1listener.setSelected(true);
                        r2listener.setSelected(false);
                        r3listener.setSelected(false);

                        r1.setEffect(effectBG_DropShadow);
                        r1.setTextFill(Color.web(color2));
                        r1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24; -fx-border-color: "+color2+"; -fx-border-radius: 24; -fx-border-width: 3 ;");
                        r2.setEffect(null);
                        r3.setEffect(null);

                    });
                    r2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> r2.setEffect(effectBG_DropShadow));
                    r2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r2listener.isSelected()){
                            r2.setEffect(effectBG_DropShadow);}
                        else{r2.setEffect(null);}
                    });
                    r2.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        r1listener.setSelected(false);
                        r2listener.setSelected(true);
                        r3listener.setSelected(false);

                        r1.setEffect(null);
                        r2.setEffect(effectBG_DropShadow);
                        r2.setTextFill(Color.web(color2));
                        r2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24; -fx-border-color: "+color2+"; -fx-border-radius: 24; -fx-border-width: 3 ;");
                        r3.setEffect(null);
                    });
                    r3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> r3.setEffect(effectBG_DropShadow));
                    r3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r3listener.isSelected()){
                            r3.setEffect(effectBG_DropShadow);}
                        else{r3.setEffect(null);}
                    });
                    r3.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        r1listener.setSelected(false);
                        r2listener.setSelected(false);
                        r3listener.setSelected(true);

                        r1.setEffect(null);
                        r2.setEffect(null);
                        r3.setEffect(effectBG_DropShadow);
                        r3.setTextFill(Color.web(color2));
                        r3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24; -fx-border-color: "+color2+"; -fx-border-radius: 24; -fx-border-width: 3 ;");

                    });

                    multiplayer.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> multiplayer.setEffect(effectBG_DropShadow));
                    multiplayer.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        multiplayer.setEffect(null);
                    });
                    multiplayer.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
                        multiplayer.setEffect(effectBG_DropShadow);
                    });

                }
                else if (tColor == 4) {

                    color2 = "#d50000";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(181,0,0), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(245,0,0), 10, 0, 5, 5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(181,0,0), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(245,0,0), 10, 0, 5, 5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBackButton = getClass().getResourceAsStream("../../../resources/svg/left_arrow/left-arrow.svg");
                    svgFileBackButton_Hover = getClass().getResourceAsStream("../../../resources/svg/left_arrow/left-arrow_blue.svg");

                    svgFileOption = getClass().getResourceAsStream("../../../resources/svg/menu/menu.svg");
                    svgFileOption_Hover = getClass().getResourceAsStream("../../../resources/svg/menu/menu_blue.svg");

                    Group svgImageBackButton = loader.loadSvg(svgFileBackButton);
                    Group svgImageBackButton_Hover = loader.loadSvg(svgFileBackButton_Hover);

                    Group svgImageOption = loader.loadSvg(svgFileOption);
                    Group svgImageOption_Hover = loader.loadSvg(svgFileOption_Hover);

                    svgImageBackButton.setScaleX(.04);
                    svgImageBackButton.setScaleY(.04);
                    svgImageBackButton_Hover.setScaleX(.04);
                    svgImageBackButton_Hover.setScaleY(.04);

                    svgImageOption.setScaleX(.04);
                    svgImageOption.setScaleY(.04);
                    svgImageOption_Hover.setScaleX(.04);
                    svgImageOption_Hover.setScaleY(.04);

                    Group svgIconBackButton = new Group(svgImageBackButton);
                    Group svgIconBackButton_Hover = new Group(svgImageBackButton_Hover);

                    Group svgIconOption = new Group(svgImageOption);
                    Group svgIconOption_Hover = new Group(svgImageOption_Hover);

                    backButton.setGraphic(svgIconOption);

                    fadeIn.setDuration(Duration.millis(500));
                    fadeOut.setDuration(Duration.millis(200));

                    fadeIn.setFromValue(0);
                    fadeIn.setToValue(10);

                    fadeOut.setFromValue(10);
                    fadeOut.setToValue(0);

                    fadeIn.setCycleCount(1);
                    fadeOut.setCycleCount(1);

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        backButton.setEffect(effectC_DropShadow);
                        backButton.setGraphic(svgIconBackButton);

                        l1.setText("");
                        l2.setText("Back to Home");
                        l3.setText("");

                        Panel1.setEffect(blur);
                        Panel2.setEffect(blur);
                        Panel3.setEffect(blur);
                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        backButton.setEffect(null);
                        backButton.setGraphic(svgIconOption);

                        l1.setText("MEMORY");
                        l2.setText("GAME");
                        l3.setText("Mᴜʟᴛɪ Pʟᴀʏᴇʀ");

                        Panel1.setEffect(effectBG_DropShadow);
                        Panel2.setEffect(effectBG_DropShadow);
                        Panel3.setEffect(effectBG_DropShadow);

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e ->{

                        backButton.setGraphic(svgIconBackButton_Hover);

                        Panel1.setEffect(null);
                        Panel2.setEffect(null);
                        Panel3.setEffect(null);

                        fadeOut5.play();
                        fadeOut5_1.play();
                        fadeOut5_2.play();
                        fadeOut.play();
                        fadeOut2.play();
                        fadeOut3.play();
                        fadeOut4.play();
                        fadeOut6.play();
                        fadeOut7.play();
                        fadeOut8.play();
                        fadeOut9.play();
                        fadeOut9_1.play();
                        fadeOut9_2.play();
                        fadeOut9_3.play();
                        fadeOut9_4.play();
                        fadeOut9_5.play();
                        fadeOut9_6.play();
                        fadeOut9_7.play();
                        fadeOut9_8.play();
                        fadeOut9_9.play();
                        fadeOut9_10.play();
                        fadeOut9_11.play();
                        fadeOut9_12.play();
                        fadeOut9_13.play();

                    });

                    Panelex3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        backButton.setGraphic(svgIconOption_Hover);

                    });
                    Panelex3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        backButton.setGraphic(svgIconOption);

                    });

                    //INIT
                    if(f.exists()) {

                        input = new FileInputStream("config.properties");
                        properties.load(input);

                        int width = Integer.parseInt(properties.getProperty("width"));

                        if (width==999){

                            singleMode.setDisable(false);
                            doubleMode.setDisable(false);
                            hardModebtn.setDisable(false);
                            hellModebtn.setDisable(false);

                            singleMode.setVisible(true);
                            doubleMode.setVisible(true);
                            hardModebtn.setVisible(true);
                            hellModebtn.setVisible(true);

                        }
                        else if (width==1600){

                            singleMode.setDisable(false);
                            doubleMode.setDisable(false);
                            hardModebtn.setDisable(true);
                            hellModebtn.setDisable(true);

                            singleMode.setVisible(true);
                            doubleMode.setVisible(true);
                            hardModebtn.setVisible(false);
                            hellModebtn.setVisible(false);

                        }
                        else if (width==1280){

                            singleMode.setDisable(false);
                            doubleMode.setDisable(false);
                            hardModebtn.setDisable(true);
                            hellModebtn.setDisable(true);

                            singleMode.setVisible(true);
                            doubleMode.setVisible(true);
                            hardModebtn.setVisible(false);
                            hellModebtn.setVisible(false);

                        }
                    }
                    if(f3.exists()) {

                        input3 = new FileInputStream("gamemode.properties");
                        properties3.load(input3);

                        int gSelected = Integer.parseInt(properties3.getProperty("GSelected"));
                        int tSelected = Integer.parseInt(properties3.getProperty("TSelected"));
                        int rSelected = Integer.parseInt(properties3.getProperty("RSelected"));
                        int tfSelected = Integer.parseInt(properties3.getProperty("TFSelected"));
                        int tbSelected = Integer.parseInt(properties3.getProperty("TBSelected"));

                        if (gSelected==0){

                            singleMode.setEffect(null);
                            doubleMode.setEffect(null);
                            hardModebtn.setEffect(null);
                            hellModebtn.setEffect(null);

                            g1listener.setSelected(false);
                            g2listener.setSelected(false);
                            g3listener.setSelected(false);
                            g4listener.setSelected(false);

                        }
                        else if (gSelected==1){

                            singleMode.setEffect(effectBG_DropShadow);
                            singleMode.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                            singleMode.setTextFill(Color.web(color2));
                            doubleMode.setEffect(null);
                            hardModebtn.setEffect(null);
                            hellModebtn.setEffect(null);

                            g1listener.setSelected(true);
                            g2listener.setSelected(false);
                            g3listener.setSelected(false);
                            g4listener.setSelected(false);

                            mode.setMode(1);

                        }
                        else if (gSelected==2){

                            singleMode.setEffect(null);
                            doubleMode.setEffect(effectBG_DropShadow);
                            doubleMode.setTextFill(Color.web(color2));
                            doubleMode.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                            hardModebtn.setEffect(null);
                            hellModebtn.setEffect(null);

                            g1listener.setSelected(false);
                            g2listener.setSelected(true);
                            g3listener.setSelected(false);
                            g4listener.setSelected(false);

                            mode.setMode(2);

                        }
                        else if (gSelected==3){

                            singleMode.setEffect(null);
                            doubleMode.setEffect(null);
                            hardModebtn.setEffect(effectBG_DropShadow);
                            hardModebtn.setTextFill(Color.web(color2));
                            hardModebtn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                            hellModebtn.setEffect(null);

                            g1listener.setSelected(false);
                            g2listener.setSelected(false);
                            g3listener.setSelected(true);
                            g4listener.setSelected(false);

                            mode.setMode(3);

                        }
                        else if (gSelected==4){

                            singleMode.setEffect(null);
                            doubleMode.setEffect(null);
                            hardModebtn.setEffect(null);
                            hellModebtn.setEffect(effectBG_DropShadow);
                            hellModebtn.setTextFill(Color.web(color2));
                            hellModebtn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");

                            g1listener.setSelected(false);
                            g2listener.setSelected(false);
                            g3listener.setSelected(false);
                            g4listener.setSelected(true);

                            mode.setMode(4);

                        }

                        if (tSelected==0){

                            FrontlightTheme.setEffect(null);
                            FrontblackTheme.setEffect(null);
                            FrontredTheme.setEffect(null);
                            BacklightTheme.setEffect(null);
                            BackblackTheme.setEffect(null);
                            BackredTheme.setEffect(null);
                            UNOTheme.setEffect(null);

                            t1alistener.setSelected(false);
                            t1blistener.setSelected(false);
                            t2alistener.setSelected(false);
                            t2blistener.setSelected(false);
                            t3alistener.setSelected(false);
                            t3blistener.setSelected(false);
                            t4listener.setSelected(false);

                        }
                        else if (tSelected==1){

                            if (tfSelected==0) {

                                FrontlightTheme.setEffect(null);
                                FrontblackTheme.setEffect(null);
                                FrontredTheme.setEffect(null);
                                UNOTheme.setEffect(null);

                                t1alistener.setSelected(false);
                                t2alistener.setSelected(false);
                                t3alistener.setSelected(false);
                                t4listener.setSelected(false);


                            }
                            else if (tfSelected==1) {

                                FrontlightTheme.setEffect(effectBG_DropShadow);
                                FrontlightTheme.setTextFill(Color.web(color2));
                                FrontlightTheme.setStyle("-fx-background-color: #f8f8f8; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                FrontblackTheme.setEffect(null);
                                FrontredTheme.setEffect(null);
                                UNOTheme.setEffect(null);

                                t1alistener.setSelected(true);
                                t2alistener.setSelected(false);
                                t3alistener.setSelected(false);
                                t4listener.setSelected(false);


                            }
                            else if (tfSelected==2) {

                                FrontlightTheme.setEffect(null);
                                FrontblackTheme.setEffect(effectBG_DropShadow);
                                FrontblackTheme.setTextFill(Color.web(color2));
                                FrontblackTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                FrontredTheme.setEffect(null);
                                UNOTheme.setEffect(null);

                                t1alistener.setSelected(false);
                                t2alistener.setSelected(true);
                                t3alistener.setSelected(false);
                                t4listener.setSelected(false);

                            }
                            else if (tfSelected==3) {

                                FrontlightTheme.setEffect(null);
                                FrontblackTheme.setEffect(null);
                                FrontredTheme.setEffect(effectBG_DropShadow);
                                FrontredTheme.setTextFill(Color.web(color2));
                                FrontredTheme.setStyle("-fx-background-color: #ff0000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                UNOTheme.setEffect(null);

                                t1alistener.setSelected(false);
                                t2alistener.setSelected(false);
                                t3alistener.setSelected(true);
                                t4listener.setSelected(false);

                            }

                            if (tbSelected == 0) {

                                BacklightTheme.setEffect(null);
                                BackblackTheme.setEffect(null);
                                BackredTheme.setEffect(null);

                                t1blistener.setSelected(false);
                                t2blistener.setSelected(false);
                                t3blistener.setSelected(false);

                            }
                            else if (tbSelected == 1) {

                                BacklightTheme.setEffect(effectBG_DropShadow);
                                BacklightTheme.setTextFill(Color.web(color2));
                                BacklightTheme.setStyle("-fx-background-color: #f8f8f8; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                BackblackTheme.setEffect(null);
                                BackredTheme.setEffect(null);

                                t1blistener.setSelected(true);
                                t2blistener.setSelected(false);
                                t3blistener.setSelected(false);

                            }
                            else if (tbSelected == 2) {

                                BacklightTheme.setEffect(null);
                                BackblackTheme.setEffect(effectBG_DropShadow);
                                BackblackTheme.setTextFill(Color.web(color2));
                                BackblackTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                BackredTheme.setEffect(null);

                                t1blistener.setSelected(false);
                                t2blistener.setSelected(true);
                                t3blistener.setSelected(false);

                            }
                            else if (tbSelected == 3) {

                                BacklightTheme.setEffect(null);
                                BackblackTheme.setEffect(null);
                                BackredTheme.setEffect(effectBG_DropShadow);
                                BackredTheme.setStyle("-fx-background-color: #ff0000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                BackredTheme.setTextFill(Color.web(color2));

                                t1blistener.setSelected(false);
                                t2blistener.setSelected(false);
                                t3blistener.setSelected(true);

                            }

                        }
                        else if (tSelected==2){

                            FrontlightTheme.setEffect(null);
                            FrontblackTheme.setEffect(null);
                            FrontredTheme.setEffect(null);
                            BacklightTheme.setEffect(null);
                            BackblackTheme.setEffect(null);
                            BackredTheme.setEffect(null);
                            UNOTheme.setEffect(effectBG_DropShadow);
                            UNOTheme.setTextFill(Color.web(color2));
                            UNOTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");

                            t1alistener.setSelected(false);
                            t1blistener.setSelected(false);
                            t2alistener.setSelected(false);
                            t2blistener.setSelected(false);
                            t3alistener.setSelected(false);
                            t3blistener.setSelected(false);
                            t4listener.setSelected(true);

                        }

                        if (rSelected==0){

                            r1.setEffect(null);
                            r2.setEffect(null);
                            r3.setEffect(null);

                            r1listener.setSelected(false);
                            r2listener.setSelected(false);
                            r3listener.setSelected(false);

                        }
                        else if (rSelected==1){

                            r1.setEffect(effectBG_DropShadow);
                            r1.setTextFill(Color.web(color2));
                            r1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 16; -fx-border-color: "+color2+"; -fx-border-radius: 16; -fx-border-width: 3 ;");
                            r2.setEffect(null);
                            r3.setEffect(null);

                            r1listener.setSelected(true);
                            r2listener.setSelected(false);
                            r3listener.setSelected(false);

                            mode.setRivalsNumber(1);
                            mode.setRival1("Goldfish");
                            mode.setRival2("");
                            mode.setRival3("");

                        }
                        else if (rSelected==2){

                            r1.setEffect(null);
                            r2.setEffect(effectBG_DropShadow);
                            r2.setTextFill(Color.web(color2));
                            r2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 16; -fx-border-color: "+color2+"; -fx-border-radius: 16; -fx-border-width: 3 ;");
                            r3.setEffect(null);

                            r1listener.setSelected(false);
                            r2listener.setSelected(true);
                            r3listener.setSelected(false);

                            mode.setRivalsNumber(2);
                            mode.setRival1("Goldfish");
                            mode.setRival2("Goldfish");
                            mode.setRival3("");

                        }
                        else if (rSelected==3){

                            r1.setEffect(null);
                            r2.setEffect(null);
                            r3.setEffect(effectBG_DropShadow);
                            r3.setTextFill(Color.web(color2));
                            r3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 16; -fx-border-color: "+color2+"; -fx-border-radius: 16; -fx-border-width: 3 ;");

                            r1listener.setSelected(false);
                            r2listener.setSelected(false);
                            r3listener.setSelected(true);

                            mode.setRivalsNumber(3);
                            mode.setRival1("Goldfish");
                            mode.setRival2("Goldfish");
                            mode.setRival3("Goldfish");

                        }

                        if (gSelected==0||tSelected==0||tfSelected==0||tbSelected==0||rSelected==0){
                            multiplayer.setVisible(false);
                        }else {
                            multiplayer.setVisible(true);
                        }

                    }

                    singleMode.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> singleMode.setEffect(effectBG_DropShadow));
                    singleMode.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (g1listener.isSelected()){
                            singleMode.setEffect(effectBG_DropShadow);}
                        else{singleMode.setEffect(null);}
                    });
                    singleMode.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        g1listener.setSelected(true);
                        g2listener.setSelected(false);
                        g3listener.setSelected(false);
                        g4listener.setSelected(false);

                        singleMode.setEffect(effectBG_DropShadow);
                        singleMode.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        singleMode.setTextFill(Color.web(color2));
                        doubleMode.setEffect(null);
                        hardModebtn.setEffect(null);
                        hellModebtn.setEffect(null);

                    });

                    doubleMode.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> doubleMode.setEffect(effectBG_DropShadow));
                    doubleMode.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (g2listener.isSelected()){
                            doubleMode.setEffect(effectBG_DropShadow);}
                        else{doubleMode.setEffect(null);}
                    });
                    doubleMode.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        g1listener.setSelected(false);
                        g2listener.setSelected(true);
                        g3listener.setSelected(false);
                        g4listener.setSelected(false);

                        singleMode.setEffect(null);
                        doubleMode.setEffect(effectBG_DropShadow);
                        doubleMode.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        doubleMode.setTextFill(Color.web(color2));
                        hardModebtn.setEffect(null);
                        hellModebtn.setEffect(null);

                    });

                    hardModebtn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> hardModebtn.setEffect(effectBG_DropShadow));
                    hardModebtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (g3listener.isSelected()){
                            hardModebtn.setEffect(effectBG_DropShadow);}
                        else{hardModebtn.setEffect(null);}
                    });
                    hardModebtn.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        g1listener.setSelected(false);
                        g2listener.setSelected(false);
                        g3listener.setSelected(true);
                        g4listener.setSelected(false);

                        singleMode.setEffect(null);
                        doubleMode.setEffect(null);
                        hardModebtn.setEffect(effectBG_DropShadow);
                        hardModebtn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        hardModebtn.setTextFill(Color.web(color2));
                        hellModebtn.setEffect(null);

                    });

                    hellModebtn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> hellModebtn.setEffect(effectBG_DropShadow));
                    hellModebtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (g4listener.isSelected()){
                            hellModebtn.setEffect(effectBG_DropShadow);}
                        else{hellModebtn.setEffect(null);}
                    });
                    hellModebtn.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        g1listener.setSelected(false);
                        g2listener.setSelected(false);
                        g3listener.setSelected(false);
                        g4listener.setSelected(true);

                        singleMode.setEffect(null);
                        doubleMode.setEffect(null);
                        hardModebtn.setEffect(null);
                        hellModebtn.setEffect(effectBG_DropShadow);
                        hellModebtn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        hellModebtn.setTextFill(Color.web(color2));

                    });

                    //THEME
                    FrontlightTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> FrontlightTheme.setEffect(effectBG_DropShadow));
                    FrontlightTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t1alistener.isSelected()){
                            FrontlightTheme.setEffect(effectBG_DropShadow);}
                        else{
                            FrontlightTheme.setEffect(null);}
                    });
                    FrontlightTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1alistener.setSelected(true);
                        t2alistener.setSelected(false);
                        t3alistener.setSelected(false);
                        t4listener.setSelected(false);

                        FrontlightTheme.setEffect(effectBG_DropShadow);
                        FrontlightTheme.setStyle("-fx-background-color: #f8f8f8; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        FrontlightTheme.setTextFill(Color.web(color2));
                        FrontblackTheme.setEffect(null);
                        FrontredTheme.setEffect(null);
                        UNOTheme.setEffect(null);

                    });

                    FrontblackTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> FrontblackTheme.setEffect(effectBG_DropShadow));
                    FrontblackTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t2alistener.isSelected()){
                            FrontblackTheme.setEffect(effectBG_DropShadow);}
                        else{
                            FrontblackTheme.setEffect(null);}
                    });
                    FrontblackTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1alistener.setSelected(false);
                        t2alistener.setSelected(true);
                        t3alistener.setSelected(false);
                        t4listener.setSelected(false);

                        FrontlightTheme.setEffect(null);
                        FrontblackTheme.setEffect(effectBG_DropShadow);
                        FrontblackTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        FrontblackTheme.setTextFill(Color.web(color2));
                        FrontredTheme.setEffect(null);
                        UNOTheme.setEffect(null);

                    });

                    FrontredTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> FrontredTheme.setEffect(effectBG_DropShadow));
                    FrontredTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t3alistener.isSelected()){
                            FrontredTheme.setEffect(effectBG_DropShadow);}
                        else{
                            FrontredTheme.setEffect(null);}
                    });
                    FrontredTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1alistener.setSelected(false);
                        t2alistener.setSelected(false);
                        t3alistener.setSelected(true);
                        t4listener.setSelected(false);

                        FrontlightTheme.setEffect(null);
                        FrontblackTheme.setEffect(null);
                        FrontredTheme.setEffect(effectBG_DropShadow);
                        FrontredTheme.setStyle("-fx-background-color: #ff0000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        FrontredTheme.setTextFill(Color.web(color2));
                        UNOTheme.setEffect(null);

                    });

                    BacklightTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> BacklightTheme.setEffect(effectBG_DropShadow));
                    BacklightTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t1blistener.isSelected()){
                            BacklightTheme.setEffect(effectBG_DropShadow);}
                        else{
                            BacklightTheme.setEffect(null);}
                    });
                    BacklightTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1blistener.setSelected(true);
                        t2blistener.setSelected(false);
                        t3blistener.setSelected(false);
                        t4listener.setSelected(false);

                        BacklightTheme.setEffect(effectBG_DropShadow);
                        BacklightTheme.setStyle("-fx-background-color: #f8f8f8; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        BacklightTheme.setTextFill(Color.web(color2));
                        BackblackTheme.setEffect(null);
                        BackredTheme.setEffect(null);
                        UNOTheme.setEffect(null);
                    });

                    BackblackTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> BackblackTheme.setEffect(effectBG_DropShadow));
                    BackblackTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t2blistener.isSelected()){
                            BackblackTheme.setEffect(effectBG_DropShadow);}
                        else{
                            BackblackTheme.setEffect(null);}
                    });
                    BackblackTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1blistener.setSelected(false);
                        t2blistener.setSelected(true);
                        t3blistener.setSelected(false);
                        t4listener.setSelected(false);

                        BacklightTheme.setEffect(null);
                        BackblackTheme.setEffect(effectBG_DropShadow);
                        BackblackTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        BackblackTheme.setTextFill(Color.web(color2));
                        BackredTheme.setEffect(null);
                        UNOTheme.setEffect(null);
                    });

                    BackredTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> BackredTheme.setEffect(effectBG_DropShadow));
                    BackredTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t3blistener.isSelected()){
                            BackredTheme.setEffect(effectBG_DropShadow);}
                        else{
                            BackredTheme.setEffect(null);}
                    });
                    BackredTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1blistener.setSelected(false);
                        t2blistener.setSelected(false);
                        t3blistener.setSelected(true);
                        t4listener.setSelected(false);

                        BacklightTheme.setEffect(null);
                        BackblackTheme.setEffect(null);
                        BackredTheme.setEffect(effectBG_DropShadow);
                        BackredTheme.setStyle("-fx-background-color: #ff0000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        BackredTheme.setTextFill(Color.web(color2));
                        UNOTheme.setEffect(null);

                    });

                    UNOTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> UNOTheme.setEffect(effectBG_DropShadow));
                    UNOTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t4listener.isSelected()){
                            UNOTheme.setEffect(effectBG_DropShadow);}
                        else{
                            UNOTheme.setEffect(null);}
                    });
                    UNOTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1alistener.setSelected(false);
                        t2alistener.setSelected(false);
                        t3alistener.setSelected(false);
                        t1blistener.setSelected(false);
                        t2blistener.setSelected(false);
                        t3blistener.setSelected(false);
                        t4listener.setSelected(true);

                        FrontlightTheme.setEffect(null);
                        FrontblackTheme.setEffect(null);
                        FrontredTheme.setEffect(null);
                        BacklightTheme.setEffect(null);
                        BackblackTheme.setEffect(null);
                        BackredTheme.setEffect(null);
                        UNOTheme.setEffect(effectBG_DropShadow);
                        UNOTheme.setTextFill(Color.web(color2));
                        UNOTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");

                    });

                    //Player Count
                    r1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> r1.setEffect(effectBG_DropShadow));
                    r1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r1listener.isSelected()){
                            r1.setEffect(effectBG_DropShadow);}
                        else{r1.setEffect(null);}
                    });
                    r1.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        r1listener.setSelected(true);
                        r2listener.setSelected(false);
                        r3listener.setSelected(false);

                        r1.setEffect(effectBG_DropShadow);
                        r1.setTextFill(Color.web(color2));
                        r1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24; -fx-border-color: "+color2+"; -fx-border-radius: 24; -fx-border-width: 3 ;");
                        r2.setEffect(null);
                        r3.setEffect(null);

                    });
                    r2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> r2.setEffect(effectBG_DropShadow));
                    r2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r2listener.isSelected()){
                            r2.setEffect(effectBG_DropShadow);}
                        else{r2.setEffect(null);}
                    });
                    r2.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        r1listener.setSelected(false);
                        r2listener.setSelected(true);
                        r3listener.setSelected(false);

                        r1.setEffect(null);
                        r2.setEffect(effectBG_DropShadow);
                        r2.setTextFill(Color.web(color2));
                        r2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24; -fx-border-color: "+color2+"; -fx-border-radius: 24; -fx-border-width: 3 ;");
                        r3.setEffect(null);
                    });
                    r3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> r3.setEffect(effectBG_DropShadow));
                    r3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r3listener.isSelected()){
                            r3.setEffect(effectBG_DropShadow);}
                        else{r3.setEffect(null);}
                    });
                    r3.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        r1listener.setSelected(false);
                        r2listener.setSelected(false);
                        r3listener.setSelected(true);

                        r1.setEffect(null);
                        r2.setEffect(null);
                        r3.setEffect(effectBG_DropShadow);
                        r3.setTextFill(Color.web(color2));
                        r3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24; -fx-border-color: "+color2+"; -fx-border-radius: 24; -fx-border-width: 3 ;");

                    });

                    multiplayer.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> multiplayer.setEffect(effectBG_DropShadow));
                    multiplayer.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        multiplayer.setEffect(null);
                    });
                    multiplayer.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
                        multiplayer.setEffect(effectBG_DropShadow);
                    });

                }

            }
            else if (theme == 2) {

                color = "#121212";

                effectBG_DropShadowADD = new DropShadow(BlurType.GAUSSIAN, Color.rgb(20,20,20), 10, 0, 5, 5);
                effectBG_DropShadow = new DropShadow(BlurType.GAUSSIAN, Color.rgb(28,28,28), 10, 0, 5, 5);
                effectBG_DropShadow.setInput(effectBG_DropShadowADD);

                effectBG_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(20,20,20), 10, 0, 5, 5);
                effectBG_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(20,20,20), 10, 0, 5, 5);
                effectBG_InnerShadow.setInput(effectBG_InnerShadowADD);

                Panel1.setEffect(effectBG_DropShadow);
                Panel2.setEffect(effectBG_DropShadow);
                Panel3.setEffect(effectBG_DropShadow);


                if (tColor == 1) {

                    color2 = "#004fcb";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,67,173), 24, 0, 9, 9);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,91,233), 24, 0, -9, -9);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,67,173), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,91,233), 10, 0, 5, 5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBackButton = getClass().getResourceAsStream("../../../resources/svg/left_arrow/left-arrow_d.svg");
                    svgFileBackButton_Hover = getClass().getResourceAsStream("../../../resources/svg/left_arrow/left-arrow_dblue.svg");

                    svgFileOption = getClass().getResourceAsStream("../../../resources/svg/menu/menu_d.svg");
                    svgFileOption_Hover = getClass().getResourceAsStream("../../../resources/svg/menu/menu_dblue.svg");

                    Group svgImageBackButton = loader.loadSvg(svgFileBackButton);
                    Group svgImageBackButton_Hover = loader.loadSvg(svgFileBackButton_Hover);

                    Group svgImageOption = loader.loadSvg(svgFileOption);
                    Group svgImageOption_Hover = loader.loadSvg(svgFileOption_Hover);

                    svgImageBackButton.setScaleX(.04);
                    svgImageBackButton.setScaleY(.04);
                    svgImageBackButton_Hover.setScaleX(.04);
                    svgImageBackButton_Hover.setScaleY(.04);

                    svgImageOption.setScaleX(.04);
                    svgImageOption.setScaleY(.04);
                    svgImageOption_Hover.setScaleX(.04);
                    svgImageOption_Hover.setScaleY(.04);

                    Group svgIconBackButton = new Group(svgImageBackButton);
                    Group svgIconBackButton_Hover = new Group(svgImageBackButton_Hover);

                    Group svgIconOption = new Group(svgImageOption);
                    Group svgIconOption_Hover = new Group(svgImageOption_Hover);

                    backButton.setGraphic(svgIconOption);

                    fadeIn.setDuration(Duration.millis(500));
                    fadeOut.setDuration(Duration.millis(200));

                    fadeIn.setFromValue(0);
                    fadeIn.setToValue(10);

                    fadeOut.setFromValue(10);
                    fadeOut.setToValue(0);

                    fadeIn.setCycleCount(1);
                    fadeOut.setCycleCount(1);

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        backButton.setEffect(effectC_DropShadow);
                        backButton.setGraphic(svgIconBackButton);

                        l1.setText("");
                        l2.setText("Back to Home");
                        l3.setText("");

                        Panel1.setEffect(blur);
                        Panel2.setEffect(blur);
                        Panel3.setEffect(blur);
                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        backButton.setEffect(null);
                        backButton.setGraphic(svgIconOption);

                        l1.setText("MEMORY");
                        l2.setText("GAME");
                        l3.setText("Mᴜʟᴛɪ Pʟᴀʏᴇʀ");

                        Panel1.setEffect(effectBG_DropShadow);
                        Panel2.setEffect(effectBG_DropShadow);
                        Panel3.setEffect(effectBG_DropShadow);

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e ->{

                        backButton.setGraphic(svgIconBackButton_Hover);

                        Panel1.setEffect(null);
                        Panel2.setEffect(null);
                        Panel3.setEffect(null);

                        fadeOut5.play();
                        fadeOut5_1.play();
                        fadeOut5_2.play();
                        fadeOut.play();
                        fadeOut2.play();
                        fadeOut3.play();
                        fadeOut4.play();
                        fadeOut6.play();
                        fadeOut7.play();
                        fadeOut8.play();
                        fadeOut9.play();
                        fadeOut9_1.play();
                        fadeOut9_2.play();
                        fadeOut9_3.play();
                        fadeOut9_4.play();
                        fadeOut9_5.play();
                        fadeOut9_6.play();
                        fadeOut9_7.play();
                        fadeOut9_8.play();
                        fadeOut9_9.play();
                        fadeOut9_10.play();
                        fadeOut9_11.play();
                        fadeOut9_12.play();
                        fadeOut9_13.play();

                    });

                    Panelex3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        backButton.setGraphic(svgIconOption_Hover);

                    });
                    Panelex3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        backButton.setGraphic(svgIconOption);

                    });

                    //INIT
                    if(f.exists()) {

                        input = new FileInputStream("config.properties");
                        properties.load(input);

                        int width = Integer.parseInt(properties.getProperty("width"));

                        if (width==999){

                            singleMode.setDisable(false);
                            doubleMode.setDisable(false);
                            hardModebtn.setDisable(false);
                            hellModebtn.setDisable(false);

                            singleMode.setVisible(true);
                            doubleMode.setVisible(true);
                            hardModebtn.setVisible(true);
                            hellModebtn.setVisible(true);

                        }
                        else if (width==1600){

                            singleMode.setDisable(false);
                            doubleMode.setDisable(false);
                            hardModebtn.setDisable(true);
                            hellModebtn.setDisable(true);

                            singleMode.setVisible(true);
                            doubleMode.setVisible(true);
                            hardModebtn.setVisible(false);
                            hellModebtn.setVisible(false);

                        }
                        else if (width==1280){

                            singleMode.setDisable(false);
                            doubleMode.setDisable(false);
                            hardModebtn.setDisable(true);
                            hellModebtn.setDisable(true);

                            singleMode.setVisible(true);
                            doubleMode.setVisible(true);
                            hardModebtn.setVisible(false);
                            hellModebtn.setVisible(false);

                        }
                    }
                    if(f3.exists()) {

                        input3 = new FileInputStream("gamemode.properties");
                        properties3.load(input3);

                        int gSelected = Integer.parseInt(properties3.getProperty("GSelected"));
                        int tSelected = Integer.parseInt(properties3.getProperty("TSelected"));
                        int rSelected = Integer.parseInt(properties3.getProperty("RSelected"));
                        int tfSelected = Integer.parseInt(properties3.getProperty("TFSelected"));
                        int tbSelected = Integer.parseInt(properties3.getProperty("TBSelected"));

                        if (gSelected==0){

                            singleMode.setEffect(null);
                            doubleMode.setEffect(null);
                            hardModebtn.setEffect(null);
                            hellModebtn.setEffect(null);

                            g1listener.setSelected(false);
                            g2listener.setSelected(false);
                            g3listener.setSelected(false);
                            g4listener.setSelected(false);

                        }
                        else if (gSelected==1){

                            singleMode.setEffect(effectBG_DropShadow);
                            singleMode.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                            singleMode.setTextFill(Color.web(color2));
                            doubleMode.setEffect(null);
                            hardModebtn.setEffect(null);
                            hellModebtn.setEffect(null);

                            g1listener.setSelected(true);
                            g2listener.setSelected(false);
                            g3listener.setSelected(false);
                            g4listener.setSelected(false);

                            mode.setMode(1);

                        }
                        else if (gSelected==2){

                            singleMode.setEffect(null);
                            doubleMode.setEffect(effectBG_DropShadow);
                            doubleMode.setTextFill(Color.web(color2));
                            doubleMode.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                            hardModebtn.setEffect(null);
                            hellModebtn.setEffect(null);

                            g1listener.setSelected(false);
                            g2listener.setSelected(true);
                            g3listener.setSelected(false);
                            g4listener.setSelected(false);

                            mode.setMode(2);

                        }
                        else if (gSelected==3){

                            singleMode.setEffect(null);
                            doubleMode.setEffect(null);
                            hardModebtn.setEffect(effectBG_DropShadow);
                            hardModebtn.setTextFill(Color.web(color2));
                            hardModebtn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                            hellModebtn.setEffect(null);

                            g1listener.setSelected(false);
                            g2listener.setSelected(false);
                            g3listener.setSelected(true);
                            g4listener.setSelected(false);

                            mode.setMode(3);

                        }
                        else if (gSelected==4){

                            singleMode.setEffect(null);
                            doubleMode.setEffect(null);
                            hardModebtn.setEffect(null);
                            hellModebtn.setEffect(effectBG_DropShadow);
                            hellModebtn.setTextFill(Color.web(color2));
                            hellModebtn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");

                            g1listener.setSelected(false);
                            g2listener.setSelected(false);
                            g3listener.setSelected(false);
                            g4listener.setSelected(true);

                            mode.setMode(4);

                        }

                        if (tSelected==0){

                            FrontlightTheme.setEffect(null);
                            FrontblackTheme.setEffect(null);
                            FrontredTheme.setEffect(null);
                            BacklightTheme.setEffect(null);
                            BackblackTheme.setEffect(null);
                            BackredTheme.setEffect(null);
                            UNOTheme.setEffect(null);

                            t1alistener.setSelected(false);
                            t1blistener.setSelected(false);
                            t2alistener.setSelected(false);
                            t2blistener.setSelected(false);
                            t3alistener.setSelected(false);
                            t3blistener.setSelected(false);
                            t4listener.setSelected(false);

                        }
                        else if (tSelected==1){

                            if (tfSelected==0) {

                                FrontlightTheme.setEffect(null);
                                FrontblackTheme.setEffect(null);
                                FrontredTheme.setEffect(null);
                                UNOTheme.setEffect(null);

                                t1alistener.setSelected(false);
                                t2alistener.setSelected(false);
                                t3alistener.setSelected(false);
                                t4listener.setSelected(false);


                            }
                            else if (tfSelected==1) {

                                FrontlightTheme.setEffect(effectBG_DropShadow);
                                FrontlightTheme.setTextFill(Color.web(color2));
                                FrontlightTheme.setStyle("-fx-background-color: #f8f8f8; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                FrontblackTheme.setEffect(null);
                                FrontredTheme.setEffect(null);
                                UNOTheme.setEffect(null);

                                t1alistener.setSelected(true);
                                t2alistener.setSelected(false);
                                t3alistener.setSelected(false);
                                t4listener.setSelected(false);


                            }
                            else if (tfSelected==2) {

                                FrontlightTheme.setEffect(null);
                                FrontblackTheme.setEffect(effectBG_DropShadow);
                                FrontblackTheme.setTextFill(Color.web(color2));
                                FrontblackTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                FrontredTheme.setEffect(null);
                                UNOTheme.setEffect(null);

                                t1alistener.setSelected(false);
                                t2alistener.setSelected(true);
                                t3alistener.setSelected(false);
                                t4listener.setSelected(false);

                            }
                            else if (tfSelected==3) {

                                FrontlightTheme.setEffect(null);
                                FrontblackTheme.setEffect(null);
                                FrontredTheme.setEffect(effectBG_DropShadow);
                                FrontredTheme.setTextFill(Color.web(color2));
                                FrontredTheme.setStyle("-fx-background-color: #ff0000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                UNOTheme.setEffect(null);

                                t1alistener.setSelected(false);
                                t2alistener.setSelected(false);
                                t3alistener.setSelected(true);
                                t4listener.setSelected(false);

                            }

                            if (tbSelected == 0) {

                                BacklightTheme.setEffect(null);
                                BackblackTheme.setEffect(null);
                                BackredTheme.setEffect(null);

                                t1blistener.setSelected(false);
                                t2blistener.setSelected(false);
                                t3blistener.setSelected(false);

                            }
                            else if (tbSelected == 1) {

                                BacklightTheme.setEffect(effectBG_DropShadow);
                                BacklightTheme.setTextFill(Color.web(color2));
                                BacklightTheme.setStyle("-fx-background-color: #f8f8f8; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                BackblackTheme.setEffect(null);
                                BackredTheme.setEffect(null);

                                t1blistener.setSelected(true);
                                t2blistener.setSelected(false);
                                t3blistener.setSelected(false);

                            }
                            else if (tbSelected == 2) {

                                BacklightTheme.setEffect(null);
                                BackblackTheme.setEffect(effectBG_DropShadow);
                                BackblackTheme.setTextFill(Color.web(color2));
                                BackblackTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                BackredTheme.setEffect(null);

                                t1blistener.setSelected(false);
                                t2blistener.setSelected(true);
                                t3blistener.setSelected(false);

                            }
                            else if (tbSelected == 3) {

                                BacklightTheme.setEffect(null);
                                BackblackTheme.setEffect(null);
                                BackredTheme.setEffect(effectBG_DropShadow);
                                BackredTheme.setStyle("-fx-background-color: #ff0000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                BackredTheme.setTextFill(Color.web(color2));

                                t1blistener.setSelected(false);
                                t2blistener.setSelected(false);
                                t3blistener.setSelected(true);

                            }

                        }
                        else if (tSelected==2){

                            FrontlightTheme.setEffect(null);
                            FrontblackTheme.setEffect(null);
                            FrontredTheme.setEffect(null);
                            BacklightTheme.setEffect(null);
                            BackblackTheme.setEffect(null);
                            BackredTheme.setEffect(null);
                            UNOTheme.setEffect(effectBG_DropShadow);
                            UNOTheme.setTextFill(Color.web(color2));
                            UNOTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");

                            t1alistener.setSelected(false);
                            t1blistener.setSelected(false);
                            t2alistener.setSelected(false);
                            t2blistener.setSelected(false);
                            t3alistener.setSelected(false);
                            t3blistener.setSelected(false);
                            t4listener.setSelected(true);

                        }

                        if (rSelected==0){

                            r1.setEffect(null);
                            r2.setEffect(null);
                            r3.setEffect(null);

                            r1listener.setSelected(false);
                            r2listener.setSelected(false);
                            r3listener.setSelected(false);

                        }
                        else if (rSelected==1){

                            r1.setEffect(effectBG_DropShadow);
                            r1.setTextFill(Color.web(color2));
                            r1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 16; -fx-border-color: "+color2+"; -fx-border-radius: 16; -fx-border-width: 3 ;");
                            r2.setEffect(null);
                            r3.setEffect(null);

                            r1listener.setSelected(true);
                            r2listener.setSelected(false);
                            r3listener.setSelected(false);

                            mode.setRivalsNumber(1);
                            mode.setRival1("Goldfish");
                            mode.setRival2("");
                            mode.setRival3("");

                        }
                        else if (rSelected==2){

                            r1.setEffect(null);
                            r2.setEffect(effectBG_DropShadow);
                            r2.setTextFill(Color.web(color2));
                            r2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 16; -fx-border-color: "+color2+"; -fx-border-radius: 16; -fx-border-width: 3 ;");
                            r3.setEffect(null);

                            r1listener.setSelected(false);
                            r2listener.setSelected(true);
                            r3listener.setSelected(false);

                            mode.setRivalsNumber(2);
                            mode.setRival1("Goldfish");
                            mode.setRival2("Goldfish");
                            mode.setRival3("");

                        }
                        else if (rSelected==3){

                            r1.setEffect(null);
                            r2.setEffect(null);
                            r3.setEffect(effectBG_DropShadow);
                            r3.setTextFill(Color.web(color2));
                            r3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 16; -fx-border-color: "+color2+"; -fx-border-radius: 16; -fx-border-width: 3 ;");

                            r1listener.setSelected(false);
                            r2listener.setSelected(false);
                            r3listener.setSelected(true);

                            mode.setRivalsNumber(3);
                            mode.setRival1("Goldfish");
                            mode.setRival2("Goldfish");
                            mode.setRival3("Goldfish");

                        }

                        if (gSelected==0||tSelected==0||tfSelected==0||tbSelected==0||rSelected==0){
                            multiplayer.setVisible(false);
                        }else {
                            multiplayer.setVisible(true);
                        }

                    }

                    singleMode.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> singleMode.setEffect(effectBG_DropShadow));
                    singleMode.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (g1listener.isSelected()){
                            singleMode.setEffect(effectBG_DropShadow);}
                        else{singleMode.setEffect(null);}
                    });
                    singleMode.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        g1listener.setSelected(true);
                        g2listener.setSelected(false);
                        g3listener.setSelected(false);
                        g4listener.setSelected(false);

                        singleMode.setEffect(effectBG_DropShadow);
                        singleMode.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        singleMode.setTextFill(Color.web(color2));
                        doubleMode.setEffect(null);
                        hardModebtn.setEffect(null);
                        hellModebtn.setEffect(null);

                    });

                    doubleMode.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> doubleMode.setEffect(effectBG_DropShadow));
                    doubleMode.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (g2listener.isSelected()){
                            doubleMode.setEffect(effectBG_DropShadow);}
                        else{doubleMode.setEffect(null);}
                    });
                    doubleMode.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        g1listener.setSelected(false);
                        g2listener.setSelected(true);
                        g3listener.setSelected(false);
                        g4listener.setSelected(false);

                        singleMode.setEffect(null);
                        doubleMode.setEffect(effectBG_DropShadow);
                        doubleMode.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        doubleMode.setTextFill(Color.web(color2));
                        hardModebtn.setEffect(null);
                        hellModebtn.setEffect(null);

                    });

                    hardModebtn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> hardModebtn.setEffect(effectBG_DropShadow));
                    hardModebtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (g3listener.isSelected()){
                            hardModebtn.setEffect(effectBG_DropShadow);}
                        else{hardModebtn.setEffect(null);}
                    });
                    hardModebtn.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        g1listener.setSelected(false);
                        g2listener.setSelected(false);
                        g3listener.setSelected(true);
                        g4listener.setSelected(false);

                        singleMode.setEffect(null);
                        doubleMode.setEffect(null);
                        hardModebtn.setEffect(effectBG_DropShadow);
                        hardModebtn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        hardModebtn.setTextFill(Color.web(color2));
                        hellModebtn.setEffect(null);

                    });

                    hellModebtn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> hellModebtn.setEffect(effectBG_DropShadow));
                    hellModebtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (g4listener.isSelected()){
                            hellModebtn.setEffect(effectBG_DropShadow);}
                        else{hellModebtn.setEffect(null);}
                    });
                    hellModebtn.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        g1listener.setSelected(false);
                        g2listener.setSelected(false);
                        g3listener.setSelected(false);
                        g4listener.setSelected(true);

                        singleMode.setEffect(null);
                        doubleMode.setEffect(null);
                        hardModebtn.setEffect(null);
                        hellModebtn.setEffect(effectBG_DropShadow);
                        hellModebtn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        hellModebtn.setTextFill(Color.web(color2));

                    });

                    //THEME
                    FrontlightTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> FrontlightTheme.setEffect(effectBG_DropShadow));
                    FrontlightTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t1alistener.isSelected()){
                            FrontlightTheme.setEffect(effectBG_DropShadow);}
                        else{
                            FrontlightTheme.setEffect(null);}
                    });
                    FrontlightTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1alistener.setSelected(true);
                        t2alistener.setSelected(false);
                        t3alistener.setSelected(false);
                        t4listener.setSelected(false);

                        FrontlightTheme.setEffect(effectBG_DropShadow);
                        FrontlightTheme.setStyle("-fx-background-color: #f8f8f8; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        FrontlightTheme.setTextFill(Color.web(color2));
                        FrontblackTheme.setEffect(null);
                        FrontredTheme.setEffect(null);
                        UNOTheme.setEffect(null);

                    });

                    FrontblackTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> FrontblackTheme.setEffect(effectBG_DropShadow));
                    FrontblackTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t2alistener.isSelected()){
                            FrontblackTheme.setEffect(effectBG_DropShadow);}
                        else{
                            FrontblackTheme.setEffect(null);}
                    });
                    FrontblackTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1alistener.setSelected(false);
                        t2alistener.setSelected(true);
                        t3alistener.setSelected(false);
                        t4listener.setSelected(false);

                        FrontlightTheme.setEffect(null);
                        FrontblackTheme.setEffect(effectBG_DropShadow);
                        FrontblackTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        FrontblackTheme.setTextFill(Color.web(color2));
                        FrontredTheme.setEffect(null);
                        UNOTheme.setEffect(null);

                    });

                    FrontredTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> FrontredTheme.setEffect(effectBG_DropShadow));
                    FrontredTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t3alistener.isSelected()){
                            FrontredTheme.setEffect(effectBG_DropShadow);}
                        else{
                            FrontredTheme.setEffect(null);}
                    });
                    FrontredTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1alistener.setSelected(false);
                        t2alistener.setSelected(false);
                        t3alistener.setSelected(true);
                        t4listener.setSelected(false);

                        FrontlightTheme.setEffect(null);
                        FrontblackTheme.setEffect(null);
                        FrontredTheme.setEffect(effectBG_DropShadow);
                        FrontredTheme.setStyle("-fx-background-color: #ff0000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        FrontredTheme.setTextFill(Color.web(color2));
                        UNOTheme.setEffect(null);

                    });

                    BacklightTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> BacklightTheme.setEffect(effectBG_DropShadow));
                    BacklightTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t1blistener.isSelected()){
                            BacklightTheme.setEffect(effectBG_DropShadow);}
                        else{
                            BacklightTheme.setEffect(null);}
                    });
                    BacklightTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1blistener.setSelected(true);
                        t2blistener.setSelected(false);
                        t3blistener.setSelected(false);
                        t4listener.setSelected(false);

                        BacklightTheme.setEffect(effectBG_DropShadow);
                        BacklightTheme.setStyle("-fx-background-color: #f8f8f8; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        BacklightTheme.setTextFill(Color.web(color2));
                        BackblackTheme.setEffect(null);
                        BackredTheme.setEffect(null);
                        UNOTheme.setEffect(null);
                    });

                    BackblackTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> BackblackTheme.setEffect(effectBG_DropShadow));
                    BackblackTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t2blistener.isSelected()){
                            BackblackTheme.setEffect(effectBG_DropShadow);}
                        else{
                            BackblackTheme.setEffect(null);}
                    });
                    BackblackTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1blistener.setSelected(false);
                        t2blistener.setSelected(true);
                        t3blistener.setSelected(false);
                        t4listener.setSelected(false);

                        BacklightTheme.setEffect(null);
                        BackblackTheme.setEffect(effectBG_DropShadow);
                        BackblackTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        BackblackTheme.setTextFill(Color.web(color2));
                        BackredTheme.setEffect(null);
                        UNOTheme.setEffect(null);
                    });

                    BackredTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> BackredTheme.setEffect(effectBG_DropShadow));
                    BackredTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t3blistener.isSelected()){
                            BackredTheme.setEffect(effectBG_DropShadow);}
                        else{
                            BackredTheme.setEffect(null);}
                    });
                    BackredTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1blistener.setSelected(false);
                        t2blistener.setSelected(false);
                        t3blistener.setSelected(true);
                        t4listener.setSelected(false);

                        BacklightTheme.setEffect(null);
                        BackblackTheme.setEffect(null);
                        BackredTheme.setEffect(effectBG_DropShadow);
                        BackredTheme.setStyle("-fx-background-color: #ff0000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        BackredTheme.setTextFill(Color.web(color2));
                        UNOTheme.setEffect(null);

                    });

                    UNOTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> UNOTheme.setEffect(effectBG_DropShadow));
                    UNOTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t4listener.isSelected()){
                            UNOTheme.setEffect(effectBG_DropShadow);}
                        else{
                            UNOTheme.setEffect(null);}
                    });
                    UNOTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1alistener.setSelected(false);
                        t2alistener.setSelected(false);
                        t3alistener.setSelected(false);
                        t1blistener.setSelected(false);
                        t2blistener.setSelected(false);
                        t3blistener.setSelected(false);
                        t4listener.setSelected(true);

                        FrontlightTheme.setEffect(null);
                        FrontblackTheme.setEffect(null);
                        FrontredTheme.setEffect(null);
                        BacklightTheme.setEffect(null);
                        BackblackTheme.setEffect(null);
                        BackredTheme.setEffect(null);
                        UNOTheme.setEffect(effectBG_DropShadow);
                        UNOTheme.setTextFill(Color.web(color2));
                        UNOTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");

                    });

                    //Player Count
                    r1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> r1.setEffect(effectBG_DropShadow));
                    r1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r1listener.isSelected()){
                            r1.setEffect(effectBG_DropShadow);}
                        else{r1.setEffect(null);}
                    });
                    r1.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        r1listener.setSelected(true);
                        r2listener.setSelected(false);
                        r3listener.setSelected(false);

                        r1.setEffect(effectBG_DropShadow);
                        r1.setTextFill(Color.web(color2));
                        r1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24; -fx-border-color: "+color2+"; -fx-border-radius: 24; -fx-border-width: 3 ;");
                        r2.setEffect(null);
                        r3.setEffect(null);

                    });
                    r2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> r2.setEffect(effectBG_DropShadow));
                    r2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r2listener.isSelected()){
                            r2.setEffect(effectBG_DropShadow);}
                        else{r2.setEffect(null);}
                    });
                    r2.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        r1listener.setSelected(false);
                        r2listener.setSelected(true);
                        r3listener.setSelected(false);

                        r1.setEffect(null);
                        r2.setEffect(effectBG_DropShadow);
                        r2.setTextFill(Color.web(color2));
                        r2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24; -fx-border-color: "+color2+"; -fx-border-radius: 24; -fx-border-width: 3 ;");
                        r3.setEffect(null);
                    });
                    r3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> r3.setEffect(effectBG_DropShadow));
                    r3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r3listener.isSelected()){
                            r3.setEffect(effectBG_DropShadow);}
                        else{r3.setEffect(null);}
                    });
                    r3.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        r1listener.setSelected(false);
                        r2listener.setSelected(false);
                        r3listener.setSelected(true);

                        r1.setEffect(null);
                        r2.setEffect(null);
                        r3.setEffect(effectBG_DropShadow);
                        r3.setTextFill(Color.web(color2));
                        r3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24; -fx-border-color: "+color2+"; -fx-border-radius: 24; -fx-border-width: 3 ;");

                    });

                    multiplayer.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> multiplayer.setEffect(effectBG_DropShadow));
                    multiplayer.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        multiplayer.setEffect(null);
                    });
                    multiplayer.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
                        multiplayer.setEffect(effectBG_DropShadow);
                    });

                }
                else if (tColor == 2) {

                    color2 = "#c9c208";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.web("#aba507"), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.web("#e7df09"), 10, 0, 5, 5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.web("#aba507"), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.web("#e7df09"), 10, 0, 5, 5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBackButton = getClass().getResourceAsStream("../../../resources/svg/left_arrow/left-arrow_d.svg");
                    svgFileBackButton_Hover = getClass().getResourceAsStream("../../../resources/svg/left_arrow/left-arrow_dyellow.svg");

                    svgFileOption = getClass().getResourceAsStream("../../../resources/svg/menu/menu_d.svg");
                    svgFileOption_Hover = getClass().getResourceAsStream("../../../resources/svg/menu/menu_dyellow.svg");

                    Group svgImageBackButton = loader.loadSvg(svgFileBackButton);
                    Group svgImageBackButton_Hover = loader.loadSvg(svgFileBackButton_Hover);

                    Group svgImageOption = loader.loadSvg(svgFileOption);
                    Group svgImageOption_Hover = loader.loadSvg(svgFileOption_Hover);

                    svgImageBackButton.setScaleX(.04);
                    svgImageBackButton.setScaleY(.04);
                    svgImageBackButton_Hover.setScaleX(.04);
                    svgImageBackButton_Hover.setScaleY(.04);

                    svgImageOption.setScaleX(.04);
                    svgImageOption.setScaleY(.04);
                    svgImageOption_Hover.setScaleX(.04);
                    svgImageOption_Hover.setScaleY(.04);

                    Group svgIconBackButton = new Group(svgImageBackButton);
                    Group svgIconBackButton_Hover = new Group(svgImageBackButton_Hover);

                    Group svgIconOption = new Group(svgImageOption);
                    Group svgIconOption_Hover = new Group(svgImageOption_Hover);

                    backButton.setGraphic(svgIconOption);

                    fadeIn.setDuration(Duration.millis(500));
                    fadeOut.setDuration(Duration.millis(200));

                    fadeIn.setFromValue(0);
                    fadeIn.setToValue(10);

                    fadeOut.setFromValue(10);
                    fadeOut.setToValue(0);

                    fadeIn.setCycleCount(1);
                    fadeOut.setCycleCount(1);

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        backButton.setEffect(effectC_DropShadow);
                        backButton.setGraphic(svgIconBackButton);

                        l1.setText("");
                        l2.setText("Back to Home");
                        l3.setText("");

                        Panel1.setEffect(blur);
                        Panel2.setEffect(blur);
                        Panel3.setEffect(blur);
                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        backButton.setEffect(null);
                        backButton.setGraphic(svgIconOption);

                        l1.setText("MEMORY");
                        l2.setText("GAME");
                        l3.setText("Mᴜʟᴛɪ Pʟᴀʏᴇʀ");

                        Panel1.setEffect(effectBG_DropShadow);
                        Panel2.setEffect(effectBG_DropShadow);
                        Panel3.setEffect(effectBG_DropShadow);

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e ->{

                        backButton.setGraphic(svgIconBackButton_Hover);

                        Panel1.setEffect(null);
                        Panel2.setEffect(null);
                        Panel3.setEffect(null);

                        fadeOut5.play();
                        fadeOut5_1.play();
                        fadeOut5_2.play();
                        fadeOut.play();
                        fadeOut2.play();
                        fadeOut3.play();
                        fadeOut4.play();
                        fadeOut6.play();
                        fadeOut7.play();
                        fadeOut8.play();
                        fadeOut9.play();
                        fadeOut9_1.play();
                        fadeOut9_2.play();
                        fadeOut9_3.play();
                        fadeOut9_4.play();
                        fadeOut9_5.play();
                        fadeOut9_6.play();
                        fadeOut9_7.play();
                        fadeOut9_8.play();
                        fadeOut9_9.play();
                        fadeOut9_10.play();
                        fadeOut9_11.play();
                        fadeOut9_12.play();
                        fadeOut9_13.play();

                    });

                    Panelex3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        backButton.setGraphic(svgIconOption_Hover);

                    });
                    Panelex3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        backButton.setGraphic(svgIconOption);

                    });

                    //INIT
                    if(f.exists()) {

                        input = new FileInputStream("config.properties");
                        properties.load(input);

                        int width = Integer.parseInt(properties.getProperty("width"));

                        if (width==999){

                            singleMode.setDisable(false);
                            doubleMode.setDisable(false);
                            hardModebtn.setDisable(false);
                            hellModebtn.setDisable(false);

                            singleMode.setVisible(true);
                            doubleMode.setVisible(true);
                            hardModebtn.setVisible(true);
                            hellModebtn.setVisible(true);

                        }
                        else if (width==1600){

                            singleMode.setDisable(false);
                            doubleMode.setDisable(false);
                            hardModebtn.setDisable(true);
                            hellModebtn.setDisable(true);

                            singleMode.setVisible(true);
                            doubleMode.setVisible(true);
                            hardModebtn.setVisible(false);
                            hellModebtn.setVisible(false);

                        }
                        else if (width==1280){

                            singleMode.setDisable(false);
                            doubleMode.setDisable(false);
                            hardModebtn.setDisable(true);
                            hellModebtn.setDisable(true);

                            singleMode.setVisible(true);
                            doubleMode.setVisible(true);
                            hardModebtn.setVisible(false);
                            hellModebtn.setVisible(false);

                        }
                    }
                    if(f3.exists()) {

                        input3 = new FileInputStream("gamemode.properties");
                        properties3.load(input3);

                        int gSelected = Integer.parseInt(properties3.getProperty("GSelected"));
                        int tSelected = Integer.parseInt(properties3.getProperty("TSelected"));
                        int rSelected = Integer.parseInt(properties3.getProperty("RSelected"));
                        int tfSelected = Integer.parseInt(properties3.getProperty("TFSelected"));
                        int tbSelected = Integer.parseInt(properties3.getProperty("TBSelected"));

                        if (gSelected==0){

                            singleMode.setEffect(null);
                            doubleMode.setEffect(null);
                            hardModebtn.setEffect(null);
                            hellModebtn.setEffect(null);

                            g1listener.setSelected(false);
                            g2listener.setSelected(false);
                            g3listener.setSelected(false);
                            g4listener.setSelected(false);

                        }
                        else if (gSelected==1){

                            singleMode.setEffect(effectBG_DropShadow);
                            singleMode.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                            singleMode.setTextFill(Color.web(color2));
                            doubleMode.setEffect(null);
                            hardModebtn.setEffect(null);
                            hellModebtn.setEffect(null);

                            g1listener.setSelected(true);
                            g2listener.setSelected(false);
                            g3listener.setSelected(false);
                            g4listener.setSelected(false);

                            mode.setMode(1);

                        }
                        else if (gSelected==2){

                            singleMode.setEffect(null);
                            doubleMode.setEffect(effectBG_DropShadow);
                            doubleMode.setTextFill(Color.web(color2));
                            doubleMode.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                            hardModebtn.setEffect(null);
                            hellModebtn.setEffect(null);

                            g1listener.setSelected(false);
                            g2listener.setSelected(true);
                            g3listener.setSelected(false);
                            g4listener.setSelected(false);

                            mode.setMode(2);

                        }
                        else if (gSelected==3){

                            singleMode.setEffect(null);
                            doubleMode.setEffect(null);
                            hardModebtn.setEffect(effectBG_DropShadow);
                            hardModebtn.setTextFill(Color.web(color2));
                            hardModebtn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                            hellModebtn.setEffect(null);

                            g1listener.setSelected(false);
                            g2listener.setSelected(false);
                            g3listener.setSelected(true);
                            g4listener.setSelected(false);

                            mode.setMode(3);

                        }
                        else if (gSelected==4){

                            singleMode.setEffect(null);
                            doubleMode.setEffect(null);
                            hardModebtn.setEffect(null);
                            hellModebtn.setEffect(effectBG_DropShadow);
                            hellModebtn.setTextFill(Color.web(color2));
                            hellModebtn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");

                            g1listener.setSelected(false);
                            g2listener.setSelected(false);
                            g3listener.setSelected(false);
                            g4listener.setSelected(true);

                            mode.setMode(4);

                        }

                        if (tSelected==0){

                            FrontlightTheme.setEffect(null);
                            FrontblackTheme.setEffect(null);
                            FrontredTheme.setEffect(null);
                            BacklightTheme.setEffect(null);
                            BackblackTheme.setEffect(null);
                            BackredTheme.setEffect(null);
                            UNOTheme.setEffect(null);

                            t1alistener.setSelected(false);
                            t1blistener.setSelected(false);
                            t2alistener.setSelected(false);
                            t2blistener.setSelected(false);
                            t3alistener.setSelected(false);
                            t3blistener.setSelected(false);
                            t4listener.setSelected(false);

                        }
                        else if (tSelected==1){

                            if (tfSelected==0) {

                                FrontlightTheme.setEffect(null);
                                FrontblackTheme.setEffect(null);
                                FrontredTheme.setEffect(null);
                                UNOTheme.setEffect(null);

                                t1alistener.setSelected(false);
                                t2alistener.setSelected(false);
                                t3alistener.setSelected(false);
                                t4listener.setSelected(false);


                            }
                            else if (tfSelected==1) {

                                FrontlightTheme.setEffect(effectBG_DropShadow);
                                FrontlightTheme.setTextFill(Color.web(color2));
                                FrontlightTheme.setStyle("-fx-background-color: #f8f8f8; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                FrontblackTheme.setEffect(null);
                                FrontredTheme.setEffect(null);
                                UNOTheme.setEffect(null);

                                t1alistener.setSelected(true);
                                t2alistener.setSelected(false);
                                t3alistener.setSelected(false);
                                t4listener.setSelected(false);


                            }
                            else if (tfSelected==2) {

                                FrontlightTheme.setEffect(null);
                                FrontblackTheme.setEffect(effectBG_DropShadow);
                                FrontblackTheme.setTextFill(Color.web(color2));
                                FrontblackTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                FrontredTheme.setEffect(null);
                                UNOTheme.setEffect(null);

                                t1alistener.setSelected(false);
                                t2alistener.setSelected(true);
                                t3alistener.setSelected(false);
                                t4listener.setSelected(false);

                            }
                            else if (tfSelected==3) {

                                FrontlightTheme.setEffect(null);
                                FrontblackTheme.setEffect(null);
                                FrontredTheme.setEffect(effectBG_DropShadow);
                                FrontredTheme.setTextFill(Color.web(color2));
                                FrontredTheme.setStyle("-fx-background-color: #ff0000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                UNOTheme.setEffect(null);

                                t1alistener.setSelected(false);
                                t2alistener.setSelected(false);
                                t3alistener.setSelected(true);
                                t4listener.setSelected(false);

                            }

                            if (tbSelected == 0) {

                                BacklightTheme.setEffect(null);
                                BackblackTheme.setEffect(null);
                                BackredTheme.setEffect(null);

                                t1blistener.setSelected(false);
                                t2blistener.setSelected(false);
                                t3blistener.setSelected(false);

                            }
                            else if (tbSelected == 1) {

                                BacklightTheme.setEffect(effectBG_DropShadow);
                                BacklightTheme.setTextFill(Color.web(color2));
                                BacklightTheme.setStyle("-fx-background-color: #f8f8f8; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                BackblackTheme.setEffect(null);
                                BackredTheme.setEffect(null);

                                t1blistener.setSelected(true);
                                t2blistener.setSelected(false);
                                t3blistener.setSelected(false);

                            }
                            else if (tbSelected == 2) {

                                BacklightTheme.setEffect(null);
                                BackblackTheme.setEffect(effectBG_DropShadow);
                                BackblackTheme.setTextFill(Color.web(color2));
                                BackblackTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                BackredTheme.setEffect(null);

                                t1blistener.setSelected(false);
                                t2blistener.setSelected(true);
                                t3blistener.setSelected(false);

                            }
                            else if (tbSelected == 3) {

                                BacklightTheme.setEffect(null);
                                BackblackTheme.setEffect(null);
                                BackredTheme.setEffect(effectBG_DropShadow);
                                BackredTheme.setStyle("-fx-background-color: #ff0000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                BackredTheme.setTextFill(Color.web(color2));

                                t1blistener.setSelected(false);
                                t2blistener.setSelected(false);
                                t3blistener.setSelected(true);

                            }

                        }
                        else if (tSelected==2){

                            FrontlightTheme.setEffect(null);
                            FrontblackTheme.setEffect(null);
                            FrontredTheme.setEffect(null);
                            BacklightTheme.setEffect(null);
                            BackblackTheme.setEffect(null);
                            BackredTheme.setEffect(null);
                            UNOTheme.setEffect(effectBG_DropShadow);
                            UNOTheme.setTextFill(Color.web(color2));
                            UNOTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");

                            t1alistener.setSelected(false);
                            t1blistener.setSelected(false);
                            t2alistener.setSelected(false);
                            t2blistener.setSelected(false);
                            t3alistener.setSelected(false);
                            t3blistener.setSelected(false);
                            t4listener.setSelected(true);

                        }

                        if (rSelected==0){

                            r1.setEffect(null);
                            r2.setEffect(null);
                            r3.setEffect(null);

                            r1listener.setSelected(false);
                            r2listener.setSelected(false);
                            r3listener.setSelected(false);

                        }
                        else if (rSelected==1){

                            r1.setEffect(effectBG_DropShadow);
                            r1.setTextFill(Color.web(color2));
                            r1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 16; -fx-border-color: "+color2+"; -fx-border-radius: 16; -fx-border-width: 3 ;");
                            r2.setEffect(null);
                            r3.setEffect(null);

                            r1listener.setSelected(true);
                            r2listener.setSelected(false);
                            r3listener.setSelected(false);

                            mode.setRivalsNumber(1);
                            mode.setRival1("Goldfish");
                            mode.setRival2("");
                            mode.setRival3("");

                        }
                        else if (rSelected==2){

                            r1.setEffect(null);
                            r2.setEffect(effectBG_DropShadow);
                            r2.setTextFill(Color.web(color2));
                            r2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 16; -fx-border-color: "+color2+"; -fx-border-radius: 16; -fx-border-width: 3 ;");
                            r3.setEffect(null);

                            r1listener.setSelected(false);
                            r2listener.setSelected(true);
                            r3listener.setSelected(false);

                            mode.setRivalsNumber(2);
                            mode.setRival1("Goldfish");
                            mode.setRival2("Goldfish");
                            mode.setRival3("");

                        }
                        else if (rSelected==3){

                            r1.setEffect(null);
                            r2.setEffect(null);
                            r3.setEffect(effectBG_DropShadow);
                            r3.setTextFill(Color.web(color2));
                            r3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 16; -fx-border-color: "+color2+"; -fx-border-radius: 16; -fx-border-width: 3 ;");

                            r1listener.setSelected(false);
                            r2listener.setSelected(false);
                            r3listener.setSelected(true);

                            mode.setRivalsNumber(3);
                            mode.setRival1("Goldfish");
                            mode.setRival2("Goldfish");
                            mode.setRival3("Goldfish");

                        }

                        if (gSelected==0||tSelected==0||tfSelected==0||tbSelected==0||rSelected==0){
                            multiplayer.setVisible(false);
                        }else {
                            multiplayer.setVisible(true);
                        }

                    }

                    singleMode.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> singleMode.setEffect(effectBG_DropShadow));
                    singleMode.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (g1listener.isSelected()){
                            singleMode.setEffect(effectBG_DropShadow);}
                        else{singleMode.setEffect(null);}
                    });
                    singleMode.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        g1listener.setSelected(true);
                        g2listener.setSelected(false);
                        g3listener.setSelected(false);
                        g4listener.setSelected(false);

                        singleMode.setEffect(effectBG_DropShadow);
                        singleMode.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        singleMode.setTextFill(Color.web(color2));
                        doubleMode.setEffect(null);
                        hardModebtn.setEffect(null);
                        hellModebtn.setEffect(null);

                    });

                    doubleMode.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> doubleMode.setEffect(effectBG_DropShadow));
                    doubleMode.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (g2listener.isSelected()){
                            doubleMode.setEffect(effectBG_DropShadow);}
                        else{doubleMode.setEffect(null);}
                    });
                    doubleMode.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        g1listener.setSelected(false);
                        g2listener.setSelected(true);
                        g3listener.setSelected(false);
                        g4listener.setSelected(false);

                        singleMode.setEffect(null);
                        doubleMode.setEffect(effectBG_DropShadow);
                        doubleMode.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        doubleMode.setTextFill(Color.web(color2));
                        hardModebtn.setEffect(null);
                        hellModebtn.setEffect(null);

                    });

                    hardModebtn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> hardModebtn.setEffect(effectBG_DropShadow));
                    hardModebtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (g3listener.isSelected()){
                            hardModebtn.setEffect(effectBG_DropShadow);}
                        else{hardModebtn.setEffect(null);}
                    });
                    hardModebtn.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        g1listener.setSelected(false);
                        g2listener.setSelected(false);
                        g3listener.setSelected(true);
                        g4listener.setSelected(false);

                        singleMode.setEffect(null);
                        doubleMode.setEffect(null);
                        hardModebtn.setEffect(effectBG_DropShadow);
                        hardModebtn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        hardModebtn.setTextFill(Color.web(color2));
                        hellModebtn.setEffect(null);

                    });

                    hellModebtn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> hellModebtn.setEffect(effectBG_DropShadow));
                    hellModebtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (g4listener.isSelected()){
                            hellModebtn.setEffect(effectBG_DropShadow);}
                        else{hellModebtn.setEffect(null);}
                    });
                    hellModebtn.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        g1listener.setSelected(false);
                        g2listener.setSelected(false);
                        g3listener.setSelected(false);
                        g4listener.setSelected(true);

                        singleMode.setEffect(null);
                        doubleMode.setEffect(null);
                        hardModebtn.setEffect(null);
                        hellModebtn.setEffect(effectBG_DropShadow);
                        hellModebtn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        hellModebtn.setTextFill(Color.web(color2));

                    });

                    //THEME
                    FrontlightTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> FrontlightTheme.setEffect(effectBG_DropShadow));
                    FrontlightTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t1alistener.isSelected()){
                            FrontlightTheme.setEffect(effectBG_DropShadow);}
                        else{
                            FrontlightTheme.setEffect(null);}
                    });
                    FrontlightTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1alistener.setSelected(true);
                        t2alistener.setSelected(false);
                        t3alistener.setSelected(false);
                        t4listener.setSelected(false);

                        FrontlightTheme.setEffect(effectBG_DropShadow);
                        FrontlightTheme.setStyle("-fx-background-color: #f8f8f8; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        FrontlightTheme.setTextFill(Color.web(color2));
                        FrontblackTheme.setEffect(null);
                        FrontredTheme.setEffect(null);
                        UNOTheme.setEffect(null);

                    });

                    FrontblackTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> FrontblackTheme.setEffect(effectBG_DropShadow));
                    FrontblackTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t2alistener.isSelected()){
                            FrontblackTheme.setEffect(effectBG_DropShadow);}
                        else{
                            FrontblackTheme.setEffect(null);}
                    });
                    FrontblackTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1alistener.setSelected(false);
                        t2alistener.setSelected(true);
                        t3alistener.setSelected(false);
                        t4listener.setSelected(false);

                        FrontlightTheme.setEffect(null);
                        FrontblackTheme.setEffect(effectBG_DropShadow);
                        FrontblackTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        FrontblackTheme.setTextFill(Color.web(color2));
                        FrontredTheme.setEffect(null);
                        UNOTheme.setEffect(null);

                    });

                    FrontredTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> FrontredTheme.setEffect(effectBG_DropShadow));
                    FrontredTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t3alistener.isSelected()){
                            FrontredTheme.setEffect(effectBG_DropShadow);}
                        else{
                            FrontredTheme.setEffect(null);}
                    });
                    FrontredTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1alistener.setSelected(false);
                        t2alistener.setSelected(false);
                        t3alistener.setSelected(true);
                        t4listener.setSelected(false);

                        FrontlightTheme.setEffect(null);
                        FrontblackTheme.setEffect(null);
                        FrontredTheme.setEffect(effectBG_DropShadow);
                        FrontredTheme.setStyle("-fx-background-color: #ff0000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        FrontredTheme.setTextFill(Color.web(color2));
                        UNOTheme.setEffect(null);

                    });

                    BacklightTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> BacklightTheme.setEffect(effectBG_DropShadow));
                    BacklightTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t1blistener.isSelected()){
                            BacklightTheme.setEffect(effectBG_DropShadow);}
                        else{
                            BacklightTheme.setEffect(null);}
                    });
                    BacklightTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1blistener.setSelected(true);
                        t2blistener.setSelected(false);
                        t3blistener.setSelected(false);
                        t4listener.setSelected(false);

                        BacklightTheme.setEffect(effectBG_DropShadow);
                        BacklightTheme.setStyle("-fx-background-color: #f8f8f8; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        BacklightTheme.setTextFill(Color.web(color2));
                        BackblackTheme.setEffect(null);
                        BackredTheme.setEffect(null);
                        UNOTheme.setEffect(null);
                    });

                    BackblackTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> BackblackTheme.setEffect(effectBG_DropShadow));
                    BackblackTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t2blistener.isSelected()){
                            BackblackTheme.setEffect(effectBG_DropShadow);}
                        else{
                            BackblackTheme.setEffect(null);}
                    });
                    BackblackTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1blistener.setSelected(false);
                        t2blistener.setSelected(true);
                        t3blistener.setSelected(false);
                        t4listener.setSelected(false);

                        BacklightTheme.setEffect(null);
                        BackblackTheme.setEffect(effectBG_DropShadow);
                        BackblackTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        BackblackTheme.setTextFill(Color.web(color2));
                        BackredTheme.setEffect(null);
                        UNOTheme.setEffect(null);
                    });

                    BackredTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> BackredTheme.setEffect(effectBG_DropShadow));
                    BackredTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t3blistener.isSelected()){
                            BackredTheme.setEffect(effectBG_DropShadow);}
                        else{
                            BackredTheme.setEffect(null);}
                    });
                    BackredTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1blistener.setSelected(false);
                        t2blistener.setSelected(false);
                        t3blistener.setSelected(true);
                        t4listener.setSelected(false);

                        BacklightTheme.setEffect(null);
                        BackblackTheme.setEffect(null);
                        BackredTheme.setEffect(effectBG_DropShadow);
                        BackredTheme.setStyle("-fx-background-color: #ff0000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        BackredTheme.setTextFill(Color.web(color2));
                        UNOTheme.setEffect(null);

                    });

                    UNOTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> UNOTheme.setEffect(effectBG_DropShadow));
                    UNOTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t4listener.isSelected()){
                            UNOTheme.setEffect(effectBG_DropShadow);}
                        else{
                            UNOTheme.setEffect(null);}
                    });
                    UNOTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1alistener.setSelected(false);
                        t2alistener.setSelected(false);
                        t3alistener.setSelected(false);
                        t1blistener.setSelected(false);
                        t2blistener.setSelected(false);
                        t3blistener.setSelected(false);
                        t4listener.setSelected(true);

                        FrontlightTheme.setEffect(null);
                        FrontblackTheme.setEffect(null);
                        FrontredTheme.setEffect(null);
                        BacklightTheme.setEffect(null);
                        BackblackTheme.setEffect(null);
                        BackredTheme.setEffect(null);
                        UNOTheme.setEffect(effectBG_DropShadow);
                        UNOTheme.setTextFill(Color.web(color2));
                        UNOTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");

                    });

                    //Player Count
                    r1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> r1.setEffect(effectBG_DropShadow));
                    r1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r1listener.isSelected()){
                            r1.setEffect(effectBG_DropShadow);}
                        else{r1.setEffect(null);}
                    });
                    r1.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        r1listener.setSelected(true);
                        r2listener.setSelected(false);
                        r3listener.setSelected(false);

                        r1.setEffect(effectBG_DropShadow);
                        r1.setTextFill(Color.web(color2));
                        r1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24; -fx-border-color: "+color2+"; -fx-border-radius: 24; -fx-border-width: 3 ;");
                        r2.setEffect(null);
                        r3.setEffect(null);

                    });
                    r2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> r2.setEffect(effectBG_DropShadow));
                    r2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r2listener.isSelected()){
                            r2.setEffect(effectBG_DropShadow);}
                        else{r2.setEffect(null);}
                    });
                    r2.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        r1listener.setSelected(false);
                        r2listener.setSelected(true);
                        r3listener.setSelected(false);

                        r1.setEffect(null);
                        r2.setEffect(effectBG_DropShadow);
                        r2.setTextFill(Color.web(color2));
                        r2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24; -fx-border-color: "+color2+"; -fx-border-radius: 24; -fx-border-width: 3 ;");
                        r3.setEffect(null);
                    });
                    r3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> r3.setEffect(effectBG_DropShadow));
                    r3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r3listener.isSelected()){
                            r3.setEffect(effectBG_DropShadow);}
                        else{r3.setEffect(null);}
                    });
                    r3.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        r1listener.setSelected(false);
                        r2listener.setSelected(false);
                        r3listener.setSelected(true);

                        r1.setEffect(null);
                        r2.setEffect(null);
                        r3.setEffect(effectBG_DropShadow);
                        r3.setTextFill(Color.web(color2));
                        r3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24; -fx-border-color: "+color2+"; -fx-border-radius: 24; -fx-border-width: 3 ;");

                    });

                    multiplayer.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> multiplayer.setEffect(effectBG_DropShadow));
                    multiplayer.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        multiplayer.setEffect(null);
                    });
                    multiplayer.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
                        multiplayer.setEffect(effectBG_DropShadow);
                    });

                }
                else if (tColor == 3) {

                    color2 = "#c00650";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,86,0), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,116,0), 10, 0, 5, 5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,86,0), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,116,0), 10, 0, 5, 5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBackButton = getClass().getResourceAsStream("../../../resources/svg/left_arrow/left-arrow_d.svg");
                    svgFileBackButton_Hover = getClass().getResourceAsStream("../../../resources/svg/left_arrow/left-arrow_dgreen.svg");

                    svgFileOption = getClass().getResourceAsStream("../../../resources/svg/menu/menu_d.svg");
                    svgFileOption_Hover = getClass().getResourceAsStream("../../../resources/svg/menu/menu_dgreen.svg");

                    Group svgImageBackButton = loader.loadSvg(svgFileBackButton);
                    Group svgImageBackButton_Hover = loader.loadSvg(svgFileBackButton_Hover);

                    Group svgImageOption = loader.loadSvg(svgFileOption);
                    Group svgImageOption_Hover = loader.loadSvg(svgFileOption_Hover);

                    svgImageBackButton.setScaleX(.04);
                    svgImageBackButton.setScaleY(.04);
                    svgImageBackButton_Hover.setScaleX(.04);
                    svgImageBackButton_Hover.setScaleY(.04);

                    svgImageOption.setScaleX(.04);
                    svgImageOption.setScaleY(.04);
                    svgImageOption_Hover.setScaleX(.04);
                    svgImageOption_Hover.setScaleY(.04);

                    Group svgIconBackButton = new Group(svgImageBackButton);
                    Group svgIconBackButton_Hover = new Group(svgImageBackButton_Hover);

                    Group svgIconOption = new Group(svgImageOption);
                    Group svgIconOption_Hover = new Group(svgImageOption_Hover);

                    backButton.setGraphic(svgIconOption);

                    fadeIn.setDuration(Duration.millis(500));
                    fadeOut.setDuration(Duration.millis(200));

                    fadeIn.setFromValue(0);
                    fadeIn.setToValue(10);

                    fadeOut.setFromValue(10);
                    fadeOut.setToValue(0);

                    fadeIn.setCycleCount(1);
                    fadeOut.setCycleCount(1);

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        backButton.setEffect(effectC_DropShadow);
                        backButton.setGraphic(svgIconBackButton);

                        l1.setText("");
                        l2.setText("Back to Home");
                        l3.setText("");

                        Panel1.setEffect(blur);
                        Panel2.setEffect(blur);
                        Panel3.setEffect(blur);
                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        backButton.setEffect(null);
                        backButton.setGraphic(svgIconOption);

                        l1.setText("MEMORY");
                        l2.setText("GAME");
                        l3.setText("Mᴜʟᴛɪ Pʟᴀʏᴇʀ");

                        Panel1.setEffect(effectBG_DropShadow);
                        Panel2.setEffect(effectBG_DropShadow);
                        Panel3.setEffect(effectBG_DropShadow);

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e ->{

                        backButton.setGraphic(svgIconBackButton_Hover);

                        Panel1.setEffect(null);
                        Panel2.setEffect(null);
                        Panel3.setEffect(null);

                        fadeOut5.play();
                        fadeOut5_1.play();
                        fadeOut5_2.play();
                        fadeOut.play();
                        fadeOut2.play();
                        fadeOut3.play();
                        fadeOut4.play();
                        fadeOut6.play();
                        fadeOut7.play();
                        fadeOut8.play();
                        fadeOut9.play();
                        fadeOut9_1.play();
                        fadeOut9_2.play();
                        fadeOut9_3.play();
                        fadeOut9_4.play();
                        fadeOut9_5.play();
                        fadeOut9_6.play();
                        fadeOut9_7.play();
                        fadeOut9_8.play();
                        fadeOut9_9.play();
                        fadeOut9_10.play();
                        fadeOut9_11.play();
                        fadeOut9_12.play();
                        fadeOut9_13.play();

                    });

                    Panelex3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        backButton.setGraphic(svgIconOption_Hover);

                    });
                    Panelex3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        backButton.setGraphic(svgIconOption);

                    });

                    //INIT
                    if(f.exists()) {

                        input = new FileInputStream("config.properties");
                        properties.load(input);

                        int width = Integer.parseInt(properties.getProperty("width"));

                        if (width==999){

                            singleMode.setDisable(false);
                            doubleMode.setDisable(false);
                            hardModebtn.setDisable(false);
                            hellModebtn.setDisable(false);

                            singleMode.setVisible(true);
                            doubleMode.setVisible(true);
                            hardModebtn.setVisible(true);
                            hellModebtn.setVisible(true);

                        }
                        else if (width==1600){

                            singleMode.setDisable(false);
                            doubleMode.setDisable(false);
                            hardModebtn.setDisable(true);
                            hellModebtn.setDisable(true);

                            singleMode.setVisible(true);
                            doubleMode.setVisible(true);
                            hardModebtn.setVisible(false);
                            hellModebtn.setVisible(false);

                        }
                        else if (width==1280){

                            singleMode.setDisable(false);
                            doubleMode.setDisable(false);
                            hardModebtn.setDisable(true);
                            hellModebtn.setDisable(true);

                            singleMode.setVisible(true);
                            doubleMode.setVisible(true);
                            hardModebtn.setVisible(false);
                            hellModebtn.setVisible(false);

                        }
                    }
                    if(f3.exists()) {

                        input3 = new FileInputStream("gamemode.properties");
                        properties3.load(input3);

                        int gSelected = Integer.parseInt(properties3.getProperty("GSelected"));
                        int tSelected = Integer.parseInt(properties3.getProperty("TSelected"));
                        int rSelected = Integer.parseInt(properties3.getProperty("RSelected"));
                        int tfSelected = Integer.parseInt(properties3.getProperty("TFSelected"));
                        int tbSelected = Integer.parseInt(properties3.getProperty("TBSelected"));

                        if (gSelected==0){

                            singleMode.setEffect(null);
                            doubleMode.setEffect(null);
                            hardModebtn.setEffect(null);
                            hellModebtn.setEffect(null);

                            g1listener.setSelected(false);
                            g2listener.setSelected(false);
                            g3listener.setSelected(false);
                            g4listener.setSelected(false);

                        }
                        else if (gSelected==1){

                            singleMode.setEffect(effectBG_DropShadow);
                            singleMode.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                            singleMode.setTextFill(Color.web(color2));
                            doubleMode.setEffect(null);
                            hardModebtn.setEffect(null);
                            hellModebtn.setEffect(null);

                            g1listener.setSelected(true);
                            g2listener.setSelected(false);
                            g3listener.setSelected(false);
                            g4listener.setSelected(false);

                            mode.setMode(1);

                        }
                        else if (gSelected==2){

                            singleMode.setEffect(null);
                            doubleMode.setEffect(effectBG_DropShadow);
                            doubleMode.setTextFill(Color.web(color2));
                            doubleMode.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                            hardModebtn.setEffect(null);
                            hellModebtn.setEffect(null);

                            g1listener.setSelected(false);
                            g2listener.setSelected(true);
                            g3listener.setSelected(false);
                            g4listener.setSelected(false);

                            mode.setMode(2);

                        }
                        else if (gSelected==3){

                            singleMode.setEffect(null);
                            doubleMode.setEffect(null);
                            hardModebtn.setEffect(effectBG_DropShadow);
                            hardModebtn.setTextFill(Color.web(color2));
                            hardModebtn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                            hellModebtn.setEffect(null);

                            g1listener.setSelected(false);
                            g2listener.setSelected(false);
                            g3listener.setSelected(true);
                            g4listener.setSelected(false);

                            mode.setMode(3);

                        }
                        else if (gSelected==4){

                            singleMode.setEffect(null);
                            doubleMode.setEffect(null);
                            hardModebtn.setEffect(null);
                            hellModebtn.setEffect(effectBG_DropShadow);
                            hellModebtn.setTextFill(Color.web(color2));
                            hellModebtn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");

                            g1listener.setSelected(false);
                            g2listener.setSelected(false);
                            g3listener.setSelected(false);
                            g4listener.setSelected(true);

                            mode.setMode(4);

                        }

                        if (tSelected==0){

                            FrontlightTheme.setEffect(null);
                            FrontblackTheme.setEffect(null);
                            FrontredTheme.setEffect(null);
                            BacklightTheme.setEffect(null);
                            BackblackTheme.setEffect(null);
                            BackredTheme.setEffect(null);
                            UNOTheme.setEffect(null);

                            t1alistener.setSelected(false);
                            t1blistener.setSelected(false);
                            t2alistener.setSelected(false);
                            t2blistener.setSelected(false);
                            t3alistener.setSelected(false);
                            t3blistener.setSelected(false);
                            t4listener.setSelected(false);

                        }
                        else if (tSelected==1){

                            if (tfSelected==0) {

                                FrontlightTheme.setEffect(null);
                                FrontblackTheme.setEffect(null);
                                FrontredTheme.setEffect(null);
                                UNOTheme.setEffect(null);

                                t1alistener.setSelected(false);
                                t2alistener.setSelected(false);
                                t3alistener.setSelected(false);
                                t4listener.setSelected(false);


                            }
                            else if (tfSelected==1) {

                                FrontlightTheme.setEffect(effectBG_DropShadow);
                                FrontlightTheme.setTextFill(Color.web(color2));
                                FrontlightTheme.setStyle("-fx-background-color: #f8f8f8; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                FrontblackTheme.setEffect(null);
                                FrontredTheme.setEffect(null);
                                UNOTheme.setEffect(null);

                                t1alistener.setSelected(true);
                                t2alistener.setSelected(false);
                                t3alistener.setSelected(false);
                                t4listener.setSelected(false);


                            }
                            else if (tfSelected==2) {

                                FrontlightTheme.setEffect(null);
                                FrontblackTheme.setEffect(effectBG_DropShadow);
                                FrontblackTheme.setTextFill(Color.web(color2));
                                FrontblackTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                FrontredTheme.setEffect(null);
                                UNOTheme.setEffect(null);

                                t1alistener.setSelected(false);
                                t2alistener.setSelected(true);
                                t3alistener.setSelected(false);
                                t4listener.setSelected(false);

                            }
                            else if (tfSelected==3) {

                                FrontlightTheme.setEffect(null);
                                FrontblackTheme.setEffect(null);
                                FrontredTheme.setEffect(effectBG_DropShadow);
                                FrontredTheme.setTextFill(Color.web(color2));
                                FrontredTheme.setStyle("-fx-background-color: #ff0000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                UNOTheme.setEffect(null);

                                t1alistener.setSelected(false);
                                t2alistener.setSelected(false);
                                t3alistener.setSelected(true);
                                t4listener.setSelected(false);

                            }

                            if (tbSelected == 0) {

                                BacklightTheme.setEffect(null);
                                BackblackTheme.setEffect(null);
                                BackredTheme.setEffect(null);

                                t1blistener.setSelected(false);
                                t2blistener.setSelected(false);
                                t3blistener.setSelected(false);

                            }
                            else if (tbSelected == 1) {

                                BacklightTheme.setEffect(effectBG_DropShadow);
                                BacklightTheme.setTextFill(Color.web(color2));
                                BacklightTheme.setStyle("-fx-background-color: #f8f8f8; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                BackblackTheme.setEffect(null);
                                BackredTheme.setEffect(null);

                                t1blistener.setSelected(true);
                                t2blistener.setSelected(false);
                                t3blistener.setSelected(false);

                            }
                            else if (tbSelected == 2) {

                                BacklightTheme.setEffect(null);
                                BackblackTheme.setEffect(effectBG_DropShadow);
                                BackblackTheme.setTextFill(Color.web(color2));
                                BackblackTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                BackredTheme.setEffect(null);

                                t1blistener.setSelected(false);
                                t2blistener.setSelected(true);
                                t3blistener.setSelected(false);

                            }
                            else if (tbSelected == 3) {

                                BacklightTheme.setEffect(null);
                                BackblackTheme.setEffect(null);
                                BackredTheme.setEffect(effectBG_DropShadow);
                                BackredTheme.setStyle("-fx-background-color: #ff0000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                BackredTheme.setTextFill(Color.web(color2));

                                t1blistener.setSelected(false);
                                t2blistener.setSelected(false);
                                t3blistener.setSelected(true);

                            }

                        }
                        else if (tSelected==2){

                            FrontlightTheme.setEffect(null);
                            FrontblackTheme.setEffect(null);
                            FrontredTheme.setEffect(null);
                            BacklightTheme.setEffect(null);
                            BackblackTheme.setEffect(null);
                            BackredTheme.setEffect(null);
                            UNOTheme.setEffect(effectBG_DropShadow);
                            UNOTheme.setTextFill(Color.web(color2));
                            UNOTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");

                            t1alistener.setSelected(false);
                            t1blistener.setSelected(false);
                            t2alistener.setSelected(false);
                            t2blistener.setSelected(false);
                            t3alistener.setSelected(false);
                            t3blistener.setSelected(false);
                            t4listener.setSelected(true);

                        }

                        if (rSelected==0){

                            r1.setEffect(null);
                            r2.setEffect(null);
                            r3.setEffect(null);

                            r1listener.setSelected(false);
                            r2listener.setSelected(false);
                            r3listener.setSelected(false);

                        }
                        else if (rSelected==1){

                            r1.setEffect(effectBG_DropShadow);
                            r1.setTextFill(Color.web(color2));
                            r1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 16; -fx-border-color: "+color2+"; -fx-border-radius: 16; -fx-border-width: 3 ;");
                            r2.setEffect(null);
                            r3.setEffect(null);

                            r1listener.setSelected(true);
                            r2listener.setSelected(false);
                            r3listener.setSelected(false);

                            mode.setRivalsNumber(1);
                            mode.setRival1("Goldfish");
                            mode.setRival2("");
                            mode.setRival3("");

                        }
                        else if (rSelected==2){

                            r1.setEffect(null);
                            r2.setEffect(effectBG_DropShadow);
                            r2.setTextFill(Color.web(color2));
                            r2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 16; -fx-border-color: "+color2+"; -fx-border-radius: 16; -fx-border-width: 3 ;");
                            r3.setEffect(null);

                            r1listener.setSelected(false);
                            r2listener.setSelected(true);
                            r3listener.setSelected(false);

                            mode.setRivalsNumber(2);
                            mode.setRival1("Goldfish");
                            mode.setRival2("Goldfish");
                            mode.setRival3("");

                        }
                        else if (rSelected==3){

                            r1.setEffect(null);
                            r2.setEffect(null);
                            r3.setEffect(effectBG_DropShadow);
                            r3.setTextFill(Color.web(color2));
                            r3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 16; -fx-border-color: "+color2+"; -fx-border-radius: 16; -fx-border-width: 3 ;");

                            r1listener.setSelected(false);
                            r2listener.setSelected(false);
                            r3listener.setSelected(true);

                            mode.setRivalsNumber(3);
                            mode.setRival1("Goldfish");
                            mode.setRival2("Goldfish");
                            mode.setRival3("Goldfish");

                        }

                        if (gSelected==0||tSelected==0||tfSelected==0||tbSelected==0||rSelected==0){
                            multiplayer.setVisible(false);
                        }else {
                            multiplayer.setVisible(true);
                        }

                    }

                    singleMode.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> singleMode.setEffect(effectBG_DropShadow));
                    singleMode.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (g1listener.isSelected()){
                            singleMode.setEffect(effectBG_DropShadow);}
                        else{singleMode.setEffect(null);}
                    });
                    singleMode.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        g1listener.setSelected(true);
                        g2listener.setSelected(false);
                        g3listener.setSelected(false);
                        g4listener.setSelected(false);

                        singleMode.setEffect(effectBG_DropShadow);
                        singleMode.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        singleMode.setTextFill(Color.web(color2));
                        doubleMode.setEffect(null);
                        hardModebtn.setEffect(null);
                        hellModebtn.setEffect(null);

                    });

                    doubleMode.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> doubleMode.setEffect(effectBG_DropShadow));
                    doubleMode.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (g2listener.isSelected()){
                            doubleMode.setEffect(effectBG_DropShadow);}
                        else{doubleMode.setEffect(null);}
                    });
                    doubleMode.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        g1listener.setSelected(false);
                        g2listener.setSelected(true);
                        g3listener.setSelected(false);
                        g4listener.setSelected(false);

                        singleMode.setEffect(null);
                        doubleMode.setEffect(effectBG_DropShadow);
                        doubleMode.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        doubleMode.setTextFill(Color.web(color2));
                        hardModebtn.setEffect(null);
                        hellModebtn.setEffect(null);

                    });

                    hardModebtn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> hardModebtn.setEffect(effectBG_DropShadow));
                    hardModebtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (g3listener.isSelected()){
                            hardModebtn.setEffect(effectBG_DropShadow);}
                        else{hardModebtn.setEffect(null);}
                    });
                    hardModebtn.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        g1listener.setSelected(false);
                        g2listener.setSelected(false);
                        g3listener.setSelected(true);
                        g4listener.setSelected(false);

                        singleMode.setEffect(null);
                        doubleMode.setEffect(null);
                        hardModebtn.setEffect(effectBG_DropShadow);
                        hardModebtn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        hardModebtn.setTextFill(Color.web(color2));
                        hellModebtn.setEffect(null);

                    });

                    hellModebtn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> hellModebtn.setEffect(effectBG_DropShadow));
                    hellModebtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (g4listener.isSelected()){
                            hellModebtn.setEffect(effectBG_DropShadow);}
                        else{hellModebtn.setEffect(null);}
                    });
                    hellModebtn.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        g1listener.setSelected(false);
                        g2listener.setSelected(false);
                        g3listener.setSelected(false);
                        g4listener.setSelected(true);

                        singleMode.setEffect(null);
                        doubleMode.setEffect(null);
                        hardModebtn.setEffect(null);
                        hellModebtn.setEffect(effectBG_DropShadow);
                        hellModebtn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        hellModebtn.setTextFill(Color.web(color2));

                    });

                    //THEME
                    FrontlightTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> FrontlightTheme.setEffect(effectBG_DropShadow));
                    FrontlightTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t1alistener.isSelected()){
                            FrontlightTheme.setEffect(effectBG_DropShadow);}
                        else{
                            FrontlightTheme.setEffect(null);}
                    });
                    FrontlightTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1alistener.setSelected(true);
                        t2alistener.setSelected(false);
                        t3alistener.setSelected(false);
                        t4listener.setSelected(false);

                        FrontlightTheme.setEffect(effectBG_DropShadow);
                        FrontlightTheme.setStyle("-fx-background-color: #f8f8f8; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        FrontlightTheme.setTextFill(Color.web(color2));
                        FrontblackTheme.setEffect(null);
                        FrontredTheme.setEffect(null);
                        UNOTheme.setEffect(null);

                    });

                    FrontblackTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> FrontblackTheme.setEffect(effectBG_DropShadow));
                    FrontblackTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t2alistener.isSelected()){
                            FrontblackTheme.setEffect(effectBG_DropShadow);}
                        else{
                            FrontblackTheme.setEffect(null);}
                    });
                    FrontblackTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1alistener.setSelected(false);
                        t2alistener.setSelected(true);
                        t3alistener.setSelected(false);
                        t4listener.setSelected(false);

                        FrontlightTheme.setEffect(null);
                        FrontblackTheme.setEffect(effectBG_DropShadow);
                        FrontblackTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        FrontblackTheme.setTextFill(Color.web(color2));
                        FrontredTheme.setEffect(null);
                        UNOTheme.setEffect(null);

                    });

                    FrontredTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> FrontredTheme.setEffect(effectBG_DropShadow));
                    FrontredTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t3alistener.isSelected()){
                            FrontredTheme.setEffect(effectBG_DropShadow);}
                        else{
                            FrontredTheme.setEffect(null);}
                    });
                    FrontredTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1alistener.setSelected(false);
                        t2alistener.setSelected(false);
                        t3alistener.setSelected(true);
                        t4listener.setSelected(false);

                        FrontlightTheme.setEffect(null);
                        FrontblackTheme.setEffect(null);
                        FrontredTheme.setEffect(effectBG_DropShadow);
                        FrontredTheme.setStyle("-fx-background-color: #ff0000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        FrontredTheme.setTextFill(Color.web(color2));
                        UNOTheme.setEffect(null);

                    });

                    BacklightTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> BacklightTheme.setEffect(effectBG_DropShadow));
                    BacklightTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t1blistener.isSelected()){
                            BacklightTheme.setEffect(effectBG_DropShadow);}
                        else{
                            BacklightTheme.setEffect(null);}
                    });
                    BacklightTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1blistener.setSelected(true);
                        t2blistener.setSelected(false);
                        t3blistener.setSelected(false);
                        t4listener.setSelected(false);

                        BacklightTheme.setEffect(effectBG_DropShadow);
                        BacklightTheme.setStyle("-fx-background-color: #f8f8f8; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        BacklightTheme.setTextFill(Color.web(color2));
                        BackblackTheme.setEffect(null);
                        BackredTheme.setEffect(null);
                        UNOTheme.setEffect(null);
                    });

                    BackblackTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> BackblackTheme.setEffect(effectBG_DropShadow));
                    BackblackTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t2blistener.isSelected()){
                            BackblackTheme.setEffect(effectBG_DropShadow);}
                        else{
                            BackblackTheme.setEffect(null);}
                    });
                    BackblackTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1blistener.setSelected(false);
                        t2blistener.setSelected(true);
                        t3blistener.setSelected(false);
                        t4listener.setSelected(false);

                        BacklightTheme.setEffect(null);
                        BackblackTheme.setEffect(effectBG_DropShadow);
                        BackblackTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        BackblackTheme.setTextFill(Color.web(color2));
                        BackredTheme.setEffect(null);
                        UNOTheme.setEffect(null);
                    });

                    BackredTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> BackredTheme.setEffect(effectBG_DropShadow));
                    BackredTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t3blistener.isSelected()){
                            BackredTheme.setEffect(effectBG_DropShadow);}
                        else{
                            BackredTheme.setEffect(null);}
                    });
                    BackredTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1blistener.setSelected(false);
                        t2blistener.setSelected(false);
                        t3blistener.setSelected(true);
                        t4listener.setSelected(false);

                        BacklightTheme.setEffect(null);
                        BackblackTheme.setEffect(null);
                        BackredTheme.setEffect(effectBG_DropShadow);
                        BackredTheme.setStyle("-fx-background-color: #ff0000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        BackredTheme.setTextFill(Color.web(color2));
                        UNOTheme.setEffect(null);

                    });

                    UNOTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> UNOTheme.setEffect(effectBG_DropShadow));
                    UNOTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t4listener.isSelected()){
                            UNOTheme.setEffect(effectBG_DropShadow);}
                        else{
                            UNOTheme.setEffect(null);}
                    });
                    UNOTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1alistener.setSelected(false);
                        t2alistener.setSelected(false);
                        t3alistener.setSelected(false);
                        t1blistener.setSelected(false);
                        t2blistener.setSelected(false);
                        t3blistener.setSelected(false);
                        t4listener.setSelected(true);

                        FrontlightTheme.setEffect(null);
                        FrontblackTheme.setEffect(null);
                        FrontredTheme.setEffect(null);
                        BacklightTheme.setEffect(null);
                        BackblackTheme.setEffect(null);
                        BackredTheme.setEffect(null);
                        UNOTheme.setEffect(effectBG_DropShadow);
                        UNOTheme.setTextFill(Color.web(color2));
                        UNOTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");

                    });

                    //Player Count
                    r1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> r1.setEffect(effectBG_DropShadow));
                    r1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r1listener.isSelected()){
                            r1.setEffect(effectBG_DropShadow);}
                        else{r1.setEffect(null);}
                    });
                    r1.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        r1listener.setSelected(true);
                        r2listener.setSelected(false);
                        r3listener.setSelected(false);

                        r1.setEffect(effectBG_DropShadow);
                        r1.setTextFill(Color.web(color2));
                        r1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24; -fx-border-color: "+color2+"; -fx-border-radius: 24; -fx-border-width: 3 ;");
                        r2.setEffect(null);
                        r3.setEffect(null);

                    });
                    r2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> r2.setEffect(effectBG_DropShadow));
                    r2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r2listener.isSelected()){
                            r2.setEffect(effectBG_DropShadow);}
                        else{r2.setEffect(null);}
                    });
                    r2.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        r1listener.setSelected(false);
                        r2listener.setSelected(true);
                        r3listener.setSelected(false);

                        r1.setEffect(null);
                        r2.setEffect(effectBG_DropShadow);
                        r2.setTextFill(Color.web(color2));
                        r2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24; -fx-border-color: "+color2+"; -fx-border-radius: 24; -fx-border-width: 3 ;");
                        r3.setEffect(null);
                    });
                    r3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> r3.setEffect(effectBG_DropShadow));
                    r3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r3listener.isSelected()){
                            r3.setEffect(effectBG_DropShadow);}
                        else{r3.setEffect(null);}
                    });
                    r3.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        r1listener.setSelected(false);
                        r2listener.setSelected(false);
                        r3listener.setSelected(true);

                        r1.setEffect(null);
                        r2.setEffect(null);
                        r3.setEffect(effectBG_DropShadow);
                        r3.setTextFill(Color.web(color2));
                        r3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24; -fx-border-color: "+color2+"; -fx-border-radius: 24; -fx-border-width: 3 ;");

                    });

                    multiplayer.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> multiplayer.setEffect(effectBG_DropShadow));
                    multiplayer.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        multiplayer.setEffect(null);
                    });
                    multiplayer.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
                        multiplayer.setEffect(effectBG_DropShadow);
                    });

                }
                else if (tColor == 4) {

                    color2 = "#9b0000";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(155,0,0), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(178,0,0), 10, 0, 5, 5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(155,0,0), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(178,0,0), 10, 0, 5, 5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBackButton = getClass().getResourceAsStream("../../../resources/svg/left_arrow/left-arrow_d.svg");
                    svgFileBackButton_Hover = getClass().getResourceAsStream("../../../resources/svg/left_arrow/left-arrow_dred.svg");

                    svgFileOption = getClass().getResourceAsStream("../../../resources/svg/menu/menu_d.svg");
                    svgFileOption_Hover = getClass().getResourceAsStream("../../../resources/svg/menu/menu_dred.svg");

                    Group svgImageBackButton = loader.loadSvg(svgFileBackButton);
                    Group svgImageBackButton_Hover = loader.loadSvg(svgFileBackButton_Hover);

                    Group svgImageOption = loader.loadSvg(svgFileOption);
                    Group svgImageOption_Hover = loader.loadSvg(svgFileOption_Hover);

                    svgImageBackButton.setScaleX(.04);
                    svgImageBackButton.setScaleY(.04);
                    svgImageBackButton_Hover.setScaleX(.04);
                    svgImageBackButton_Hover.setScaleY(.04);

                    svgImageOption.setScaleX(.04);
                    svgImageOption.setScaleY(.04);
                    svgImageOption_Hover.setScaleX(.04);
                    svgImageOption_Hover.setScaleY(.04);

                    Group svgIconBackButton = new Group(svgImageBackButton);
                    Group svgIconBackButton_Hover = new Group(svgImageBackButton_Hover);

                    Group svgIconOption = new Group(svgImageOption);
                    Group svgIconOption_Hover = new Group(svgImageOption_Hover);

                    backButton.setGraphic(svgIconOption);

                    fadeIn.setDuration(Duration.millis(500));
                    fadeOut.setDuration(Duration.millis(200));

                    fadeIn.setFromValue(0);
                    fadeIn.setToValue(10);

                    fadeOut.setFromValue(10);
                    fadeOut.setToValue(0);

                    fadeIn.setCycleCount(1);
                    fadeOut.setCycleCount(1);

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                        backButton.setEffect(effectC_DropShadow);
                        backButton.setGraphic(svgIconBackButton);

                        l1.setText("");
                        l2.setText("Back to Home");
                        l3.setText("");

                        Panel1.setEffect(blur);
                        Panel2.setEffect(blur);
                        Panel3.setEffect(blur);
                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        backButton.setEffect(null);
                        backButton.setGraphic(svgIconOption);

                        l1.setText("MEMORY");
                        l2.setText("GAME");
                        l3.setText("Multiplayer");

                        Panel1.setEffect(effectBG_DropShadow);
                        Panel2.setEffect(effectBG_DropShadow);
                        Panel3.setEffect(effectBG_DropShadow);

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e ->{

                        backButton.setGraphic(svgIconBackButton_Hover);

                        Panel1.setEffect(null);
                        Panel2.setEffect(null);
                        Panel3.setEffect(null);

                        fadeOut5.play();
                        fadeOut5_1.play();
                        fadeOut5_2.play();
                        fadeOut.play();
                        fadeOut2.play();
                        fadeOut3.play();
                        fadeOut4.play();
                        fadeOut6.play();
                        fadeOut7.play();
                        fadeOut8.play();
                        fadeOut9.play();
                        fadeOut9_1.play();
                        fadeOut9_2.play();
                        fadeOut9_3.play();
                        fadeOut9_4.play();
                        fadeOut9_5.play();
                        fadeOut9_6.play();
                        fadeOut9_7.play();
                        fadeOut9_8.play();
                        fadeOut9_9.play();
                        fadeOut9_10.play();
                        fadeOut9_11.play();
                        fadeOut9_12.play();
                        fadeOut9_13.play();

                    });

                    Panelex3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        backButton.setGraphic(svgIconOption_Hover);

                    });
                    Panelex3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        backButton.setGraphic(svgIconOption);

                    });

                    //INIT
                    if(f.exists()) {

                        input = new FileInputStream("config.properties");
                        properties.load(input);

                        int width = Integer.parseInt(properties.getProperty("width"));

                        if (width==999){

                            singleMode.setDisable(false);
                            doubleMode.setDisable(false);
                            hardModebtn.setDisable(false);
                            hellModebtn.setDisable(false);

                            singleMode.setVisible(true);
                            doubleMode.setVisible(true);
                            hardModebtn.setVisible(true);
                            hellModebtn.setVisible(true);

                        }
                        else if (width==1600){

                            singleMode.setDisable(false);
                            doubleMode.setDisable(false);
                            hardModebtn.setDisable(true);
                            hellModebtn.setDisable(true);

                            singleMode.setVisible(true);
                            doubleMode.setVisible(true);
                            hardModebtn.setVisible(false);
                            hellModebtn.setVisible(false);

                        }
                        else if (width==1280){

                            singleMode.setDisable(false);
                            doubleMode.setDisable(false);
                            hardModebtn.setDisable(true);
                            hellModebtn.setDisable(true);

                            singleMode.setVisible(true);
                            doubleMode.setVisible(true);
                            hardModebtn.setVisible(false);
                            hellModebtn.setVisible(false);

                        }
                    }
                    if(f3.exists()) {

                        input3 = new FileInputStream("gamemode.properties");
                        properties3.load(input3);

                        int gSelected = Integer.parseInt(properties3.getProperty("GSelected"));
                        int tSelected = Integer.parseInt(properties3.getProperty("TSelected"));
                        int rSelected = Integer.parseInt(properties3.getProperty("RSelected"));
                        int tfSelected = Integer.parseInt(properties3.getProperty("TFSelected"));
                        int tbSelected = Integer.parseInt(properties3.getProperty("TBSelected"));

                        if (gSelected==0){

                            singleMode.setEffect(null);
                            doubleMode.setEffect(null);
                            hardModebtn.setEffect(null);
                            hellModebtn.setEffect(null);

                            g1listener.setSelected(false);
                            g2listener.setSelected(false);
                            g3listener.setSelected(false);
                            g4listener.setSelected(false);

                        }
                        else if (gSelected==1){

                            singleMode.setEffect(effectBG_DropShadow);
                            singleMode.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                            singleMode.setTextFill(Color.web(color2));
                            doubleMode.setEffect(null);
                            hardModebtn.setEffect(null);
                            hellModebtn.setEffect(null);

                            g1listener.setSelected(true);
                            g2listener.setSelected(false);
                            g3listener.setSelected(false);
                            g4listener.setSelected(false);

                            mode.setMode(1);

                        }
                        else if (gSelected==2){

                            singleMode.setEffect(null);
                            doubleMode.setEffect(effectBG_DropShadow);
                            doubleMode.setTextFill(Color.web(color2));
                            doubleMode.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                            hardModebtn.setEffect(null);
                            hellModebtn.setEffect(null);

                            g1listener.setSelected(false);
                            g2listener.setSelected(true);
                            g3listener.setSelected(false);
                            g4listener.setSelected(false);

                            mode.setMode(2);

                        }
                        else if (gSelected==3){

                            singleMode.setEffect(null);
                            doubleMode.setEffect(null);
                            hardModebtn.setEffect(effectBG_DropShadow);
                            hardModebtn.setTextFill(Color.web(color2));
                            hardModebtn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                            hellModebtn.setEffect(null);

                            g1listener.setSelected(false);
                            g2listener.setSelected(false);
                            g3listener.setSelected(true);
                            g4listener.setSelected(false);

                            mode.setMode(3);

                        }
                        else if (gSelected==4){

                            singleMode.setEffect(null);
                            doubleMode.setEffect(null);
                            hardModebtn.setEffect(null);
                            hellModebtn.setEffect(effectBG_DropShadow);
                            hellModebtn.setTextFill(Color.web(color2));
                            hellModebtn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");

                            g1listener.setSelected(false);
                            g2listener.setSelected(false);
                            g3listener.setSelected(false);
                            g4listener.setSelected(true);

                            mode.setMode(4);

                        }

                        if (tSelected==0){

                            FrontlightTheme.setEffect(null);
                            FrontblackTheme.setEffect(null);
                            FrontredTheme.setEffect(null);
                            BacklightTheme.setEffect(null);
                            BackblackTheme.setEffect(null);
                            BackredTheme.setEffect(null);
                            UNOTheme.setEffect(null);

                            t1alistener.setSelected(false);
                            t1blistener.setSelected(false);
                            t2alistener.setSelected(false);
                            t2blistener.setSelected(false);
                            t3alistener.setSelected(false);
                            t3blistener.setSelected(false);
                            t4listener.setSelected(false);

                        }
                        else if (tSelected==1){

                            if (tfSelected==0) {

                                FrontlightTheme.setEffect(null);
                                FrontblackTheme.setEffect(null);
                                FrontredTheme.setEffect(null);
                                UNOTheme.setEffect(null);

                                t1alistener.setSelected(false);
                                t2alistener.setSelected(false);
                                t3alistener.setSelected(false);
                                t4listener.setSelected(false);


                            }
                            else if (tfSelected==1) {

                                FrontlightTheme.setEffect(effectBG_DropShadow);
                                FrontlightTheme.setTextFill(Color.web(color2));
                                FrontlightTheme.setStyle("-fx-background-color: #f8f8f8; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                FrontblackTheme.setEffect(null);
                                FrontredTheme.setEffect(null);
                                UNOTheme.setEffect(null);

                                t1alistener.setSelected(true);
                                t2alistener.setSelected(false);
                                t3alistener.setSelected(false);
                                t4listener.setSelected(false);


                            }
                            else if (tfSelected==2) {

                                FrontlightTheme.setEffect(null);
                                FrontblackTheme.setEffect(effectBG_DropShadow);
                                FrontblackTheme.setTextFill(Color.web(color2));
                                FrontblackTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                FrontredTheme.setEffect(null);
                                UNOTheme.setEffect(null);

                                t1alistener.setSelected(false);
                                t2alistener.setSelected(true);
                                t3alistener.setSelected(false);
                                t4listener.setSelected(false);

                            }
                            else if (tfSelected==3) {

                                FrontlightTheme.setEffect(null);
                                FrontblackTheme.setEffect(null);
                                FrontredTheme.setEffect(effectBG_DropShadow);
                                FrontredTheme.setTextFill(Color.web(color2));
                                FrontredTheme.setStyle("-fx-background-color: #ff0000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                UNOTheme.setEffect(null);

                                t1alistener.setSelected(false);
                                t2alistener.setSelected(false);
                                t3alistener.setSelected(true);
                                t4listener.setSelected(false);

                            }

                            if (tbSelected == 0) {

                                BacklightTheme.setEffect(null);
                                BackblackTheme.setEffect(null);
                                BackredTheme.setEffect(null);

                                t1blistener.setSelected(false);
                                t2blistener.setSelected(false);
                                t3blistener.setSelected(false);

                            }
                            else if (tbSelected == 1) {

                                BacklightTheme.setEffect(effectBG_DropShadow);
                                BacklightTheme.setTextFill(Color.web(color2));
                                BacklightTheme.setStyle("-fx-background-color: #f8f8f8; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                BackblackTheme.setEffect(null);
                                BackredTheme.setEffect(null);

                                t1blistener.setSelected(true);
                                t2blistener.setSelected(false);
                                t3blistener.setSelected(false);

                            }
                            else if (tbSelected == 2) {

                                BacklightTheme.setEffect(null);
                                BackblackTheme.setEffect(effectBG_DropShadow);
                                BackblackTheme.setTextFill(Color.web(color2));
                                BackblackTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                BackredTheme.setEffect(null);

                                t1blistener.setSelected(false);
                                t2blistener.setSelected(true);
                                t3blistener.setSelected(false);

                            }
                            else if (tbSelected == 3) {

                                BacklightTheme.setEffect(null);
                                BackblackTheme.setEffect(null);
                                BackredTheme.setEffect(effectBG_DropShadow);
                                BackredTheme.setStyle("-fx-background-color: #ff0000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                                BackredTheme.setTextFill(Color.web(color2));

                                t1blistener.setSelected(false);
                                t2blistener.setSelected(false);
                                t3blistener.setSelected(true);

                            }

                        }
                        else if (tSelected==2){

                            FrontlightTheme.setEffect(null);
                            FrontblackTheme.setEffect(null);
                            FrontredTheme.setEffect(null);
                            BacklightTheme.setEffect(null);
                            BackblackTheme.setEffect(null);
                            BackredTheme.setEffect(null);
                            UNOTheme.setEffect(effectBG_DropShadow);
                            UNOTheme.setTextFill(Color.web(color2));
                            UNOTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");

                            t1alistener.setSelected(false);
                            t1blistener.setSelected(false);
                            t2alistener.setSelected(false);
                            t2blistener.setSelected(false);
                            t3alistener.setSelected(false);
                            t3blistener.setSelected(false);
                            t4listener.setSelected(true);

                        }

                        if (rSelected==0){

                            r1.setEffect(null);
                            r2.setEffect(null);
                            r3.setEffect(null);

                            r1listener.setSelected(false);
                            r2listener.setSelected(false);
                            r3listener.setSelected(false);

                        }
                        else if (rSelected==1){

                            r1.setEffect(effectBG_DropShadow);
                            r1.setTextFill(Color.web(color2));
                            r1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 16; -fx-border-color: "+color2+"; -fx-border-radius: 16; -fx-border-width: 3 ;");
                            r2.setEffect(null);
                            r3.setEffect(null);

                            r1listener.setSelected(true);
                            r2listener.setSelected(false);
                            r3listener.setSelected(false);

                            mode.setRivalsNumber(1);
                            mode.setRival1("Goldfish");
                            mode.setRival2("");
                            mode.setRival3("");

                        }
                        else if (rSelected==2){

                            r1.setEffect(null);
                            r2.setEffect(effectBG_DropShadow);
                            r2.setTextFill(Color.web(color2));
                            r2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 16; -fx-border-color: "+color2+"; -fx-border-radius: 16; -fx-border-width: 3 ;");
                            r3.setEffect(null);

                            r1listener.setSelected(false);
                            r2listener.setSelected(true);
                            r3listener.setSelected(false);

                            mode.setRivalsNumber(2);
                            mode.setRival1("Goldfish");
                            mode.setRival2("Goldfish");
                            mode.setRival3("");

                        }
                        else if (rSelected==3){

                            r1.setEffect(null);
                            r2.setEffect(null);
                            r3.setEffect(effectBG_DropShadow);
                            r3.setTextFill(Color.web(color2));
                            r3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 16; -fx-border-color: "+color2+"; -fx-border-radius: 16; -fx-border-width: 3 ;");

                            r1listener.setSelected(false);
                            r2listener.setSelected(false);
                            r3listener.setSelected(true);

                            mode.setRivalsNumber(3);
                            mode.setRival1("Goldfish");
                            mode.setRival2("Goldfish");
                            mode.setRival3("Goldfish");

                        }

                        if (gSelected==0||tSelected==0||tfSelected==0||tbSelected==0||rSelected==0){
                            multiplayer.setVisible(false);
                        }else {
                            multiplayer.setVisible(true);
                        }

                    }

                    singleMode.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> singleMode.setEffect(effectBG_DropShadow));
                    singleMode.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (g1listener.isSelected()){
                            singleMode.setEffect(effectBG_DropShadow);}
                        else{singleMode.setEffect(null);}
                    });
                    singleMode.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        g1listener.setSelected(true);
                        g2listener.setSelected(false);
                        g3listener.setSelected(false);
                        g4listener.setSelected(false);

                        singleMode.setEffect(effectBG_DropShadow);
                        singleMode.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        singleMode.setTextFill(Color.web(color2));
                        doubleMode.setEffect(null);
                        hardModebtn.setEffect(null);
                        hellModebtn.setEffect(null);

                    });

                    doubleMode.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> doubleMode.setEffect(effectBG_DropShadow));
                    doubleMode.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (g2listener.isSelected()){
                            doubleMode.setEffect(effectBG_DropShadow);}
                        else{doubleMode.setEffect(null);}
                    });
                    doubleMode.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        g1listener.setSelected(false);
                        g2listener.setSelected(true);
                        g3listener.setSelected(false);
                        g4listener.setSelected(false);

                        singleMode.setEffect(null);
                        doubleMode.setEffect(effectBG_DropShadow);
                        doubleMode.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        doubleMode.setTextFill(Color.web(color2));
                        hardModebtn.setEffect(null);
                        hellModebtn.setEffect(null);

                    });

                    hardModebtn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> hardModebtn.setEffect(effectBG_DropShadow));
                    hardModebtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (g3listener.isSelected()){
                            hardModebtn.setEffect(effectBG_DropShadow);}
                        else{hardModebtn.setEffect(null);}
                    });
                    hardModebtn.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        g1listener.setSelected(false);
                        g2listener.setSelected(false);
                        g3listener.setSelected(true);
                        g4listener.setSelected(false);

                        singleMode.setEffect(null);
                        doubleMode.setEffect(null);
                        hardModebtn.setEffect(effectBG_DropShadow);
                        hardModebtn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        hardModebtn.setTextFill(Color.web(color2));
                        hellModebtn.setEffect(null);

                    });

                    hellModebtn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> hellModebtn.setEffect(effectBG_DropShadow));
                    hellModebtn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (g4listener.isSelected()){
                            hellModebtn.setEffect(effectBG_DropShadow);}
                        else{hellModebtn.setEffect(null);}
                    });
                    hellModebtn.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        g1listener.setSelected(false);
                        g2listener.setSelected(false);
                        g3listener.setSelected(false);
                        g4listener.setSelected(true);

                        singleMode.setEffect(null);
                        doubleMode.setEffect(null);
                        hardModebtn.setEffect(null);
                        hellModebtn.setEffect(effectBG_DropShadow);
                        hellModebtn.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        hellModebtn.setTextFill(Color.web(color2));

                    });

                    //THEME
                    FrontlightTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> FrontlightTheme.setEffect(effectBG_DropShadow));
                    FrontlightTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t1alistener.isSelected()){
                            FrontlightTheme.setEffect(effectBG_DropShadow);}
                        else{
                            FrontlightTheme.setEffect(null);}
                    });
                    FrontlightTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1alistener.setSelected(true);
                        t2alistener.setSelected(false);
                        t3alistener.setSelected(false);
                        t4listener.setSelected(false);

                        FrontlightTheme.setEffect(effectBG_DropShadow);
                        FrontlightTheme.setStyle("-fx-background-color: #f8f8f8; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        FrontlightTheme.setTextFill(Color.web(color2));
                        FrontblackTheme.setEffect(null);
                        FrontredTheme.setEffect(null);
                        UNOTheme.setEffect(null);

                    });

                    FrontblackTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> FrontblackTheme.setEffect(effectBG_DropShadow));
                    FrontblackTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t2alistener.isSelected()){
                            FrontblackTheme.setEffect(effectBG_DropShadow);}
                        else{
                            FrontblackTheme.setEffect(null);}
                    });
                    FrontblackTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1alistener.setSelected(false);
                        t2alistener.setSelected(true);
                        t3alistener.setSelected(false);
                        t4listener.setSelected(false);

                        FrontlightTheme.setEffect(null);
                        FrontblackTheme.setEffect(effectBG_DropShadow);
                        FrontblackTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        FrontblackTheme.setTextFill(Color.web(color2));
                        FrontredTheme.setEffect(null);
                        UNOTheme.setEffect(null);

                    });

                    FrontredTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> FrontredTheme.setEffect(effectBG_DropShadow));
                    FrontredTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t3alistener.isSelected()){
                            FrontredTheme.setEffect(effectBG_DropShadow);}
                        else{
                            FrontredTheme.setEffect(null);}
                    });
                    FrontredTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1alistener.setSelected(false);
                        t2alistener.setSelected(false);
                        t3alistener.setSelected(true);
                        t4listener.setSelected(false);

                        FrontlightTheme.setEffect(null);
                        FrontblackTheme.setEffect(null);
                        FrontredTheme.setEffect(effectBG_DropShadow);
                        FrontredTheme.setStyle("-fx-background-color: #ff0000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        FrontredTheme.setTextFill(Color.web(color2));
                        UNOTheme.setEffect(null);

                    });

                    BacklightTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> BacklightTheme.setEffect(effectBG_DropShadow));
                    BacklightTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t1blistener.isSelected()){
                            BacklightTheme.setEffect(effectBG_DropShadow);}
                        else{
                            BacklightTheme.setEffect(null);}
                    });
                    BacklightTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1blistener.setSelected(true);
                        t2blistener.setSelected(false);
                        t3blistener.setSelected(false);
                        t4listener.setSelected(false);

                        BacklightTheme.setEffect(effectBG_DropShadow);
                        BacklightTheme.setStyle("-fx-background-color: #f8f8f8; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        BacklightTheme.setTextFill(Color.web(color2));
                        BackblackTheme.setEffect(null);
                        BackredTheme.setEffect(null);
                        UNOTheme.setEffect(null);
                    });

                    BackblackTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> BackblackTheme.setEffect(effectBG_DropShadow));
                    BackblackTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t2blistener.isSelected()){
                            BackblackTheme.setEffect(effectBG_DropShadow);}
                        else{
                            BackblackTheme.setEffect(null);}
                    });
                    BackblackTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1blistener.setSelected(false);
                        t2blistener.setSelected(true);
                        t3blistener.setSelected(false);
                        t4listener.setSelected(false);

                        BacklightTheme.setEffect(null);
                        BackblackTheme.setEffect(effectBG_DropShadow);
                        BackblackTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        BackblackTheme.setTextFill(Color.web(color2));
                        BackredTheme.setEffect(null);
                        UNOTheme.setEffect(null);
                    });

                    BackredTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> BackredTheme.setEffect(effectBG_DropShadow));
                    BackredTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t3blistener.isSelected()){
                            BackredTheme.setEffect(effectBG_DropShadow);}
                        else{
                            BackredTheme.setEffect(null);}
                    });
                    BackredTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1blistener.setSelected(false);
                        t2blistener.setSelected(false);
                        t3blistener.setSelected(true);
                        t4listener.setSelected(false);

                        BacklightTheme.setEffect(null);
                        BackblackTheme.setEffect(null);
                        BackredTheme.setEffect(effectBG_DropShadow);
                        BackredTheme.setStyle("-fx-background-color: #ff0000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");
                        BackredTheme.setTextFill(Color.web(color2));
                        UNOTheme.setEffect(null);

                    });

                    UNOTheme.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> UNOTheme.setEffect(effectBG_DropShadow));
                    UNOTheme.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (t4listener.isSelected()){
                            UNOTheme.setEffect(effectBG_DropShadow);}
                        else{
                            UNOTheme.setEffect(null);}
                    });
                    UNOTheme.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        t1alistener.setSelected(false);
                        t2alistener.setSelected(false);
                        t3alistener.setSelected(false);
                        t1blistener.setSelected(false);
                        t2blistener.setSelected(false);
                        t3blistener.setSelected(false);
                        t4listener.setSelected(true);

                        FrontlightTheme.setEffect(null);
                        FrontblackTheme.setEffect(null);
                        FrontredTheme.setEffect(null);
                        BacklightTheme.setEffect(null);
                        BackblackTheme.setEffect(null);
                        BackredTheme.setEffect(null);
                        UNOTheme.setEffect(effectBG_DropShadow);
                        UNOTheme.setTextFill(Color.web(color2));
                        UNOTheme.setStyle("-fx-background-color: #000; -fx-background-radius: 36 36 36 36; -fx-border-color: "+color2+"; -fx-border-radius: 36 36 36 36; -fx-border-width: 3 ;");

                    });

                    //Player Count
                    r1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> r1.setEffect(effectBG_DropShadow));
                    r1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r1listener.isSelected()){
                            r1.setEffect(effectBG_DropShadow);}
                        else{r1.setEffect(null);}
                    });
                    r1.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        r1listener.setSelected(true);
                        r2listener.setSelected(false);
                        r3listener.setSelected(false);

                        r1.setEffect(effectBG_DropShadow);
                        r1.setTextFill(Color.web(color2));
                        r1.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24; -fx-border-color: "+color2+"; -fx-border-radius: 24; -fx-border-width: 3 ;");
                        r2.setEffect(null);
                        r3.setEffect(null);

                    });
                    r2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> r2.setEffect(effectBG_DropShadow));
                    r2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r2listener.isSelected()){
                            r2.setEffect(effectBG_DropShadow);}
                        else{r2.setEffect(null);}
                    });
                    r2.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        r1listener.setSelected(false);
                        r2listener.setSelected(true);
                        r3listener.setSelected(false);

                        r1.setEffect(null);
                        r2.setEffect(effectBG_DropShadow);
                        r2.setTextFill(Color.web(color2));
                        r2.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24; -fx-border-color: "+color2+"; -fx-border-radius: 24; -fx-border-width: 3 ;");
                        r3.setEffect(null);
                    });
                    r3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> r3.setEffect(effectBG_DropShadow));
                    r3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        if (r3listener.isSelected()){
                            r3.setEffect(effectBG_DropShadow);}
                        else{r3.setEffect(null);}
                    });
                    r3.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {

                        r1listener.setSelected(false);
                        r2listener.setSelected(false);
                        r3listener.setSelected(true);

                        r1.setEffect(null);
                        r2.setEffect(null);
                        r3.setEffect(effectBG_DropShadow);
                        r3.setTextFill(Color.web(color2));
                        r3.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 24; -fx-border-color: "+color2+"; -fx-border-radius: 24; -fx-border-width: 3 ;");

                    });

                    multiplayer.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> multiplayer.setEffect(effectBG_DropShadow));
                    multiplayer.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                        multiplayer.setEffect(null);
                    });
                    multiplayer.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
                        multiplayer.setEffect(effectBG_DropShadow);
                    });

                }

            }

        }

    }

    @FXML
    private void backButtonClicked() throws IOException{
        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        output = new FileOutputStream("config.properties");
        properties.setProperty("MenuSelected", "1");
        properties.store(output, null);

        output3 = new FileOutputStream("gamemode.properties");
        properties3.setProperty("GSelected", "0");
        properties3.setProperty("TSelected", "0");
        properties3.setProperty("TFSelected", "0");
        properties3.setProperty("TBSelected", "0");
        properties3.setProperty("RSelected", "0");
        properties3.store(output3, null);

        Parent root = FXMLLoader.load(getClass().getResource("../../../resources/view/MainMenu.fxml"));
        Stage stage = (Stage) backButton.getScene().getWindow();
        stage.getScene().setRoot(root);

        File f = new File("config.properties");
        if(f.exists()) {
            input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }

    }
    @FXML
    private void startClicked() throws IOException{
        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        output = new FileOutputStream("config.properties");
        properties.setProperty("MenuSelected", "1");
        properties.store(output, null);

        mode.setGlobalMode("Multiplayer");
        FXMLLoader Loader = new FXMLLoader();

        File f = new File("config.properties");
        File f3 = new File("gamemode.properties");
        if(f3.exists()) {
            input3 = new FileInputStream("gamemode.properties");
            properties3.load(input3);

            int tSelected = Integer.parseInt(properties3.getProperty("TSelected"));
            int tbSelected = Integer.parseInt(properties3.getProperty("TBSelected"));
            int tfSelected = Integer.parseInt(properties3.getProperty("TFSelected"));

            if (tSelected==1){

                if (tfSelected == 1) {

                    output3 = new FileOutputStream("gamemode.properties");
                    properties3.setProperty("TSelected", "1");
                    properties3.store(output3, null);

                    if (tbSelected == 1) {
                        theme = new Image("main/resources/images/Cards/backgoundLight.png");
                    } else if (tbSelected == 2) {
                        theme = new Image("main/resources/images/Cards/backgoundDark.png");
                    } else if (tbSelected == 3) {
                        theme = new Image("main/resources/images/Cards/backgroundRed.png");
                    }
                }
                else if (tfSelected == 2) {

                    output3 = new FileOutputStream("gamemode.properties");
                    properties3.setProperty("TSelected", "2");
                    properties3.store(output3, null);

                    if (tbSelected == 1) {
                        theme = new Image("main/resources/images/Cards/backgoundLight.png");
                    } else if (tbSelected == 2) {
                        theme = new Image("main/resources/images/Cards/backgoundDark.png");
                    } else if (tbSelected == 3) {
                        theme = new Image("main/resources/images/Cards/backgroundRed.png");
                    }
                }
                else if (tfSelected == 3) {

                    output3 = new FileOutputStream("gamemode.properties");
                    properties3.setProperty("TSelected", "3");
                    properties3.store(output3, null);

                    if (tbSelected == 1) {
                        theme = new Image("main/resources/images/Cards/backgoundLight.png");
                    } else if (tbSelected == 2) {
                        theme = new Image("main/resources/images/Cards/backgoundDark.png");
                    } else if (tbSelected == 3) {
                        theme = new Image("main/resources/images/Cards/backgroundRed.png");
                    }
                }

            }
            else if (tSelected==2){

                output3 = new FileOutputStream("gamemode.properties");
                properties3.setProperty("TSelected", "2");
                properties3.store(output3, null);

                theme = new Image("main/resources/images/Cards/backgoundUNO.png");

            }

            Loader.setLocation(getClass().getResource("../../../resources/view/Multiplayer.fxml"));
            Loader.load();
            Multiplayer multi2 = Loader.getController();

            Stage stage = (Stage) multiplayer.getScene().getWindow();
            multi2.setMode(mode,theme);
            multi2.gameStart();
            stage.getScene().setRoot(Loader.getRoot());


        }

    }

    //PLAYER
    @FXML
    private void r1Clicked() throws IOException {
        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        mode.setRivalsNumber(1);
        mode.setRival1("Goldfish");
        mode.setRival2("");
        mode.setRival3("");

        output3 = new FileOutputStream("gamemode.properties");
        properties3.setProperty("RMode", "1");
        properties3.setProperty("RSelected", "1");
        properties3.store(output3, null);

        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("../../../resources/view/MultiplayerSettings.fxml")));
        Stage stage = (Stage) r1.getScene().getWindow();
        stage.getScene().setRoot(root);

        File f = new File("config.properties");
        if(f.exists()) {
            input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }
    }
    @FXML
    private void r2Clicked() throws IOException {
        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        mode.setRivalsNumber(2);
        mode.setRival1("Goldfish");
        mode.setRival2("Goldfish");
        mode.setRival3("");
        output3 = new FileOutputStream("gamemode.properties");
        properties3.setProperty("RMode", "2");
        properties3.setProperty("RSelected", "2");
        properties3.store(output3, null);

        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("../../../resources/view/MultiplayerSettings.fxml")));
        Stage stage = (Stage) r2.getScene().getWindow();
        stage.getScene().setRoot(root);

        File f = new File("config.properties");
        if(f.exists()) {
            input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }
    }
    @FXML
    private void r3Clicked() throws IOException {
        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        mode.setRivalsNumber(3);
        mode.setRival1("Goldfish");
        mode.setRival2("Goldfish");
        mode.setRival3("Goldfish");

        output3 = new FileOutputStream("gamemode.properties");
        properties3.setProperty("RMode", "3");
        properties3.setProperty("RSelected", "3");
        properties3.store(output3, null);

        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("../../../resources/view/MultiplayerSettings.fxml")));
        Stage stage = (Stage) r3.getScene().getWindow();
        stage.getScene().setRoot(root);

        File f = new File("config.properties");
        if(f.exists()) {
            input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }

    }

    //GAMEMODE
    @FXML
    private void easyModeClicked() throws IOException {
        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        output3 = new FileOutputStream("gamemode.properties");
        properties3.setProperty("GSelected", "1");
        properties3.store(output3, null);

        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("../../../resources/view/MultiplayerSettings.fxml")));
        Stage stage = (Stage) r2.getScene().getWindow();
        stage.getScene().setRoot(root);

        File f = new File("config.properties");
        if(f.exists()) {
            input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }

    }
    @FXML
    private void mediumModeClicked() throws IOException {
        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        output3 = new FileOutputStream("gamemode.properties");
        properties3.setProperty("GSelected", "2");
        properties3.store(output3, null);

        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("../../../resources/view/MultiplayerSettings.fxml")));
        Stage stage = (Stage) r2.getScene().getWindow();
        stage.getScene().setRoot(root);

        File f = new File("config.properties");
        if(f.exists()) {
            input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }

    }
    @FXML
    private void hardModeClicked() throws IOException {
        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        output3 = new FileOutputStream("gamemode.properties");
        properties3.setProperty("GSelected", "3");
        properties3.store(output3, null);

        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("../../../resources/view/MultiplayerSettings.fxml")));
        Stage stage = (Stage) r2.getScene().getWindow();
        stage.getScene().setRoot(root);

        File f = new File("config.properties");
        if(f.exists()) {
            input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }

    }
    @FXML
    private void hellModeClicked() throws IOException {
        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        output3 = new FileOutputStream("gamemode.properties");
        properties3.setProperty("GSelected", "4");
        properties3.store(output3, null);

        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("../../../resources/view/MultiplayerSettings.fxml")));
        Stage stage = (Stage) r2.getScene().getWindow();
        stage.getScene().setRoot(root);

        File f = new File("config.properties");
        if(f.exists()) {
            input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }

    }

    //CARD
    ////CARD FRONT
    @FXML
    private void frontlightClicked() throws IOException {
        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        output3 = new FileOutputStream("gamemode.properties");
        properties3.setProperty("TSelected", "1");
        properties3.setProperty("TFSelected", "1");
        properties3.store(output3, null);

        File f = new File("config.properties");
        File f3 = new File("gamemode.properties");

        if(f3.exists()) {
            input3 = new FileInputStream("config.properties");
            properties3.load(input3);

            int tbSelected = Integer.parseInt(properties3.getProperty("TBSelected"));

            if(tbSelected == 0 ){

                t1blistener.setSelected(false);
                t2blistener.setSelected(false);
                t3blistener.setSelected(false);

            }
            else if(tbSelected == 1){

                t1blistener.setSelected(true);
                t2blistener.setSelected(false);
                t3blistener.setSelected(false);

            }
            else if(tbSelected == 2){

                t1blistener.setSelected(false);
                t2blistener.setSelected(true);
                t3blistener.setSelected(false);

            }
            else if(tbSelected == 3){

                t1blistener.setSelected(false);
                t2blistener.setSelected(false);
                t3blistener.setSelected(true);

            }

        }

        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("../../../resources/view/MultiplayerSettings.fxml")));
        Stage stage = (Stage) FrontlightTheme.getScene().getWindow();
        stage.getScene().setRoot(root);

        if(f.exists()) {
            input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }

    }
    @FXML
    private void frontdarkClicked() throws IOException {
        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        output3 = new FileOutputStream("gamemode.properties");
        properties3.setProperty("TSelected", "1");
        properties3.setProperty("TFSelected", "2");
        properties3.store(output3, null);

        File f = new File("config.properties");
        File f3 = new File("gamemode.properties");

        if(f3.exists()) {
            input3 = new FileInputStream("config.properties");
            properties3.load(input3);

            int tbSelected = Integer.parseInt(properties3.getProperty("TBSelected"));

            if(tbSelected == 0 ){

                t1blistener.setSelected(false);
                t2blistener.setSelected(false);
                t3blistener.setSelected(false);

            }
            else if(tbSelected == 1 ){

                t1blistener.setSelected(true);
                t2blistener.setSelected(false);
                t3blistener.setSelected(false);

            }
            else if(tbSelected == 2 ){

                t1blistener.setSelected(false);
                t2blistener.setSelected(true);
                t3blistener.setSelected(false);

            }
            else if(tbSelected == 3 ){

                t1blistener.setSelected(false);
                t2blistener.setSelected(false);
                t3blistener.setSelected(true);

            }

        }

        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("../../../resources/view/MultiplayerSettings.fxml")));
        Stage stage = (Stage) FrontblackTheme.getScene().getWindow();
        stage.getScene().setRoot(root);

        if(f.exists()) {
            input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }

    }
    @FXML
    private void frontredClicked() throws IOException {
        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        output3 = new FileOutputStream("gamemode.properties");
        properties3.setProperty("TSelected", "1");
        properties3.setProperty("TFSelected", "3");
        properties3.store(output3, null);

        File f = new File("config.properties");
        File f3 = new File("gamemode.properties");

        if(f3.exists()) {
            input3 = new FileInputStream("config.properties");
            properties3.load(input3);

            int tbSelected = Integer.parseInt(properties3.getProperty("TBSelected"));
            if(tbSelected == 0 ){

                t1blistener.setSelected(false);
                t2blistener.setSelected(false);
                t3blistener.setSelected(false);

            }
            else if(tbSelected == 1 ){

                t1blistener.setSelected(true);
                t2blistener.setSelected(false);
                t3blistener.setSelected(false);

            }
            else if(tbSelected == 2 ){

                t1blistener.setSelected(false);
                t2blistener.setSelected(true);
                t3blistener.setSelected(false);

            }
            else if(tbSelected == 3 ){

                t1blistener.setSelected(false);
                t2blistener.setSelected(false);
                t3blistener.setSelected(true);

            }

        }

        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("../../../resources/view/MultiplayerSettings.fxml")));
        Stage stage = (Stage) FrontblackTheme.getScene().getWindow();
        stage.getScene().setRoot(root);

        if(f.exists()) {
            input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }

    }

    ////CARD BACK
    @FXML
    private void backlightClicked() throws IOException {
        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        output3 = new FileOutputStream("gamemode.properties");
        properties3.setProperty("TSelected", "1");
        properties3.setProperty("TBSelected", "1");
        properties3.store(output3, null);

        File f = new File("config.properties");
        File f3 = new File("gamemode.properties");

        if(f3.exists()) {

            input3 = new FileInputStream("config.properties");
            properties3.load(input3);

            int tfSelected = Integer.parseInt(properties3.getProperty("TFSelected"));

            if(tfSelected == 0 ){

                t1alistener.setSelected(false);
                t2alistener.setSelected(false);
                t3alistener.setSelected(false);

            }
            else if(tfSelected == 1 ){

                t1alistener.setSelected(true);
                t2alistener.setSelected(false);
                t3alistener.setSelected(false);

            }
            else if(tfSelected == 2 ){

                t1alistener.setSelected(false);
                t2alistener.setSelected(true);
                t3alistener.setSelected(false);

            }
            else if(tfSelected == 3 ){

                t1alistener.setSelected(false);
                t2alistener.setSelected(false);
                t3alistener.setSelected(true);

            }

        }

        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("../../../resources/view/MultiplayerSettings.fxml")));
        Stage stage = (Stage) BacklightTheme.getScene().getWindow();
        stage.getScene().setRoot(root);

        if(f.exists()) {
            input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }

    }
    @FXML
    private void backdarkClicked() throws IOException {
        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        output3 = new FileOutputStream("gamemode.properties");
        properties3.setProperty("TSelected", "1");
        properties3.setProperty("TBSelected", "2");
        properties3.store(output3, null);

        File f = new File("config.properties");
        File f3 = new File("gamemode.properties");

        if(f3.exists()) {
            input3 = new FileInputStream("config.properties");
            properties3.load(input3);

            int tfSelected = Integer.parseInt(properties3.getProperty("TFSelected"));

            if(tfSelected == 0 ){

                t1alistener.setSelected(false);
                t2alistener.setSelected(false);
                t3alistener.setSelected(false);

            }
            else if(tfSelected == 1 ){

                t1alistener.setSelected(true);
                t2alistener.setSelected(false);
                t3alistener.setSelected(false);

            }
            else if(tfSelected == 2 ){

                t1alistener.setSelected(false);
                t2alistener.setSelected(true);
                t3alistener.setSelected(false);

            }
            else if(tfSelected == 3 ){

                t1alistener.setSelected(false);
                t2alistener.setSelected(false);
                t3alistener.setSelected(true);

            }

        }

        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("../../../resources/view/MultiplayerSettings.fxml")));
        Stage stage = (Stage) BackblackTheme.getScene().getWindow();
        stage.getScene().setRoot(root);

        if(f.exists()) {
            input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }

    }
    @FXML
    private void backredClicked() throws IOException {
        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        output3 = new FileOutputStream("gamemode.properties");
        properties3.setProperty("TSelected", "1");
        properties3.setProperty("TBSelected", "3");
        properties3.store(output3, null);

        File f = new File("config.properties");
        File f3 = new File("gamemode.properties");

        if(f3.exists()) {
            input3 = new FileInputStream("config.properties");
            properties3.load(input3);

            int tfSelected = Integer.parseInt(properties3.getProperty("TFSelected"));

            if(tfSelected == 0 ){

                t1alistener.setSelected(false);
                t2alistener.setSelected(false);
                t3alistener.setSelected(false);

            }
            else if(tfSelected == 1 ){

                t1alistener.setSelected(true);
                t2alistener.setSelected(false);
                t3alistener.setSelected(false);

            }
            else if(tfSelected == 2 ){

                t1alistener.setSelected(false);
                t2alistener.setSelected(true);
                t3alistener.setSelected(false);

            }
            else if(tfSelected == 3 ){

                t1alistener.setSelected(false);
                t2alistener.setSelected(false);
                t3alistener.setSelected(true);

            }

        }

        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("../../../resources/view/MultiplayerSettings.fxml")));
        Stage stage = (Stage) BackredTheme.getScene().getWindow();
        stage.getScene().setRoot(root);

        if(f.exists()) {
            input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }

    }

    ////CARD SPECiAL
    @FXML
    private void UNOClicked() throws IOException {
        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        output3 = new FileOutputStream("gamemode.properties");
        properties3.setProperty("TSelected", "2");
        properties3.setProperty("TFSelected", "1");
        properties3.setProperty("TBSelected", "1");
        properties3.store(output3, null);

        File f = new File("config.properties");
        File f3 = new File("gamemode.properties");

        if(f3.exists()) {
            input3 = new FileInputStream("config.properties");
            properties3.load(input3);

            int tSelected = Integer.parseInt(properties3.getProperty("TSelected"));
            if(tSelected == 4){

                t1alistener.setSelected(false);
                t2alistener.setSelected(false);
                t3alistener.setSelected(false);
                t1blistener.setSelected(false);
                t2blistener.setSelected(false);
                t3blistener.setSelected(false);
                t4listener.setSelected(true);

            }
            else {

            }

        }

        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("../../../resources/view/MultiplayerSettings.fxml")));
        Stage stage = (Stage) BackredTheme.getScene().getWindow();
        stage.getScene().setRoot(root);

        if(f.exists()) {
            input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            if(width == 999 ){

            }
            else {
                root.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });
                root.setOnMouseDragged(event -> {
                    stage.setX(event.getScreenX() - xOffset);
                    stage.setY(event.getScreenY() - yOffset);
                });
            }
        }

    }

}
