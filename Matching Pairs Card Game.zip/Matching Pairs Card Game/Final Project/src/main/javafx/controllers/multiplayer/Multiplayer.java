package main.javafx.controllers.multiplayer;

import javafx.animation.FadeTransition;
import javafx.animation.KeyFrame;
import javafx.animation.ScaleTransition;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.effect.BlurType;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.InnerShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;
import main.javafx.controllers.Game;
import main.javafx.model.Card;
import main.javafx.model.GameMode;
import main.javafx.util.SvgLoader;

import java.io.*;
import java.util.*;


public class Multiplayer extends Game {

    private int clicks,random1,random2,random3,wins1,wins2,wins3,wins4;
    @FXML
    private BorderPane gg11;
    @FXML
    private GridPane grid,grid2,grid21,Panelex,r3Panel,r1Panel,r2Panel;
    @FXML
    private HBox p1,p2;
    @FXML
    private Button backButton,next,b1,b2,b3,b11,b21,r3p1Icon,r3p2Icon,r3p3Icon,r3p4Icon,r2p1Icon,r2p2Icon,r2p3Icon,r1p1Icon,r1p2Icon;

    @FXML
    private Label turn,nextTurn,player1,player2,player3,player4,winLabel,l2,l1,l3,l4;

    @FXML
    private Label r1p1Label,r1p2Label,r2p1Label,r2p2Label,r2p3Label,r3p1Label,r3p2Label,r3p3Label,r3p4Label;

    @FXML
    private ColumnConstraints pp1;

    private int b111 = 0;
    private String t,nt,p3,p4;
    private String pl1,pl2,pl3,pl4,you;
    private String playerTurn1,playerTurn2,playerTurn3,playerTurn4,youWin,botWin;

    int pplay=0;

    private ImageView clickedImageView;
    private int[] scoreBots = new int[3];

    private double xOffset = 0;
    private double yOffset = 0;

    private Properties properties = new Properties();
    private Properties properties2 = new Properties();
    private Properties properties3 = new Properties();

    private InputStream input = null;
    private InputStream input2 = null;
    private InputStream input3 = null;
    private OutputStream output = null;
    private OutputStream output2 = null;
    private OutputStream output3 = null;

    private MediaPlayer mediaPlayer;
    final SvgLoader loader = new SvgLoader();

    DropShadow effectBG_DropShadow,effectC_DropShadowADD,effectC_DropShadow,effectBG_DropShadowADD;

    InnerShadow effectBG_InnerShadowADD,effectBG_InnerShadow,effectC_InnerShadowADD,effectC_InnerShadow;
    InputStream svgFileBack,svgFileBack_Hover,svgFileHome,svgFileHome_Hover,svgFileHome1,svgFileHome1_Hover,svgFileRetry,svgFileRetry_Hover,svgFileRetry1,svgFileRetry1_Hover,svgFilePause,svgFilePause_Hover,svgFileMenu,svgFileMenu_Hover;
    InputStream svgFilePlayer,svgFilePlayer2,svgFilePlayer3,svgFilePlayer4,svgFilePlayer5,svgFilePlayer6,svgFilePlayer7,svgFilePlayer8,svgFilePlayer9;
    InputStream svgFilePlayer_Hover,svgFilePlayer2_Hover,svgFilePlayer3_Hover,svgFilePlayer4_Hover,svgFilePlayer5_Hover,svgFilePlayer6_Hover,svgFilePlayer7_Hover,svgFilePlayer8_Hover,svgFilePlayer9_Hover;

    String color,color2;


    public Multiplayer(){
        clicks = 0;
        clickedImageView = null;
        Media buttonSound = new Media(new File("src/main/resources/Sounds/buttonSound.wav").toURI().toString());
        mediaPlayer = new MediaPlayer(buttonSound);
    }

    public void initialize()throws IOException{
        File f =new File("score.properties");
        File f2 =new File("config.properties");
        File f3 = new File("gamemode.properties");
        if(f2.exists()) {
            input = new FileInputStream("config.properties");
            properties.load(input);

            int width = Integer.parseInt(properties.getProperty("width"));
            int theme = Integer.parseInt(properties.getProperty("TMode"));
            int tColor = Integer.parseInt(properties.getProperty("TColor"));

            if (width==999){

                backButton.setPrefSize(64,64);

                if (theme==1){

                    color = "#f3f5f7";

                    if (tColor==1){

                        color2 = "#007aff";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#c0c2c4"));
                        b11.setTextFill(Color.web("#c0c2c4"));
                        b2.setTextFill(Color.web("#c0c2c4"));
                        b21.setTextFill(Color.web("#c0c2c4"));
                        b3.setTextFill(Color.web("#c0c2c4"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+";");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==2){

                        color2 = "#fff44f";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#c0c2c4"));
                        b11.setTextFill(Color.web("#c0c2c4"));
                        b2.setTextFill(Color.web("#c0c2c4"));
                        b21.setTextFill(Color.web("#c0c2c4"));
                        b3.setTextFill(Color.web("#c0c2c4"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+";");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==3){

                        color2 = "#00c853";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#c0c2c4"));
                        b11.setTextFill(Color.web("#c0c2c4"));
                        b2.setTextFill(Color.web("#c0c2c4"));
                        b21.setTextFill(Color.web("#c0c2c4"));
                        b3.setTextFill(Color.web("#c0c2c4"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+";");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==4){

                        color2 = "#d50000";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#c0c2c4"));
                        b11.setTextFill(Color.web("#c0c2c4"));
                        b2.setTextFill(Color.web("#c0c2c4"));
                        b21.setTextFill(Color.web("#c0c2c4"));
                        b3.setTextFill(Color.web("#c0c2c4"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+";");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }

                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));
                    Panelex.setStyle("-fx-background-color: "+color+"; -fx-background-radius:  0 0 0 34;");
                    if (f3.exists()){
                        input3 = new FileInputStream("gamemode.properties");
                        properties3.load(input3);

                        int GMode = Integer.parseInt(properties3.getProperty("RMode"));
                        if (GMode == 1) {
                            r1Panel.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 0 0;");
                            r1p1Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r1p2Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                        }
                        else if (GMode == 3) {
                            r3Panel.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 0 0;");
                            r3p1Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r3p2Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r3p3Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r3p4Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                        }
                        else if (GMode == 2) {
                            r2Panel.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 0 0;");
                            r2p1Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r2p2Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r2p3Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                        }

                    }

                }
                else if (theme==2){

                    color = "#181818";

                    if (tColor==1){

                        color2 = "#004fcb";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#3E3E3E"));
                        b11.setTextFill(Color.web("#3E3E3E"));
                        b2.setTextFill(Color.web("#3E3E3E"));
                        b21.setTextFill(Color.web("#3E3E3E"));
                        b3.setTextFill(Color.web("#3E3E3E"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }
                    else if (tColor==2){

                        color2 = "#c9c208";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#3E3E3E"));
                        b11.setTextFill(Color.web("#3E3E3E"));
                        b2.setTextFill(Color.web("#3E3E3E"));
                        b21.setTextFill(Color.web("#3E3E3E"));
                        b3.setTextFill(Color.web("#3E3E3E"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+";");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==3){

                        color2 = "#006500";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#3E3E3E"));
                        b11.setTextFill(Color.web("#3E3E3E"));
                        b2.setTextFill(Color.web("#3E3E3E"));
                        b21.setTextFill(Color.web("#3E3E3E"));
                        b3.setTextFill(Color.web("#3E3E3E"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+";");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }
                    else if (tColor==4){
                        color2 = "#9b0000";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#3E3E3E"));
                        b11.setTextFill(Color.web("#3E3E3E"));
                        b2.setTextFill(Color.web("#3E3E3E"));
                        b21.setTextFill(Color.web("#3E3E3E"));
                        b3.setTextFill(Color.web("#3E3E3E"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+";");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 0;");

                    }

                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));
                    Panelex.setStyle("-fx-background-color: "+color+"; -fx-background-radius:  0 0 0 34;");
                    if (f3.exists()){
                        input3 = new FileInputStream("gamemode.properties");
                        properties3.load(input3);

                        int GMode = Integer.parseInt(properties3.getProperty("RMode"));
                        if (GMode == 1) {
                            r1Panel.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 0 0;");
                            r1p1Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r1p2Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                        }
                        else if (GMode == 3) {
                            r3Panel.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 0 0;");
                            r3p1Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r3p2Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r3p3Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r3p4Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                        }
                        else if (GMode == 2) {
                            r2Panel.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 0 0;");
                            r2p1Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r2p2Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r2p3Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                        }

                    }

                }

            }
            else if (width==1600){

                backButton.setPrefSize(64,64);

                if (theme==1){

                    color = "#f3f5f7";

                    if (tColor==1){

                        color2 = "#007aff";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#c0c2c4"));
                        b11.setTextFill(Color.web("#c0c2c4"));
                        b2.setTextFill(Color.web("#c0c2c4"));
                        b21.setTextFill(Color.web("#c0c2c4"));
                        b3.setTextFill(Color.web("#c0c2c4"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }
                    else if (tColor==2){

                        color2 = "#fff44f";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#c0c2c4"));
                        b11.setTextFill(Color.web("#c0c2c4"));
                        b2.setTextFill(Color.web("#c0c2c4"));
                        b21.setTextFill(Color.web("#c0c2c4"));
                        b3.setTextFill(Color.web("#c0c2c4"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }
                    else if (tColor==3){

                        color2 = "#00c853";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#c0c2c4"));
                        b11.setTextFill(Color.web("#c0c2c4"));
                        b2.setTextFill(Color.web("#c0c2c4"));
                        b21.setTextFill(Color.web("#c0c2c4"));
                        b3.setTextFill(Color.web("#c0c2c4"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }
                    else if (tColor==4){

                        color2 = "#d50000";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#c0c2c4"));
                        b11.setTextFill(Color.web("#c0c2c4"));
                        b2.setTextFill(Color.web("#c0c2c4"));
                        b21.setTextFill(Color.web("#c0c2c4"));
                        b3.setTextFill(Color.web("#c0c2c4"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }

                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));
                    Panelex.setStyle("-fx-background-color: "+color+"; -fx-background-radius:  0 0 0 34;");

                    if (f3.exists()){
                        input3 = new FileInputStream("gamemode.properties");
                        properties3.load(input3);

                        int GMode = Integer.parseInt(properties3.getProperty("RMode"));
                        if (GMode == 1) {
                            r1Panel.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 34 0;");
                            r1p1Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r1p2Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                        }else if (GMode == 3) {
                            r3Panel.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 34 0;");
                            r3p1Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r3p2Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r3p3Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r3p4Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                        }else if (GMode == 2) {
                            r2Panel.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 34 0;");
                            r2p1Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r2p2Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r2p3Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                        }

                    }

                }
                else if (theme==2){

                    color = "#181818";

                    if (tColor==1){

                        color2 = "#004fcb";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#3E3E3E"));
                        b11.setTextFill(Color.web("#3E3E3E"));
                        b2.setTextFill(Color.web("#3E3E3E"));
                        b21.setTextFill(Color.web("#3E3E3E"));
                        b3.setTextFill(Color.web("#3E3E3E"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }
                    else if (tColor==2){

                        color2 = "#c9c208";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#3E3E3E"));
                        b11.setTextFill(Color.web("#3E3E3E"));
                        b2.setTextFill(Color.web("#3E3E3E"));
                        b21.setTextFill(Color.web("#3E3E3E"));
                        b3.setTextFill(Color.web("#3E3E3E"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }
                    else if (tColor==3){

                        color2 = "#006500";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#3E3E3E"));
                        b11.setTextFill(Color.web("#3E3E3E"));
                        b2.setTextFill(Color.web("#3E3E3E"));
                        b21.setTextFill(Color.web("#3E3E3E"));
                        b3.setTextFill(Color.web("#3E3E3E"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }
                    else if (tColor==4){
                        color2 = "#9b0000";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#3E3E3E"));
                        b11.setTextFill(Color.web("#3E3E3E"));
                        b2.setTextFill(Color.web("#3E3E3E"));
                        b21.setTextFill(Color.web("#3E3E3E"));
                        b3.setTextFill(Color.web("#3E3E3E"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }

                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));
                    Panelex.setStyle("-fx-background-color: "+color+"; -fx-background-radius:  0 0 0 34;");
                    if (f3.exists()){
                        input3 = new FileInputStream("gamemode.properties");
                        properties3.load(input3);

                        int GMode = Integer.parseInt(properties3.getProperty("RMode"));
                        if (GMode == 1) {
                            r1Panel.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 34 0;");
                            r1p1Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r1p2Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                        }else if (GMode == 3) {
                            r3Panel.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 34 0;");
                            r3p1Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r3p2Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r3p3Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r3p4Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                        }else if (GMode == 2) {
                            r2Panel.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 34 0;");
                            r2p1Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r2p2Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r2p3Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                        }

                    }


                }

            }
            else if (width==1280){

                if (theme==1){

                    color = "#f3f5f7";

                    if (tColor==1){

                        color2 = "#007aff";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#c0c2c4"));
                        b11.setTextFill(Color.web("#c0c2c4"));
                        b2.setTextFill(Color.web("#c0c2c4"));
                        b21.setTextFill(Color.web("#c0c2c4"));
                        b3.setTextFill(Color.web("#c0c2c4"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }
                    else if (tColor==2){

                        color2 = "#fff44f";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#c0c2c4"));
                        b11.setTextFill(Color.web("#c0c2c4"));
                        b2.setTextFill(Color.web("#c0c2c4"));
                        b21.setTextFill(Color.web("#c0c2c4"));
                        b3.setTextFill(Color.web("#c0c2c4"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }
                    else if (tColor==3){

                        color2 = "#00c853";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#c0c2c4"));
                        b11.setTextFill(Color.web("#c0c2c4"));
                        b2.setTextFill(Color.web("#c0c2c4"));
                        b21.setTextFill(Color.web("#c0c2c4"));
                        b3.setTextFill(Color.web("#c0c2c4"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }
                    else if (tColor==4){

                        color2 = "#d50000";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#c0c2c4"));
                        b11.setTextFill(Color.web("#c0c2c4"));
                        b2.setTextFill(Color.web("#c0c2c4"));
                        b21.setTextFill(Color.web("#c0c2c4"));
                        b3.setTextFill(Color.web("#c0c2c4"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }

                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));
                    Panelex.setStyle("-fx-background-color: "+color+"; -fx-background-radius:  0 0 0 34;");

                    if (f3.exists()){
                        input3 = new FileInputStream("gamemode.properties");
                        properties3.load(input3);

                        int GMode = Integer.parseInt(properties3.getProperty("RMode"));
                        if (GMode == 1) {
                            r1Panel.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 34 0;");
                            r1p1Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r1p2Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                        }else if (GMode == 3) {
                            r3Panel.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 34 0;");
                            r3p1Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r3p2Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r3p3Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r3p4Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                        }else if (GMode == 2) {
                            r2Panel.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 34 0;");
                            r2p1Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r2p2Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r2p3Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                        }

                    }

                }
                else if (theme==2){

                    color = "#181818";

                    if (tColor==1){

                        color2 = "#004fcb";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#3E3E3E"));
                        b11.setTextFill(Color.web("#3E3E3E"));
                        b2.setTextFill(Color.web("#3E3E3E"));
                        b21.setTextFill(Color.web("#3E3E3E"));
                        b3.setTextFill(Color.web("#3E3E3E"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }
                    else if (tColor==2){

                        color2 = "#c9c208";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#3E3E3E"));
                        b11.setTextFill(Color.web("#3E3E3E"));
                        b2.setTextFill(Color.web("#3E3E3E"));
                        b21.setTextFill(Color.web("#3E3E3E"));
                        b3.setTextFill(Color.web("#3E3E3E"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }
                    else if (tColor==3){

                        color2 = "#006500";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#3E3E3E"));
                        b11.setTextFill(Color.web("#3E3E3E"));
                        b2.setTextFill(Color.web("#3E3E3E"));
                        b21.setTextFill(Color.web("#3E3E3E"));
                        b3.setTextFill(Color.web("#3E3E3E"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }
                    else if (tColor==4){
                        color2 = "#9b0000";
                        l3.setTextFill(Color.web(color2));
                        l4.setTextFill(Color.web(color2));
                        b1.setTextFill(Color.web("#3E3E3E"));
                        b11.setTextFill(Color.web("#3E3E3E"));
                        b2.setTextFill(Color.web("#3E3E3E"));
                        b21.setTextFill(Color.web("#3E3E3E"));
                        b3.setTextFill(Color.web("#3E3E3E"));
                        b1.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        b3.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        gg11.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 36 36 36 36;");
                        grid.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid2.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");
                        grid21.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 0 0 36 34;");

                    }

                    l1.setTextFill(Color.web(color));
                    l2.setTextFill(Color.web(color));
                    Panelex.setStyle("-fx-background-color: "+color+"; -fx-background-radius:  0 0 0 34;");
                    if (f3.exists()){
                        input3 = new FileInputStream("gamemode.properties");
                        properties3.load(input3);

                        int GMode = Integer.parseInt(properties3.getProperty("RMode"));
                        if (GMode == 1) {
                            r1Panel.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 34 0;");
                            r1p1Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r1p2Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                        }else if (GMode == 3) {
                            r3Panel.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 34 0;");
                            r3p1Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r3p2Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r3p3Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r3p4Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                        }else if (GMode == 2) {
                            r2Panel.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 36 0 34 0;");
                            r2p1Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r2p2Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                            r2p3Icon.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");
                        }

                    }


                }

            }

        }

        if(f.exists()){
            InputStream input2 = new FileInputStream("score.properties");
            properties2.load(input2);
            wins1 = Integer.parseInt(properties2.getProperty("MultiplayerWins1"));
            wins2 = Integer.parseInt(properties2.getProperty("MultiplayerWins2"));
            wins3 = Integer.parseInt(properties2.getProperty("MultiplayerWins3"));
            wins4 = Integer.parseInt(properties2.getProperty("MultiplayerWins4"));
        }
        themeHandler();
    }

    private void themeHandler() throws IOException {
///
        FadeTransition fadeIn = new FadeTransition();//Back button
        FadeTransition fadeIn2 = new FadeTransition();//BG-g
        FadeTransition fadeIn3 = new FadeTransition();//BG-g1
        FadeTransition fadeIn4 = new FadeTransition();//PANELex
        FadeTransition fadeIn4_1 = new FadeTransition();//PANELex2
        FadeTransition fadeIn5 = new FadeTransition();//l1
        FadeTransition fadeIn5_1 = new FadeTransition();//l2
        FadeTransition fadeIn5_2 = new FadeTransition();//l3
        FadeTransition fadeIn5_3 = new FadeTransition();//l4
        FadeTransition fadeIn6 = new FadeTransition();//b11
        FadeTransition fadeIn6_1 = new FadeTransition();//b21
        FadeTransition fadeIn7 = new FadeTransition();//b1
        FadeTransition fadeIn7_1 = new FadeTransition();//b2
        FadeTransition fadeIn7_2 = new FadeTransition();//b3
        ////

        FadeTransition fadeIn8 = new FadeTransition();//lt1
        FadeTransition fadeIn8_1 = new FadeTransition();//lt2
        FadeTransition fadeIn9 = new FadeTransition();//r1
        FadeTransition fadeIn9_1 = new FadeTransition();//r2
        FadeTransition fadeIn10 = new FadeTransition();//back
        FadeTransition fadeIn11 = new FadeTransition();//l2

        ///
        FadeTransition fadeOut = new FadeTransition();//BG
        FadeTransition fadeOut2 = new FadeTransition();//BG
        FadeTransition fadeOut3 = new FadeTransition();//BG
        FadeTransition fadeOut4 = new FadeTransition();//PANELex1
        FadeTransition fadeOut4_1 = new FadeTransition();//PANELex2
        FadeTransition fadeOut5 = new FadeTransition();//l1
        FadeTransition fadeOut5_1 = new FadeTransition();//l2
        FadeTransition fadeOut5_2 = new FadeTransition();//l3
        FadeTransition fadeOut5_3 = new FadeTransition();//l4
        FadeTransition fadeOut6 = new FadeTransition();//b11
        FadeTransition fadeOut6_1 = new FadeTransition();//b21
        FadeTransition fadeOut7 = new FadeTransition();//b1
        FadeTransition fadeOut7_1 = new FadeTransition();//b2
        FadeTransition fadeOut7_2 = new FadeTransition();//b3
        ////
        FadeTransition fadeOut8 = new FadeTransition();//lt1
        FadeTransition fadeOut8_1 = new FadeTransition();//lt2
        FadeTransition fadeOut9 = new FadeTransition();//r1
        FadeTransition fadeOut9_1 = new FadeTransition();//r2
        FadeTransition fadeOut10 = new FadeTransition();//back
        FadeTransition fadeOut11 = new FadeTransition();//l2

        fadeIn.setDuration(Duration.millis(500));//BG
        fadeIn2.setDuration(Duration.millis(500));//BG
        fadeIn3.setDuration(Duration.millis(500));//BG
        fadeIn4.setDuration(Duration.millis(100));//PANEL1
        fadeIn4_1.setDuration(Duration.millis(100));//PANEL2
        fadeIn5.setDuration(Duration.millis(250));//l1
        fadeIn5_1.setDuration(Duration.millis(350));//l2
        fadeIn5_2.setDuration(Duration.millis(400));//l3
        fadeIn5_3.setDuration(Duration.millis(400));//l4
        fadeIn6.setDuration(Duration.millis(100));//b11
        fadeIn6_1.setDuration(Duration.millis(200));//b21
        fadeIn7.setDuration(Duration.millis(650));//b1
        fadeIn7_1.setDuration(Duration.millis(750));//b2
        fadeIn7_2.setDuration(Duration.millis(900));//b3

        fadeIn8.setDuration(Duration.millis(100));//lt1
        fadeIn8_1.setDuration(Duration.millis(60));//lt2
        fadeIn9.setDuration(Duration.millis(250));//r1
        fadeIn9_1.setDuration(Duration.millis(750));//r2
        fadeIn10.setDuration(Duration.millis(750));//back
        fadeIn11.setDuration(Duration.millis(750));//l2

        fadeOut.setDuration(Duration.millis(500));//BG
        fadeOut2.setDuration(Duration.millis(500));//BG
        fadeOut3.setDuration(Duration.millis(500));//BG
        fadeOut4.setDuration(Duration.millis(250));//PANEL1
        fadeOut4_1.setDuration(Duration.millis(250));//PANEL2
        fadeOut5.setDuration(Duration.millis(500));//l1
        fadeOut5_1.setDuration(Duration.millis(500));//l2
        fadeOut5_2.setDuration(Duration.millis(500));//l3
        fadeOut5_3.setDuration(Duration.millis(500));//l3
        fadeOut6.setDuration(Duration.millis(250));//b11
        fadeOut6_1.setDuration(Duration.millis(250));//b21
        fadeOut7.setDuration(Duration.millis(500));//b1
        fadeOut7_1.setDuration(Duration.millis(500));//b2
        fadeOut7_2.setDuration(Duration.millis(500));//b3

        fadeOut8.setDuration(Duration.millis(250));//lt1
        fadeOut8_1.setDuration(Duration.millis(500));//lt2
        fadeOut9.setDuration(Duration.millis(500));//r1
        fadeOut9_1.setDuration(Duration.millis(500));//r2
        fadeOut10.setDuration(Duration.millis(300));//back
        fadeOut11.setDuration(Duration.millis(300));//l2

        fadeIn.setFromValue(0);
        fadeIn.setToValue(10);
        fadeIn2.setFromValue(0);
        fadeIn2.setToValue(10);
        fadeIn3.setFromValue(0);
        fadeIn3.setToValue(10);
        fadeIn4.setFromValue(0);
        fadeIn4.setToValue(10);
        fadeIn4_1.setFromValue(0);
        fadeIn4_1.setToValue(10);
        fadeIn5.setFromValue(0);
        fadeIn5.setToValue(10);
        fadeIn5_1.setFromValue(0);
        fadeIn5_1.setToValue(10);
        fadeIn5_2.setFromValue(0);
        fadeIn5_2.setToValue(10);
        fadeIn5_3.setFromValue(0);
        fadeIn5_3.setToValue(10);
        fadeIn6.setFromValue(0);
        fadeIn6.setToValue(10);
        fadeIn6_1.setFromValue(0);
        fadeIn6_1.setToValue(10);
        fadeIn7.setFromValue(0);
        fadeIn7.setToValue(10);
        fadeIn7_1.setFromValue(0);
        fadeIn7_1.setToValue(10);
        fadeIn7_2.setFromValue(0);
        fadeIn7_2.setToValue(10);

        fadeIn8.setFromValue(0);
        fadeIn8.setToValue(10);
        fadeIn8_1.setFromValue(0);
        fadeIn8_1.setToValue(10);
        fadeIn9.setFromValue(0);
        fadeIn9.setToValue(10);
        fadeIn9_1.setFromValue(0);
        fadeIn9_1.setToValue(10);
        fadeIn10.setFromValue(0);
        fadeIn10.setToValue(10);
        fadeIn11.setFromValue(0);
        fadeIn11.setToValue(10);

        fadeOut.setFromValue(10);
        fadeOut.setToValue(0);
        fadeOut2.setFromValue(10);
        fadeOut2.setToValue(0);
        fadeOut3.setFromValue(10);
        fadeOut3.setToValue(0);
        fadeOut4.setFromValue(10);
        fadeOut4.setToValue(0);
        fadeOut4_1.setFromValue(10);
        fadeOut4_1.setToValue(0);
        fadeOut5.setFromValue(10);
        fadeOut5.setToValue(0);
        fadeOut5_1.setFromValue(10);
        fadeOut5_1.setToValue(0);
        fadeOut5_2.setFromValue(10);
        fadeOut5_2.setToValue(0);
        fadeOut5_3.setFromValue(10);
        fadeOut5_3.setToValue(0);
        fadeOut6.setFromValue(10);
        fadeOut6.setToValue(0);
        fadeOut6_1.setFromValue(10);
        fadeOut6_1.setToValue(0);
        fadeOut7.setFromValue(10);
        fadeOut7.setToValue(0);
        fadeOut7_1.setFromValue(10);
        fadeOut7_1.setToValue(0);
        fadeOut7_2.setFromValue(10);
        fadeOut7_2.setToValue(0);

        fadeOut8.setFromValue(10);
        fadeOut8.setToValue(0);
        fadeOut8_1.setFromValue(10);
        fadeOut8_1.setToValue(0);
        fadeOut9.setFromValue(10);
        fadeOut9.setToValue(0);
        fadeOut9_1.setFromValue(10);
        fadeOut9_1.setToValue(0);
        fadeOut10.setFromValue(10);
        fadeOut10.setToValue(0);
        fadeOut11.setFromValue(10);
        fadeOut11.setToValue(0);

        fadeIn.setCycleCount(1);
        fadeIn2.setCycleCount(1);
        fadeIn3.setCycleCount(1);
        fadeIn4.setCycleCount(1);
        fadeIn4_1.setCycleCount(1);
        fadeIn5.setCycleCount(1);
        fadeIn5_1.setCycleCount(1);
        fadeIn5_2.setCycleCount(1);
        fadeIn5_3.setCycleCount(1);
        fadeIn6.setCycleCount(1);
        fadeIn6_1.setCycleCount(1);
        fadeIn7.setCycleCount(1);
        fadeIn7_1.setCycleCount(1);
        fadeIn7_2.setCycleCount(1);

        fadeIn8.setCycleCount(1);
        fadeIn8_1.setCycleCount(1);
        fadeIn9.setCycleCount(1);
        fadeIn9_1.setCycleCount(1);
        fadeIn10.setCycleCount(1);
        fadeIn11.setCycleCount(1);

        fadeOut.setCycleCount(1);
        fadeOut2.setCycleCount(1);
        fadeOut3.setCycleCount(1);
        fadeOut4.setCycleCount(1);
        fadeOut4_1.setCycleCount(1);
        fadeOut5.setCycleCount(1);
        fadeOut5_1.setCycleCount(1);
        fadeOut5_2.setCycleCount(1);
        fadeOut5_3.setCycleCount(1);
        fadeOut6.setCycleCount(1);
        fadeOut6_1.setCycleCount(1);
        fadeOut7.setCycleCount(1);
        fadeOut7_1.setCycleCount(1);
        fadeOut7_2.setCycleCount(1);

        fadeOut8.setCycleCount(1);
        fadeOut8_1.setCycleCount(1);
        fadeOut9.setCycleCount(1);
        fadeOut9_1.setCycleCount(1);
        fadeOut10.setCycleCount(1);
        fadeOut11.setCycleCount(1);

        fadeIn.setNode(backButton);
        fadeIn2.setNode(grid);
        fadeIn3.setNode(grid2);
        fadeIn4.setNode(Panelex);
        fadeIn5.setNode(l1);
        fadeIn5_1.setNode(l2);
        fadeIn5_2.setNode(l3);
        fadeIn5_3.setNode(l4);
        fadeIn6.setNode(b11);
        fadeIn6_1.setNode(b21);
        fadeIn7.setNode(b1);
        fadeIn7_1.setNode(b2);
        fadeIn7_2.setNode(b3);

        fadeOut.setNode(backButton);
        fadeOut2.setNode(grid);
        fadeOut3.setNode(grid2);
        fadeOut4.setNode(Panelex);
        fadeOut5.setNode(l1);
        fadeOut5_1.setNode(l2);
        fadeOut5_2.setNode(l3);
        fadeOut5_3.setNode(l4);
        fadeOut6.setNode(b11);
        fadeOut6_1.setNode(b21);
        fadeOut7.setNode(b1);
        fadeOut7_1.setNode(b2);
        fadeOut7_2.setNode(b3);

        backButton.setVisible(false);
        grid.setVisible(false);
        Panelex.setVisible(false);
        r1Panel.setVisible(false);
        r2Panel.setVisible(false);
        r3Panel.setVisible(false);
        l1.setVisible(false);
        l2.setVisible(false);

        File f = new File("gamemode.properties");
        if(f.exists()) {
            InputStream input = new FileInputStream("gamemode.properties");
            properties.load(input);

            int GMode = Integer.parseInt(properties.getProperty("RMode"));
            int menuSelected = Integer.parseInt(properties.getProperty("MenuSelected"));
            int theme = Integer.parseInt(properties.getProperty("TMode"));
            int tColor = Integer.parseInt(properties.getProperty("TColor"));

            if (menuSelected == 1){

                backButton.setVisible(true);
                grid.setVisible(true);
                Panelex.setVisible(true);

                if (GMode == 1) {
                    fadeIn4_1.setNode(r1Panel);
                    fadeOut4_1.setNode(r1Panel);
                    r1Panel.setVisible(true);
                }else if (GMode == 3) {
                    fadeIn4_1.setNode(r3Panel);
                    fadeOut4_1.setNode(r3Panel);
                    r3Panel.setVisible(true);
                }else if (GMode == 2) {
                    fadeIn4_1.setNode(r2Panel);
                    fadeOut4_1.setNode(r2Panel);
                    r2Panel.setVisible(true);
                }

                l1.setVisible(true);
                l2.setVisible(true);

                fadeIn.play();
                fadeIn2.play();
                fadeIn4.play();
                fadeIn4_1.play();
                fadeIn5.play();
                fadeIn5_1.play();

                output = new FileOutputStream("config.properties");
                properties.setProperty("MenuSelected", "2");
                properties.store(output, null);

            }

            if(theme==1){

                color = "#f3f5f7";

                effectBG_DropShadowADD = new DropShadow(BlurType.GAUSSIAN, Color.rgb(206,207,210), 36, 0, 9, 9);
                effectBG_DropShadow = new DropShadow(BlurType.GAUSSIAN, Color.rgb(255,255,255), 18, 0, -9, -9);
                effectBG_DropShadow.setInput(effectBG_DropShadowADD);

                effectBG_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(206,207,210), 18, 0, 9, 9);
                effectBG_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(255,255,255), 18, 0, -9, -9);
                effectBG_InnerShadow.setInput(effectBG_InnerShadowADD);

                if (tColor==1) {

                    color2 = "#007aff";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,104,217), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,140,255), 10, 0, -5, -5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,104,217), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,140,255), 10, 0, -5, -5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBack = getClass().getResourceAsStream("../../../resources/svg/left_arrow_2/left-arrow.svg");//
                    svgFileBack_Hover = getClass().getResourceAsStream("../../../resources/svg/left_arrow_2/left-arrow_dblue.svg");//
                    svgFileHome = getClass().getResourceAsStream("../../../resources/svg/home/home.svg");//
                    svgFileHome_Hover = getClass().getResourceAsStream("../../../resources/svg/home/home_dblue.svg");//
                    svgFileHome1 = getClass().getResourceAsStream("../../../resources/svg/home/home.svg");//
                    svgFileHome1_Hover = getClass().getResourceAsStream("../../../resources/svg/home/home_dblue.svg");//
                    svgFileRetry = getClass().getResourceAsStream("../../../resources/svg/refresh/refresh.svg");//
                    svgFileRetry_Hover = getClass().getResourceAsStream("../../../resources/svg/refresh/refresh_dblue.svg");//
                    svgFileRetry1 = getClass().getResourceAsStream("../../../resources/svg/refresh/refresh.svg");//
                    svgFileRetry1_Hover = getClass().getResourceAsStream("../../../resources/svg/refresh/refresh_dblue.svg");//
                    svgFilePause = getClass().getResourceAsStream("../../../resources/svg/pause/pause.svg");//
                    svgFilePause_Hover = getClass().getResourceAsStream("../../../resources/svg/pause/pause_dblue.svg");//
                    svgFileMenu = getClass().getResourceAsStream("../../../resources/svg/menu/menu.svg");//
                    svgFileMenu_Hover = getClass().getResourceAsStream("../../../resources/svg/menu/menu_dblue.svg");//

                    svgFilePlayer = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer2 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer3 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer4 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer5 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer6 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer7 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer8 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer9 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");

                    svgFilePlayer_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer2_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer3_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer4_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer5_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer6_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer7_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer8_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer9_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");

                    Group svgBack = loader.loadSvg(svgFileBack);
                    Group svgBack_Hover = loader.loadSvg(svgFileBack_Hover);
                    Group svgHome = loader.loadSvg(svgFileHome);
                    Group svgHome_Hover = loader.loadSvg(svgFileHome_Hover);
                    Group svgHome1 = loader.loadSvg(svgFileHome1);
                    Group svgHome1_Hover = loader.loadSvg(svgFileHome1_Hover);
                    Group svgRetry = loader.loadSvg(svgFileRetry);
                    Group svgRetry_Hover = loader.loadSvg(svgFileRetry_Hover);
                    Group svgRetry1 = loader.loadSvg(svgFileRetry1);
                    Group svgRetry1_Hover = loader.loadSvg(svgFileRetry1_Hover);
                    Group svgPause = loader.loadSvg(svgFilePause);
                    Group svgPause_Hover = loader.loadSvg(svgFilePause_Hover);
                    Group svgMenu = loader.loadSvg(svgFileMenu);
                    Group svgMenu_Hover = loader.loadSvg(svgFileMenu_Hover);

                    Group svgImagePlayer = loader.loadSvg(svgFilePlayer);
                    Group svgImagePlayer2 = loader.loadSvg(svgFilePlayer2);
                    Group svgImagePlayer3 = loader.loadSvg(svgFilePlayer3);
                    Group svgImagePlayer4 = loader.loadSvg(svgFilePlayer4);
                    Group svgImagePlayer5 = loader.loadSvg(svgFilePlayer5);
                    Group svgImagePlayer6 = loader.loadSvg(svgFilePlayer6);
                    Group svgImagePlayer7 = loader.loadSvg(svgFilePlayer7);
                    Group svgImagePlayer8 = loader.loadSvg(svgFilePlayer8);
                    Group svgImagePlayer9 = loader.loadSvg(svgFilePlayer9);
                    Group svgImagePlayer_Hover = loader.loadSvg(svgFilePlayer_Hover);
                    Group svgImagePlayer2_Hover = loader.loadSvg(svgFilePlayer2_Hover);
                    Group svgImagePlayer3_Hover = loader.loadSvg(svgFilePlayer3_Hover);
                    Group svgImagePlayer4_Hover = loader.loadSvg(svgFilePlayer4_Hover);
                    Group svgImagePlayer5_Hover = loader.loadSvg(svgFilePlayer5_Hover);
                    Group svgImagePlayer6_Hover = loader.loadSvg(svgFilePlayer6_Hover);
                    Group svgImagePlayer7_Hover = loader.loadSvg(svgFilePlayer7_Hover);
                    Group svgImagePlayer8_Hover = loader.loadSvg(svgFilePlayer8_Hover);
                    Group svgImagePlayer9_Hover = loader.loadSvg(svgFilePlayer9_Hover);

                    svgBack.setScaleX(.1);
                    svgBack.setScaleY(.1);
                    svgBack_Hover.setScaleX(.1);
                    svgBack_Hover.setScaleY(.1);
                    svgHome.setScaleX(.1);
                    svgHome.setScaleY(.1);
                    svgHome_Hover.setScaleX(.1);
                    svgHome_Hover.setScaleY(.1);
                    svgHome1.setScaleX(.1);
                    svgHome1.setScaleY(.1);
                    svgHome1_Hover.setScaleX(.1);
                    svgHome1_Hover.setScaleY(.1);
                    svgRetry.setScaleX(.1);
                    svgRetry.setScaleY(.1);
                    svgRetry_Hover.setScaleX(.1);
                    svgRetry_Hover.setScaleY(.1);
                    svgRetry1.setScaleX(.1);
                    svgRetry1.setScaleY(.1);
                    svgRetry1_Hover.setScaleX(.1);
                    svgRetry1_Hover.setScaleY(.1);
                    svgPause.setScaleX(.04);
                    svgPause.setScaleY(.04);
                    svgPause_Hover.setScaleX(.04);
                    svgPause_Hover.setScaleY(.04);
                    svgMenu.setScaleX(.04);
                    svgMenu.setScaleY(.04);
                    svgMenu_Hover.setScaleX(.04);
                    svgMenu_Hover.setScaleY(.04);

                    svgImagePlayer.setScaleX(.05);
                    svgImagePlayer.setScaleY(.05);

                    svgImagePlayer2.setScaleX(.05);
                    svgImagePlayer2.setScaleY(.05);

                    svgImagePlayer3.setScaleX(.05);
                    svgImagePlayer3.setScaleY(.05);

                    svgImagePlayer4.setScaleX(.05);
                    svgImagePlayer4.setScaleY(.05);

                    svgImagePlayer5.setScaleX(.05);
                    svgImagePlayer5.setScaleY(.05);

                    svgImagePlayer6.setScaleX(.05);
                    svgImagePlayer6.setScaleY(.05);

                    svgImagePlayer7.setScaleX(.05);
                    svgImagePlayer7.setScaleY(.05);

                    svgImagePlayer8.setScaleX(.05);
                    svgImagePlayer8.setScaleY(.05);

                    svgImagePlayer9.setScaleX(.05);
                    svgImagePlayer9.setScaleY(.05);

                    svgImagePlayer_Hover.setScaleX(.05);
                    svgImagePlayer_Hover.setScaleY(.05);

                    svgImagePlayer2_Hover.setScaleX(.05);
                    svgImagePlayer2_Hover.setScaleY(.05);

                    svgImagePlayer3_Hover.setScaleX(.05);
                    svgImagePlayer3_Hover.setScaleY(.05);

                    svgImagePlayer4_Hover.setScaleX(.05);
                    svgImagePlayer4_Hover.setScaleY(.05);

                    svgImagePlayer5_Hover.setScaleX(.05);
                    svgImagePlayer5_Hover.setScaleY(.05);

                    svgImagePlayer6_Hover.setScaleX(.05);
                    svgImagePlayer6_Hover.setScaleY(.05);

                    svgImagePlayer7_Hover.setScaleX(.05);
                    svgImagePlayer7_Hover.setScaleY(.05);

                    svgImagePlayer8_Hover.setScaleX(.05);
                    svgImagePlayer8_Hover.setScaleY(.05);

                    svgImagePlayer9_Hover.setScaleX(.05);
                    svgImagePlayer9_Hover.setScaleY(.05);

                    Group svgIconBack = new Group(svgBack);
                    Group svgIconBack_Hover = new Group(svgBack_Hover);
                    Group svgIconHome = new Group(svgHome);
                    Group svgIconHome_Hover = new Group(svgHome_Hover);
                    Group svgIconHome1 = new Group(svgHome1);
                    Group svgIconHome1_Hover = new Group(svgHome1_Hover);
                    Group svgIconRetry = new Group(svgRetry);
                    Group svgIconRetry_Hover = new Group(svgRetry_Hover);
                    Group svgIconRetry1 = new Group(svgRetry1);
                    Group svgIconRetry1_Hover = new Group(svgRetry1_Hover);
                    Group svgIconPause = new Group(svgPause);
                    Group svgIconPause_Hover = new Group(svgPause_Hover);
                    Group svgIconMenu = new Group(svgMenu);
                    Group svgIconMenu_Hover = new Group(svgMenu_Hover);

                    Group svgIconPlayer = new Group(svgImagePlayer);
                    Group svgIconPlayer2 = new Group(svgImagePlayer2);
                    Group svgIconPlayer3 = new Group(svgImagePlayer3);
                    Group svgIconPlayer4 = new Group(svgImagePlayer4);
                    Group svgIconPlayer5 = new Group(svgImagePlayer5);
                    Group svgIconPlayer6 = new Group(svgImagePlayer6);
                    Group svgIconPlayer7 = new Group(svgImagePlayer7);
                    Group svgIconPlayer8 = new Group(svgImagePlayer8);
                    Group svgIconPlayer9 = new Group(svgImagePlayer9);
                    Group svgIconPlayer_Hover = new Group(svgImagePlayer_Hover);
                    Group svgIconPlayer2_Hover = new Group(svgImagePlayer2_Hover);
                    Group svgIconPlayer3_Hover = new Group(svgImagePlayer3_Hover);
                    Group svgIconPlayer4_Hover = new Group(svgImagePlayer4_Hover);
                    Group svgIconPlayer5_Hover = new Group(svgImagePlayer5_Hover);
                    Group svgIconPlayer6_Hover = new Group(svgImagePlayer6_Hover);
                    Group svgIconPlayer7_Hover = new Group(svgImagePlayer7_Hover);
                    Group svgIconPlayer8_Hover = new Group(svgImagePlayer8_Hover);
                    Group svgIconPlayer9_Hover = new Group(svgImagePlayer9_Hover);

                    r3p1Icon.setGraphic(svgIconPlayer);
                    r3p2Icon.setGraphic(svgIconPlayer2);
                    r3p3Icon.setGraphic(svgIconPlayer3);
                    r3p4Icon.setGraphic(svgIconPlayer4);
                    r2p1Icon.setGraphic(svgIconPlayer5);
                    r2p2Icon.setGraphic(svgIconPlayer6);
                    r2p3Icon.setGraphic(svgIconPlayer7);
                    r1p1Icon.setGraphic(svgIconPlayer8);
                    r1p2Icon.setGraphic(svgIconPlayer9);

                    backButton.setGraphic(svgIconMenu);

                    b1.setGraphic(svgIconBack);
                    b2.setGraphic(svgIconRetry);
                    b3.setGraphic(svgIconHome);
                    b11.setGraphic(svgIconRetry1);
                    b21.setGraphic(svgIconHome1);
                    l4.setEffect(effectC_InnerShadow);
                    l3.setEffect(effectC_InnerShadow);

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        if (b111==0){

                            l1.setText("");
                            l2.setText("Pause");
                            backButton.setEffect(effectC_DropShadow);
                            backButton.setGraphic(svgIconPause_Hover);
                            backButton.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");

                        }
                        else {


                            backButton.setGraphic(svgIconPause);

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        if (b111==0){

                            l1.setText("Memory");
                            l2.setText("Game");
                            backButton.setEffect(null);
                            backButton.setGraphic(svgIconMenu);
                            backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                        }else {

                            backButton.setEffect(null);
                            backButton.setGraphic(svgIconPause);

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        if (b111==0){
                            b111=1;
                            grid2.setVisible(true);
                            grid2.setDisable(false);

                            fadeOut.play();
                            fadeOut5.play();
                            fadeOut5_1.play();

                            fadeIn3.play();
                            fadeIn5_3.play();

                            fadeIn7.play();
                            fadeIn7_1.play();
                            fadeIn7_2.play();

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        fadeIn.play();

                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        backButton.setGraphic(svgIconPause);

                    });

                    b1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b1.setTextFill(Color.web("#004fcb"));
                        b1.setEffect(effectC_DropShadow);
                        b1.setGraphic(svgIconBack_Hover);

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b1.setTextFill(Color.web("#c0c2c4"));
                        b1.setEffect(null);
                        b1.setGraphic(svgIconBack);

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {
                        b111=0;
                        fadeIn.play();
                        fadeIn5.play();
                        fadeIn5_1.play();

                        fadeOut3.play();
                        fadeOut5_3.play();

                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                        grid2.setDisable(true);
                        backButton.setGraphic(svgIconMenu);
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                    });

                    b2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b2.setTextFill(Color.web("#004fcb"));
                        b2.setEffect(effectC_DropShadow);
                        b2.setGraphic(svgIconRetry_Hover);

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b2.setTextFill(Color.web("#c0c2c4"));
                        b2.setEffect(null);
                        b2.setGraphic(svgIconRetry);

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut2.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_3.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            backClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b3.setTextFill(Color.web("#004fcb"));
                        b3.setEffect(effectC_DropShadow);
                        b3.setGraphic(svgIconHome_Hover);

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b3.setTextFill(Color.web("#c0c2c4"));
                        b3.setEffect(null);
                        b3.setGraphic(svgIconHome);

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut2.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_3.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            HomeClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b11.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b11.setTextFill(Color.web("#004fcb"));
                        b11.setEffect(effectC_DropShadow);
                        b11.setGraphic(svgIconRetry1_Hover);

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b11.setTextFill(Color.web("#c0c2c4"));
                        b11.setEffect(null);
                        b11.setGraphic(svgIconRetry1);

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_2.play();
                        fadeOut6.play();
                        fadeOut6_1.play();

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            backClicked2();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b21.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b21.setTextFill(Color.web("#004fcb"));
                        b21.setEffect(effectC_DropShadow);
                        b21.setGraphic(svgIconHome1_Hover);

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b21.setTextFill(Color.web("#c0c2c4"));
                        b21.setEffect(null);
                        b21.setGraphic(svgIconHome1);

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_2.play();
                        fadeOut6.play();
                        fadeOut6_1.play();

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            HomeClicked2();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                }
                else if (tColor==2) {

                    color2 = "#fff44f";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.web("#d9cf43"), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.web("#ffff5b"), 10, 0, -5, -5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.web("#d9cf43"), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.web("#ffff5b"), 10, 0, -5, -5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBack = getClass().getResourceAsStream("../../../resources/svg/left_arrow_2/left-arrow.svg");//
                    svgFileBack_Hover = getClass().getResourceAsStream("../../../resources/svg/left_arrow_2/left-arrow_dyellow.svg");//
                    svgFileHome = getClass().getResourceAsStream("../../../resources/svg/home/home.svg");//
                    svgFileHome_Hover = getClass().getResourceAsStream("../../../resources/svg/home/home_dyellow.svg");//
                    svgFileHome1 = getClass().getResourceAsStream("../../../resources/svg/home/home.svg");//
                    svgFileHome1_Hover = getClass().getResourceAsStream("../../../resources/svg/home/home_dyellow.svg");//
                    svgFileRetry = getClass().getResourceAsStream("../../../resources/svg/refresh/refresh.svg");//
                    svgFileRetry_Hover = getClass().getResourceAsStream("../../../resources/svg/refresh/refresh_dyellow.svg");//
                    svgFileRetry1 = getClass().getResourceAsStream("../../../resources/svg/refresh/refresh.svg");//
                    svgFileRetry1_Hover = getClass().getResourceAsStream("../../../resources/svg/refresh/refresh_dyellow.svg");//
                    svgFilePause = getClass().getResourceAsStream("../../../resources/svg/pause/pause.svg");//
                    svgFilePause_Hover = getClass().getResourceAsStream("../../../resources/svg/pause/pause_dyellow.svg");//
                    svgFileMenu = getClass().getResourceAsStream("../../../resources/svg/menu/menu.svg");//
                    svgFileMenu_Hover = getClass().getResourceAsStream("../../../resources/svg/menu/menu_dyellow.svg");//

                    svgFilePlayer = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer2 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer3 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer4 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer5 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer6 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer7 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer8 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer9 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");

                    svgFilePlayer_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_yellow.svg");
                    svgFilePlayer2_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_yellow.svg");
                    svgFilePlayer3_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_yellow.svg");
                    svgFilePlayer4_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_yellow.svg");
                    svgFilePlayer5_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_yellow.svg");
                    svgFilePlayer6_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_yellow.svg");
                    svgFilePlayer7_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_yellow.svg");
                    svgFilePlayer8_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_yellow.svg");
                    svgFilePlayer9_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_yellow.svg");

                    Group svgBack = loader.loadSvg(svgFileBack);
                    Group svgBack_Hover = loader.loadSvg(svgFileBack_Hover);
                    Group svgHome = loader.loadSvg(svgFileHome);
                    Group svgHome_Hover = loader.loadSvg(svgFileHome_Hover);
                    Group svgHome1 = loader.loadSvg(svgFileHome1);
                    Group svgHome1_Hover = loader.loadSvg(svgFileHome1_Hover);
                    Group svgRetry = loader.loadSvg(svgFileRetry);
                    Group svgRetry_Hover = loader.loadSvg(svgFileRetry_Hover);
                    Group svgRetry1 = loader.loadSvg(svgFileRetry1);
                    Group svgRetry1_Hover = loader.loadSvg(svgFileRetry1_Hover);
                    Group svgPause = loader.loadSvg(svgFilePause);
                    Group svgPause_Hover = loader.loadSvg(svgFilePause_Hover);
                    Group svgMenu = loader.loadSvg(svgFileMenu);
                    Group svgMenu_Hover = loader.loadSvg(svgFileMenu_Hover);

                    Group svgImagePlayer = loader.loadSvg(svgFilePlayer);
                    Group svgImagePlayer2 = loader.loadSvg(svgFilePlayer2);
                    Group svgImagePlayer3 = loader.loadSvg(svgFilePlayer3);
                    Group svgImagePlayer4 = loader.loadSvg(svgFilePlayer4);
                    Group svgImagePlayer5 = loader.loadSvg(svgFilePlayer5);
                    Group svgImagePlayer6 = loader.loadSvg(svgFilePlayer6);
                    Group svgImagePlayer7 = loader.loadSvg(svgFilePlayer7);
                    Group svgImagePlayer8 = loader.loadSvg(svgFilePlayer8);
                    Group svgImagePlayer9 = loader.loadSvg(svgFilePlayer9);
                    Group svgImagePlayer_Hover = loader.loadSvg(svgFilePlayer_Hover);
                    Group svgImagePlayer2_Hover = loader.loadSvg(svgFilePlayer2_Hover);
                    Group svgImagePlayer3_Hover = loader.loadSvg(svgFilePlayer3_Hover);
                    Group svgImagePlayer4_Hover = loader.loadSvg(svgFilePlayer4_Hover);
                    Group svgImagePlayer5_Hover = loader.loadSvg(svgFilePlayer5_Hover);
                    Group svgImagePlayer6_Hover = loader.loadSvg(svgFilePlayer6_Hover);
                    Group svgImagePlayer7_Hover = loader.loadSvg(svgFilePlayer7_Hover);
                    Group svgImagePlayer8_Hover = loader.loadSvg(svgFilePlayer8_Hover);
                    Group svgImagePlayer9_Hover = loader.loadSvg(svgFilePlayer9_Hover);

                    svgBack.setScaleX(.1);
                    svgBack.setScaleY(.1);
                    svgBack_Hover.setScaleX(.1);
                    svgBack_Hover.setScaleY(.1);
                    svgHome.setScaleX(.1);
                    svgHome.setScaleY(.1);
                    svgHome_Hover.setScaleX(.1);
                    svgHome_Hover.setScaleY(.1);
                    svgHome1.setScaleX(.1);
                    svgHome1.setScaleY(.1);
                    svgHome1_Hover.setScaleX(.1);
                    svgHome1_Hover.setScaleY(.1);
                    svgRetry.setScaleX(.1);
                    svgRetry.setScaleY(.1);
                    svgRetry_Hover.setScaleX(.1);
                    svgRetry_Hover.setScaleY(.1);
                    svgRetry1.setScaleX(.1);
                    svgRetry1.setScaleY(.1);
                    svgRetry1_Hover.setScaleX(.1);
                    svgRetry1_Hover.setScaleY(.1);
                    svgPause.setScaleX(.04);
                    svgPause.setScaleY(.04);
                    svgPause_Hover.setScaleX(.04);
                    svgPause_Hover.setScaleY(.04);
                    svgMenu.setScaleX(.04);
                    svgMenu.setScaleY(.04);
                    svgMenu_Hover.setScaleX(.04);
                    svgMenu_Hover.setScaleY(.04);

                    svgImagePlayer.setScaleX(.05);
                    svgImagePlayer.setScaleY(.05);

                    svgImagePlayer2.setScaleX(.05);
                    svgImagePlayer2.setScaleY(.05);

                    svgImagePlayer3.setScaleX(.05);
                    svgImagePlayer3.setScaleY(.05);

                    svgImagePlayer4.setScaleX(.05);
                    svgImagePlayer4.setScaleY(.05);

                    svgImagePlayer5.setScaleX(.05);
                    svgImagePlayer5.setScaleY(.05);

                    svgImagePlayer6.setScaleX(.05);
                    svgImagePlayer6.setScaleY(.05);

                    svgImagePlayer7.setScaleX(.05);
                    svgImagePlayer7.setScaleY(.05);

                    svgImagePlayer8.setScaleX(.05);
                    svgImagePlayer8.setScaleY(.05);

                    svgImagePlayer9.setScaleX(.05);
                    svgImagePlayer9.setScaleY(.05);

                    svgImagePlayer_Hover.setScaleX(.05);
                    svgImagePlayer_Hover.setScaleY(.05);

                    svgImagePlayer2_Hover.setScaleX(.05);
                    svgImagePlayer2_Hover.setScaleY(.05);

                    svgImagePlayer3_Hover.setScaleX(.05);
                    svgImagePlayer3_Hover.setScaleY(.05);

                    svgImagePlayer4_Hover.setScaleX(.05);
                    svgImagePlayer4_Hover.setScaleY(.05);

                    svgImagePlayer5_Hover.setScaleX(.05);
                    svgImagePlayer5_Hover.setScaleY(.05);

                    svgImagePlayer6_Hover.setScaleX(.05);
                    svgImagePlayer6_Hover.setScaleY(.05);

                    svgImagePlayer7_Hover.setScaleX(.05);
                    svgImagePlayer7_Hover.setScaleY(.05);

                    svgImagePlayer8_Hover.setScaleX(.05);
                    svgImagePlayer8_Hover.setScaleY(.05);

                    svgImagePlayer9_Hover.setScaleX(.05);
                    svgImagePlayer9_Hover.setScaleY(.05);

                    Group svgIconBack = new Group(svgBack);
                    Group svgIconBack_Hover = new Group(svgBack_Hover);
                    Group svgIconHome = new Group(svgHome);
                    Group svgIconHome_Hover = new Group(svgHome_Hover);
                    Group svgIconHome1 = new Group(svgHome1);
                    Group svgIconHome1_Hover = new Group(svgHome1_Hover);
                    Group svgIconRetry = new Group(svgRetry);
                    Group svgIconRetry_Hover = new Group(svgRetry_Hover);
                    Group svgIconRetry1 = new Group(svgRetry1);
                    Group svgIconRetry1_Hover = new Group(svgRetry1_Hover);
                    Group svgIconPause = new Group(svgPause);
                    Group svgIconPause_Hover = new Group(svgPause_Hover);
                    Group svgIconMenu = new Group(svgMenu);
                    Group svgIconMenu_Hover = new Group(svgMenu_Hover);

                    Group svgIconPlayer = new Group(svgImagePlayer);
                    Group svgIconPlayer2 = new Group(svgImagePlayer2);
                    Group svgIconPlayer3 = new Group(svgImagePlayer3);
                    Group svgIconPlayer4 = new Group(svgImagePlayer4);
                    Group svgIconPlayer5 = new Group(svgImagePlayer5);
                    Group svgIconPlayer6 = new Group(svgImagePlayer6);
                    Group svgIconPlayer7 = new Group(svgImagePlayer7);
                    Group svgIconPlayer8 = new Group(svgImagePlayer8);
                    Group svgIconPlayer9 = new Group(svgImagePlayer9);
                    Group svgIconPlayer_Hover = new Group(svgImagePlayer_Hover);
                    Group svgIconPlayer2_Hover = new Group(svgImagePlayer2_Hover);
                    Group svgIconPlayer3_Hover = new Group(svgImagePlayer3_Hover);
                    Group svgIconPlayer4_Hover = new Group(svgImagePlayer4_Hover);
                    Group svgIconPlayer5_Hover = new Group(svgImagePlayer5_Hover);
                    Group svgIconPlayer6_Hover = new Group(svgImagePlayer6_Hover);
                    Group svgIconPlayer7_Hover = new Group(svgImagePlayer7_Hover);
                    Group svgIconPlayer8_Hover = new Group(svgImagePlayer8_Hover);
                    Group svgIconPlayer9_Hover = new Group(svgImagePlayer9_Hover);

                    r3p1Icon.setGraphic(svgIconPlayer);
                    r3p2Icon.setGraphic(svgIconPlayer2);
                    r3p3Icon.setGraphic(svgIconPlayer3);
                    r3p4Icon.setGraphic(svgIconPlayer4);
                    r2p1Icon.setGraphic(svgIconPlayer5);
                    r2p2Icon.setGraphic(svgIconPlayer6);
                    r2p3Icon.setGraphic(svgIconPlayer7);
                    r1p1Icon.setGraphic(svgIconPlayer8);
                    r1p2Icon.setGraphic(svgIconPlayer9);

                    backButton.setGraphic(svgIconMenu);

                    b1.setGraphic(svgIconBack);
                    b2.setGraphic(svgIconRetry);
                    b3.setGraphic(svgIconHome);
                    b11.setGraphic(svgIconRetry1);
                    b21.setGraphic(svgIconHome1);
                    l4.setEffect(effectC_InnerShadow);
                    l3.setEffect(effectC_InnerShadow);

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        if (b111==0){

                            l1.setText("");
                            l2.setText("Pause");
                            backButton.setEffect(effectC_DropShadow);
                            backButton.setGraphic(svgIconPause_Hover);
                            backButton.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");

                        }
                        else {


                            backButton.setGraphic(svgIconPause);

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        if (b111==0){

                            l1.setText("Memory");
                            l2.setText("Game");
                            backButton.setEffect(null);
                            backButton.setGraphic(svgIconMenu);
                            backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                        }else {

                            backButton.setEffect(null);
                            backButton.setGraphic(svgIconPause);

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        if (b111==0){
                            b111=1;
                            grid2.setVisible(true);
                            grid2.setDisable(false);

                            fadeOut.play();
                            fadeOut5.play();
                            fadeOut5_1.play();

                            fadeIn3.play();
                            fadeIn5_3.play();

                            fadeIn7.play();
                            fadeIn7_1.play();
                            fadeIn7_2.play();

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        fadeIn.play();

                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        backButton.setGraphic(svgIconPause);

                    });

                    b1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b1.setTextFill(Color.web("#c9c208"));
                        b1.setEffect(effectC_DropShadow);
                        b1.setGraphic(svgIconBack_Hover);

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b1.setTextFill(Color.web("#c0c2c4"));
                        b1.setEffect(null);
                        b1.setGraphic(svgIconBack);

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {
                        b111=0;
                        fadeIn.play();
                        fadeIn5.play();
                        fadeIn5_1.play();

                        fadeOut3.play();
                        fadeOut5_3.play();

                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                        grid2.setDisable(true);
                        backButton.setGraphic(svgIconMenu);
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                    });

                    b2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b2.setTextFill(Color.web("#c9c208"));
                        b2.setEffect(effectC_DropShadow);
                        b2.setGraphic(svgIconRetry_Hover);

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b2.setTextFill(Color.web("#c0c2c4"));
                        b2.setEffect(null);
                        b2.setGraphic(svgIconRetry);

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut2.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_3.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            backClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b3.setTextFill(Color.web("#c9c208"));
                        b3.setEffect(effectC_DropShadow);
                        b3.setGraphic(svgIconHome_Hover);

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b3.setTextFill(Color.web("#c0c2c4"));
                        b3.setEffect(null);
                        b3.setGraphic(svgIconHome);

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut2.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_3.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            HomeClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b11.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b11.setTextFill(Color.web("#c9c208"));
                        b11.setEffect(effectC_DropShadow);
                        b11.setGraphic(svgIconRetry1_Hover);

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b11.setTextFill(Color.web("#c0c2c4"));
                        b11.setEffect(null);
                        b11.setGraphic(svgIconRetry1);

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_2.play();
                        fadeOut6.play();
                        fadeOut6_1.play();

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            backClicked2();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b21.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b21.setTextFill(Color.web("#c9c208"));
                        b21.setEffect(effectC_DropShadow);
                        b21.setGraphic(svgIconHome1_Hover);

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b21.setTextFill(Color.web("#c0c2c4"));
                        b21.setEffect(null);
                        b21.setGraphic(svgIconHome1);

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_2.play();
                        fadeOut6.play();
                        fadeOut6_1.play();

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            HomeClicked2();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                }
                else if (tColor==3) {

                    color2 = "#00c853";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,200,83), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,230,95), 10, 0, -5, -5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,200,83), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,230,95), 10, 0, -5, -5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBack = getClass().getResourceAsStream("../../../resources/svg/left_arrow_2/left-arrow.svg");//
                    svgFileBack_Hover = getClass().getResourceAsStream("../../../resources/svg/left_arrow_2/left-arrow_dgreen.svg");//
                    svgFileHome = getClass().getResourceAsStream("../../../resources/svg/home/home.svg");//
                    svgFileHome_Hover = getClass().getResourceAsStream("../../../resources/svg/home/home_dgreen.svg");//
                    svgFileHome1 = getClass().getResourceAsStream("../../../resources/svg/home/home.svg");//
                    svgFileHome1_Hover = getClass().getResourceAsStream("../../../resources/svg/home/home_dgreen.svg");//
                    svgFileRetry = getClass().getResourceAsStream("../../../resources/svg/refresh/refresh.svg");//
                    svgFileRetry_Hover = getClass().getResourceAsStream("../../../resources/svg/refresh/refresh_dgreen.svg");//
                    svgFileRetry1 = getClass().getResourceAsStream("../../../resources/svg/refresh/refresh.svg");//
                    svgFileRetry1_Hover = getClass().getResourceAsStream("../../../resources/svg/refresh/refresh_dgreen.svg");//
                    svgFilePause = getClass().getResourceAsStream("../../../resources/svg/pause/pause.svg");//
                    svgFilePause_Hover = getClass().getResourceAsStream("../../../resources/svg/pause/pause_dgreen.svg");//
                    svgFileMenu = getClass().getResourceAsStream("../../../resources/svg/menu/menu.svg");//
                    svgFileMenu_Hover = getClass().getResourceAsStream("../../../resources/svg/menu/menu_dgreen.svg");//

                    svgFilePlayer = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer2 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer3 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer4 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer5 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer6 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer7 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer8 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer9 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");

                    svgFilePlayer_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_green.svg");
                    svgFilePlayer2_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_green.svg");
                    svgFilePlayer3_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_green.svg");
                    svgFilePlayer4_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_green.svg");
                    svgFilePlayer5_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_green.svg");
                    svgFilePlayer6_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_green.svg");
                    svgFilePlayer7_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_green.svg");
                    svgFilePlayer8_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_green.svg");
                    svgFilePlayer9_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_green.svg");

                    Group svgBack = loader.loadSvg(svgFileBack);
                    Group svgBack_Hover = loader.loadSvg(svgFileBack_Hover);
                    Group svgHome = loader.loadSvg(svgFileHome);
                    Group svgHome_Hover = loader.loadSvg(svgFileHome_Hover);
                    Group svgHome1 = loader.loadSvg(svgFileHome1);
                    Group svgHome1_Hover = loader.loadSvg(svgFileHome1_Hover);
                    Group svgRetry = loader.loadSvg(svgFileRetry);
                    Group svgRetry_Hover = loader.loadSvg(svgFileRetry_Hover);
                    Group svgRetry1 = loader.loadSvg(svgFileRetry1);
                    Group svgRetry1_Hover = loader.loadSvg(svgFileRetry1_Hover);
                    Group svgPause = loader.loadSvg(svgFilePause);
                    Group svgPause_Hover = loader.loadSvg(svgFilePause_Hover);
                    Group svgMenu = loader.loadSvg(svgFileMenu);
                    Group svgMenu_Hover = loader.loadSvg(svgFileMenu_Hover);

                    Group svgImagePlayer = loader.loadSvg(svgFilePlayer);
                    Group svgImagePlayer2 = loader.loadSvg(svgFilePlayer2);
                    Group svgImagePlayer3 = loader.loadSvg(svgFilePlayer3);
                    Group svgImagePlayer4 = loader.loadSvg(svgFilePlayer4);
                    Group svgImagePlayer5 = loader.loadSvg(svgFilePlayer5);
                    Group svgImagePlayer6 = loader.loadSvg(svgFilePlayer6);
                    Group svgImagePlayer7 = loader.loadSvg(svgFilePlayer7);
                    Group svgImagePlayer8 = loader.loadSvg(svgFilePlayer8);
                    Group svgImagePlayer9 = loader.loadSvg(svgFilePlayer9);
                    Group svgImagePlayer_Hover = loader.loadSvg(svgFilePlayer_Hover);
                    Group svgImagePlayer2_Hover = loader.loadSvg(svgFilePlayer2_Hover);
                    Group svgImagePlayer3_Hover = loader.loadSvg(svgFilePlayer3_Hover);
                    Group svgImagePlayer4_Hover = loader.loadSvg(svgFilePlayer4_Hover);
                    Group svgImagePlayer5_Hover = loader.loadSvg(svgFilePlayer5_Hover);
                    Group svgImagePlayer6_Hover = loader.loadSvg(svgFilePlayer6_Hover);
                    Group svgImagePlayer7_Hover = loader.loadSvg(svgFilePlayer7_Hover);
                    Group svgImagePlayer8_Hover = loader.loadSvg(svgFilePlayer8_Hover);
                    Group svgImagePlayer9_Hover = loader.loadSvg(svgFilePlayer9_Hover);

                    svgBack.setScaleX(.1);
                    svgBack.setScaleY(.1);
                    svgBack_Hover.setScaleX(.1);
                    svgBack_Hover.setScaleY(.1);
                    svgHome.setScaleX(.1);
                    svgHome.setScaleY(.1);
                    svgHome_Hover.setScaleX(.1);
                    svgHome_Hover.setScaleY(.1);
                    svgHome1.setScaleX(.1);
                    svgHome1.setScaleY(.1);
                    svgHome1_Hover.setScaleX(.1);
                    svgHome1_Hover.setScaleY(.1);
                    svgRetry.setScaleX(.1);
                    svgRetry.setScaleY(.1);
                    svgRetry_Hover.setScaleX(.1);
                    svgRetry_Hover.setScaleY(.1);
                    svgRetry1.setScaleX(.1);
                    svgRetry1.setScaleY(.1);
                    svgRetry1_Hover.setScaleX(.1);
                    svgRetry1_Hover.setScaleY(.1);
                    svgPause.setScaleX(.04);
                    svgPause.setScaleY(.04);
                    svgPause_Hover.setScaleX(.04);
                    svgPause_Hover.setScaleY(.04);
                    svgMenu.setScaleX(.04);
                    svgMenu.setScaleY(.04);
                    svgMenu_Hover.setScaleX(.04);
                    svgMenu_Hover.setScaleY(.04);

                    svgImagePlayer.setScaleX(.05);
                    svgImagePlayer.setScaleY(.05);

                    svgImagePlayer2.setScaleX(.05);
                    svgImagePlayer2.setScaleY(.05);

                    svgImagePlayer3.setScaleX(.05);
                    svgImagePlayer3.setScaleY(.05);

                    svgImagePlayer4.setScaleX(.05);
                    svgImagePlayer4.setScaleY(.05);

                    svgImagePlayer5.setScaleX(.05);
                    svgImagePlayer5.setScaleY(.05);

                    svgImagePlayer6.setScaleX(.05);
                    svgImagePlayer6.setScaleY(.05);

                    svgImagePlayer7.setScaleX(.05);
                    svgImagePlayer7.setScaleY(.05);

                    svgImagePlayer8.setScaleX(.05);
                    svgImagePlayer8.setScaleY(.05);

                    svgImagePlayer9.setScaleX(.05);
                    svgImagePlayer9.setScaleY(.05);

                    svgImagePlayer_Hover.setScaleX(.05);
                    svgImagePlayer_Hover.setScaleY(.05);

                    svgImagePlayer2_Hover.setScaleX(.05);
                    svgImagePlayer2_Hover.setScaleY(.05);

                    svgImagePlayer3_Hover.setScaleX(.05);
                    svgImagePlayer3_Hover.setScaleY(.05);

                    svgImagePlayer4_Hover.setScaleX(.05);
                    svgImagePlayer4_Hover.setScaleY(.05);

                    svgImagePlayer5_Hover.setScaleX(.05);
                    svgImagePlayer5_Hover.setScaleY(.05);

                    svgImagePlayer6_Hover.setScaleX(.05);
                    svgImagePlayer6_Hover.setScaleY(.05);

                    svgImagePlayer7_Hover.setScaleX(.05);
                    svgImagePlayer7_Hover.setScaleY(.05);

                    svgImagePlayer8_Hover.setScaleX(.05);
                    svgImagePlayer8_Hover.setScaleY(.05);

                    svgImagePlayer9_Hover.setScaleX(.05);
                    svgImagePlayer9_Hover.setScaleY(.05);

                    Group svgIconBack = new Group(svgBack);
                    Group svgIconBack_Hover = new Group(svgBack_Hover);
                    Group svgIconHome = new Group(svgHome);
                    Group svgIconHome_Hover = new Group(svgHome_Hover);
                    Group svgIconHome1 = new Group(svgHome1);
                    Group svgIconHome1_Hover = new Group(svgHome1_Hover);
                    Group svgIconRetry = new Group(svgRetry);
                    Group svgIconRetry_Hover = new Group(svgRetry_Hover);
                    Group svgIconRetry1 = new Group(svgRetry1);
                    Group svgIconRetry1_Hover = new Group(svgRetry1_Hover);
                    Group svgIconPause = new Group(svgPause);
                    Group svgIconPause_Hover = new Group(svgPause_Hover);
                    Group svgIconMenu = new Group(svgMenu);
                    Group svgIconMenu_Hover = new Group(svgMenu_Hover);

                    Group svgIconPlayer = new Group(svgImagePlayer);
                    Group svgIconPlayer2 = new Group(svgImagePlayer2);
                    Group svgIconPlayer3 = new Group(svgImagePlayer3);
                    Group svgIconPlayer4 = new Group(svgImagePlayer4);
                    Group svgIconPlayer5 = new Group(svgImagePlayer5);
                    Group svgIconPlayer6 = new Group(svgImagePlayer6);
                    Group svgIconPlayer7 = new Group(svgImagePlayer7);
                    Group svgIconPlayer8 = new Group(svgImagePlayer8);
                    Group svgIconPlayer9 = new Group(svgImagePlayer9);
                    Group svgIconPlayer_Hover = new Group(svgImagePlayer_Hover);
                    Group svgIconPlayer2_Hover = new Group(svgImagePlayer2_Hover);
                    Group svgIconPlayer3_Hover = new Group(svgImagePlayer3_Hover);
                    Group svgIconPlayer4_Hover = new Group(svgImagePlayer4_Hover);
                    Group svgIconPlayer5_Hover = new Group(svgImagePlayer5_Hover);
                    Group svgIconPlayer6_Hover = new Group(svgImagePlayer6_Hover);
                    Group svgIconPlayer7_Hover = new Group(svgImagePlayer7_Hover);
                    Group svgIconPlayer8_Hover = new Group(svgImagePlayer8_Hover);
                    Group svgIconPlayer9_Hover = new Group(svgImagePlayer9_Hover);

                    r3p1Icon.setGraphic(svgIconPlayer);
                    r3p2Icon.setGraphic(svgIconPlayer2);
                    r3p3Icon.setGraphic(svgIconPlayer3);
                    r3p4Icon.setGraphic(svgIconPlayer4);
                    r2p1Icon.setGraphic(svgIconPlayer5);
                    r2p2Icon.setGraphic(svgIconPlayer6);
                    r2p3Icon.setGraphic(svgIconPlayer7);
                    r1p1Icon.setGraphic(svgIconPlayer8);
                    r1p2Icon.setGraphic(svgIconPlayer9);

                    backButton.setGraphic(svgIconMenu);

                    b1.setGraphic(svgIconBack);
                    b2.setGraphic(svgIconRetry);
                    b3.setGraphic(svgIconHome);
                    b11.setGraphic(svgIconRetry1);
                    b21.setGraphic(svgIconHome1);
                    l4.setEffect(effectC_InnerShadow);
                    l3.setEffect(effectC_InnerShadow);

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        if (b111==0){

                            l1.setText("");
                            l2.setText("Pause");
                            backButton.setEffect(effectC_DropShadow);
                            backButton.setGraphic(svgIconPause_Hover);
                            backButton.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");

                        }
                        else {


                            backButton.setGraphic(svgIconPause);

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        if (b111==0){

                            l1.setText("Memory");
                            l2.setText("Game");
                            backButton.setEffect(null);
                            backButton.setGraphic(svgIconMenu);
                            backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                        }else {

                            backButton.setEffect(null);
                            backButton.setGraphic(svgIconPause);

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        if (b111==0){
                            b111=1;
                            grid2.setVisible(true);
                            grid2.setDisable(false);

                            fadeOut.play();
                            fadeOut5.play();
                            fadeOut5_1.play();

                            fadeIn3.play();
                            fadeIn5_3.play();

                            fadeIn7.play();
                            fadeIn7_1.play();
                            fadeIn7_2.play();

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        fadeIn.play();

                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        backButton.setGraphic(svgIconPause);

                    });

                    b1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b1.setTextFill(Color.web("#006500"));
                        b1.setEffect(effectC_DropShadow);
                        b1.setGraphic(svgIconBack_Hover);

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b1.setTextFill(Color.web("#c0c2c4"));
                        b1.setEffect(null);
                        b1.setGraphic(svgIconBack);

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {
                        b111=0;
                        fadeIn.play();
                        fadeIn5.play();
                        fadeIn5_1.play();

                        fadeOut3.play();
                        fadeOut5_3.play();

                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                        grid2.setDisable(true);
                        backButton.setGraphic(svgIconMenu);
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                    });

                    b2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b2.setTextFill(Color.web("#006500"));
                        b2.setEffect(effectC_DropShadow);
                        b2.setGraphic(svgIconRetry_Hover);

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b2.setTextFill(Color.web("#c0c2c4"));
                        b2.setEffect(null);
                        b2.setGraphic(svgIconRetry);

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut2.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_3.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            backClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b3.setTextFill(Color.web("#006500"));
                        b3.setEffect(effectC_DropShadow);
                        b3.setGraphic(svgIconHome_Hover);

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b3.setTextFill(Color.web("#c0c2c4"));
                        b3.setEffect(null);
                        b3.setGraphic(svgIconHome);

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut2.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_3.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            HomeClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b11.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b11.setTextFill(Color.web("#006500"));
                        b11.setEffect(effectC_DropShadow);
                        b11.setGraphic(svgIconRetry1_Hover);

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b11.setTextFill(Color.web("#c0c2c4"));
                        b11.setEffect(null);
                        b11.setGraphic(svgIconRetry1);

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_2.play();
                        fadeOut6.play();
                        fadeOut6_1.play();

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            backClicked2();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b21.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b21.setTextFill(Color.web("#006500"));
                        b21.setEffect(effectC_DropShadow);
                        b21.setGraphic(svgIconHome1_Hover);

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b21.setTextFill(Color.web("#c0c2c4"));
                        b21.setEffect(null);
                        b21.setGraphic(svgIconHome1);

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_2.play();
                        fadeOut6.play();
                        fadeOut6_1.play();

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            HomeClicked2();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                }
                else if (tColor==4) {

                    color2 = "#d50000";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(181,0,0), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(245,0,0), 10, 0, -5, -5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(181,0,0), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(245,0,0), 10, 0, -5, -5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBack = getClass().getResourceAsStream("../../../resources/svg/left_arrow_2/left-arrow.svg");//
                    svgFileBack_Hover = getClass().getResourceAsStream("../../../resources/svg/left_arrow_2/left-arrow_dred.svg");//
                    svgFileHome = getClass().getResourceAsStream("../../../resources/svg/home/home.svg");//
                    svgFileHome_Hover = getClass().getResourceAsStream("../../../resources/svg/home/home_dred.svg");//
                    svgFileHome1 = getClass().getResourceAsStream("../../../resources/svg/home/home.svg");//
                    svgFileHome1_Hover = getClass().getResourceAsStream("../../../resources/svg/home/home_dred.svg");//
                    svgFileRetry = getClass().getResourceAsStream("../../../resources/svg/refresh/refresh.svg");//
                    svgFileRetry_Hover = getClass().getResourceAsStream("../../../resources/svg/refresh/refresh_dred.svg");//
                    svgFileRetry1 = getClass().getResourceAsStream("../../../resources/svg/refresh/refresh.svg");//
                    svgFileRetry1_Hover = getClass().getResourceAsStream("../../../resources/svg/refresh/refresh_dred.svg");//
                    svgFilePause = getClass().getResourceAsStream("../../../resources/svg/pause/pause.svg");//
                    svgFilePause_Hover = getClass().getResourceAsStream("../../../resources/svg/pause/pause_dred.svg");//
                    svgFileMenu = getClass().getResourceAsStream("../../../resources/svg/menu/menu.svg");//
                    svgFileMenu_Hover = getClass().getResourceAsStream("../../../resources/svg/menu/menu_dred.svg");//

                    svgFilePlayer = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer2 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer3 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer4 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer5 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer6 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer7 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer8 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer9 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");

                    svgFilePlayer_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_red.svg");
                    svgFilePlayer2_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_red.svg");
                    svgFilePlayer3_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_red.svg");
                    svgFilePlayer4_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_red.svg");
                    svgFilePlayer5_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_red.svg");
                    svgFilePlayer6_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_red.svg");
                    svgFilePlayer7_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_red.svg");
                    svgFilePlayer8_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_red.svg");
                    svgFilePlayer9_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_red.svg");

                    Group svgBack = loader.loadSvg(svgFileBack);
                    Group svgBack_Hover = loader.loadSvg(svgFileBack_Hover);
                    Group svgHome = loader.loadSvg(svgFileHome);
                    Group svgHome_Hover = loader.loadSvg(svgFileHome_Hover);
                    Group svgHome1 = loader.loadSvg(svgFileHome1);
                    Group svgHome1_Hover = loader.loadSvg(svgFileHome1_Hover);
                    Group svgRetry = loader.loadSvg(svgFileRetry);
                    Group svgRetry_Hover = loader.loadSvg(svgFileRetry_Hover);
                    Group svgRetry1 = loader.loadSvg(svgFileRetry1);
                    Group svgRetry1_Hover = loader.loadSvg(svgFileRetry1_Hover);
                    Group svgPause = loader.loadSvg(svgFilePause);
                    Group svgPause_Hover = loader.loadSvg(svgFilePause_Hover);
                    Group svgMenu = loader.loadSvg(svgFileMenu);
                    Group svgMenu_Hover = loader.loadSvg(svgFileMenu_Hover);

                    Group svgImagePlayer = loader.loadSvg(svgFilePlayer);
                    Group svgImagePlayer2 = loader.loadSvg(svgFilePlayer2);
                    Group svgImagePlayer3 = loader.loadSvg(svgFilePlayer3);
                    Group svgImagePlayer4 = loader.loadSvg(svgFilePlayer4);
                    Group svgImagePlayer5 = loader.loadSvg(svgFilePlayer5);
                    Group svgImagePlayer6 = loader.loadSvg(svgFilePlayer6);
                    Group svgImagePlayer7 = loader.loadSvg(svgFilePlayer7);
                    Group svgImagePlayer8 = loader.loadSvg(svgFilePlayer8);
                    Group svgImagePlayer9 = loader.loadSvg(svgFilePlayer9);
                    Group svgImagePlayer_Hover = loader.loadSvg(svgFilePlayer_Hover);
                    Group svgImagePlayer2_Hover = loader.loadSvg(svgFilePlayer2_Hover);
                    Group svgImagePlayer3_Hover = loader.loadSvg(svgFilePlayer3_Hover);
                    Group svgImagePlayer4_Hover = loader.loadSvg(svgFilePlayer4_Hover);
                    Group svgImagePlayer5_Hover = loader.loadSvg(svgFilePlayer5_Hover);
                    Group svgImagePlayer6_Hover = loader.loadSvg(svgFilePlayer6_Hover);
                    Group svgImagePlayer7_Hover = loader.loadSvg(svgFilePlayer7_Hover);
                    Group svgImagePlayer8_Hover = loader.loadSvg(svgFilePlayer8_Hover);
                    Group svgImagePlayer9_Hover = loader.loadSvg(svgFilePlayer9_Hover);

                    svgBack.setScaleX(.1);
                    svgBack.setScaleY(.1);
                    svgBack_Hover.setScaleX(.1);
                    svgBack_Hover.setScaleY(.1);
                    svgHome.setScaleX(.1);
                    svgHome.setScaleY(.1);
                    svgHome_Hover.setScaleX(.1);
                    svgHome_Hover.setScaleY(.1);
                    svgHome1.setScaleX(.1);
                    svgHome1.setScaleY(.1);
                    svgHome1_Hover.setScaleX(.1);
                    svgHome1_Hover.setScaleY(.1);
                    svgRetry.setScaleX(.1);
                    svgRetry.setScaleY(.1);
                    svgRetry_Hover.setScaleX(.1);
                    svgRetry_Hover.setScaleY(.1);
                    svgRetry1.setScaleX(.1);
                    svgRetry1.setScaleY(.1);
                    svgRetry1_Hover.setScaleX(.1);
                    svgRetry1_Hover.setScaleY(.1);
                    svgPause.setScaleX(.04);
                    svgPause.setScaleY(.04);
                    svgPause_Hover.setScaleX(.04);
                    svgPause_Hover.setScaleY(.04);
                    svgMenu.setScaleX(.04);
                    svgMenu.setScaleY(.04);
                    svgMenu_Hover.setScaleX(.04);
                    svgMenu_Hover.setScaleY(.04);

                    svgImagePlayer.setScaleX(.05);
                    svgImagePlayer.setScaleY(.05);

                    svgImagePlayer2.setScaleX(.05);
                    svgImagePlayer2.setScaleY(.05);

                    svgImagePlayer3.setScaleX(.05);
                    svgImagePlayer3.setScaleY(.05);

                    svgImagePlayer4.setScaleX(.05);
                    svgImagePlayer4.setScaleY(.05);

                    svgImagePlayer5.setScaleX(.05);
                    svgImagePlayer5.setScaleY(.05);

                    svgImagePlayer6.setScaleX(.05);
                    svgImagePlayer6.setScaleY(.05);

                    svgImagePlayer7.setScaleX(.05);
                    svgImagePlayer7.setScaleY(.05);

                    svgImagePlayer8.setScaleX(.05);
                    svgImagePlayer8.setScaleY(.05);

                    svgImagePlayer9.setScaleX(.05);
                    svgImagePlayer9.setScaleY(.05);

                    svgImagePlayer_Hover.setScaleX(.05);
                    svgImagePlayer_Hover.setScaleY(.05);

                    svgImagePlayer2_Hover.setScaleX(.05);
                    svgImagePlayer2_Hover.setScaleY(.05);

                    svgImagePlayer3_Hover.setScaleX(.05);
                    svgImagePlayer3_Hover.setScaleY(.05);

                    svgImagePlayer4_Hover.setScaleX(.05);
                    svgImagePlayer4_Hover.setScaleY(.05);

                    svgImagePlayer5_Hover.setScaleX(.05);
                    svgImagePlayer5_Hover.setScaleY(.05);

                    svgImagePlayer6_Hover.setScaleX(.05);
                    svgImagePlayer6_Hover.setScaleY(.05);

                    svgImagePlayer7_Hover.setScaleX(.05);
                    svgImagePlayer7_Hover.setScaleY(.05);

                    svgImagePlayer8_Hover.setScaleX(.05);
                    svgImagePlayer8_Hover.setScaleY(.05);

                    svgImagePlayer9_Hover.setScaleX(.05);
                    svgImagePlayer9_Hover.setScaleY(.05);

                    Group svgIconBack = new Group(svgBack);
                    Group svgIconBack_Hover = new Group(svgBack_Hover);
                    Group svgIconHome = new Group(svgHome);
                    Group svgIconHome_Hover = new Group(svgHome_Hover);
                    Group svgIconHome1 = new Group(svgHome1);
                    Group svgIconHome1_Hover = new Group(svgHome1_Hover);
                    Group svgIconRetry = new Group(svgRetry);
                    Group svgIconRetry_Hover = new Group(svgRetry_Hover);
                    Group svgIconRetry1 = new Group(svgRetry1);
                    Group svgIconRetry1_Hover = new Group(svgRetry1_Hover);
                    Group svgIconPause = new Group(svgPause);
                    Group svgIconPause_Hover = new Group(svgPause_Hover);
                    Group svgIconMenu = new Group(svgMenu);
                    Group svgIconMenu_Hover = new Group(svgMenu_Hover);

                    Group svgIconPlayer = new Group(svgImagePlayer);
                    Group svgIconPlayer2 = new Group(svgImagePlayer2);
                    Group svgIconPlayer3 = new Group(svgImagePlayer3);
                    Group svgIconPlayer4 = new Group(svgImagePlayer4);
                    Group svgIconPlayer5 = new Group(svgImagePlayer5);
                    Group svgIconPlayer6 = new Group(svgImagePlayer6);
                    Group svgIconPlayer7 = new Group(svgImagePlayer7);
                    Group svgIconPlayer8 = new Group(svgImagePlayer8);
                    Group svgIconPlayer9 = new Group(svgImagePlayer9);
                    Group svgIconPlayer_Hover = new Group(svgImagePlayer_Hover);
                    Group svgIconPlayer2_Hover = new Group(svgImagePlayer2_Hover);
                    Group svgIconPlayer3_Hover = new Group(svgImagePlayer3_Hover);
                    Group svgIconPlayer4_Hover = new Group(svgImagePlayer4_Hover);
                    Group svgIconPlayer5_Hover = new Group(svgImagePlayer5_Hover);
                    Group svgIconPlayer6_Hover = new Group(svgImagePlayer6_Hover);
                    Group svgIconPlayer7_Hover = new Group(svgImagePlayer7_Hover);
                    Group svgIconPlayer8_Hover = new Group(svgImagePlayer8_Hover);
                    Group svgIconPlayer9_Hover = new Group(svgImagePlayer9_Hover);

                    r3p1Icon.setGraphic(svgIconPlayer);
                    r3p2Icon.setGraphic(svgIconPlayer2);
                    r3p3Icon.setGraphic(svgIconPlayer3);
                    r3p4Icon.setGraphic(svgIconPlayer4);
                    r2p1Icon.setGraphic(svgIconPlayer5);
                    r2p2Icon.setGraphic(svgIconPlayer6);
                    r2p3Icon.setGraphic(svgIconPlayer7);
                    r1p1Icon.setGraphic(svgIconPlayer8);
                    r1p2Icon.setGraphic(svgIconPlayer9);

                    backButton.setGraphic(svgIconMenu);

                    b1.setGraphic(svgIconBack);
                    b2.setGraphic(svgIconRetry);
                    b3.setGraphic(svgIconHome);
                    b11.setGraphic(svgIconRetry1);
                    b21.setGraphic(svgIconHome1);
                    l4.setEffect(effectC_InnerShadow);
                    l3.setEffect(effectC_InnerShadow);

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        if (b111==0){

                            l1.setText("");
                            l2.setText("Pause");
                            backButton.setEffect(effectC_DropShadow);
                            backButton.setGraphic(svgIconPause_Hover);
                            backButton.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");

                        }
                        else {


                            backButton.setGraphic(svgIconPause);

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        if (b111==0){

                            l1.setText("Memory");
                            l2.setText("Game");
                            backButton.setEffect(null);
                            backButton.setGraphic(svgIconMenu);
                            backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                        }else {

                            backButton.setEffect(null);
                            backButton.setGraphic(svgIconPause);

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        if (b111==0){
                            b111=1;
                            grid2.setVisible(true);
                            grid2.setDisable(false);

                            fadeOut.play();
                            fadeOut5.play();
                            fadeOut5_1.play();

                            fadeIn3.play();
                            fadeIn5_3.play();

                            fadeIn7.play();
                            fadeIn7_1.play();
                            fadeIn7_2.play();

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        fadeIn.play();

                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        backButton.setGraphic(svgIconPause);

                    });

                    b1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b1.setTextFill(Color.web("#9b0000"));
                        b1.setEffect(effectC_DropShadow);
                        b1.setGraphic(svgIconBack_Hover);

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b1.setTextFill(Color.web("#c0c2c4"));
                        b1.setEffect(null);
                        b1.setGraphic(svgIconBack);

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {
                        b111=0;
                        fadeIn.play();
                        fadeIn5.play();
                        fadeIn5_1.play();

                        fadeOut3.play();
                        fadeOut5_3.play();

                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                        grid2.setDisable(true);
                        backButton.setGraphic(svgIconMenu);
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                    });

                    b2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b2.setTextFill(Color.web("#9b0000"));
                        b2.setEffect(effectC_DropShadow);
                        b2.setGraphic(svgIconRetry_Hover);

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b2.setTextFill(Color.web("#c0c2c4"));
                        b2.setEffect(null);
                        b2.setGraphic(svgIconRetry);

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut2.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_3.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            backClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b3.setTextFill(Color.web("#9b0000"));
                        b3.setEffect(effectC_DropShadow);
                        b3.setGraphic(svgIconHome_Hover);

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b3.setTextFill(Color.web("#c0c2c4"));
                        b3.setEffect(null);
                        b3.setGraphic(svgIconHome);

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut2.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_3.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            HomeClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b11.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b11.setTextFill(Color.web("#9b0000"));
                        b11.setEffect(effectC_DropShadow);
                        b11.setGraphic(svgIconRetry1_Hover);

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b11.setTextFill(Color.web("#c0c2c4"));
                        b11.setEffect(null);
                        b11.setGraphic(svgIconRetry1);

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_2.play();
                        fadeOut6.play();
                        fadeOut6_1.play();

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            backClicked2();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b21.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b21.setTextFill(Color.web("#9b0000"));
                        b21.setEffect(effectC_DropShadow);
                        b21.setGraphic(svgIconHome1_Hover);

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b21.setTextFill(Color.web("#c0c2c4"));
                        b21.setEffect(null);
                        b21.setGraphic(svgIconHome1);

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_2.play();
                        fadeOut6.play();
                        fadeOut6_1.play();

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            HomeClicked2();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                }

            }
            else if(theme==2){

                color = "#181818";

                effectBG_DropShadowADD = new DropShadow(BlurType.GAUSSIAN, Color.rgb(20,20,20), 18, 0, 9, 9);
                effectBG_DropShadow = new DropShadow(BlurType.GAUSSIAN, Color.rgb(28,28,28), 18, 0, -9, -9);
                effectBG_DropShadow.setInput(effectBG_DropShadowADD);

                effectBG_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(20,20,20), 18, 0, 9, 9);
                effectBG_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(20,20,20), 18, 0, -9, -9);
                effectBG_InnerShadow.setInput(effectBG_InnerShadowADD);

                if (tColor==1) {

                    color2 = "#004fcb";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,67,173), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,91,233), 10, 0, -5, -5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,67,173), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,91,233), 10, 0, -5, -5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBack = getClass().getResourceAsStream("../../../resources/svg/left_arrow_2/left-arrow_d.svg");//
                    svgFileBack_Hover = getClass().getResourceAsStream("../../../resources/svg/left_arrow_2/left-arrow_blue.svg");//
                    svgFileHome = getClass().getResourceAsStream("../../../resources/svg/home/home_d.svg");//
                    svgFileHome_Hover = getClass().getResourceAsStream("../../../resources/svg/home/home_blue.svg");//
                    svgFileHome1 = getClass().getResourceAsStream("../../../resources/svg/home/home_d.svg");//
                    svgFileHome1_Hover = getClass().getResourceAsStream("../../../resources/svg/home/home_blue.svg");//
                    svgFileRetry = getClass().getResourceAsStream("../../../resources/svg/refresh/refresh_d.svg");//
                    svgFileRetry_Hover = getClass().getResourceAsStream("../../../resources/svg/refresh/refresh_blue.svg");//
                    svgFileRetry1 = getClass().getResourceAsStream("../../../resources/svg/refresh/refresh_d.svg");//
                    svgFileRetry1_Hover = getClass().getResourceAsStream("../../../resources/svg/refresh/refresh_blue.svg");//
                    svgFilePause = getClass().getResourceAsStream("../../../resources/svg/pause/pause_d.svg");//
                    svgFilePause_Hover = getClass().getResourceAsStream("../../../resources/svg/pause/pause_blue.svg");//
                    svgFileMenu = getClass().getResourceAsStream("../../../resources/svg/menu/menu_d.svg");//
                    svgFileMenu_Hover = getClass().getResourceAsStream("../../../resources/svg/menu/menu_blue.svg");//

                    svgFilePlayer = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer2 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer3 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer4 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer5 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer6 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer7 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer8 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer9 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");

                    svgFilePlayer_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer2_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer3_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer4_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer5_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer6_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer7_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer8_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer9_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");

                    Group svgBack = loader.loadSvg(svgFileBack);
                    Group svgBack_Hover = loader.loadSvg(svgFileBack_Hover);
                    Group svgHome = loader.loadSvg(svgFileHome);
                    Group svgHome_Hover = loader.loadSvg(svgFileHome_Hover);
                    Group svgHome1 = loader.loadSvg(svgFileHome1);
                    Group svgHome1_Hover = loader.loadSvg(svgFileHome1_Hover);
                    Group svgRetry = loader.loadSvg(svgFileRetry);
                    Group svgRetry_Hover = loader.loadSvg(svgFileRetry_Hover);
                    Group svgRetry1 = loader.loadSvg(svgFileRetry1);
                    Group svgRetry1_Hover = loader.loadSvg(svgFileRetry1_Hover);
                    Group svgPause = loader.loadSvg(svgFilePause);
                    Group svgPause_Hover = loader.loadSvg(svgFilePause_Hover);
                    Group svgMenu = loader.loadSvg(svgFileMenu);
                    Group svgMenu_Hover = loader.loadSvg(svgFileMenu_Hover);

                    Group svgImagePlayer = loader.loadSvg(svgFilePlayer);
                    Group svgImagePlayer2 = loader.loadSvg(svgFilePlayer2);
                    Group svgImagePlayer3 = loader.loadSvg(svgFilePlayer3);
                    Group svgImagePlayer4 = loader.loadSvg(svgFilePlayer4);
                    Group svgImagePlayer5 = loader.loadSvg(svgFilePlayer5);
                    Group svgImagePlayer6 = loader.loadSvg(svgFilePlayer6);
                    Group svgImagePlayer7 = loader.loadSvg(svgFilePlayer7);
                    Group svgImagePlayer8 = loader.loadSvg(svgFilePlayer8);
                    Group svgImagePlayer9 = loader.loadSvg(svgFilePlayer9);
                    Group svgImagePlayer_Hover = loader.loadSvg(svgFilePlayer_Hover);
                    Group svgImagePlayer2_Hover = loader.loadSvg(svgFilePlayer2_Hover);
                    Group svgImagePlayer3_Hover = loader.loadSvg(svgFilePlayer3_Hover);
                    Group svgImagePlayer4_Hover = loader.loadSvg(svgFilePlayer4_Hover);
                    Group svgImagePlayer5_Hover = loader.loadSvg(svgFilePlayer5_Hover);
                    Group svgImagePlayer6_Hover = loader.loadSvg(svgFilePlayer6_Hover);
                    Group svgImagePlayer7_Hover = loader.loadSvg(svgFilePlayer7_Hover);
                    Group svgImagePlayer8_Hover = loader.loadSvg(svgFilePlayer8_Hover);
                    Group svgImagePlayer9_Hover = loader.loadSvg(svgFilePlayer9_Hover);

                    svgBack.setScaleX(.1);
                    svgBack.setScaleY(.1);
                    svgBack_Hover.setScaleX(.1);
                    svgBack_Hover.setScaleY(.1);
                    svgHome.setScaleX(.1);
                    svgHome.setScaleY(.1);
                    svgHome_Hover.setScaleX(.1);
                    svgHome_Hover.setScaleY(.1);
                    svgHome1.setScaleX(.1);
                    svgHome1.setScaleY(.1);
                    svgHome1_Hover.setScaleX(.1);
                    svgHome1_Hover.setScaleY(.1);
                    svgRetry.setScaleX(.1);
                    svgRetry.setScaleY(.1);
                    svgRetry_Hover.setScaleX(.1);
                    svgRetry_Hover.setScaleY(.1);
                    svgRetry1.setScaleX(.1);
                    svgRetry1.setScaleY(.1);
                    svgRetry1_Hover.setScaleX(.1);
                    svgRetry1_Hover.setScaleY(.1);
                    svgPause.setScaleX(.04);
                    svgPause.setScaleY(.04);
                    svgPause_Hover.setScaleX(.04);
                    svgPause_Hover.setScaleY(.04);
                    svgMenu.setScaleX(.04);
                    svgMenu.setScaleY(.04);
                    svgMenu_Hover.setScaleX(.04);
                    svgMenu_Hover.setScaleY(.04);

                    svgImagePlayer.setScaleX(.05);
                    svgImagePlayer.setScaleY(.05);

                    svgImagePlayer2.setScaleX(.05);
                    svgImagePlayer2.setScaleY(.05);

                    svgImagePlayer3.setScaleX(.05);
                    svgImagePlayer3.setScaleY(.05);

                    svgImagePlayer4.setScaleX(.05);
                    svgImagePlayer4.setScaleY(.05);

                    svgImagePlayer5.setScaleX(.05);
                    svgImagePlayer5.setScaleY(.05);

                    svgImagePlayer6.setScaleX(.05);
                    svgImagePlayer6.setScaleY(.05);

                    svgImagePlayer7.setScaleX(.05);
                    svgImagePlayer7.setScaleY(.05);

                    svgImagePlayer8.setScaleX(.05);
                    svgImagePlayer8.setScaleY(.05);

                    svgImagePlayer9.setScaleX(.05);
                    svgImagePlayer9.setScaleY(.05);

                    svgImagePlayer_Hover.setScaleX(.05);
                    svgImagePlayer_Hover.setScaleY(.05);

                    svgImagePlayer2_Hover.setScaleX(.05);
                    svgImagePlayer2_Hover.setScaleY(.05);

                    svgImagePlayer3_Hover.setScaleX(.05);
                    svgImagePlayer3_Hover.setScaleY(.05);

                    svgImagePlayer4_Hover.setScaleX(.05);
                    svgImagePlayer4_Hover.setScaleY(.05);

                    svgImagePlayer5_Hover.setScaleX(.05);
                    svgImagePlayer5_Hover.setScaleY(.05);

                    svgImagePlayer6_Hover.setScaleX(.05);
                    svgImagePlayer6_Hover.setScaleY(.05);

                    svgImagePlayer7_Hover.setScaleX(.05);
                    svgImagePlayer7_Hover.setScaleY(.05);

                    svgImagePlayer8_Hover.setScaleX(.05);
                    svgImagePlayer8_Hover.setScaleY(.05);

                    svgImagePlayer9_Hover.setScaleX(.05);
                    svgImagePlayer9_Hover.setScaleY(.05);

                    Group svgIconBack = new Group(svgBack);
                    Group svgIconBack_Hover = new Group(svgBack_Hover);
                    Group svgIconHome = new Group(svgHome);
                    Group svgIconHome_Hover = new Group(svgHome_Hover);
                    Group svgIconHome1 = new Group(svgHome1);
                    Group svgIconHome1_Hover = new Group(svgHome1_Hover);
                    Group svgIconRetry = new Group(svgRetry);
                    Group svgIconRetry_Hover = new Group(svgRetry_Hover);
                    Group svgIconRetry1 = new Group(svgRetry1);
                    Group svgIconRetry1_Hover = new Group(svgRetry1_Hover);
                    Group svgIconPause = new Group(svgPause);
                    Group svgIconPause_Hover = new Group(svgPause_Hover);
                    Group svgIconMenu = new Group(svgMenu);
                    Group svgIconMenu_Hover = new Group(svgMenu_Hover);

                    Group svgIconPlayer = new Group(svgImagePlayer);
                    Group svgIconPlayer2 = new Group(svgImagePlayer2);
                    Group svgIconPlayer3 = new Group(svgImagePlayer3);
                    Group svgIconPlayer4 = new Group(svgImagePlayer4);
                    Group svgIconPlayer5 = new Group(svgImagePlayer5);
                    Group svgIconPlayer6 = new Group(svgImagePlayer6);
                    Group svgIconPlayer7 = new Group(svgImagePlayer7);
                    Group svgIconPlayer8 = new Group(svgImagePlayer8);
                    Group svgIconPlayer9 = new Group(svgImagePlayer9);
                    Group svgIconPlayer_Hover = new Group(svgImagePlayer_Hover);
                    Group svgIconPlayer2_Hover = new Group(svgImagePlayer2_Hover);
                    Group svgIconPlayer3_Hover = new Group(svgImagePlayer3_Hover);
                    Group svgIconPlayer4_Hover = new Group(svgImagePlayer4_Hover);
                    Group svgIconPlayer5_Hover = new Group(svgImagePlayer5_Hover);
                    Group svgIconPlayer6_Hover = new Group(svgImagePlayer6_Hover);
                    Group svgIconPlayer7_Hover = new Group(svgImagePlayer7_Hover);
                    Group svgIconPlayer8_Hover = new Group(svgImagePlayer8_Hover);
                    Group svgIconPlayer9_Hover = new Group(svgImagePlayer9_Hover);

                    r3p1Icon.setGraphic(svgIconPlayer);
                    r3p2Icon.setGraphic(svgIconPlayer2);
                    r3p3Icon.setGraphic(svgIconPlayer3);
                    r3p4Icon.setGraphic(svgIconPlayer4);
                    r2p1Icon.setGraphic(svgIconPlayer5);
                    r2p2Icon.setGraphic(svgIconPlayer6);
                    r2p3Icon.setGraphic(svgIconPlayer7);
                    r1p1Icon.setGraphic(svgIconPlayer8);
                    r1p2Icon.setGraphic(svgIconPlayer9);

                    backButton.setGraphic(svgIconMenu);

                    b1.setGraphic(svgIconBack);
                    b2.setGraphic(svgIconRetry);
                    b3.setGraphic(svgIconHome);
                    b11.setGraphic(svgIconRetry1);
                    b21.setGraphic(svgIconHome1);
                    l4.setEffect(effectC_InnerShadow);
                    l3.setEffect(effectC_InnerShadow);

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        if (b111==0){

                            l1.setText("");
                            l2.setText("Pause");
                            backButton.setEffect(effectC_DropShadow);
                            backButton.setGraphic(svgIconPause_Hover);
                            backButton.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");

                        }
                        else {


                            backButton.setGraphic(svgIconPause);

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        if (b111==0){

                            l1.setText("Memory");
                            l2.setText("Game");
                            backButton.setEffect(null);
                            backButton.setGraphic(svgIconMenu);
                            backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                        }else {

                            backButton.setEffect(null);
                            backButton.setGraphic(svgIconPause);

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        if (b111==0){
                            b111=1;
                            grid2.setVisible(true);
                            grid2.setDisable(false);

                            fadeOut.play();
                            fadeOut5.play();
                            fadeOut5_1.play();

                            fadeIn3.play();
                            fadeIn5_3.play();

                            fadeIn7.play();
                            fadeIn7_1.play();
                            fadeIn7_2.play();

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        fadeIn.play();

                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        backButton.setGraphic(svgIconPause);

                    });

                    b1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b1.setTextFill(Color.web("#007aff"));
                        b1.setEffect(effectC_DropShadow);
                        b1.setGraphic(svgIconBack_Hover);

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b1.setTextFill(Color.web("#3E3E3E"));
                        b1.setEffect(null);
                        b1.setGraphic(svgIconBack);

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {
                        b111=0;
                        fadeIn.play();
                        fadeIn5.play();
                        fadeIn5_1.play();

                        fadeOut3.play();
                        fadeOut5_3.play();

                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                        grid2.setDisable(true);
                        backButton.setGraphic(svgIconMenu);
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                    });

                    b2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b2.setTextFill(Color.web("#007aff"));
                        b2.setEffect(effectC_DropShadow);
                        b2.setGraphic(svgIconRetry_Hover);

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b2.setTextFill(Color.web("#3E3E3E"));
                        b2.setEffect(null);
                        b2.setGraphic(svgIconRetry);

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut2.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_3.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            backClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b3.setTextFill(Color.web("#007aff"));
                        b3.setEffect(effectC_DropShadow);
                        b3.setGraphic(svgIconHome_Hover);

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b3.setTextFill(Color.web("#3E3E3E"));
                        b3.setEffect(null);
                        b3.setGraphic(svgIconHome);

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut2.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_3.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            HomeClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b11.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b11.setTextFill(Color.web("#007aff"));
                        b11.setEffect(effectC_DropShadow);
                        b11.setGraphic(svgIconRetry1_Hover);

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b11.setTextFill(Color.web("#3E3E3E"));
                        b11.setEffect(null);
                        b11.setGraphic(svgIconRetry1);

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_2.play();
                        fadeOut6.play();
                        fadeOut6_1.play();

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            backClicked2();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b21.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b21.setTextFill(Color.web("#007aff"));
                        b21.setEffect(effectC_DropShadow);
                        b21.setGraphic(svgIconHome1_Hover);

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b21.setTextFill(Color.web("#3E3E3E"));
                        b21.setEffect(null);
                        b21.setGraphic(svgIconHome1);

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_2.play();
                        fadeOut6.play();
                        fadeOut6_1.play();

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            HomeClicked2();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                }
                else if (tColor==2) {

                    color2 = "#c9c208";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.web("#aba507"), 18, 0, 9, 9);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.web("#e7df09"), 18, 0, -9, -9);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.web("#aba507"), 18, 0, 9, 9);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.web("#e7df09"), 18, 0, -9, -9);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBack = getClass().getResourceAsStream("../../../resources/svg/left_arrow_2/left-arrow_d.svg");//
                    svgFileBack_Hover = getClass().getResourceAsStream("../../../resources/svg/left_arrow_2/left-arrow_blue.svg");//
                    svgFileHome = getClass().getResourceAsStream("../../../resources/svg/home/home_d.svg");//
                    svgFileHome_Hover = getClass().getResourceAsStream("../../../resources/svg/home/home_blue.svg");//
                    svgFileHome1 = getClass().getResourceAsStream("../../../resources/svg/home/home_d.svg");//
                    svgFileHome1_Hover = getClass().getResourceAsStream("../../../resources/svg/home/home_blue.svg");//
                    svgFileRetry = getClass().getResourceAsStream("../../../resources/svg/refresh/refresh_d.svg");//
                    svgFileRetry_Hover = getClass().getResourceAsStream("../../../resources/svg/refresh/refresh_blue.svg");//
                    svgFileRetry1 = getClass().getResourceAsStream("../../../resources/svg/refresh/refresh_d.svg");//
                    svgFileRetry1_Hover = getClass().getResourceAsStream("../../../resources/svg/refresh/refresh_blue.svg");//
                    svgFilePause = getClass().getResourceAsStream("../../../resources/svg/pause/pause_d.svg");//
                    svgFilePause_Hover = getClass().getResourceAsStream("../../../resources/svg/pause/pause_blue.svg");//
                    svgFileMenu = getClass().getResourceAsStream("../../../resources/svg/menu/menu_d.svg");//
                    svgFileMenu_Hover = getClass().getResourceAsStream("../../../resources/svg/menu/menu_blue.svg");//

                    svgFilePlayer = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer2 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer3 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer4 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer5 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer6 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer7 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer8 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer9 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");

                    svgFilePlayer_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer2_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer3_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer4_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer5_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer6_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer7_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer8_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer9_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");

                    Group svgBack = loader.loadSvg(svgFileBack);
                    Group svgBack_Hover = loader.loadSvg(svgFileBack_Hover);
                    Group svgHome = loader.loadSvg(svgFileHome);
                    Group svgHome_Hover = loader.loadSvg(svgFileHome_Hover);
                    Group svgHome1 = loader.loadSvg(svgFileHome1);
                    Group svgHome1_Hover = loader.loadSvg(svgFileHome1_Hover);
                    Group svgRetry = loader.loadSvg(svgFileRetry);
                    Group svgRetry_Hover = loader.loadSvg(svgFileRetry_Hover);
                    Group svgRetry1 = loader.loadSvg(svgFileRetry1);
                    Group svgRetry1_Hover = loader.loadSvg(svgFileRetry1_Hover);
                    Group svgPause = loader.loadSvg(svgFilePause);
                    Group svgPause_Hover = loader.loadSvg(svgFilePause_Hover);
                    Group svgMenu = loader.loadSvg(svgFileMenu);
                    Group svgMenu_Hover = loader.loadSvg(svgFileMenu_Hover);

                    Group svgImagePlayer = loader.loadSvg(svgFilePlayer);
                    Group svgImagePlayer2 = loader.loadSvg(svgFilePlayer2);
                    Group svgImagePlayer3 = loader.loadSvg(svgFilePlayer3);
                    Group svgImagePlayer4 = loader.loadSvg(svgFilePlayer4);
                    Group svgImagePlayer5 = loader.loadSvg(svgFilePlayer5);
                    Group svgImagePlayer6 = loader.loadSvg(svgFilePlayer6);
                    Group svgImagePlayer7 = loader.loadSvg(svgFilePlayer7);
                    Group svgImagePlayer8 = loader.loadSvg(svgFilePlayer8);
                    Group svgImagePlayer9 = loader.loadSvg(svgFilePlayer9);
                    Group svgImagePlayer_Hover = loader.loadSvg(svgFilePlayer_Hover);
                    Group svgImagePlayer2_Hover = loader.loadSvg(svgFilePlayer2_Hover);
                    Group svgImagePlayer3_Hover = loader.loadSvg(svgFilePlayer3_Hover);
                    Group svgImagePlayer4_Hover = loader.loadSvg(svgFilePlayer4_Hover);
                    Group svgImagePlayer5_Hover = loader.loadSvg(svgFilePlayer5_Hover);
                    Group svgImagePlayer6_Hover = loader.loadSvg(svgFilePlayer6_Hover);
                    Group svgImagePlayer7_Hover = loader.loadSvg(svgFilePlayer7_Hover);
                    Group svgImagePlayer8_Hover = loader.loadSvg(svgFilePlayer8_Hover);
                    Group svgImagePlayer9_Hover = loader.loadSvg(svgFilePlayer9_Hover);

                    svgBack.setScaleX(.1);
                    svgBack.setScaleY(.1);
                    svgBack_Hover.setScaleX(.1);
                    svgBack_Hover.setScaleY(.1);
                    svgHome.setScaleX(.1);
                    svgHome.setScaleY(.1);
                    svgHome_Hover.setScaleX(.1);
                    svgHome_Hover.setScaleY(.1);
                    svgHome1.setScaleX(.1);
                    svgHome1.setScaleY(.1);
                    svgHome1_Hover.setScaleX(.1);
                    svgHome1_Hover.setScaleY(.1);
                    svgRetry.setScaleX(.1);
                    svgRetry.setScaleY(.1);
                    svgRetry_Hover.setScaleX(.1);
                    svgRetry_Hover.setScaleY(.1);
                    svgRetry1.setScaleX(.1);
                    svgRetry1.setScaleY(.1);
                    svgRetry1_Hover.setScaleX(.1);
                    svgRetry1_Hover.setScaleY(.1);
                    svgPause.setScaleX(.04);
                    svgPause.setScaleY(.04);
                    svgPause_Hover.setScaleX(.04);
                    svgPause_Hover.setScaleY(.04);
                    svgMenu.setScaleX(.04);
                    svgMenu.setScaleY(.04);
                    svgMenu_Hover.setScaleX(.04);
                    svgMenu_Hover.setScaleY(.04);

                    svgImagePlayer.setScaleX(.05);
                    svgImagePlayer.setScaleY(.05);

                    svgImagePlayer2.setScaleX(.05);
                    svgImagePlayer2.setScaleY(.05);

                    svgImagePlayer3.setScaleX(.05);
                    svgImagePlayer3.setScaleY(.05);

                    svgImagePlayer4.setScaleX(.05);
                    svgImagePlayer4.setScaleY(.05);

                    svgImagePlayer5.setScaleX(.05);
                    svgImagePlayer5.setScaleY(.05);

                    svgImagePlayer6.setScaleX(.05);
                    svgImagePlayer6.setScaleY(.05);

                    svgImagePlayer7.setScaleX(.05);
                    svgImagePlayer7.setScaleY(.05);

                    svgImagePlayer8.setScaleX(.05);
                    svgImagePlayer8.setScaleY(.05);

                    svgImagePlayer9.setScaleX(.05);
                    svgImagePlayer9.setScaleY(.05);

                    svgImagePlayer_Hover.setScaleX(.05);
                    svgImagePlayer_Hover.setScaleY(.05);

                    svgImagePlayer2_Hover.setScaleX(.05);
                    svgImagePlayer2_Hover.setScaleY(.05);

                    svgImagePlayer3_Hover.setScaleX(.05);
                    svgImagePlayer3_Hover.setScaleY(.05);

                    svgImagePlayer4_Hover.setScaleX(.05);
                    svgImagePlayer4_Hover.setScaleY(.05);

                    svgImagePlayer5_Hover.setScaleX(.05);
                    svgImagePlayer5_Hover.setScaleY(.05);

                    svgImagePlayer6_Hover.setScaleX(.05);
                    svgImagePlayer6_Hover.setScaleY(.05);

                    svgImagePlayer7_Hover.setScaleX(.05);
                    svgImagePlayer7_Hover.setScaleY(.05);

                    svgImagePlayer8_Hover.setScaleX(.05);
                    svgImagePlayer8_Hover.setScaleY(.05);

                    svgImagePlayer9_Hover.setScaleX(.05);
                    svgImagePlayer9_Hover.setScaleY(.05);

                    Group svgIconBack = new Group(svgBack);
                    Group svgIconBack_Hover = new Group(svgBack_Hover);
                    Group svgIconHome = new Group(svgHome);
                    Group svgIconHome_Hover = new Group(svgHome_Hover);
                    Group svgIconHome1 = new Group(svgHome1);
                    Group svgIconHome1_Hover = new Group(svgHome1_Hover);
                    Group svgIconRetry = new Group(svgRetry);
                    Group svgIconRetry_Hover = new Group(svgRetry_Hover);
                    Group svgIconRetry1 = new Group(svgRetry1);
                    Group svgIconRetry1_Hover = new Group(svgRetry1_Hover);
                    Group svgIconPause = new Group(svgPause);
                    Group svgIconPause_Hover = new Group(svgPause_Hover);
                    Group svgIconMenu = new Group(svgMenu);
                    Group svgIconMenu_Hover = new Group(svgMenu_Hover);

                    Group svgIconPlayer = new Group(svgImagePlayer);
                    Group svgIconPlayer2 = new Group(svgImagePlayer2);
                    Group svgIconPlayer3 = new Group(svgImagePlayer3);
                    Group svgIconPlayer4 = new Group(svgImagePlayer4);
                    Group svgIconPlayer5 = new Group(svgImagePlayer5);
                    Group svgIconPlayer6 = new Group(svgImagePlayer6);
                    Group svgIconPlayer7 = new Group(svgImagePlayer7);
                    Group svgIconPlayer8 = new Group(svgImagePlayer8);
                    Group svgIconPlayer9 = new Group(svgImagePlayer9);
                    Group svgIconPlayer_Hover = new Group(svgImagePlayer_Hover);
                    Group svgIconPlayer2_Hover = new Group(svgImagePlayer2_Hover);
                    Group svgIconPlayer3_Hover = new Group(svgImagePlayer3_Hover);
                    Group svgIconPlayer4_Hover = new Group(svgImagePlayer4_Hover);
                    Group svgIconPlayer5_Hover = new Group(svgImagePlayer5_Hover);
                    Group svgIconPlayer6_Hover = new Group(svgImagePlayer6_Hover);
                    Group svgIconPlayer7_Hover = new Group(svgImagePlayer7_Hover);
                    Group svgIconPlayer8_Hover = new Group(svgImagePlayer8_Hover);
                    Group svgIconPlayer9_Hover = new Group(svgImagePlayer9_Hover);

                    r3p1Icon.setGraphic(svgIconPlayer);
                    r3p2Icon.setGraphic(svgIconPlayer2);
                    r3p3Icon.setGraphic(svgIconPlayer3);
                    r3p4Icon.setGraphic(svgIconPlayer4);
                    r2p1Icon.setGraphic(svgIconPlayer5);
                    r2p2Icon.setGraphic(svgIconPlayer6);
                    r2p3Icon.setGraphic(svgIconPlayer7);
                    r1p1Icon.setGraphic(svgIconPlayer8);
                    r1p2Icon.setGraphic(svgIconPlayer9);

                    backButton.setGraphic(svgIconMenu);

                    b1.setGraphic(svgIconBack);
                    b2.setGraphic(svgIconRetry);
                    b3.setGraphic(svgIconHome);
                    b11.setGraphic(svgIconRetry1);
                    b21.setGraphic(svgIconHome1);
                    l4.setEffect(effectC_InnerShadow);
                    l3.setEffect(effectC_InnerShadow);

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        if (b111==0){

                            l1.setText("");
                            l2.setText("Pause");
                            backButton.setEffect(effectC_DropShadow);
                            backButton.setGraphic(svgIconPause_Hover);
                            backButton.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");

                        }
                        else {


                            backButton.setGraphic(svgIconPause);

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        if (b111==0){

                            l1.setText("Memory");
                            l2.setText("Game");
                            backButton.setEffect(null);
                            backButton.setGraphic(svgIconMenu);
                            backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                        }else {

                            backButton.setEffect(null);
                            backButton.setGraphic(svgIconPause);

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        if (b111==0){
                            b111=1;
                            grid2.setVisible(true);
                            grid2.setDisable(false);

                            fadeOut.play();
                            fadeOut5.play();
                            fadeOut5_1.play();

                            fadeIn3.play();
                            fadeIn5_3.play();

                            fadeIn7.play();
                            fadeIn7_1.play();
                            fadeIn7_2.play();

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        fadeIn.play();

                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        backButton.setGraphic(svgIconPause);

                    });

                    b1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b1.setTextFill(Color.web("#fff44f"));
                        b1.setEffect(effectC_DropShadow);
                        b1.setGraphic(svgIconBack_Hover);

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b1.setTextFill(Color.web("#3E3E3E"));
                        b1.setEffect(null);
                        b1.setGraphic(svgIconBack);

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {
                        b111=0;
                        fadeIn.play();
                        fadeIn5.play();
                        fadeIn5_1.play();

                        fadeOut3.play();
                        fadeOut5_3.play();

                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                        grid2.setDisable(true);
                        backButton.setGraphic(svgIconMenu);
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                    });

                    b2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b2.setTextFill(Color.web("#fff44f"));
                        b2.setEffect(effectC_DropShadow);
                        b2.setGraphic(svgIconRetry_Hover);

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b2.setTextFill(Color.web("#3E3E3E"));
                        b2.setEffect(null);
                        b2.setGraphic(svgIconRetry);

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut2.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_3.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            backClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b3.setTextFill(Color.web("#fff44f"));
                        b3.setEffect(effectC_DropShadow);
                        b3.setGraphic(svgIconHome_Hover);

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b3.setTextFill(Color.web("#3E3E3E"));
                        b3.setEffect(null);
                        b3.setGraphic(svgIconHome);

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut2.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_3.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            HomeClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b11.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b11.setTextFill(Color.web("#fff44f"));
                        b11.setEffect(effectC_DropShadow);
                        b11.setGraphic(svgIconRetry1_Hover);

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b11.setTextFill(Color.web("#3E3E3E"));
                        b11.setEffect(null);
                        b11.setGraphic(svgIconRetry1);

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_2.play();
                        fadeOut6.play();
                        fadeOut6_1.play();

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            backClicked2();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b21.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b21.setTextFill(Color.web("#fff44f"));
                        b21.setEffect(effectC_DropShadow);
                        b21.setGraphic(svgIconHome1_Hover);

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b21.setTextFill(Color.web("#3E3E3E"));
                        b21.setEffect(null);
                        b21.setGraphic(svgIconHome1);

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_2.play();
                        fadeOut6.play();
                        fadeOut6_1.play();

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            HomeClicked2();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                }
                else if (tColor==3) {

                    color2 = "#006500";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,86,0), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,116,0), 10, 0, -5, -5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,86,0), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,116,0), 10, 0, -5, -5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBack = getClass().getResourceAsStream("../../../resources/svg/left_arrow_2/left-arrow_d.svg");//
                    svgFileBack_Hover = getClass().getResourceAsStream("../../../resources/svg/left_arrow_2/left-arrow_blue.svg");//
                    svgFileHome = getClass().getResourceAsStream("../../../resources/svg/home/home_d.svg");//
                    svgFileHome_Hover = getClass().getResourceAsStream("../../../resources/svg/home/home_blue.svg");//
                    svgFileHome1 = getClass().getResourceAsStream("../../../resources/svg/home/home_d.svg");//
                    svgFileHome1_Hover = getClass().getResourceAsStream("../../../resources/svg/home/home_blue.svg");//
                    svgFileRetry = getClass().getResourceAsStream("../../../resources/svg/refresh/refresh_d.svg");//
                    svgFileRetry_Hover = getClass().getResourceAsStream("../../../resources/svg/refresh/refresh_blue.svg");//
                    svgFileRetry1 = getClass().getResourceAsStream("../../../resources/svg/refresh/refresh_d.svg");//
                    svgFileRetry1_Hover = getClass().getResourceAsStream("../../../resources/svg/refresh/refresh_blue.svg");//
                    svgFilePause = getClass().getResourceAsStream("../../../resources/svg/pause/pause_d.svg");//
                    svgFilePause_Hover = getClass().getResourceAsStream("../../../resources/svg/pause/pause_blue.svg");//
                    svgFileMenu = getClass().getResourceAsStream("../../../resources/svg/menu/menu_d.svg");//
                    svgFileMenu_Hover = getClass().getResourceAsStream("../../../resources/svg/menu/menu_blue.svg");//

                    svgFilePlayer = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer2 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer3 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer4 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer5 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer6 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer7 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer8 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer9 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");

                    svgFilePlayer_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer2_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer3_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer4_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer5_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer6_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer7_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer8_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer9_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");

                    Group svgBack = loader.loadSvg(svgFileBack);
                    Group svgBack_Hover = loader.loadSvg(svgFileBack_Hover);
                    Group svgHome = loader.loadSvg(svgFileHome);
                    Group svgHome_Hover = loader.loadSvg(svgFileHome_Hover);
                    Group svgHome1 = loader.loadSvg(svgFileHome1);
                    Group svgHome1_Hover = loader.loadSvg(svgFileHome1_Hover);
                    Group svgRetry = loader.loadSvg(svgFileRetry);
                    Group svgRetry_Hover = loader.loadSvg(svgFileRetry_Hover);
                    Group svgRetry1 = loader.loadSvg(svgFileRetry1);
                    Group svgRetry1_Hover = loader.loadSvg(svgFileRetry1_Hover);
                    Group svgPause = loader.loadSvg(svgFilePause);
                    Group svgPause_Hover = loader.loadSvg(svgFilePause_Hover);
                    Group svgMenu = loader.loadSvg(svgFileMenu);
                    Group svgMenu_Hover = loader.loadSvg(svgFileMenu_Hover);

                    Group svgImagePlayer = loader.loadSvg(svgFilePlayer);
                    Group svgImagePlayer2 = loader.loadSvg(svgFilePlayer2);
                    Group svgImagePlayer3 = loader.loadSvg(svgFilePlayer3);
                    Group svgImagePlayer4 = loader.loadSvg(svgFilePlayer4);
                    Group svgImagePlayer5 = loader.loadSvg(svgFilePlayer5);
                    Group svgImagePlayer6 = loader.loadSvg(svgFilePlayer6);
                    Group svgImagePlayer7 = loader.loadSvg(svgFilePlayer7);
                    Group svgImagePlayer8 = loader.loadSvg(svgFilePlayer8);
                    Group svgImagePlayer9 = loader.loadSvg(svgFilePlayer9);
                    Group svgImagePlayer_Hover = loader.loadSvg(svgFilePlayer_Hover);
                    Group svgImagePlayer2_Hover = loader.loadSvg(svgFilePlayer2_Hover);
                    Group svgImagePlayer3_Hover = loader.loadSvg(svgFilePlayer3_Hover);
                    Group svgImagePlayer4_Hover = loader.loadSvg(svgFilePlayer4_Hover);
                    Group svgImagePlayer5_Hover = loader.loadSvg(svgFilePlayer5_Hover);
                    Group svgImagePlayer6_Hover = loader.loadSvg(svgFilePlayer6_Hover);
                    Group svgImagePlayer7_Hover = loader.loadSvg(svgFilePlayer7_Hover);
                    Group svgImagePlayer8_Hover = loader.loadSvg(svgFilePlayer8_Hover);
                    Group svgImagePlayer9_Hover = loader.loadSvg(svgFilePlayer9_Hover);

                    svgBack.setScaleX(.1);
                    svgBack.setScaleY(.1);
                    svgBack_Hover.setScaleX(.1);
                    svgBack_Hover.setScaleY(.1);
                    svgHome.setScaleX(.1);
                    svgHome.setScaleY(.1);
                    svgHome_Hover.setScaleX(.1);
                    svgHome_Hover.setScaleY(.1);
                    svgHome1.setScaleX(.1);
                    svgHome1.setScaleY(.1);
                    svgHome1_Hover.setScaleX(.1);
                    svgHome1_Hover.setScaleY(.1);
                    svgRetry.setScaleX(.1);
                    svgRetry.setScaleY(.1);
                    svgRetry_Hover.setScaleX(.1);
                    svgRetry_Hover.setScaleY(.1);
                    svgRetry1.setScaleX(.1);
                    svgRetry1.setScaleY(.1);
                    svgRetry1_Hover.setScaleX(.1);
                    svgRetry1_Hover.setScaleY(.1);
                    svgPause.setScaleX(.04);
                    svgPause.setScaleY(.04);
                    svgPause_Hover.setScaleX(.04);
                    svgPause_Hover.setScaleY(.04);
                    svgMenu.setScaleX(.04);
                    svgMenu.setScaleY(.04);
                    svgMenu_Hover.setScaleX(.04);
                    svgMenu_Hover.setScaleY(.04);

                    svgImagePlayer.setScaleX(.05);
                    svgImagePlayer.setScaleY(.05);

                    svgImagePlayer2.setScaleX(.05);
                    svgImagePlayer2.setScaleY(.05);

                    svgImagePlayer3.setScaleX(.05);
                    svgImagePlayer3.setScaleY(.05);

                    svgImagePlayer4.setScaleX(.05);
                    svgImagePlayer4.setScaleY(.05);

                    svgImagePlayer5.setScaleX(.05);
                    svgImagePlayer5.setScaleY(.05);

                    svgImagePlayer6.setScaleX(.05);
                    svgImagePlayer6.setScaleY(.05);

                    svgImagePlayer7.setScaleX(.05);
                    svgImagePlayer7.setScaleY(.05);

                    svgImagePlayer8.setScaleX(.05);
                    svgImagePlayer8.setScaleY(.05);

                    svgImagePlayer9.setScaleX(.05);
                    svgImagePlayer9.setScaleY(.05);

                    svgImagePlayer_Hover.setScaleX(.05);
                    svgImagePlayer_Hover.setScaleY(.05);

                    svgImagePlayer2_Hover.setScaleX(.05);
                    svgImagePlayer2_Hover.setScaleY(.05);

                    svgImagePlayer3_Hover.setScaleX(.05);
                    svgImagePlayer3_Hover.setScaleY(.05);

                    svgImagePlayer4_Hover.setScaleX(.05);
                    svgImagePlayer4_Hover.setScaleY(.05);

                    svgImagePlayer5_Hover.setScaleX(.05);
                    svgImagePlayer5_Hover.setScaleY(.05);

                    svgImagePlayer6_Hover.setScaleX(.05);
                    svgImagePlayer6_Hover.setScaleY(.05);

                    svgImagePlayer7_Hover.setScaleX(.05);
                    svgImagePlayer7_Hover.setScaleY(.05);

                    svgImagePlayer8_Hover.setScaleX(.05);
                    svgImagePlayer8_Hover.setScaleY(.05);

                    svgImagePlayer9_Hover.setScaleX(.05);
                    svgImagePlayer9_Hover.setScaleY(.05);

                    Group svgIconBack = new Group(svgBack);
                    Group svgIconBack_Hover = new Group(svgBack_Hover);
                    Group svgIconHome = new Group(svgHome);
                    Group svgIconHome_Hover = new Group(svgHome_Hover);
                    Group svgIconHome1 = new Group(svgHome1);
                    Group svgIconHome1_Hover = new Group(svgHome1_Hover);
                    Group svgIconRetry = new Group(svgRetry);
                    Group svgIconRetry_Hover = new Group(svgRetry_Hover);
                    Group svgIconRetry1 = new Group(svgRetry1);
                    Group svgIconRetry1_Hover = new Group(svgRetry1_Hover);
                    Group svgIconPause = new Group(svgPause);
                    Group svgIconPause_Hover = new Group(svgPause_Hover);
                    Group svgIconMenu = new Group(svgMenu);
                    Group svgIconMenu_Hover = new Group(svgMenu_Hover);

                    Group svgIconPlayer = new Group(svgImagePlayer);
                    Group svgIconPlayer2 = new Group(svgImagePlayer2);
                    Group svgIconPlayer3 = new Group(svgImagePlayer3);
                    Group svgIconPlayer4 = new Group(svgImagePlayer4);
                    Group svgIconPlayer5 = new Group(svgImagePlayer5);
                    Group svgIconPlayer6 = new Group(svgImagePlayer6);
                    Group svgIconPlayer7 = new Group(svgImagePlayer7);
                    Group svgIconPlayer8 = new Group(svgImagePlayer8);
                    Group svgIconPlayer9 = new Group(svgImagePlayer9);
                    Group svgIconPlayer_Hover = new Group(svgImagePlayer_Hover);
                    Group svgIconPlayer2_Hover = new Group(svgImagePlayer2_Hover);
                    Group svgIconPlayer3_Hover = new Group(svgImagePlayer3_Hover);
                    Group svgIconPlayer4_Hover = new Group(svgImagePlayer4_Hover);
                    Group svgIconPlayer5_Hover = new Group(svgImagePlayer5_Hover);
                    Group svgIconPlayer6_Hover = new Group(svgImagePlayer6_Hover);
                    Group svgIconPlayer7_Hover = new Group(svgImagePlayer7_Hover);
                    Group svgIconPlayer8_Hover = new Group(svgImagePlayer8_Hover);
                    Group svgIconPlayer9_Hover = new Group(svgImagePlayer9_Hover);

                    r3p1Icon.setGraphic(svgIconPlayer);
                    r3p2Icon.setGraphic(svgIconPlayer2);
                    r3p3Icon.setGraphic(svgIconPlayer3);
                    r3p4Icon.setGraphic(svgIconPlayer4);
                    r2p1Icon.setGraphic(svgIconPlayer5);
                    r2p2Icon.setGraphic(svgIconPlayer6);
                    r2p3Icon.setGraphic(svgIconPlayer7);
                    r1p1Icon.setGraphic(svgIconPlayer8);
                    r1p2Icon.setGraphic(svgIconPlayer9);

                    backButton.setGraphic(svgIconMenu);

                    b1.setGraphic(svgIconBack);
                    b2.setGraphic(svgIconRetry);
                    b3.setGraphic(svgIconHome);
                    b11.setGraphic(svgIconRetry1);
                    b21.setGraphic(svgIconHome1);
                    l4.setEffect(effectC_InnerShadow);
                    l3.setEffect(effectC_InnerShadow);

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        if (b111==0){

                            l1.setText("");
                            l2.setText("Pause");
                            backButton.setEffect(effectC_DropShadow);
                            backButton.setGraphic(svgIconPause_Hover);
                            backButton.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");

                        }
                        else {


                            backButton.setGraphic(svgIconPause);

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        if (b111==0){

                            l1.setText("Memory");
                            l2.setText("Game");
                            backButton.setEffect(null);
                            backButton.setGraphic(svgIconMenu);
                            backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                        }else {

                            backButton.setEffect(null);
                            backButton.setGraphic(svgIconPause);

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        if (b111==0){
                            b111=1;
                            grid2.setVisible(true);
                            grid2.setDisable(false);

                            fadeOut.play();
                            fadeOut5.play();
                            fadeOut5_1.play();

                            fadeIn3.play();
                            fadeIn5_3.play();

                            fadeIn7.play();
                            fadeIn7_1.play();
                            fadeIn7_2.play();

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        fadeIn.play();

                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        backButton.setGraphic(svgIconPause);

                    });

                    b1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b1.setTextFill(Color.web("#00c853"));
                        b1.setEffect(effectC_DropShadow);
                        b1.setGraphic(svgIconBack_Hover);

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b1.setTextFill(Color.web("#3E3E3E"));
                        b1.setEffect(null);
                        b1.setGraphic(svgIconBack);

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {
                        b111=0;
                        fadeIn.play();
                        fadeIn5.play();
                        fadeIn5_1.play();

                        fadeOut3.play();
                        fadeOut5_3.play();

                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                        grid2.setDisable(true);
                        backButton.setGraphic(svgIconMenu);
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                    });

                    b2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b2.setTextFill(Color.web("#00c853"));
                        b2.setEffect(effectC_DropShadow);
                        b2.setGraphic(svgIconRetry_Hover);

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b2.setTextFill(Color.web("#3E3E3E"));
                        b2.setEffect(null);
                        b2.setGraphic(svgIconRetry);

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut2.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_3.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            backClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b3.setTextFill(Color.web("#00c853"));
                        b3.setEffect(effectC_DropShadow);
                        b3.setGraphic(svgIconHome_Hover);

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b3.setTextFill(Color.web("#3E3E3E"));
                        b3.setEffect(null);
                        b3.setGraphic(svgIconHome);

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut2.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_3.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            HomeClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b11.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b11.setTextFill(Color.web("#00c853"));
                        b11.setEffect(effectC_DropShadow);
                        b11.setGraphic(svgIconRetry1_Hover);

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b11.setTextFill(Color.web("#3E3E3E"));
                        b11.setEffect(null);
                        b11.setGraphic(svgIconRetry1);

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_2.play();
                        fadeOut6.play();
                        fadeOut6_1.play();

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            backClicked2();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b21.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b21.setTextFill(Color.web("#00c853"));
                        b21.setEffect(effectC_DropShadow);
                        b21.setGraphic(svgIconHome1_Hover);

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b21.setTextFill(Color.web("#3E3E3E"));
                        b21.setEffect(null);
                        b21.setGraphic(svgIconHome1);

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_2.play();
                        fadeOut6.play();
                        fadeOut6_1.play();

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            HomeClicked2();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });


                }
                else if (tColor==4) {

                    color2 = "#9b0000";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(155,0,0), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(178,0,0), 10, 0, -5, -5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(155,0,0), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(178,0,0), 10, 0, -5, -5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFileBack = getClass().getResourceAsStream("../../../resources/svg/left_arrow_2/left-arrow_d.svg");//
                    svgFileBack_Hover = getClass().getResourceAsStream("../../../resources/svg/left_arrow_2/left-arrow_blue.svg");//
                    svgFileHome = getClass().getResourceAsStream("../../../resources/svg/home/home_d.svg");//
                    svgFileHome_Hover = getClass().getResourceAsStream("../../../resources/svg/home/home_blue.svg");//
                    svgFileHome1 = getClass().getResourceAsStream("../../../resources/svg/home/home_d.svg");//
                    svgFileHome1_Hover = getClass().getResourceAsStream("../../../resources/svg/home/home_blue.svg");//
                    svgFileRetry = getClass().getResourceAsStream("../../../resources/svg/refresh/refresh_d.svg");//
                    svgFileRetry_Hover = getClass().getResourceAsStream("../../../resources/svg/refresh/refresh_blue.svg");//
                    svgFileRetry1 = getClass().getResourceAsStream("../../../resources/svg/refresh/refresh_d.svg");//
                    svgFileRetry1_Hover = getClass().getResourceAsStream("../../../resources/svg/refresh/refresh_blue.svg");//
                    svgFilePause = getClass().getResourceAsStream("../../../resources/svg/pause/pause_d.svg");//
                    svgFilePause_Hover = getClass().getResourceAsStream("../../../resources/svg/pause/pause_blue.svg");//
                    svgFileMenu = getClass().getResourceAsStream("../../../resources/svg/menu/menu_d.svg");//
                    svgFileMenu_Hover = getClass().getResourceAsStream("../../../resources/svg/menu/menu_blue.svg");//

                    svgFilePlayer = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer2 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer3 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer4 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer5 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer6 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer7 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer8 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer9 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");

                    svgFilePlayer_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer2_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer3_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer4_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer5_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer6_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer7_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer8_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer9_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");

                    Group svgBack = loader.loadSvg(svgFileBack);
                    Group svgBack_Hover = loader.loadSvg(svgFileBack_Hover);
                    Group svgHome = loader.loadSvg(svgFileHome);
                    Group svgHome_Hover = loader.loadSvg(svgFileHome_Hover);
                    Group svgHome1 = loader.loadSvg(svgFileHome1);
                    Group svgHome1_Hover = loader.loadSvg(svgFileHome1_Hover);
                    Group svgRetry = loader.loadSvg(svgFileRetry);
                    Group svgRetry_Hover = loader.loadSvg(svgFileRetry_Hover);
                    Group svgRetry1 = loader.loadSvg(svgFileRetry1);
                    Group svgRetry1_Hover = loader.loadSvg(svgFileRetry1_Hover);
                    Group svgPause = loader.loadSvg(svgFilePause);
                    Group svgPause_Hover = loader.loadSvg(svgFilePause_Hover);
                    Group svgMenu = loader.loadSvg(svgFileMenu);
                    Group svgMenu_Hover = loader.loadSvg(svgFileMenu_Hover);

                    Group svgImagePlayer = loader.loadSvg(svgFilePlayer);
                    Group svgImagePlayer2 = loader.loadSvg(svgFilePlayer2);
                    Group svgImagePlayer3 = loader.loadSvg(svgFilePlayer3);
                    Group svgImagePlayer4 = loader.loadSvg(svgFilePlayer4);
                    Group svgImagePlayer5 = loader.loadSvg(svgFilePlayer5);
                    Group svgImagePlayer6 = loader.loadSvg(svgFilePlayer6);
                    Group svgImagePlayer7 = loader.loadSvg(svgFilePlayer7);
                    Group svgImagePlayer8 = loader.loadSvg(svgFilePlayer8);
                    Group svgImagePlayer9 = loader.loadSvg(svgFilePlayer9);
                    Group svgImagePlayer_Hover = loader.loadSvg(svgFilePlayer_Hover);
                    Group svgImagePlayer2_Hover = loader.loadSvg(svgFilePlayer2_Hover);
                    Group svgImagePlayer3_Hover = loader.loadSvg(svgFilePlayer3_Hover);
                    Group svgImagePlayer4_Hover = loader.loadSvg(svgFilePlayer4_Hover);
                    Group svgImagePlayer5_Hover = loader.loadSvg(svgFilePlayer5_Hover);
                    Group svgImagePlayer6_Hover = loader.loadSvg(svgFilePlayer6_Hover);
                    Group svgImagePlayer7_Hover = loader.loadSvg(svgFilePlayer7_Hover);
                    Group svgImagePlayer8_Hover = loader.loadSvg(svgFilePlayer8_Hover);
                    Group svgImagePlayer9_Hover = loader.loadSvg(svgFilePlayer9_Hover);

                    svgBack.setScaleX(.1);
                    svgBack.setScaleY(.1);
                    svgBack_Hover.setScaleX(.1);
                    svgBack_Hover.setScaleY(.1);
                    svgHome.setScaleX(.1);
                    svgHome.setScaleY(.1);
                    svgHome_Hover.setScaleX(.1);
                    svgHome_Hover.setScaleY(.1);
                    svgHome1.setScaleX(.1);
                    svgHome1.setScaleY(.1);
                    svgHome1_Hover.setScaleX(.1);
                    svgHome1_Hover.setScaleY(.1);
                    svgRetry.setScaleX(.1);
                    svgRetry.setScaleY(.1);
                    svgRetry_Hover.setScaleX(.1);
                    svgRetry_Hover.setScaleY(.1);
                    svgRetry1.setScaleX(.1);
                    svgRetry1.setScaleY(.1);
                    svgRetry1_Hover.setScaleX(.1);
                    svgRetry1_Hover.setScaleY(.1);
                    svgPause.setScaleX(.04);
                    svgPause.setScaleY(.04);
                    svgPause_Hover.setScaleX(.04);
                    svgPause_Hover.setScaleY(.04);
                    svgMenu.setScaleX(.04);
                    svgMenu.setScaleY(.04);
                    svgMenu_Hover.setScaleX(.04);
                    svgMenu_Hover.setScaleY(.04);

                    svgImagePlayer.setScaleX(.05);
                    svgImagePlayer.setScaleY(.05);

                    svgImagePlayer2.setScaleX(.05);
                    svgImagePlayer2.setScaleY(.05);

                    svgImagePlayer3.setScaleX(.05);
                    svgImagePlayer3.setScaleY(.05);

                    svgImagePlayer4.setScaleX(.05);
                    svgImagePlayer4.setScaleY(.05);

                    svgImagePlayer5.setScaleX(.05);
                    svgImagePlayer5.setScaleY(.05);

                    svgImagePlayer6.setScaleX(.05);
                    svgImagePlayer6.setScaleY(.05);

                    svgImagePlayer7.setScaleX(.05);
                    svgImagePlayer7.setScaleY(.05);

                    svgImagePlayer8.setScaleX(.05);
                    svgImagePlayer8.setScaleY(.05);

                    svgImagePlayer9.setScaleX(.05);
                    svgImagePlayer9.setScaleY(.05);

                    svgImagePlayer_Hover.setScaleX(.05);
                    svgImagePlayer_Hover.setScaleY(.05);

                    svgImagePlayer2_Hover.setScaleX(.05);
                    svgImagePlayer2_Hover.setScaleY(.05);

                    svgImagePlayer3_Hover.setScaleX(.05);
                    svgImagePlayer3_Hover.setScaleY(.05);

                    svgImagePlayer4_Hover.setScaleX(.05);
                    svgImagePlayer4_Hover.setScaleY(.05);

                    svgImagePlayer5_Hover.setScaleX(.05);
                    svgImagePlayer5_Hover.setScaleY(.05);

                    svgImagePlayer6_Hover.setScaleX(.05);
                    svgImagePlayer6_Hover.setScaleY(.05);

                    svgImagePlayer7_Hover.setScaleX(.05);
                    svgImagePlayer7_Hover.setScaleY(.05);

                    svgImagePlayer8_Hover.setScaleX(.05);
                    svgImagePlayer8_Hover.setScaleY(.05);

                    svgImagePlayer9_Hover.setScaleX(.05);
                    svgImagePlayer9_Hover.setScaleY(.05);

                    Group svgIconBack = new Group(svgBack);
                    Group svgIconBack_Hover = new Group(svgBack_Hover);
                    Group svgIconHome = new Group(svgHome);
                    Group svgIconHome_Hover = new Group(svgHome_Hover);
                    Group svgIconHome1 = new Group(svgHome1);
                    Group svgIconHome1_Hover = new Group(svgHome1_Hover);
                    Group svgIconRetry = new Group(svgRetry);
                    Group svgIconRetry_Hover = new Group(svgRetry_Hover);
                    Group svgIconRetry1 = new Group(svgRetry1);
                    Group svgIconRetry1_Hover = new Group(svgRetry1_Hover);
                    Group svgIconPause = new Group(svgPause);
                    Group svgIconPause_Hover = new Group(svgPause_Hover);
                    Group svgIconMenu = new Group(svgMenu);
                    Group svgIconMenu_Hover = new Group(svgMenu_Hover);

                    Group svgIconPlayer = new Group(svgImagePlayer);
                    Group svgIconPlayer2 = new Group(svgImagePlayer2);
                    Group svgIconPlayer3 = new Group(svgImagePlayer3);
                    Group svgIconPlayer4 = new Group(svgImagePlayer4);
                    Group svgIconPlayer5 = new Group(svgImagePlayer5);
                    Group svgIconPlayer6 = new Group(svgImagePlayer6);
                    Group svgIconPlayer7 = new Group(svgImagePlayer7);
                    Group svgIconPlayer8 = new Group(svgImagePlayer8);
                    Group svgIconPlayer9 = new Group(svgImagePlayer9);
                    Group svgIconPlayer_Hover = new Group(svgImagePlayer_Hover);
                    Group svgIconPlayer2_Hover = new Group(svgImagePlayer2_Hover);
                    Group svgIconPlayer3_Hover = new Group(svgImagePlayer3_Hover);
                    Group svgIconPlayer4_Hover = new Group(svgImagePlayer4_Hover);
                    Group svgIconPlayer5_Hover = new Group(svgImagePlayer5_Hover);
                    Group svgIconPlayer6_Hover = new Group(svgImagePlayer6_Hover);
                    Group svgIconPlayer7_Hover = new Group(svgImagePlayer7_Hover);
                    Group svgIconPlayer8_Hover = new Group(svgImagePlayer8_Hover);
                    Group svgIconPlayer9_Hover = new Group(svgImagePlayer9_Hover);

                    r3p1Icon.setGraphic(svgIconPlayer);
                    r3p2Icon.setGraphic(svgIconPlayer2);
                    r3p3Icon.setGraphic(svgIconPlayer3);
                    r3p4Icon.setGraphic(svgIconPlayer4);
                    r2p1Icon.setGraphic(svgIconPlayer5);
                    r2p2Icon.setGraphic(svgIconPlayer6);
                    r2p3Icon.setGraphic(svgIconPlayer7);
                    r1p1Icon.setGraphic(svgIconPlayer8);
                    r1p2Icon.setGraphic(svgIconPlayer9);

                    backButton.setGraphic(svgIconMenu);

                    b1.setGraphic(svgIconBack);
                    b2.setGraphic(svgIconRetry);
                    b3.setGraphic(svgIconHome);
                    b11.setGraphic(svgIconRetry1);
                    b21.setGraphic(svgIconHome1);
                    l4.setEffect(effectC_InnerShadow);
                    l3.setEffect(effectC_InnerShadow);

                    backButton.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        if (b111==0){

                            l1.setText("");
                            l2.setText("Pause");
                            backButton.setEffect(effectC_DropShadow);
                            backButton.setGraphic(svgIconPause_Hover);
                            backButton.setStyle("-fx-background-color: "+color+"; -fx-background-radius: 50%;");

                        }
                        else {


                            backButton.setGraphic(svgIconPause);

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        if (b111==0){

                            l1.setText("Memory");
                            l2.setText("Game");
                            backButton.setEffect(null);
                            backButton.setGraphic(svgIconMenu);
                            backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                        }else {

                            backButton.setEffect(null);
                            backButton.setGraphic(svgIconPause);

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        if (b111==0){
                            b111=1;
                            grid2.setVisible(true);
                            grid2.setDisable(false);

                            fadeOut.play();
                            fadeOut5.play();
                            fadeOut5_1.play();

                            fadeIn3.play();
                            fadeIn5_3.play();

                            fadeIn7.play();
                            fadeIn7_1.play();
                            fadeIn7_2.play();

                        }

                    });
                    backButton.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        fadeIn.play();

                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");
                        backButton.setGraphic(svgIconPause);

                    });

                    b1.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b1.setTextFill(Color.web("#d50000"));
                        b1.setEffect(effectC_DropShadow);
                        b1.setGraphic(svgIconBack_Hover);

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b1.setTextFill(Color.web("#3E3E3E"));
                        b1.setEffect(null);
                        b1.setGraphic(svgIconBack);

                    });
                    b1.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {
                        b111=0;
                        fadeIn.play();
                        fadeIn5.play();
                        fadeIn5_1.play();

                        fadeOut3.play();
                        fadeOut5_3.play();

                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                        grid2.setDisable(true);
                        backButton.setGraphic(svgIconMenu);
                        backButton.setStyle("-fx-background-color: "+color2+"; -fx-background-radius: 50%;");

                    });

                    b2.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b2.setTextFill(Color.web("#d50000"));
                        b2.setEffect(effectC_DropShadow);
                        b2.setGraphic(svgIconRetry_Hover);

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b2.setTextFill(Color.web("#3E3E3E"));
                        b2.setEffect(null);
                        b2.setGraphic(svgIconRetry);

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut2.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_3.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                    });
                    b2.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            backClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b3.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b3.setTextFill(Color.web("#d50000"));
                        b3.setEffect(effectC_DropShadow);
                        b3.setGraphic(svgIconHome_Hover);

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b3.setTextFill(Color.web("#3E3E3E"));
                        b3.setEffect(null);
                        b3.setGraphic(svgIconHome);

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut2.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_3.play();
                        fadeOut7.play();
                        fadeOut7_1.play();
                        fadeOut7_2.play();

                    });
                    b3.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            HomeClicked();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b11.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b11.setTextFill(Color.web("#d50000"));
                        b11.setEffect(effectC_DropShadow);
                        b11.setGraphic(svgIconRetry1_Hover);

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b11.setTextFill(Color.web("#3E3E3E"));
                        b11.setEffect(null);
                        b11.setGraphic(svgIconRetry1);

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_2.play();
                        fadeOut6.play();
                        fadeOut6_1.play();

                    });
                    b11.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            backClicked2();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                    b21.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {

                        b21.setTextFill(Color.web("#d50000"));
                        b21.setEffect(effectC_DropShadow);
                        b21.setGraphic(svgIconHome1_Hover);

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {

                        b21.setTextFill(Color.web("#3E3E3E"));
                        b21.setEffect(null);
                        b21.setGraphic(svgIconHome1);

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

                        fadeOut.play();
                        fadeOut4.play();
                        fadeOut4_1.play();
                        fadeOut5_2.play();
                        fadeOut6.play();
                        fadeOut6_1.play();

                    });
                    b21.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> {

                        try {
                            HomeClicked2();
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }

                    });

                }

            }

        }

    }

    @Override
    public void setMode(GameMode gameMode, Image theme) throws IOException {
        super.setMode(gameMode, theme);
    }

    public void multiplayerStart(){
        createImageViews(grid,imageViews);
        createImages(cards);
        shuffleCards(imageViews);
        setImages(imageViews,cards);

        player();
        playerg2();
        playerg3();
        playerg4();

    }
    //PLAYER INIT
    @Override
    public void player() {
        super.player();
    }
    @Override
    public void playerg2() {
        super.playerg2();
    }
    @Override
    public void playerg3() {
        super.playerg3();
    }
    @Override
    public void playerg4() {
        super.playerg4();
    }

    @Override
    public void clickEvent(ImageView imageView, Card card) {
        super.clickEvent(imageView,card);

        clickedImageView = imageView;
        clicks++;
        pplay++;

        File f = new File("gamemode.properties");
        if(f.exists()) {
            InputStream input = null;
            try {
                input = new FileInputStream("gamemode.properties");
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            try {
                properties.load(input);
            } catch (IOException e) {
                e.printStackTrace();
            }

            int theme = Integer.parseInt(properties.getProperty("TMode"));
            int tColor = Integer.parseInt(properties.getProperty("TColor"));

            if(theme==1){

                if (tColor==1) {

                    color2 = "#007aff";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,104,217), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,140,255), 10, 0, -5, -5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,104,217), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,140,255), 10, 0, -5, -5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFilePlayer = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer2 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer3 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer4 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer5 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer6 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer7 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer8 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer9 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");

                    svgFilePlayer_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer2_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer3_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer4_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer5_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer6_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer7_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer8_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer9_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");

                }
                else if (tColor==2) {

                    color2 = "#fff44f";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.web("#d9cf43"), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.web("#ffff5b"), 10, 0, -5, -5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.web("#d9cf43"), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.web("#ffff5b"), 10, 0, -5, -5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFilePlayer = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer2 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer3 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer4 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer5 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer6 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer7 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer8 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer9 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");

                    svgFilePlayer_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer2_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer3_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer4_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer5_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer6_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer7_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer8_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer9_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");

                }
                else if (tColor==3) {

                    color2 = "#00c853";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,200,83), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,230,95), 10, 0, -5, -5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,200,83), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,230,95), 10, 0, -5, -5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFilePlayer = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer2 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer3 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer4 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer5 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer6 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer7 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer8 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer9 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");

                    svgFilePlayer_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer2_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer3_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer4_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer5_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer6_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer7_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer8_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer9_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");

                }
                else if (tColor==4) {

                    color2 = "#d50000";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(181,0,0), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(245,0,0), 10, 0, -5, -5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(181,0,0), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(245,0,0), 10, 0, -5, -5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFilePlayer = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer2 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer3 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer4 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer5 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer6 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer7 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer8 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");
                    svgFilePlayer9 = getClass().getResourceAsStream("../../../resources/svg/user/user.svg");

                    svgFilePlayer_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer2_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer3_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer4_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer5_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer6_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer7_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer8_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");
                    svgFilePlayer9_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_blue.svg");

                }

            }
            else if(theme==2){

                color = "#181818";

                if (tColor==1) {

                    color2 = "#004fcb";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,67,173), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,91,233), 10, 0, -5, -5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,67,173), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,91,233), 10, 0, -5, -5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFilePlayer = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer2 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer3 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer4 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer5 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer6 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer7 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer8 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer9 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");

                    svgFilePlayer_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer2_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer3_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer4_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer5_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer6_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer7_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer8_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");
                    svgFilePlayer9_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dblue.svg");

                }
                else if (tColor==2) {

                    color2 = "#c9c208";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(169,173,0), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(229,235,0), 10, 0, -5, -5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(169,173,0), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(229,235,0), 10, 0, -5, -5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFilePlayer = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer2 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer3 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer4 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer5 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer6 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer7 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer8 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer9 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");

                    svgFilePlayer_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dyellow.svg");
                    svgFilePlayer2_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dyellow.svg");
                    svgFilePlayer3_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dyellow.svg");
                    svgFilePlayer4_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dyellow.svg");
                    svgFilePlayer5_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dyellow.svg");
                    svgFilePlayer6_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dyellow.svg");
                    svgFilePlayer7_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dyellow.svg");
                    svgFilePlayer8_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dyellow.svg");
                    svgFilePlayer9_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dyellow.svg");

                }
                else if (tColor==3) {

                    color2 = "#006500";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,86,0), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(0,116,0), 10, 0, -5, -5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,86,0), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(0,116,0), 10, 0, -5, -5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFilePlayer = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer2 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer3 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer4 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer5 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer6 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer7 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer8 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer9 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");

                    svgFilePlayer_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dgreen.svg");
                    svgFilePlayer2_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dgreen.svg");
                    svgFilePlayer3_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dgreen.svg");
                    svgFilePlayer4_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dgreen.svg");
                    svgFilePlayer5_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dgreen.svg");
                    svgFilePlayer6_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dgreen.svg");
                    svgFilePlayer7_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dgreen.svg");
                    svgFilePlayer8_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dgreen.svg");
                    svgFilePlayer9_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dgreen.svg");


                }
                else if (tColor==4) {

                    color2 = "#9b0000";

                    effectC_DropShadowADD= new DropShadow(BlurType.GAUSSIAN, Color.rgb(155,0,0), 10, 0, 5, 5);
                    effectC_DropShadow= new DropShadow(BlurType.GAUSSIAN, Color.rgb(178,0,0), 10, 0, -5, -5);
                    effectC_DropShadow.setInput(effectC_DropShadowADD);

                    effectC_InnerShadowADD = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(155,0,0), 10, 0, 5, 5);
                    effectC_InnerShadow = new InnerShadow(BlurType.GAUSSIAN, Color.rgb(178,0,0), 10, 0, -5, -5);
                    effectC_InnerShadow.setInput(effectC_InnerShadowADD);

                    svgFilePlayer = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer2 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer3 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer4 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer5 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer6 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer7 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer8 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");
                    svgFilePlayer9 = getClass().getResourceAsStream("../../../resources/svg/user/user_d.svg");

                    svgFilePlayer_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dred.svg");
                    svgFilePlayer2_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dred.svg");
                    svgFilePlayer3_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dred.svg");
                    svgFilePlayer4_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dred.svg");
                    svgFilePlayer5_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dred.svg");
                    svgFilePlayer6_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dred.svg");
                    svgFilePlayer7_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dred.svg");
                    svgFilePlayer8_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dred.svg");
                    svgFilePlayer9_Hover = getClass().getResourceAsStream("../../../resources/svg/user/user_dred.svg");

                }

            }

        }

        Group svgImagePlayer = loader.loadSvg(svgFilePlayer);
        Group svgImagePlayer2 = loader.loadSvg(svgFilePlayer2);
        Group svgImagePlayer3 = loader.loadSvg(svgFilePlayer3);
        Group svgImagePlayer4 = loader.loadSvg(svgFilePlayer4);
        Group svgImagePlayer5 = loader.loadSvg(svgFilePlayer5);
        Group svgImagePlayer6 = loader.loadSvg(svgFilePlayer6);
        Group svgImagePlayer7 = loader.loadSvg(svgFilePlayer7);
        Group svgImagePlayer8 = loader.loadSvg(svgFilePlayer8);
        Group svgImagePlayer9 = loader.loadSvg(svgFilePlayer9);
        Group svgImagePlayer_Hover = loader.loadSvg(svgFilePlayer_Hover);
        Group svgImagePlayer2_Hover = loader.loadSvg(svgFilePlayer2_Hover);
        Group svgImagePlayer3_Hover = loader.loadSvg(svgFilePlayer3_Hover);
        Group svgImagePlayer4_Hover = loader.loadSvg(svgFilePlayer4_Hover);
        Group svgImagePlayer5_Hover = loader.loadSvg(svgFilePlayer5_Hover);
        Group svgImagePlayer6_Hover = loader.loadSvg(svgFilePlayer6_Hover);
        Group svgImagePlayer7_Hover = loader.loadSvg(svgFilePlayer7_Hover);
        Group svgImagePlayer8_Hover = loader.loadSvg(svgFilePlayer8_Hover);
        Group svgImagePlayer9_Hover = loader.loadSvg(svgFilePlayer9_Hover);

        svgImagePlayer.setScaleX(.05);
        svgImagePlayer.setScaleY(.05);

        svgImagePlayer2.setScaleX(.05);
        svgImagePlayer2.setScaleY(.05);

        svgImagePlayer3.setScaleX(.05);
        svgImagePlayer3.setScaleY(.05);

        svgImagePlayer4.setScaleX(.05);
        svgImagePlayer4.setScaleY(.05);

        svgImagePlayer5.setScaleX(.05);
        svgImagePlayer5.setScaleY(.05);

        svgImagePlayer6.setScaleX(.05);
        svgImagePlayer6.setScaleY(.05);

        svgImagePlayer7.setScaleX(.05);
        svgImagePlayer7.setScaleY(.05);

        svgImagePlayer8.setScaleX(.05);
        svgImagePlayer8.setScaleY(.05);

        svgImagePlayer9.setScaleX(.05);
        svgImagePlayer9.setScaleY(.05);

        svgImagePlayer_Hover.setScaleX(.05);
        svgImagePlayer_Hover.setScaleY(.05);

        svgImagePlayer2_Hover.setScaleX(.05);
        svgImagePlayer2_Hover.setScaleY(.05);

        svgImagePlayer3_Hover.setScaleX(.05);
        svgImagePlayer3_Hover.setScaleY(.05);

        svgImagePlayer4_Hover.setScaleX(.05);
        svgImagePlayer4_Hover.setScaleY(.05);

        svgImagePlayer5_Hover.setScaleX(.05);
        svgImagePlayer5_Hover.setScaleY(.05);

        svgImagePlayer6_Hover.setScaleX(.05);
        svgImagePlayer6_Hover.setScaleY(.05);

        svgImagePlayer7_Hover.setScaleX(.05);
        svgImagePlayer7_Hover.setScaleY(.05);

        svgImagePlayer8_Hover.setScaleX(.05);
        svgImagePlayer8_Hover.setScaleY(.05);

        svgImagePlayer9_Hover.setScaleX(.05);
        svgImagePlayer9_Hover.setScaleY(.05);

        Group svgIconPlayer = new Group(svgImagePlayer);
        Group svgIconPlayer2 = new Group(svgImagePlayer2);
        Group svgIconPlayer3 = new Group(svgImagePlayer3);
        Group svgIconPlayer4 = new Group(svgImagePlayer4);
        Group svgIconPlayer5 = new Group(svgImagePlayer5);
        Group svgIconPlayer6 = new Group(svgImagePlayer6);
        Group svgIconPlayer7 = new Group(svgImagePlayer7);
        Group svgIconPlayer8 = new Group(svgImagePlayer8);
        Group svgIconPlayer9 = new Group(svgImagePlayer9);
        Group svgIconPlayer_Hover = new Group(svgImagePlayer_Hover);
        Group svgIconPlayer2_Hover = new Group(svgImagePlayer2_Hover);
        Group svgIconPlayer3_Hover = new Group(svgImagePlayer3_Hover);
        Group svgIconPlayer4_Hover = new Group(svgImagePlayer4_Hover);
        Group svgIconPlayer5_Hover = new Group(svgImagePlayer5_Hover);
        Group svgIconPlayer6_Hover = new Group(svgImagePlayer6_Hover);
        Group svgIconPlayer7_Hover = new Group(svgImagePlayer7_Hover);
        Group svgIconPlayer8_Hover = new Group(svgImagePlayer8_Hover);
        Group svgIconPlayer9_Hover = new Group(svgImagePlayer9_Hover);

        //findWinner();
        if (gameMode.getRivalsNumber() == 1){

            r1p1Label.setText(""+score.getFoundCards());
            r1p2Label.setText(""+score2.getFoundCards2());

        }
        else if (gameMode.getRivalsNumber() == 2){

            r2p1Label.setText(""+score.getFoundCards());
            r2p2Label.setText(""+score2.getFoundCards2());
            r2p3Label.setText(""+score3.getFoundCards3());

        }
        else if (gameMode.getRivalsNumber() == 3){

            r3p1Label.setText(""+score.getFoundCards());
            r3p2Label.setText(""+score2.getFoundCards2());
            r3p3Label.setText(""+score3.getFoundCards3());
            r3p4Label.setText(""+score4.getFoundCards4());

        }

        if (gameMode.getRivalsNumber() == 1 && clicks == 0) {
            enableAll();
            player();

            r1p1Icon.setGraphic(svgIconPlayer8_Hover);
            r1p2Icon.setGraphic(svgIconPlayer9);
        }
        else if (gameMode.getRivalsNumber() == 1 && clicks == 1) {
            r1p1Icon.setGraphic(svgIconPlayer8_Hover);
            enable(clickedImageView);
        }
        else if (gameMode.getRivalsNumber() == 1 && clicks == 2 && !cardsMatch) {
            playerg2();
            r1p1Icon.setGraphic(svgIconPlayer8);
            r1p2Icon.setGraphic(svgIconPlayer9_Hover);
            disableAll();
            Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1.2), event -> {
                imageView1.setImage(card1.getBackground());
                imageView2.setImage(card2.getBackground());
                imageView1.setDisable(false);
                imageView2.setDisable(false);
                enableAll();

            }));
            timeline.play();

        }
        else if (gameMode.getRivalsNumber() == 1 && clicks == 2 && cardsMatch) {
            player();
            clicks = 0;
            r1p1Icon.setGraphic(svgIconPlayer8_Hover);
            r1p2Icon.setGraphic(svgIconPlayer9);
            disableAll();
            Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1.2), event -> {
                imageView1.setImage(card1.getBackground());
                imageView2.setImage(card2.getBackground());
                imageView1.setDisable(false);
                imageView2.setDisable(false);
                enableAll();

            }));
            timeline.play();
        }
        else if (gameMode.getRivalsNumber() == 1 && clicks == 3) {
            r1p2Icon.setGraphic(svgIconPlayer9_Hover);
            enable(clickedImageView);
        }
        else if (gameMode.getRivalsNumber() == 1 && clicks == 4 && !cardsMatch) {
            player();
            clicks = 0;

            r1p1Icon.setGraphic(svgIconPlayer8_Hover);
            r1p2Icon.setGraphic(svgIconPlayer9);
            disableAll();
            Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1.2), event -> {
                imageView1.setImage(card1.getBackground());
                imageView2.setImage(card2.getBackground());
                imageView1.setDisable(false);
                imageView2.setDisable(false);
                enableAll();

            }));
            timeline.play();
        }
        else if (gameMode.getRivalsNumber() == 1 && clicks == 4 && cardsMatch) {
            playerg2();
            clicks = 2-clicks;
            r1p1Icon.setGraphic(svgIconPlayer8);
            r1p2Icon.setGraphic(svgIconPlayer9_Hover);
            disableAll();
            Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1.2), event -> {
                imageView1.setImage(card1.getBackground());
                imageView2.setImage(card2.getBackground());
                imageView1.setDisable(false);
                imageView2.setDisable(false);
                enableAll();

            }));
            timeline.play();

        }

        if (gameMode.getRivalsNumber() == 2 && clicks == 0) {
            enableAll();
            player();

            r2p1Icon.setGraphic(svgIconPlayer5_Hover);
            r2p2Icon.setGraphic(svgIconPlayer6);
            r2p3Icon.setGraphic(svgIconPlayer7);

        }
        else if (gameMode.getRivalsNumber() == 2 && clicks == 1) {
            r2p1Icon.setGraphic(svgIconPlayer5_Hover);
            enable(clickedImageView);
        }
        else if (gameMode.getRivalsNumber() == 2 && clicks == 2 && !cardsMatch) {
            playerg2();
            r2p1Icon.setGraphic(svgIconPlayer5);
            r2p2Icon.setGraphic(svgIconPlayer6_Hover);
            r2p3Icon.setGraphic(svgIconPlayer7);
            disableAll();
            Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1.2), event -> {
                imageView1.setImage(card1.getBackground());
                imageView2.setImage(card2.getBackground());
                imageView1.setDisable(false);
                imageView2.setDisable(false);
                enableAll();

            }));
            timeline.play();
        }
        else if (gameMode.getRivalsNumber() == 2 && clicks == 2 && cardsMatch) {
            player();
            clicks = 0;
            r2p1Icon.setGraphic(svgIconPlayer5_Hover);
            r2p2Icon.setGraphic(svgIconPlayer6);
            r2p3Icon.setGraphic(svgIconPlayer7);
            disableAll();
            Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1.2), event -> {
                imageView1.setImage(card1.getBackground());
                imageView2.setImage(card2.getBackground());
                imageView1.setDisable(false);
                imageView2.setDisable(false);
                enableAll();

            }));
            timeline.play();
        }
        else if (gameMode.getRivalsNumber() == 2 && clicks == 3) {
            r2p2Icon.setGraphic(svgIconPlayer6_Hover);
            enable(clickedImageView);
        }
        else if (gameMode.getRivalsNumber() == 2 && clicks == 4 && !cardsMatch) {
            playerg3();
            r2p1Icon.setGraphic(svgIconPlayer5);
            r2p2Icon.setGraphic(svgIconPlayer6);
            r2p3Icon.setGraphic(svgIconPlayer7_Hover);
            disableAll();
            Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1.2), event -> {
                imageView1.setImage(card1.getBackground());
                imageView2.setImage(card2.getBackground());
                imageView1.setDisable(false);
                imageView2.setDisable(false);
                enableAll();

            }));
            timeline.play();

        }
        else if (gameMode.getRivalsNumber() == 2 && clicks == 4 && cardsMatch) {
            playerg2();
            clicks = 2;
            r2p1Icon.setGraphic(svgIconPlayer5);
            r2p2Icon.setGraphic(svgIconPlayer6_Hover);
            r2p3Icon.setGraphic(svgIconPlayer7);
            disableAll();
            Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1.2), event -> {
                imageView1.setImage(card1.getBackground());
                imageView2.setImage(card2.getBackground());
                imageView1.setDisable(false);
                imageView2.setDisable(false);
                enableAll();

            }));
            timeline.play();

        }
        else if (gameMode.getRivalsNumber() == 2 && clicks == 5) {
            r2p3Icon.setGraphic(svgIconPlayer7_Hover);
            enable(clickedImageView);
        }
        else if (gameMode.getRivalsNumber() == 2 && clicks == 6 && !cardsMatch) {
            player();
            clicks = 0;

            r2p1Icon.setGraphic(svgIconPlayer5_Hover);
            r2p2Icon.setGraphic(svgIconPlayer6);
            r2p3Icon.setGraphic(svgIconPlayer7);
            disableAll();
            Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1.2), event -> {
                imageView1.setImage(card1.getBackground());
                imageView2.setImage(card2.getBackground());
                imageView1.setDisable(false);
                imageView2.setDisable(false);
                enableAll();

            }));
            timeline.play();

        }
        else if (gameMode.getRivalsNumber() == 2 && clicks == 6 && cardsMatch) {
            playerg3();
            clicks = 4;
            r2p1Icon.setGraphic(svgIconPlayer5);
            r2p2Icon.setGraphic(svgIconPlayer6);
            r2p3Icon.setGraphic(svgIconPlayer7_Hover);
            disableAll();
            Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1.2), event -> {
                imageView1.setImage(card1.getBackground());
                imageView2.setImage(card2.getBackground());
                imageView1.setDisable(false);
                imageView2.setDisable(false);
                enableAll();

            }));
            timeline.play();

        }

        if (gameMode.getRivalsNumber() == 3 && clicks == 0) {
            enableAll();
            player();

            r3p1Icon.setGraphic(svgIconPlayer_Hover);
            r3p2Icon.setGraphic(svgIconPlayer2);
            r3p3Icon.setGraphic(svgIconPlayer3);
            r3p4Icon.setGraphic(svgIconPlayer4);

        }
        else if (gameMode.getRivalsNumber() == 3 && clicks == 1) {
            r3p1Icon.setGraphic(svgIconPlayer_Hover);
            enable(clickedImageView);
        }
        else if (gameMode.getRivalsNumber() == 3 && clicks == 2 && !cardsMatch) {
            playerg2();
            r3p1Icon.setGraphic(svgIconPlayer);
            r3p2Icon.setGraphic(svgIconPlayer2_Hover);
            r3p3Icon.setGraphic(svgIconPlayer3);
            r3p4Icon.setGraphic(svgIconPlayer4);
            disableAll();
            Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1.2), event -> {
                imageView1.setImage(card1.getBackground());
                imageView2.setImage(card2.getBackground());
                imageView1.setDisable(false);
                imageView2.setDisable(false);
                enableAll();

            }));
            timeline.play();
        }
        else if (gameMode.getRivalsNumber() == 3 && clicks == 2 && cardsMatch) {
            player();
            clicks = 0;
            r3p1Icon.setGraphic(svgIconPlayer_Hover);
            r3p2Icon.setGraphic(svgIconPlayer2);
            r3p3Icon.setGraphic(svgIconPlayer3);
            r3p4Icon.setGraphic(svgIconPlayer4);
            disableAll();
            Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1.2), event -> {
                imageView1.setImage(card1.getBackground());
                imageView2.setImage(card2.getBackground());
                imageView1.setDisable(false);
                imageView2.setDisable(false);
                enableAll();

            }));
            timeline.play();
        }
        else if (gameMode.getRivalsNumber() == 3 && clicks == 3) {
            r3p2Icon.setGraphic(svgIconPlayer2_Hover);
            enable(clickedImageView);
        }
        else if (gameMode.getRivalsNumber() == 3 && clicks == 4 && !cardsMatch) {
            playerg3();

            r3p1Icon.setGraphic(svgIconPlayer);
            r3p2Icon.setGraphic(svgIconPlayer2);
            r3p3Icon.setGraphic(svgIconPlayer3_Hover);
            r3p4Icon.setGraphic(svgIconPlayer4);
            disableAll();
            Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1.2), event -> {
                imageView1.setImage(card1.getBackground());
                imageView2.setImage(card2.getBackground());
                imageView1.setDisable(false);
                imageView2.setDisable(false);
                enableAll();

            }));
            timeline.play();

        }
        else if (gameMode.getRivalsNumber() == 3 && clicks == 4 && cardsMatch) {
            playerg2();
            clicks = 2;

            r3p1Icon.setGraphic(svgIconPlayer);
            r3p2Icon.setGraphic(svgIconPlayer2_Hover);
            r3p3Icon.setGraphic(svgIconPlayer3);
            r3p4Icon.setGraphic(svgIconPlayer4);
            disableAll();
            Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1.2), event -> {
                imageView1.setImage(card1.getBackground());
                imageView2.setImage(card2.getBackground());
                imageView1.setDisable(false);
                imageView2.setDisable(false);
                enableAll();

            }));
            timeline.play();

        }
        else if (gameMode.getRivalsNumber() == 3 && clicks == 5) {
            r3p3Icon.setGraphic(svgIconPlayer3_Hover);
            enable(clickedImageView);
        }
        else if (gameMode.getRivalsNumber() == 3 && clicks == 6 && !cardsMatch) {
            playerg4();
            r3p1Icon.setGraphic(svgIconPlayer);
            r3p2Icon.setGraphic(svgIconPlayer2);
            r3p3Icon.setGraphic(svgIconPlayer3);
            r3p4Icon.setGraphic(svgIconPlayer4_Hover);
            disableAll();
            Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1.2), event -> {
                imageView1.setImage(card1.getBackground());
                imageView2.setImage(card2.getBackground());
                imageView1.setDisable(false);
                imageView2.setDisable(false);
                enableAll();

            }));
            timeline.play();

        }
        else if (gameMode.getRivalsNumber() == 3 && clicks == 6 && cardsMatch) {
            playerg3();
            clicks = 4;
            r3p1Icon.setGraphic(svgIconPlayer);
            r3p2Icon.setGraphic(svgIconPlayer2);
            r3p3Icon.setGraphic(svgIconPlayer3_Hover);
            r3p4Icon.setGraphic(svgIconPlayer4);
            disableAll();
            Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1.2), event -> {
                imageView1.setImage(card1.getBackground());
                imageView2.setImage(card2.getBackground());
                imageView1.setDisable(false);
                imageView2.setDisable(false);
                enableAll();

            }));
            timeline.play();

        }
        else if (gameMode.getRivalsNumber() == 3 && clicks == 7) {
            r3p4Icon.setGraphic(svgIconPlayer4_Hover);
            enable(clickedImageView);
        }
        else if (gameMode.getRivalsNumber() == 3 && clicks == 8 && !cardsMatch) {
            player();
            clicks = 0;

            r3p1Icon.setGraphic(svgIconPlayer_Hover);
            r3p2Icon.setGraphic(svgIconPlayer2);
            r3p3Icon.setGraphic(svgIconPlayer3);
            r3p4Icon.setGraphic(svgIconPlayer4);

            disableAll();
            Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1.2), event -> {
                imageView1.setImage(card1.getBackground());
                imageView2.setImage(card2.getBackground());
                imageView1.setDisable(false);
                imageView2.setDisable(false);
                enableAll();

            }));
            timeline.play();

        }
        else if (gameMode.getRivalsNumber() == 3 && clicks == 8 && cardsMatch) {
            playerg4();
            clicks = 6;

            r3p1Icon.setGraphic(svgIconPlayer);
            r3p2Icon.setGraphic(svgIconPlayer2);
            r3p3Icon.setGraphic(svgIconPlayer3);
            r3p4Icon.setGraphic(svgIconPlayer4_Hover);

            disableAll();
            Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1.2), event -> {
                imageView1.setImage(card1.getBackground());
                imageView2.setImage(card2.getBackground());
                imageView1.setDisable(false);
                imageView2.setDisable(false);
                enableAll();

            }));
            timeline.play();

        }

        if ( foundCards.size() == gameMode.getSize() && !gameMode.getGlobalMode().equals("SingleMode")) {
            Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(3),event -> eraseCards(grid)));
            timeline.play();

            grid21.setVisible(true);
            grid21.setDisable(false);

            ///
            FadeTransition fadeIn = new FadeTransition();//Back button
            FadeTransition fadeIn2 = new FadeTransition();//BG-g
            FadeTransition fadeIn3 = new FadeTransition();//BG-g1
            FadeTransition fadeIn4 = new FadeTransition();//PANELex
            FadeTransition fadeIn4_1 = new FadeTransition();//PANELex2
            FadeTransition fadeIn5_2 = new FadeTransition();//l3
            FadeTransition fadeIn6 = new FadeTransition();//b11
            FadeTransition fadeIn6_1 = new FadeTransition();//b21

            ///
            FadeTransition fadeOut = new FadeTransition();//Back button
            FadeTransition fadeOut2 = new FadeTransition();//BG
            FadeTransition fadeOut3 = new FadeTransition();//BG
            FadeTransition fadeOut4 = new FadeTransition();//PANELex1
            FadeTransition fadeOut4_1 = new FadeTransition();//PANELex2
            FadeTransition fadeOut5 = new FadeTransition();//l1
            FadeTransition fadeOut5_1 = new FadeTransition();//l2
            FadeTransition fadeOut5_2 = new FadeTransition();//l3
            FadeTransition fadeOut6 = new FadeTransition();//b11
            FadeTransition fadeOut6_1 = new FadeTransition();//b21

            fadeIn.setDuration(Duration.millis(500));//BG
            fadeIn2.setDuration(Duration.millis(500));//BG
            fadeIn3.setDuration(Duration.millis(500));//BG
            fadeIn4.setDuration(Duration.millis(750));//PANEL1
            fadeIn4_1.setDuration(Duration.millis(800));//PANEL2
            fadeIn5_2.setDuration(Duration.millis(400));//l3
            fadeIn6.setDuration(Duration.millis(100));//b11
            fadeIn6_1.setDuration(Duration.millis(200));//b21

            fadeOut.setDuration(Duration.millis(500));//BG
            fadeOut2.setDuration(Duration.millis(500));//BG
            fadeOut3.setDuration(Duration.millis(500));//BG
            fadeOut4.setDuration(Duration.millis(750));//PANEL1
            fadeOut4_1.setDuration(Duration.millis(800));//
            fadeOut5.setDuration(Duration.millis(500));//l3
            fadeOut5_1.setDuration(Duration.millis(500));//l3
            fadeOut5_2.setDuration(Duration.millis(500));//l3
            fadeOut6.setDuration(Duration.millis(250));//b11
            fadeOut6_1.setDuration(Duration.millis(250));//b21

            fadeIn.setFromValue(0);
            fadeIn.setToValue(10);
            fadeIn2.setFromValue(0);
            fadeIn2.setToValue(10);
            fadeIn3.setFromValue(0);
            fadeIn3.setToValue(10);
            fadeIn4.setFromValue(0);
            fadeIn4.setToValue(10);
            fadeIn4_1.setFromValue(0);
            fadeIn4_1.setToValue(10);
            fadeIn5_2.setFromValue(0);
            fadeIn5_2.setToValue(10);
            fadeIn6.setFromValue(0);
            fadeIn6.setToValue(10);
            fadeIn6_1.setFromValue(0);
            fadeIn6_1.setToValue(10);

            fadeOut.setFromValue(10);
            fadeOut.setToValue(0);
            fadeOut2.setFromValue(10);
            fadeOut2.setToValue(0);
            fadeOut3.setFromValue(10);
            fadeOut3.setToValue(0);
            fadeOut4.setFromValue(10);
            fadeOut4.setToValue(0);
            fadeOut4_1.setFromValue(10);
            fadeOut4_1.setToValue(0);
            fadeOut5.setFromValue(10);
            fadeOut5.setToValue(0);
            fadeOut5_1.setFromValue(10);
            fadeOut5_1.setToValue(0);
            fadeOut5_2.setFromValue(10);
            fadeOut5_2.setToValue(0);
            fadeOut6.setFromValue(10);
            fadeOut6.setToValue(0);
            fadeOut6_1.setFromValue(10);
            fadeOut6_1.setToValue(0);

            fadeIn.setCycleCount(1);
            fadeIn2.setCycleCount(1);
            fadeIn3.setCycleCount(1);
            fadeIn4.setCycleCount(1);
            fadeIn4_1.setCycleCount(1);
            fadeIn5_2.setCycleCount(1);
            fadeIn6.setCycleCount(1);
            fadeIn6_1.setCycleCount(1);

            fadeOut.setCycleCount(1);
            fadeOut2.setCycleCount(1);
            fadeOut3.setCycleCount(1);
            fadeOut4.setCycleCount(1);
            fadeOut4_1.setCycleCount(1);
            fadeOut5.setCycleCount(1);
            fadeOut5_1.setCycleCount(1);
            fadeOut5_2.setCycleCount(1);
            fadeOut6.setCycleCount(1);
            fadeOut6_1.setCycleCount(1);

            fadeIn.setNode(backButton);
            fadeIn2.setNode(grid);
            fadeIn3.setNode(grid21);
            fadeIn5_2.setNode(l3);
            fadeIn6.setNode(b11);
            fadeIn6_1.setNode(b21);

            fadeOut.setNode(backButton);
            fadeOut2.setNode(grid);
            fadeOut3.setNode(grid21);
            fadeOut5.setNode(l1);
            fadeOut5_1.setNode(l2);
            fadeOut5_2.setNode(l3);
            fadeOut6.setNode(b11);
            fadeOut6_1.setNode(b21);

            fadeOut.play();
            fadeOut5.play();
            fadeOut5_1.play();
            fadeOut.play();
            fadeIn3.play();
            fadeIn5_2.play();
            fadeIn6.play();
            fadeIn6_1.play();

            if (gameMode.getRivalsNumber()==1){

                if(gameMode.getMode() == 1){
                    int ss = Integer.parseInt(properties2.getProperty("MultiplayerWins1"));
                    if (ss==0){

                        ss=1;

                    }

                    int ss1 = score.getFoundCards();
                    int ss2 = score2.getFoundCards2();
                    if (ss1>ss2) {

                        l3.setText("PLAYER 1 WIN");

                        if (ss1>ss) {
                            properties2.setProperty("MultiplayerWins1", Integer.toString(ss1));
                        }

                    }
                    if (ss2>ss1) {

                        l3.setText("PLAYER 2 WIN");

                        if (ss2>ss) {
                            properties2.setProperty("MultiplayerWins1", Integer.toString(ss2));
                        }

                    }

                }
                else if(gameMode.getMode() == 2){

                    int ss = Integer.parseInt(properties2.getProperty("MultiplayerWins2"));
                    if (ss==0){

                        ss=1;

                    }

                    int ss1 = score.getFoundCards();
                    int ss2 = score2.getFoundCards2();
                    if (ss1>ss2) {

                        l3.setText("PLAYER 1 WIN");

                        if (ss1>ss) {
                            properties2.setProperty("MultiplayerWins2", Integer.toString(ss1));
                        }

                    }
                    if (ss2>ss1) {

                        l3.setText("PLAYER 2 WIN");

                        if (ss2>ss) {
                            properties2.setProperty("MultiplayerWins2", Integer.toString(ss2));
                        }

                    }

                }
                else if(gameMode.getMode() == 3){

                    int ss = Integer.parseInt(properties2.getProperty("MultiplayerWins3"));
                    if (ss==0){

                        ss=1;

                    }

                    int ss1 = score.getFoundCards();
                    int ss2 = score2.getFoundCards2();
                    if (ss1>ss2) {

                        l3.setText("PLAYER 1 WIN");

                        if (ss1>ss) {
                            properties2.setProperty("MultiplayerWins3", Integer.toString(ss1));
                        }

                    }
                    if (ss2>ss1) {

                        l3.setText("PLAYER 2 WIN");

                        if (ss2>ss) {
                            properties2.setProperty("MultiplayerWins3", Integer.toString(ss2));
                        }

                    }

                }
                else if(gameMode.getMode() == 4){

                    int ss = Integer.parseInt(properties2.getProperty("MultiplayerWins4"));
                    if (ss==0){

                        ss=1;

                    }

                    int ss1 = score.getFoundCards();
                    int ss2 = score2.getFoundCards2();
                    if (ss1>ss2) {

                        l3.setText("PLAYER 1 WIN");

                        if (ss1>ss) {
                            properties2.setProperty("MultiplayerWins4", Integer.toString(ss1));
                        }

                    }
                    if (ss2>ss1) {

                        l3.setText("PLAYER 2 WIN");

                        if (ss2>ss) {
                            properties2.setProperty("MultiplayerWins4", Integer.toString(ss2));
                        }

                    }

                }

            }
            else if (gameMode.getRivalsNumber()==2){

                if(gameMode.getMode() == 1){
                    int ss = Integer.parseInt(properties2.getProperty("MultiplayerWins1"));
                    if (ss==0){

                        ss=1;

                    }

                    int ss1 = score.getFoundCards();
                    int ss2 = score2.getFoundCards2();
                    int ss3 = score3.getFoundCards3();

                    if (ss1>ss2 && ss1>ss3) {

                        l3.setText("PLAYER 1 WIN");

                        if (ss1>ss) {
                            properties2.setProperty("MultiplayerWins1", Integer.toString(ss1));
                        }

                    }
                    if (ss2>ss1 && ss2>ss3) {

                        l3.setText("PLAYER 2 WIN");

                        if (ss2>ss) {
                            properties2.setProperty("MultiplayerWins1", Integer.toString(ss2));
                        }

                    }
                    if (ss3>ss1 && ss3>ss2) {

                        l3.setText("PLAYER 3 WIN");

                        if (ss3>ss) {

                            properties2.setProperty("MultiplayerWins1", Integer.toString(ss3));
                        }

                    }

                }
                else if(gameMode.getMode() == 2){

                    int ss = Integer.parseInt(properties2.getProperty("MultiplayerWins2"));
                    if (ss==0){

                        ss=1;

                    }

                    int ss1 = score.getFoundCards();
                    int ss2 = score2.getFoundCards2();
                    int ss3 = score3.getFoundCards3();

                    if (ss1>ss2 && ss1>ss3) {

                        l3.setText("PLAYER 1 WIN");

                        if (ss1>ss) {
                            properties2.setProperty("MultiplayerWins2", Integer.toString(ss1));
                        }

                    }
                    if (ss2>ss1 && ss2>ss3) {

                        l3.setText("PLAYER 2 WIN");

                        if (ss2>ss) {
                            properties2.setProperty("MultiplayerWins2", Integer.toString(ss2));
                        }

                    }
                    if (ss3>ss1 && ss3>ss2) {

                        l3.setText("PLAYER 3 WIN");

                        if (ss3>ss) {

                            properties2.setProperty("MultiplayerWins2", Integer.toString(ss3));
                        }

                    }

                }
                else if(gameMode.getMode() == 3){

                    int ss = Integer.parseInt(properties2.getProperty("MultiplayerWins3"));
                    if (ss==0){

                        ss=1;

                    }

                    int ss1 = score.getFoundCards();
                    int ss2 = score2.getFoundCards2();
                    int ss3 = score3.getFoundCards3();

                    if (ss1>ss2 && ss1>ss3) {

                        l3.setText("PLAYER 1 WIN");

                        if (ss1>ss) {
                            properties2.setProperty("MultiplayerWins3", Integer.toString(ss1));
                        }

                    }
                    if (ss2>ss1 && ss2>ss3) {

                        l3.setText("PLAYER 2 WIN");

                        if (ss2>ss) {
                            properties2.setProperty("MultiplayerWins3", Integer.toString(ss2));
                        }

                    }
                    if (ss3>ss1 && ss3>ss2) {

                        l3.setText("PLAYER 3 WIN");

                        if (ss3>ss) {

                            properties2.setProperty("MultiplayerWins3", Integer.toString(ss3));
                        }

                    }

                }
                else if(gameMode.getMode() == 4){

                    int ss = Integer.parseInt(properties2.getProperty("MultiplayerWins4"));
                    if (ss==0){

                        ss=1;

                    }

                    int ss1 = score.getFoundCards();
                    int ss2 = score2.getFoundCards2();
                    int ss3 = score3.getFoundCards3();

                    if (ss1>ss2 && ss1>ss3) {

                        l3.setText("PLAYER 1 WIN");

                        if (ss1>ss) {
                            properties2.setProperty("MultiplayerWins4", Integer.toString(ss1));
                        }

                    }
                    if (ss2>ss1 && ss2>ss3) {

                        l3.setText("PLAYER 2 WIN");

                        if (ss2>ss) {
                            properties2.setProperty("MultiplayerWins4", Integer.toString(ss2));
                        }

                    }
                    if (ss3>ss1 && ss3>ss2) {

                        l3.setText("PLAYER 3 WIN");

                        if (ss3>ss) {

                            properties2.setProperty("MultiplayerWins4", Integer.toString(ss3));
                        }

                    }

                }

            }
            else if (gameMode.getRivalsNumber()==3){

                if(gameMode.getMode() == 1){
                    int ss = Integer.parseInt(properties2.getProperty("MultiplayerWins1"));
                    if (ss==0){

                        ss=1;

                    }

                    int ss1 = score.getFoundCards();
                    int ss2 = score2.getFoundCards2();
                    int ss3 = score3.getFoundCards3();
                    int ss4 = score4.getFoundCards4();

                    if (ss1>ss2 && ss1>ss3 && ss1>ss4) {

                        l3.setText("PLAYER 1 WIN");

                        if (ss1>ss) {
                            properties2.setProperty("MultiplayerWins1", Integer.toString(ss1));
                        }

                    }
                    if (ss2>ss1 && ss2>ss3 && ss2>ss4) {

                        l3.setText("PLAYER 2 WIN");

                        if (ss2>ss) {
                            properties2.setProperty("MultiplayerWins1", Integer.toString(ss2));
                        }

                    }
                    if (ss3>ss1 && ss3>ss2 && ss3>ss4) {

                        l3.setText("PLAYER 3 WIN");

                        if (ss3>ss) {
                            properties2.setProperty("MultiplayerWins1", Integer.toString(ss3));
                        }

                    }
                    if (ss4>ss1 && ss4>ss2 && ss4>ss3) {

                        l3.setText("PLAYER 4 WIN");

                        if (ss3>ss) {
                            properties2.setProperty("MultiplayerWins1", Integer.toString(ss4));
                        }

                    }

                }
                else if(gameMode.getMode() == 2){

                    int ss = Integer.parseInt(properties2.getProperty("MultiplayerWins2"));
                    if (ss==0){

                        ss=1;

                    }

                    int ss1 = score.getFoundCards();
                    int ss2 = score2.getFoundCards2();
                    int ss3 = score3.getFoundCards3();
                    int ss4 = score4.getFoundCards4();

                    if (ss1>ss2 && ss1>ss3 && ss1>ss4) {

                        l3.setText("PLAYER 1 WIN");

                        if (ss1>ss) {
                            properties2.setProperty("MultiplayerWins2", Integer.toString(ss1));
                        }

                    }
                    if (ss2>ss1 && ss2>ss3 && ss2>ss4) {

                        l3.setText("PLAYER 2 WIN");

                        if (ss2>ss) {
                            properties2.setProperty("MultiplayerWins2", Integer.toString(ss2));
                        }

                    }
                    if (ss3>ss1 && ss3>ss2 && ss3>ss4) {

                        l3.setText("PLAYER 3 WIN");

                        if (ss3>ss) {
                            properties2.setProperty("MultiplayerWins2", Integer.toString(ss3));
                        }

                    }
                    if (ss4>ss1 && ss4>ss2 && ss4>ss3) {

                        l3.setText("PLAYER 4 WIN");

                        if (ss3>ss) {
                            properties2.setProperty("MultiplayerWins2", Integer.toString(ss4));
                        }

                    }

                }
                else if(gameMode.getMode() == 3){

                    int ss = Integer.parseInt(properties2.getProperty("MultiplayerWins3"));
                    if (ss==0){

                        ss=1;

                    }
                    
                    int ss1 = score.getFoundCards();
                    int ss2 = score2.getFoundCards2();
                    int ss3 = score3.getFoundCards3();
                    int ss4 = score4.getFoundCards4();

                    if (ss1>ss2 && ss1>ss3 && ss1>ss4) {

                        l3.setText("PLAYER 1 WIN");

                        if (ss1>ss) {
                            properties2.setProperty("MultiplayerWins3", Integer.toString(ss1));
                        }

                    }
                    if (ss2>ss1 && ss2>ss3 && ss2>ss4) {

                        l3.setText("PLAYER 2 WIN");

                        if (ss2>ss) {
                            properties2.setProperty("MultiplayerWins3", Integer.toString(ss2));
                        }

                    }
                    if (ss3>ss1 && ss3>ss2 && ss3>ss4) {

                        l3.setText("PLAYER 3 WIN");

                        if (ss3>ss) {
                            properties2.setProperty("MultiplayerWins3", Integer.toString(ss3));
                        }

                    }
                    if (ss4>ss1 && ss4>ss2 && ss4>ss3) {

                        l3.setText("PLAYER 4 WIN");

                        if (ss3>ss) {
                            properties2.setProperty("MultiplayerWins3", Integer.toString(ss4));
                        }

                    }

                }
                else if(gameMode.getMode() == 4){

                    int ss = Integer.parseInt(properties2.getProperty("MultiplayerWins4"));
                    if (ss==0){

                        ss=1;

                    }

                    int ss1 = score.getFoundCards();
                    int ss2 = score2.getFoundCards2();
                    int ss3 = score3.getFoundCards3();
                    int ss4 = score4.getFoundCards4();

                    if (ss1>ss2 && ss1>ss3 && ss1>ss4) {

                        l3.setText("PLAYER 1 WIN");

                        if (ss1>ss) {
                            properties2.setProperty("MultiplayerWins4", Integer.toString(ss1));
                        }

                    }
                    if (ss2>ss1 && ss2>ss3 && ss2>ss4) {

                        l3.setText("PLAYER 2 WIN");

                        if (ss2>ss) {
                            properties2.setProperty("MultiplayerWins4", Integer.toString(ss2));
                        }

                    }
                    if (ss3>ss1 && ss3>ss2 && ss3>ss4) {

                        l3.setText("PLAYER 3 WIN");

                        if (ss3>ss) {
                            properties2.setProperty("MultiplayerWins4", Integer.toString(ss3));
                        }

                    }
                    if (ss4>ss1 && ss4>ss2 && ss4>ss3) {

                        l3.setText("PLAYER 4 WIN");

                        if (ss3>ss) {
                            properties2.setProperty("MultiplayerWins4", Integer.toString(ss4));
                        }

                    }

                }

            }

            //here retry

            try {
                output = new FileOutputStream("score.properties");
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            try {
                properties2.store(output,null);
            } catch (IOException e) {
                e.printStackTrace();
            }

        }

        if (clicks == 0) {
            Timeline playAgain = new Timeline(new KeyFrame(Duration.seconds(1.5), event -> enableAll()));
            playAgain.play();
        }


    }

    private void findAnimation(ImageView imageView1,ImageView imageView2,Card card1,Card card2){
        ScaleTransition scaleTransition = new ScaleTransition(Duration.seconds(0.5),imageView1);
        scaleTransition.setFromX(1);
        scaleTransition.setToX(-1);
        scaleTransition.play();
        scaleTransition.setOnFinished(event -> {
            imageView1.setScaleX(1);
            imageView1.setImage(card1.getValue());
            imageView1.setDisable(true);
            imageView1.setOpacity(0.6);
        });

        ScaleTransition scaleTransition2 = new ScaleTransition(Duration.seconds(0.5),imageView2);
        scaleTransition2.setFromX(1);
        scaleTransition2.setToX(-1);
        scaleTransition2.play();
        scaleTransition2.setOnFinished(event -> {
            imageView2.setScaleX(1);
            imageView2.setImage(card2.getValue());
            imageView2.setDisable(true);
            imageView2.setOpacity(0.6);
        });
    }
    private void enable(ImageView imageView){
        super.enableAll();
        imageView.setDisable(true);
    }

    @Override
    public void backClicked() throws IOException {
        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        output = new FileOutputStream("config.properties");
        properties.setProperty("MenuSelected", "1");
        properties.store(output, null);

        Parent root = FXMLLoader.load(getClass().getResource("../../../resources/view/MultiplayerSettings.fxml"));
        Stage stage = (Stage) b2.getScene().getWindow();
        stage.getScene().setRoot(root);

    }
    @Override
    public void backClicked2() throws IOException {
        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        output = new FileOutputStream("config.properties");
        properties.setProperty("MenuSelected", "1");
        properties.store(output, null);

        Parent root = FXMLLoader.load(getClass().getResource("../../../resources/view/MultiplayerSettings.fxml"));
        Stage stage = (Stage) b11.getScene().getWindow();
        stage.getScene().setRoot(root);

    }
    @Override
    public void HomeClicked() throws IOException {
        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        output = new FileOutputStream("config.properties");
        properties.setProperty("MenuSelected", "1");
        properties.store(output, null);

        Parent root = FXMLLoader.load(getClass().getResource("../../../resources/view/MainMenu.fxml"));
        Stage stage = (Stage) b3.getScene().getWindow();
        stage.getScene().setRoot(root);

    }
    @Override
    public void HomeClicked2() throws IOException {
        mediaPlayer.seek(Duration.ZERO);
        mediaPlayer.play();
        output = new FileOutputStream("config.properties");
        properties.setProperty("MenuSelected", "1");
        properties.store(output, null);

        Parent root = FXMLLoader.load(getClass().getResource("../../../resources/view/MainMenu.fxml"));
        Stage stage = (Stage) b21.getScene().getWindow();
        stage.getScene().setRoot(root);

    }

}