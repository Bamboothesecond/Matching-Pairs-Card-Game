package main.javafx.model;

public class Score {
    private int moves;
    private int moves2;
    private int moves3;
    private int moves4;

    private int foundCards;
    private int foundCards2;
    private int foundCards3;
    private int foundCards4;

    public int getFoundCards() {
        return foundCards;
    }
    public int getFoundCards2() {
        return foundCards2;
    }
    public int getFoundCards3() {
        return foundCards3;
    }
    public int getFoundCards4() {
        return foundCards4;
    }

    public void setFoundCards(int foundCards) {
        this.foundCards = foundCards;
    }
    public void setFoundCards2(int foundCards2) {
        this.foundCards2 = foundCards2;
    }
    public void setFoundCards3(int foundCards3) {
        this.foundCards3 = foundCards3;
    }
    public void setFoundCards4(int foundCards4) {
        this.foundCards4 = foundCards4;
    }

    public int getMoves() {
        return moves;
    }
    public int getMoves2() {
        return moves2;
    }
    public int getMoves3() {
        return moves3;
    }
    public int getMoves4() {
        return moves4;
    }

    public void setMoves(int moves) {
        this.moves = moves;
    }
    public void setMoves2(int moves2) {
        this.moves2 = moves2;
    }
    public void setMoves3(int moves3) {
        this.moves3 = moves3;
    }
    public void setMoves4(int moves4) {
        this.moves4 = moves4;
    }

    public void updateMoves(){
        moves++;
    }
    public void updateMoves2(){
        moves2++;
    }
    public void updateMoves3(){
        moves3++;
    }
    public void updateMoves4(){
        moves4++;
    }

    public void updateFoundCards(){
        foundCards++;
    }
    public void updateFoundCards2(){
        foundCards2++;
    }
    public void updateFoundCards3(){
        foundCards3++;
    }
    public void updateFoundCards4(){
        foundCards4++;
    }
}
